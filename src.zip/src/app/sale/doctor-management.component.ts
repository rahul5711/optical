import { Component, OnInit } from '@angular/core';
import { AdminService } from '../services/admin.service';
import { CompanyService } from '../services/company.service';

import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';
@Component({
  selector: 'app-doctor-management',
  templateUrl: './doctor-management.component.html'
})
export class DoctorManagementComponent implements OnInit {
  dispalyAllFields = true;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  public id = parseInt(this.route.snapshot.paramMap.get('ID'), 10);
  permission = JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  editDoctorList = false;
  addDoctorList = false;
  deleteDoctorList = false;
  doctorList: any;
  data1: any = {
    ID: null, CompanyID: null, Name: '', DOB: '', Anniversary: '', Designation: '', Qualification: null, HospitalName: null, MobileNo1: null,
    MobileNo2: null, PhoneNo: null, Email: null, Address: null, Branch: null, Landmark: null, PhotoURL: null, DoctorType: null,
    DoctorLoyalty: null, LoyaltyPerPatient: null, LoginPermission: 0, LoginName: '', Password: '', Status: 1, CreatedBy: null,
    UpdatedBy: null, CreatedOn: null, UpdatedOn: null, CommissionType: 0, CommissionMode: 0, CommissionValue: 0, CommissionValueNB: 0
  };

  userShop: any = { ID: null, UserID: this.id, ShopID: null, RoleID: null, Status: 1, CreatedOn: null, CreatedBy: null };
  oldLoginName = "";

  userImage: any;
  usershopList: any;
  disableSuperAdminFields = false;
  toggleChecked = false;
  stringUrl: string;
  shopList: any;
  roleList: any;
  color: ThemePalette = 'primary';
  constructor(private adminService: AdminService,
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
    private compressImage: CompressImageService
  ) { }

  ngOnInit() {
    this.getDoctorList();
    this.permission.forEach(element => {
      if (element.ModuleName === 'DoctorList') {
        this.editDoctorList = element.Edit;
        this.addDoctorList = element.Add;
        this.deleteDoctorList = element.Delete;
      }
    });
    if (this.loggedInUser.UserGroup !== 'SuperAdmin') { this.disableSuperAdminFields = true; }

    if (this.id !== 0) {
      this.spinner.show();
      this.adminService.getDataByID(this.id, 'getDoctorByID', 'Doctor').subscribe(data => {
        this.data1 = data.result;
        this.data1.CommissionType = data.result.CommissionType.toString();
        this.data1.CommissionMode = data.result.CommissionMode.toString();

        this.oldLoginName =  this.data1.LoginName;
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'bottom',
          'right'
        );
        this.userImage = this.sanitize(this.data1.PhotoURL);
      }, (err) => {
        console.log(err);
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Data Not Loaded.',
          'bottom',
          'right'
        );
      });
    }
  }
  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
    } else { return null; }
  }
   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }
  getDoctorList() {
    this.companyService.getSupportMasterList('DoctorType').subscribe(data => {
      this.doctorList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'bottom',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'bottom',
        'right'
      );
    });
  }


 

  uploadImage(e) {
    let image: File = e.target.files[0]
    console.log(`Image size before compressed: ${image.size} bytes.`)
    this.compressImage.compress(image)
      .pipe(take(1)).subscribe(compressedImage => {
        console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
        const frmData = new FormData();
        frmData.append('file', compressedImage);
        this.adminService.uploadFile(frmData).subscribe(data => {
          this.data1.PhotoURL = data.fileName;
          this.userImage = this.sanitize(this.data1.PhotoURL);
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Image successfully Uploaded',
            'bottom',
            'right'
          );
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Image Not Uploaded.',
            'bottom',
            'right'
          );
        });
  })}

  checkforDuplicate(){
    if(this.oldLoginName != this.data1.LoginName){
      this.companyService.checkforDuplicate('Doctor', this.data1.LoginName).subscribe(res => {
       if(res.result === false){alert ("Login Name alredy Exist, Please Use Unique Name")}
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data.', 
          'bottom',
          'right'
        );
      });
    }
  }
  enterSubmit(event) {
    if (event.keyCode === 13) {
      alert("hii");
    }
    console.log(event.keyCode , 'event.keyCodeevent.keyCode');
    // if (event.keyCode === 17) {
    //   this.onSubmit();
    // }
  }

  onSubmit() {
    this.spinner.show();
    this.data1.CompanyID = this.loggedInCompany.ID;
    if(this.oldLoginName != this.data1.LoginName){
      this.companyService.checkforDuplicate('Doctor', this.data1.LoginName).subscribe(res => {
        this.spinner.hide();
       if(res.result === false){
         alert ("Login Name alredy Exist, Please Use Unique Name")
        } else {
          this.adminService.saveData('Doctor', this.data1).subscribe(data1 => {
            this.router.navigate(['/sale/doctor-list']);
            this.spinner.hide();
            this.showNotification(
              'bg-green',
              'Data Saved successfully',
              'bottom',
              'right'
            );
          }, (err) => {
            console.log(err);
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Data Not Saved.',
              'bottom',
              'right'
            );
          });
        }
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'bottom',
          'right'
        );
      });
    }  else {
      this.adminService.saveData('Doctor', this.data1).subscribe(data1 => {
        this.router.navigate(['/sale/doctor-list']);
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Saved successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Data Not Saved.',
          'top',
          'right'
        );
      });
    }
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
