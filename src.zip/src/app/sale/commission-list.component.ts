import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService} from '../services/company.service';
import {DomSanitizer} from '@angular/platform-browser';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from '../../environments/environment';
import * as moment from 'moment';


@Component({
  selector: 'app-commission-list',
  templateUrl: './commission-list.component.html',
  styleUrls: ['./commission-list.component.css']
})
export class CommissionListComponent implements OnInit {
  term:any;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  stringUrl: string;
  dataList: any[];
  currency = {Symbol: 'INR', Format: '1.2-2' };
  historyList= [];
  editPurchaseList = true;
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute
  ) { }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  public userType = this.route.snapshot.paramMap.get('userType');

  ngOnInit() {
    if(this.id !== 0){
      let whereList =  ' and CommissionMaster.UserType = '+  '"' +  this.userType + '"' +  ' and CommissionMaster.UserID = ' + this.id; 
    this.getData(whereList);
  }
  }

  getDatabyUserType(){
    let whereList = ' and CommissionMaster.UserType = ' +  '"' +this.userType + '"';
    this.getData(whereList);
  }

  getData(whereList){
    this.companyService.getCommissionList(whereList, this.userType).subscribe(data => {
      this.dataList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }

  paymentHistory(UserType, ID){
    this.spinner.show();
    this.companyService.geListByOtherID(UserType+'PaymentHistory' , ID).subscribe(data => {
      this.historyList = data.result;
      this.spinner.hide();
    
    }, (err) => { console.log(err);
                  this.spinner.hide();
                
    });
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
