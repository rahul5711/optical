import { Component, OnInit, ViewChild } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { AdminService } from '../services/admin.service';
import { User } from '../model/User';

import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSelect } from '@angular/material/select';
import * as moment from 'moment';
import { NgxSpinnerService } from "ngx-spinner";
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { summaryFileName } from '@angular/compiler/src/aot/util';
import { DateAdapter } from '@angular/material/core';

@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css']
})
export class BillingComponent implements OnInit {

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  selectedCustomer = {
    ID: null, Name: null, Sno: '', CompanyID: null, MobileNo1: "", MobileNo2: "", PhoneNo: "", Address: "", GSTNo: "", Email: "",
    PhotoURL: "", DOB: "", Anniversary: "", RefferedByDoc: "", ReferenceType: "", Category: "", Status: 1, CreatedBy: null,
    UpdatedBy: null, CreatedOn: null, UpdatedOn: null
  };
  Balance = 0;
  received = 0;
  showPower = false;
  shopMode = false;
  addPreOrderButton = false;
  showPreOderFeild = true;
  options = { WholeSale: false, Manual: false, PreOrder: false };
  payableAmount = 0;
  serviceOptions: any;
  pdfLink = '';
  BillLink = '';
  applyPayment = {
    ID: null, CustomerID: this.selectedCustomer.ID, CompanyID: this.selectedCustomer.CompanyID, ShopID: this.loggedInShop.ShopID,
    CreditType: 'Credit', PaymentDate: null, PayableAmount: null, PaidAmount: 0, CustomerCredit: 0, PaymentMode: null, CardNo: null,
    PaymentReferenceNo: null, Comments: null, Status: 1, CreatedBy: null, CreatedOn: null, UpdatedBy: null, UpdatedOn: null, pendingPaymentList: {},
    RewardPayment: 0, ApplyReward: false, ApplyReturn: false
  };

  rewardFilter = { ExpiryDate: '', CustomerID: null, Status: 'Credit' };
  showProductExpDate = false;
  customerList = [];
  searchBarCode: any;
  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  selectedBarCode: any;
  specList: any = [];
  prodList: any[];
  supplierList: any[];
  shopList: any[];
  item: any;
  item1: any;
  charge: any;
  chargeList = [];
  docList: any;
  service: any;
  category = 'Product';
  TrayList: any;

  disableAddButtons = false;
  TempProductStatus = false;
  tmpTotalamt = 0;
  tempItem = { Item: null, Spec: null };
  itemList = [];
  serviceList = [];
  data = { billMaster: null, Product: null, billDetail: null, service: null, EyeMeasurement: false };
  tempCustomerCredit;
  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  currency = { Symbol: 'INR', Format: '1.2-2' };
  selectedBillMaster: any = {
    ID: null, CustomerID: null, CustomerName: null, CompanyID: null, PurchaseDate: null, GSTNo: null, ShopID: null, ShopName: null,
    BillDate: null, DeliveryDate: null, PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0,
    DiscountAmount: 0, GSTAmount: 0, AddlDiscount: 0, TotalAmount: 0.00, DueAmount: 0.00, Invoice: null, Receipt: null, Doctor: 0, Employee: null, TrayNo: null, Sno: "", ProductStatus: 'Pending'
  };

  data1 = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };


  sampleBillItem: any = {
    ID: null, ProductName: null, ProductTypeName: null, ProductTypeID: null, UnitPrice: 0.00, HSNCode: null, Quantity: 0, SubTotal: 0.00,
    DiscountPercentage: 0, DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
    WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, Barcode: null, Manual: false, PreOrder: false, Status: 1,
    Option: null, Family: 'Self', MeasurementID: null, SupplierID: null, ProductExpDate: null
  };

  sampleitem: any = {
    ID: null, ProductName: null, ProductTypeName: null, ProductTypeID: null, UnitPrice: 0.00, HSNCode: null, Quantity: 0, SubTotal: 0.00,
    DiscountPercentage: 0, DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false,
    RetailPrice: 0.00, WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, Barcode: null, Manual: false,
    PreOrder: false, Status: 1, Option: null, Family: 'Self', MeasurementID: null, SupplierID: null, ProductExpDate: null

  };

  selectedPurchaseMaster: any = {
    ID: null, SupplierID: null, SupplierName: null, CompanyID: null, GSTNo: null, ShopID: null, ShopName: null, PurchaseDate: null,
    PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0, DiscountAmount: 0, GSTAmount: 0,
    TotalAmount: 0, preOrder: null, Manual: null,
  };


  sampleitem1: any = {
    ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00, Quantity: 0,
    SubTotal: 0.00, DiscountPercentage: 0, DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00,
    Multiple: false, RetailPrice: '', WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '', Status: 1
  };

  billItem: any;

  body = {
    customer: null, billMaster: null, billItemList: null, serviceList: null, paidList: null, unpaidList: null, loggedInShop: null,
    loggedInCompany: null, loggedInCompanySetting: null, loggedInUser: null
  };

  sampleService: any = {
    ID: null, PurchaseID: null, ServiceType: null, Name:'',CompanyID: null, Description: null, Price: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
    GSTType: 'None', TotalAmount: 0.00, Status: 1
  };
  barCodeList: any;
  billItemList:any = [];
  unpaidList = [{ InvoiceNo: 'No Pending Invoice', TotalAmount: 0.00, DueAmount: 0.00 }];
  paidList = [{ PaymentMode: 'No previous Payment', PaymentDate: null, Amount: 0.00 }];
  AddDiscountdisable = false;
  billdata = [];
  invoiceLink: any;
  disableApplyPaymentButton: boolean;
  familyList: any;
  WholeSalePrice = false;
  paymentModeList: any;
  dataList: any;
  PaymentModesList: any;
  employeeList: any;
  disableEE = false
  gstList: any;
  WholeSaleDis = false;

  constructor(private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute,
    private dateAdapter: DateAdapter<any>,
  ) { }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  public id2 = parseInt(this.route.snapshot.paramMap.get('id2'), 10);
  gstdividelist = [];
  sgst = 0;
  cgst = 0;
  ngOnInit() {
    this.spinner.show();
    this.dateAdapter.setLocale('hi-IN');
    this.getGstList();

    if (this.id === 0) {
      let todaydate = moment(new Date()).format('YYYY-MM-DD');
      let delDate = moment(new Date()).add(this.loggedInCompanySetting.DeliveryDay, 'days').format('YYYY-MM-DD');
      this.selectedBillMaster.BillDate = todaydate;
      this.selectedBillMaster.DeliveryDate = delDate;
      this.selectedBillMaster.Employee = this.loggedInUser.ID


    }
    // if (this.loggedInCompanySetting.WholeSalePrice === "true" && this.loggedInCompany.RetailPrice === 'true') {
    //   this.WholeSalePrice = true;
    //   this.WholeSaleDis = false
    // } else {
    //   this.WholeSalePrice = false;
    //   this.WholeSaleDis = true
    // }

    // if (this.loggedInCompany.WholeSale == 'true'  ) {
    //   // this.sampleBillItem.WholeSale = true;
    //   this.billItem.WholeSale = true;
    //   this.WholeSaleDis = true
    
    // } else {
    //   // this.sampleBillItem.WholeSale = false
    //   this.billItem.WholeSale = false
    //   this.WholeSaleDis = true

    // }
    
    // if (this.loggedInCompany.WholeSale == 'true' && this.loggedInCompany.RetailPrice == 'true') {
    //   // this.sampleBillItem.WholeSale = false;
    //   this.billItem.WholeSale = false;
    //   this.WholeSaleDis = false
    // }



    this.getEmployeeList();

    this.getDoctorList();
    this.getTrayList();
    this.myngOnInit();
    this.getPaymentModesList();
    // this.sendCusemail();
    // this.  getBillMasterList() ;
    // if (this.loggedInCompany.WholeSale === "true") {
    //   this.billItem.WholeSale = true;
    //   this.billItem.PreOrder = false;
    // this.billItem.Manual = false;
    // this.WholeSaleDis = false

    // } else {
    //   this.billItem.WholeSale = false;
    //   this.billItem.PreOrder = false;
    // this.billItem.Manual = false;
    // this.WholeSaleDis = true

    // }

    if (this.loggedInCompany.WholeSale === 'true') {
      this.sampleBillItem.WholeSale = true;
      this.billItem.WholeSale = true;
      this.WholeSaleDis = true
    } 
    if (this.loggedInCompany.WholeSale === 'false') {
      this.sampleBillItem.WholeSale = false;
      this.billItem.WholeSale = false;
      this.WholeSaleDis = true
    } 

    if (this.loggedInCompany.WholeSale === 'true' && this.loggedInCompany.RetailPrice === 'true') {
      this.sampleBillItem.WholeSale = false;
      this.billItem.WholeSale = false;
      this.WholeSaleDis = false
    }

    
    // else if (this.loggedInCompany.WholeSale === 'false') {
    //   this.billItem.WholeSale = false
    // }

    // if (this.loggedInCompany.RetailPrice === 'true') {
    //   this.billItem.WholeSale = false;
    //   this.WholeSaleDis = false

    // } 
  }


  // getBillMasterList() {
  //   this.spinner.show();
  //   let parem = {};
  //   this.companyService.getExtendedListByParam('BillMaster', parem).subscribe(data => {
  //     this.dataList = data.result;
  //     this.selectedBillMaster.Sno = this.dataList.length + 1;
  //     console.log(this.selectedBillMaster.Sno , 'this.selectedBillMaster.Sno');
  //     this.spinner.hide();

  //     this.showNotification(
  //       'bg-green',
  //       'Data Loaded successfully',
  //       'top',
  //       'right'
  //     );
  //   }, (err) => {
  //     this.spinner.hide();
  //     this.showNotification(
  //       'bg-red',
  //       'Data Not Loaded.',
  //       'top',
  //       'right'
  //     );
  //   });
  // }

  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => {
      this.PaymentModesList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getTrayList() {
    this.companyService.getSupportMasterList('TrayNo').subscribe(data => {
      this.TrayList = data.result;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getDoctorList() {
    this.companyService.getShortListByCompany('Doctor', 1).subscribe(data => {
      this.docList = data.result;
    }, (err) => {

    });
  }

  getEmployeeList() {
    this.companyService.getShortListByCompany('User', 1).subscribe(data => {
      this.employeeList = data.result;
    }, (err) => {
    });
  }



  myngOnInit() {

    if (this.id2 !== 0) {
      this.companyService.getShortDataByID('Customer', this.id2).subscribe(data => {
        this.selectedCustomer = data.result;
        this.getFamily();
        this.selectedBillMaster.CustomerID = this.selectedCustomer.ID;
        this.selectedBillMaster.CustomerName = this.selectedCustomer.Name;
        this.selectedBillMaster.CustomerSno = this.selectedCustomer.Sno;

        this.selectedBillMaster.CompanyID = this.selectedCustomer.CompanyID;
        this.selectedBillMaster.GSTNo = this.selectedCustomer.GSTNo;
        this.selectedBillMaster.PaymentStatus = 'unpaid';

      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
      this.companyService.getCredit(this.id2, 'Customer').subscribe(data => {
        this.applyPayment.CustomerCredit = data.result;
      });
      this.getReward(this.id2);
    }

    if (this.id !== 0) {
      this.getBillData(this.id);
      this.getPendingPayments(this.id2);
      this.getPreviousPayments(this.id);
      this.getEmployeeList();


    }

    this.getProductList();
    this.getPaymentModeList();

    this.getserviceOptions();
    // this.getSupplierList();
    this.getShopList();
    this.item = this.sampleitem;
    this.billItem = JSON.parse(JSON.stringify(this.sampleBillItem));
    this.service = this.sampleService;

  }



  sendSms(mode) {

    let temp = JSON.parse(this.loggedInCompanySetting.SmsSetting);
    let val = '';
    let CustomerName = this.selectedCustomer.Name;
    let phoneNo = this.selectedCustomer.MobileNo1;
    let CustomerOrder = this.selectedBillMaster.InvoiceNo;
    let ShopName = this.loggedInShop.Name;
    let ContactNo = this.loggedInShop.MobileNo1;
    let OrderPDFLink = this.selectedBillMaster.Invoice;
    let CustomerOrderNo = this.selectedBillMaster.InvoiceNo;
    let TotalAmount = this.selectedBillMaster.TotalAmount;
    let BalanceAmount = this.selectedBillMaster.DueAmount;
    
    let BillPDFLink = this.selectedBillMaster.Receipt;
    let CustomerCreditNote = this.pdfLink;
    let Website = this.loggedInCompany.Website;
    let senderID = this.loggedInCompanySetting.SenderID;
    let msgAPIKey = this.loggedInCompanySetting.MsgAPIKey;
    let message = '';
    let templateID = '';

    switch (mode) {
     
      case 'readyForDelivery':
        let Sms1 = temp[temp.findIndex(element => element.MessageName === 'Billing (Advance)')].MessageText;
        templateID = temp[temp.findIndex(element => element.MessageName === 'Billing (Advance)')].MessageID;
        message = eval('`' + Sms1 + '`');

        break;
      case 'FinalBill':
        let Sms2 = temp[temp.findIndex(element => element.MessageName === 'Billing (Finel Delivery)')].MessageText;
        templateID = temp[temp.findIndex(element => element.MessageName === 'Billing (Finel Delivery)')].MessageID;
        message = eval('`' + Sms2 + '`');
        break;
      case 'CustomerNote':
        message = temp[temp.findIndex(element => element.MessageName === 'CustomerBirthday')].MessageText;
        break;
    }

    console.log(message, phoneNo, templateID, 'msg');
    Swal.fire({
      title: 'Are you sure?',
      text: message,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Send it!'
    }).then((result) => {
      if (result.isConfirmed) {
        if(this.selectedCustomer.MobileNo1) {
          this.companyService.sendSms1(phoneNo, message, templateID , senderID, msgAPIKey).subscribe(data => {
            console.log(data,'datadatadata');
        // Swal.fire(
        //   'Send SMS',
        //   'Send SMS  success',
        //   'success'
        // )
      })}
       
      }
    })
  
  }

  getPaymentModeList() {
    this.companyService.getSupportMasterList('paymentModeType').subscribe(data => {
      this.paymentModeList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getFamily() {
    this.companyService.geListByOtherID('Family', this.id2).subscribe(data => {
      this.familyList = data.result;
    }, (err) => {
    });
  }

  getBillData(ID) {

    this.spinner.show();
    this.companyService.getBillData(ID).subscribe(data => {
      this.spinner.hide();
      this.selectedBillMaster = data.billMaster;
      // this.selectedBillMaster.BillDate = moment(this.selectedBillMaster.BillDate).format('MM/DD/YYYY');
      if (data.billMaster.AddlDiscount !== 0) {
        this.AddDiscountdisable = true;
      }
      console.log(this.selectedBillMaster, 'this.selectedBillMaster');
      this.billItemList = data.billDetail;
      this.serviceList = data.service;
console.log(this.serviceList);


      this.calculateGrandTotal();

      console.log(this.billItemList, 'this.billItemList');
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }


  getPreviousPayments(ID) {

    const parem = [{ BillMasterID: ID, op: "=" }];
    this.companyService.getExtendedListByParamNew('PaymentDetail', parem).subscribe(data => {
      this.paidList = data.result;

      if (this.paidList.length === 0) {
        this.paidList = [{ PaymentMode: 'No previous Payment', PaymentDate: null, Amount: 0.00 }];


      }

    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }


  getPendingPayments(ID) {
    const parem = [{ "BillMaster.CustomerID": ID, op: "=" }, { "BillMaster.PaymentStatus": "paid", op: "<>" }];
    this.spinner.show();
    this.companyService.getShortListByParamNew('BillMaster', parem).subscribe(data => {
      this.spinner.hide();
      this.unpaidList = data.result;
      this.Balance = this.unpaidList[0]?.TotalAmount;

      if (this.unpaidList.length === 0) {
        this.unpaidList = [{ InvoiceNo: 'No Pending Invoice', TotalAmount: 0.00, DueAmount: 0.00 }];

      }
      this.applyPayment.PayableAmount = this.unpaidList.reduce((a, b) => {

        return a + b.DueAmount;
      }, 0);
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  updateCurrection() {
    this.selectedBillMaster.ShopID = this.loggedInShop.ShopID;
    this.data.billMaster = this.selectedBillMaster;
    this.data.billDetail = this.billItemList;
    this.data.service = this.serviceList;

    this.data.billMaster.DueAmount = this.data.billMaster.DueAmount - Number(this.data.billMaster.AddlDiscount);
    
    
    this.companyService.updateCurrection('Billing', this.data).subscribe(data1 => {
      

      this.item = {
        ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
        Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
        DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
        WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '', Status: 1
      };
          
      this.id = this.data.billMaster.ID;

      this.myngOnInit();
      // this.selectedBillMaster.ID = data1.result;
      // this.getBillData(this.selectedBillMaster.ID);
      // this.getPendingPayments(this.selectedBillMaster.CustomerID);
      // this.getPreviousPayments(this.selectedBillMaster.ID);
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Saved Successfully',
        'top',
        'right'
      );
     

    }, (err) => {
      this.spinner.hide();
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }


  cancelBill() {
    this.spinner.show();

    // this.selectedBillMaster.DueAmount = this.selectedBillMaster.DueAmount - Number(this.selectedBillMaster.AddlDiscount);
    this.selectedBillMaster.ShopID = this.loggedInShop.ShopID;
    this.data.billMaster = this.selectedBillMaster;
    this.data.billDetail = this.billItemList;
    this.data.service = this.serviceList;

    this.data.billMaster.DueAmount = this.data.billMaster.DueAmount - Number(this.data.billMaster.AddlDiscount);
    
    

      
 
  
    
    this.companyService.updateBill('Billing', this.data).subscribe(data1 => {
      this.item = {
        ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
        Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
        DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
        WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '', Status: 1
      };

     
           
      // this.selectedBillMaster.ID = data1.result;
      // this.getBillData(this.selectedBillMaster.ID);
      // this.getPendingPayments(this.selectedBillMaster.CustomerID);
      // this.getPreviousPayments(this.selectedBillMaster.ID);
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Saved Successfully',
        'top',
        'right'
      );
      this.id = this.data.billMaster.ID;

      this.myngOnInit();
      if(this.loggedInCompany.WholeSale === 'true'){
        if (this.item.WholeSale === false || this.item.WholeSale === 'false') {
           this.billItem.WholeSale = true;
        } 
      }
    }, (err) => {
      this.spinner.hide();
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product', 1).subscribe(data => {
      this.prodList = data.result;
      console.log(this.prodList, "bb")

    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getserviceOptions() {
    this.companyService.getShortListByCompany('ServiceMaster', 1).subscribe(data => {
      this.serviceOptions = data.result;
      
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  setValues() {
    this.serviceOptions.forEach(element => {
      if (element.ID === this.service.ServiceType) {
       
        this.service.Name = element.Name 
        this.service.Price = element.Price;
        this.service.Cost = element.Cost;
        this.service.Description = element.Description;
        this.service.GSTAmount = element.GSTAmount;
        this.service.GSTPercentage = element.GSTPercentage;
        this.service.GSTType = element.GSTType;
        this.service.TotalAmount = element.TotalAmount;
      }
    });
  }

  calculateFields1(fieldName, mode) {

    switch (mode) {
      case 'subTotal':
        this.billItem.SubTotal = +this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount;
        break;
      case 'discount':
        if (fieldName === 'DiscountPercentage') {
          this.billItem.DiscountAmount = +this.billItem.SubTotal * +this.billItem.DiscountPercentage / 100;
          this.billItem.SubTotal =
            +this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount;
          if (!this.billItem.WholeSale) { this.billItem.TotalAmount = this.item.SubTotal; } else {
            this.billItem.TotalAmount = this.item.SubTotal + +this.billItem.GSTAmount;
          }
        }
        if (fieldName === 'DiscountAmount') {
          this.billItem.DiscountPercentage = 100 * +this.billItem.DiscountAmount / +this.billItem.SubTotal;
        }
        this.billItem.SubTotal =
          +this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount;
        if (!this.billItem.WholeSale) { this.billItem.TotalAmount = this.item.SubTotal; } else {
          this.billItem.TotalAmount = this.item.SubTotal + +this.billItem.GSTAmount;
        }
        break;
      case 'gst':
        if (fieldName === 'GSTPercentage') {
          this.billItem.GSTAmount =
            (+this.billItem.SubTotal - this.billItem.DiscountAmount) * +this.billItem.GSTPercentage / 100;
        }
        if (fieldName === 'GSTAmount') {
          this.billItem.GSTPercentage =
            100 * +this.billItem.GSTAmount / (+this.billItem.SubTotal - this.billItem.DiscountAmount);
        }
        break;
      case 'chgst':
        if (fieldName === 'GSTPercentage') {
          this.service.GSTAmount =
            +this.service.Price * +this.service.GSTPercentage / 100;
        }
        if (fieldName === 'GSTAmount') {
          this.service.GSTPercentage =
            100 * +this.service.GSTAmount / (+this.service.Price);
        }
        break;
      case 'total':
        this.billItem.TotalAmount = +this.billItem.SubTotal - +this.billItem.GSTAmount - +this.billItem.DiscountAmount;
        break;
      case 'chtotal':
        this.service.TotalAmount = +this.service.GSTAmount + +this.service.Price;
        break;
    }
  }


  calculateFields(fieldName, mode) {
    if (isNaN(Number(this.billItem.UnitPrice)) === true) {
      alert("please fill up integer value");
      this.billItem.UnitPrice = 0;
    }
    if (isNaN(Number(this.billItem.Quantity)) === true) {
      alert("please fill up integer value");
      this.billItem.Quantity = 0;
    }
    if (isNaN(Number(this.billItem.DiscountPercentage)) === true) {
      alert("please fill up integer value");
      this.billItem.DiscountPercentage = 0;
    }
    if (isNaN(Number(this.billItem.DiscountAmount)) === true) {
      alert("please fill up integer value");
      this.billItem.DiscountAmount = 0;
    }
    if (isNaN(Number(this.billItem.GSTPercentage)) === true) {
      alert("please fill up integer value");
      this.billItem.GSTPercentage = 0;
    } else {
      switch (mode) {

        case 'subTotal':
          if (this.billItem.Quantity === null || this.item.Quantity === '') {
            this.billItem.Quantity = 0;
          } else {
            this.billItem.GSTAmount = (+this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount) - ((+this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount) / (1 + +this.billItem.GSTPercentage / 100));
          }
          if (this.billItem.UnitPrice === null || this.billItem.UnitPrice === '') {
            this.billItem.UnitPrice = 0;
          }
          this.billItem.SubTotal = +this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount ;
          // this.item.SubTotal = +this.item.Quantity * +this.item.UnitPrice - this.item.DiscountAmount;
          break;
        case 'discount':

          if (fieldName === 'DiscountPercentage') {
            if (Number(this.billItem.DiscountPercentage) > 100) {
              alert("you can't give 100% above discount");
              this.billItem.DiscountPercentage = 0
            } else {
              this.billItem.DiscountAmount = +this.billItem.Quantity * +this.billItem.UnitPrice * +this.billItem.DiscountPercentage / 100;
            }
          }
          if (fieldName === 'DiscountAmount') {
            // if(Number(this.billItem.DiscountAmount) > this.billItem.SubTotal ){
            //   alert("you can't give SubTotal above discount");
            //   this.billItem.DiscountAmount = 0
            // }else{
            this.billItem.DiscountPercentage = 100 * +this.billItem.DiscountAmount / (+this.billItem.Quantity * +this.billItem.UnitPrice);

            // }
          }
          break;
        case 'gst':
          if (!this.billItem.WholeSale) {
            if (fieldName === 'GSTPercentage') {
              this.billItem.GSTAmount = (+this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount) - ((+this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount) / (1 + +this.billItem.GSTPercentage / 100));
            }
            if (fieldName === 'GSTAmount') {
              this.billItem.GSTPercentage = 100 * +this.billItem.GSTAmount / (+this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount);
            }
          } else {
            if (fieldName === 'GSTPercentage') {
              if (this.billItem.GSTPercentage === null || this.billItem.GSTPercentage === '' || (Number(this.billItem.GSTPercentage) > 100)) {
                alert("you can't give 100% above GST");
                this.billItem.GSTPercentage = 0;
              }
              else {
                this.billItem.GSTAmount = (+this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount) * +this.billItem.GSTPercentage / 100;
              }

            }
            if (fieldName === 'GSTAmount') {
              if (this.billItem.GSTAmount === null || this.billItem.GSTAmount === '') {

                this.billItem.GSTAmount = 0;
              } else {
                this.billItem.GSTPercentage = 100 * +this.billItem.GSTAmount / (+this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount);
              }

            }
          }
          break;

        case 'total':
          this.billItem.TotalAmount = +this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount;
          this.billItem.SubTotal = this.billItem.TotalAmount - +this.billItem.GSTAmount;
          break;
      }
      if (!this.billItem.WholeSale) {
        this.billItem.TotalAmount = +this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount;
        this.billItem.SubTotal = this.billItem.TotalAmount - +this.billItem.GSTAmount;

      } else {
        this.billItem.SubTotal = +this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount;
        this.billItem.TotalAmount = +this.billItem.SubTotal + +this.billItem.GSTAmount;
      }




      this.billItem.GSTAmount = this.convertToDecimal(+this.billItem.GSTAmount, 2);
      this.billItem.GSTPercentage = this.convertToDecimal(+this.billItem.GSTPercentage, 2);
      this.billItem.DiscountAmount = this.convertToDecimal(+this.billItem.DiscountAmount, 2);
      this.billItem.DiscountPercentage = this.convertToDecimal(+this.billItem.DiscountPercentage, 2);
      this.billItem.TotalAmount = this.convertToDecimal(+this.billItem.TotalAmount, 2);
      this.billItem.SubTotal = this.convertToDecimal(+this.billItem.SubTotal, 2);
      this.billItem.UnitPrice = this.convertToDecimal(+this.billItem.UnitPrice, 2);

      // this.billItem.GSTAmount = +this.billItem.GSTAmount.toFixed(2);
      // this.billItem.GSTPercentage = +this.billItem.GSTPercentage.toFixed(0);
      // this.billItem.DiscountAmount = this.convertToDecimal(+this.billItem.DiscountAmount, 2)
      // this.billItem.DiscountPercentage = +this.billItem.DiscountPercentage.toFixed(2);
      // this.billItem.TotalAmount = +this.billItem.TotalAmount.toFixed(2);
      // this.billItem.SubTotal = this.convertToDecimal(+ this.billItem.SubTotal, 2);;
    }
  }

  convertToDecimal(num, x) {
    return Number(Math.round(parseFloat(num + 'e' + x)) + 'e-' + x);
  }

  paymentHistory() {
    this.spinner.show();
    this.companyService.geListByOtherID('CustomerPaymentHistory', this.id).subscribe(data => {
      this.customerList = data.result;
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();

    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }



  addItem() {

    if (this.category === 'Services') {
      if (this.selectedBillMaster.ID !== null) { this.service.Status = 2; }
      this.serviceList.push(this.service);
      this.service = {
        ID: null, ServiceType: null, Name:'', CompanyID: null, Description: null, Price: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
        GSTType: 'None', TotalAmount: 0.00, Status: 1
      };
    }

    if (this.category === 'Product') {
      if (this.selectedProduct.toUpperCase() === "LENS" || this.selectedProduct.toUpperCase() === "CONTACT LENS" || this.selectedProduct.toUpperCase()) {
        let tableName = "";
        this.billItem.ProductTypeName = this.selectedProduct;
        if (this.selectedProduct.toUpperCase() === "LENS" || this.selectedProduct.toUpperCase()) {
          tableName = "spectacle_rx";
          if (this.billItem.PreOrder !== true) { this.billItem.SupplierID = -1; } else { this.billItem.SupplierID = 0; }
        } else { tableName = "contact_lens_rx"; }
        const parem = [{ CustomerID: this.selectedCustomer.ID, op: "=" }, { Family: this.billItem.Family, op: "=" }];
        this.companyService.getShortListByParamNewBill(tableName, parem).subscribe(data1 => {
          if (data1.result.length !== 0) {
            this.item.MeasurementID = JSON.stringify(data1.result[0]);
            this.billItem.MeasurementID = JSON.stringify(data1.result[0]);
            this.addProductItem();
            this.selectedBillMaster.Quantity = 0;
            this.selectedBillMaster.SubTotal = 0;
            this.selectedBillMaster.DiscountAmount = 0;
            this.selectedBillMaster.GSTAmount = 0;
            this.cgst = 0;
            this.sgst = 0;


            this.selectedBillMaster.TotalAmount = 0;
            this.calculateGrandTotal();
          } else {
            this.item.MeasurementID = 'null';
            this.billItem.MeasurementID = 'null';
            this.addProductItem();
            this.selectedBillMaster.Quantity = 0;
            this.selectedBillMaster.SubTotal = 0;
            this.selectedBillMaster.DiscountAmount = 0;
            this.selectedBillMaster.GSTAmount = 0;
            this.cgst = 0;
            this.sgst = 0;


            this.selectedBillMaster.TotalAmount = 0;
            this.calculateGrandTotal();
            // alert("Customer Eye Measurement is not recorded. Please add Measurement before Adding this item");
            // Swal.fire({
            //   icon: 'error',
            //   title: 'Oops...',
            //   text: 'No Data for Eye Measurement Available',
            //   footer: 'Customer Eye Measurement is not recorded. Please add Measurement before Adding this item'
            // });
          }

        });
      } else {
        this.addProductItem();
      }
    }
    this.selectedBillMaster.Quantity = 0;
    this.selectedBillMaster.SubTotal = 0;
    this.selectedBillMaster.DiscountAmount = 0;
    this.selectedBillMaster.GSTAmount = 0;


    this.selectedBillMaster.TotalAmount = 0;
    this.cgst = 0;
    this.sgst = 0;
    this.calculateGrandTotal();
    

    
  }

  addProductItem() {
    if (this.selectedBillMaster.ID !== null) { this.billItem.Status = 2; }
    //  let dupAlert = 0;
    //   this.billItemList.forEach(ele => {
    //     if(ele.ID === null && ele.ProductTypeName === this.billItem.ProductTypeName && ele.ProductName === this.billItem.ProductName) {
    //       alert("you can't add duplicate product, you will have to first delete and then increase quantity");
    //       dupAlert = 1;

    //     }
    //   })
    // if(dupAlert === 0) {
    // }
    if (!this.billItem.PreOrder && this.billItem.Quantity > this.item.BarCodeCount) {
      alert("Reqested Item Quantity not available. Please change the Quantity");
    } else {
      this.billItemList.unshift(this.billItem);
      if(this.billItem.WholeSale == false){
       this.billItem.WholeSale = false;
       this.sampleBillItem.WholeSale = false;
     }

      if(this.billItem.WholeSale == true ){
        this.billItem.WholeSale = true;
        this.sampleBillItem.WholeSale = true;
      } 
      this.billItem = JSON.parse(JSON.stringify(this.sampleBillItem));
      
      this.item = {
        
        ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
        Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
        DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
        WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '', Status: 1
      };
         
      // if(this.loggedInCompany.WholeSale === 'true'){
      //   if (this.item.WholeSale === false || this.item.WholeSale === 'false' ) {
      //      this.billItem.WholeSale = true;
      //   } 
      // }
      this.item.BarCodeCount = 0;
      this.selectedProduct = "";
      this.specList = [];
      this.showProductExpDate = false;

      // if(this.loggedInCompany.WholeSale === 'true'){
      //   this.billItem.WholeSale = true;
      // }else{
      //   this.billItem.WholeSale = false;
      // }




      this.barCodeList = [];
      this.searchBarCode = '';

    }
  }

  openURL(mode) {
    let url = "";
    if (mode === 'Invoice') {
      url = this.selectedBillMaster.Invoice;
    } else { url = this.selectedBillMaster.Receipt; }
    window.open(url, '_blank');
  }

  deleteItem(category: any, i:any) {
    if (category === "Product") {      
      if (this.billItemList[i].ID === null) {
        this.billItemList.splice(i, 1);
      } else {
        this.billItemList[i].Status = 0;
      }

    } else if (category === "Service") {
      if (this.serviceList[i].ID === null) {
        this.serviceList.splice(i, 1);
      } else {
        this.serviceList[i].Status = 0;
      }
    }
    // this.selectedBillMaster.Quantity = 0;
    // this.selectedBillMaster.SubTotal = 0;
    // this.selectedBillMaster.DiscountAmount = 0;
    // this.selectedBillMaster.GSTAmount = 0;
    // this.selectedBillMaster.TotalAmount = 0;
    // this.cgst = 0;
    // this.sgst = 0;

    this.calculateGrandTotal();
  }

  calculateGrandTotal() {
    // this.selectedBillMaster.Quantity = 0;
    // this.selectedBillMaster.SubTotal = 0;
    // this.selectedBillMaster.DiscountAmount = 0;
    // this.selectedBillMaster.GSTAmount = 0;
    // this.selectedBillMaster.TotalAmount = 0;
    this.selectedBillMaster.Quantity = 0;
    this.selectedBillMaster.SubTotal = 0;
    this.selectedBillMaster.DiscountAmount = 0;
    this.selectedBillMaster.GSTAmount = 0;
    this.selectedBillMaster.TotalAmount = 0;
    this.cgst = 0;
    this.sgst = 0;
    this.gstdividelist.forEach(ele => {
      ele.Amount = 0;
    })
    this.billItemList.forEach(element => {
      if (element.Status !== 0) {
        this.selectedBillMaster.Quantity = +this.selectedBillMaster.Quantity + +element.Quantity;
        this.selectedBillMaster.SubTotal = +this.selectedBillMaster.SubTotal + +element.SubTotal;
        this.selectedBillMaster.DiscountAmount = +this.selectedBillMaster.DiscountAmount + +element.DiscountAmount;
        this.selectedBillMaster.GSTAmount = +this.selectedBillMaster.GSTAmount + +element.GSTAmount;
        this.selectedBillMaster.TotalAmount = +this.selectedBillMaster.TotalAmount + +element.TotalAmount;
        this.selectedBillMaster.DueAmount = this.selectedBillMaster.TotalAmount;
      }
      this.gstdividelist.forEach(ele => {
        if (element.GSTType === ele.GstType && element.Status !== 0 && element.GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(element.GSTAmount);
        }
      })
      if (element.Status !== 0 && element.GSTType.toUpperCase() === 'CGST-SGST') {
        this.sgst += Number(element.GSTAmount) / 2;
        this.cgst += Number(element.GSTAmount) / 2;

      }
    });

    this.serviceList.forEach(element => {
      if (element.Status !== 0) {
        this.selectedBillMaster.SubTotal = +this.selectedBillMaster.SubTotal + +element.Price;
        this.selectedBillMaster.GSTAmount = +this.selectedBillMaster.GSTAmount + +element.GSTAmount;
        this.selectedBillMaster.TotalAmount = +this.selectedBillMaster.TotalAmount + +element.TotalAmount;
      }
      this.gstdividelist.forEach(ele => {
        if (element.GSTType === ele.GstType && element.Status !== 0 && element.GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(element.GSTAmount);
        }
      })
      if (element.Status !== 0 && element.GSTType.toUpperCase() === 'CGST-SGST') {

        this.sgst += Number(element.GSTAmount) / 2;
        this.cgst += Number(element.GSTAmount) / 2;

      }
    });

  }

  getSupplierDetails(event) {
    const index = this.supplierList.findIndex(element => element.Name === event.value);
    this.selectedBillMaster.SupplierID = this.supplierList[index].ID;
    this.selectedBillMaster.SupplierName = this.supplierList[index].Name;
    this.selectedBillMaster.GSTNo = this.supplierList[index].GSTNo;
  }

  getfieldList() {
    if (this.selectedProduct !== null || this.selectedProduct !== '') {
      this.prodList.forEach(element => {
        if (element.Name === this.selectedProduct) {
          this.item.ProductTypeID = element.ID;
          this.sampleitem.HSNCode = element.HSNCode;
          // this.item.HSNCode = element.HSNCode;
          this.sampleBillItem.HSNCode = element.HSNCode;
          this.billItem.HSNCode = element.HSNCode;
          this.billItem.ProductTypeID = element.ID;
          this.item.GSTPercentage = element.GSTPercentage;
          this.item.GSTType = element.GSTType;
          this.billItem.GSTPercentage = element.GSTPercentage;
          this.billItem.GSTType = element.GSTType;


        }
      });
      this.item.ProductTypeName = this.selectedProduct;
      this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
        this.specList = data.result;
        this.getSptTableData();
        if (this.specList.length !== 0) {
          this.specList.forEach(ele => {
            if (ele.FieldType !== "Date") {
              this.showProductExpDate = false;
            } else if (ele.FieldType === "Date") {
              this.showProductExpDate = true;

            }
          })
        } else {
          this.showProductExpDate = false;

        }

      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }
    });

  }

  displayAddField(i) {
    this.specList[i].DisplayAdd = 1;
  }

  saveFieldData(i) {
    this.specList[i].DisplayAdd = 0;
    let count = 0;
    this.specList[i].SptTableData.forEach(element => {
      if (element.TableValue.toLowerCase() === this.specList[i].SelectedValue.toLowerCase()) { count = count + 1; }

    });
    if (count !== 0 || this.specList[i].SelectedValue === '') { alert("Duplicate or Empty Values are not allowed"); } else {
      const Ref = this.specList[i].Ref;
      let RefValue = 0;
      if (Ref !== 0) {
        this.specList.forEach((element, j) => {
          if (element.FieldName === Ref) { RefValue = element.SelectedValue; }
        });
      }
      this.spinner.show();
      this.companyService.saveProductSupportData(this.specList[i].SelectedValue, RefValue, this.specList[i].SptTableName)
        .subscribe(data => {
          this.companyService.getProductSupportData(this.specList[i].SptTableName, RefValue).subscribe(data1 => {
            this.showNotification(
              'bg-green',
              'Data Saved Sucessfully',
              'top',
              'right'
            );
            this.specList[i].SptTableData = data1.result;
            this.specList[i].SptFilterData = data1.result;
            this.spinner.hide();
          }, (err) => {
            console.log(err);
            this.showNotification(
              'bg-red',
              'Error Loading Data',
              'top',
              'right'
            );
          });
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
    }

  }

  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 14) {
      this.addItem();
    }
    // if (event.keyCode === 17) {
    //   this.onSubmit();
    // }
  }



  CheckAvailableQuantity() {
    if (this.billItem.PreOrder) {
      alert("This item is being Pre-Ordered. Temporary Inventory will be created till the Item is delivered to Shop");
    }
    if (!this.billItem.PreOrder && this.billItem.Quantity > this.item.BarCodeCount) {
      alert("Reqested Item Quantity not available. Please change the Quantity");
      this.billItem.Quantity = 0;
    }
  }

  onSubmit() { }

  onSubmit1() {
    this.spinner.show();
    this.selectedBillMaster.BillDate = moment(this.selectedBillMaster.BillDate).format('YYYY-MM-DD');
    this.selectedBillMaster.DeliveryDate = moment(this.selectedBillMaster.DeliveryDate).format('YYYY-MM-DD');

    this.selectedBillMaster.ShopID = this.loggedInShop.ShopID;
    this.data.billMaster = this.selectedBillMaster;
    this.data.billDetail = this.billItemList;
    this.data.service = this.serviceList;

    this.companyService.saveBill('Billing', this.data).subscribe(data1 => {
      this.spinner.hide();
      this.selectedBillMaster.ID = data1.result;
      // this.generateBill('Invoice');
      this.id = data1.result;
      // this.getBillData(this.selectedBillMaster.ID);
      // this.getPendingPayments(this.selectedBillMaster.CustomerID);
      // this.getPreviousPayments(this.selectedBillMaster.ID);
      this.showNotification(
        'bg-green',
        'Data Saved Successfully',
        'top',
        'right'
      );
      // this.myngOnInit();

      this.router.navigate(['/sale/billing', this.id, this.id2]);
      if (this.id !== 0) {
        this.getBillData(this.id);
        this.getPendingPayments(this.id2);
        this.getPreviousPayments(this.id);
      }

    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  onPaymentSubmit() {
    this.spinner.show();
    this.disableApplyPaymentButton = true;

    this.applyPayment.CustomerID = this.selectedCustomer.ID;
    this.applyPayment.CompanyID = this.selectedCustomer.CompanyID;
    this.applyPayment.ShopID = this.loggedInShop.ShopID;
    this.applyPayment.pendingPaymentList = this.unpaidList;
    if (this.applyPayment.ApplyReward === true) {
      this.applyPayment.RewardPayment = Number(this.applyPayment.RewardPayment) * Number(this.loggedInCompanySetting.AppliedReward) / 100;
    }
    this.companyService.applyPayment('Payment', 'Customer', this.applyPayment).subscribe(data1 => {
      this.spinner.hide();
      this.applyPayment.ApplyReward = false;
      this.applyPayment.ApplyReturn = false;

      this.getReward(this.id2);
      this.applyPayment.PaidAmount = 0; this.applyPayment.PaymentMode = 0;
      this.getBillData(this.selectedBillMaster.ID);
      this.getPendingPayments(this.selectedBillMaster.CustomerID);
      this.getPreviousPayments(this.selectedBillMaster.ID);
      this.companyService.getCredit(this.id2, 'Customer').subscribe(data => {

        this.applyPayment.CustomerCredit = data.result;
      });
      this.disableApplyPaymentButton = false;
      this.showNotification(
        'bg-green',
        'Payment Applied Successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  setProductName() {
    // this.barCodeList.forEach(element => {
    //   if(element.Barcode == this.searchBarCode) {
    //     this.billItem.ProductName = element.ProductName;
    //   }
    // });
  }


  getProductDataByBarCodeNo() {
    if (this.searchBarCode !== '' && this.searchBarCode !== undefined) {
      this.companyService.getProductDataByBarCodeNo(this.searchBarCode, this.billItem.PreOrder, false).subscribe(data1 => {
        this.item = data1.result;
        if (this.item.Barcode === null) { alert("Incorrect Barcode OR Product not available in this Shop"); }
        else if (this.item.BarCodeCount === 0) { alert("Item not available in Inventoty. You can Pre-Order"); }
        this.billItem.ProductName = "";
        this.barCodeList.forEach(element => {
          if (element.Barcode === this.searchBarCode) {
            this.billItem.ProductName = element.ProductName;


          }
          // this.xferItem.ProductName = this.xferItem.ProductName + "/" + element.SelectedValue;
        });
        this.prodList.forEach(element => {
          if (element.Name === this.selectedProduct) {
            this.billItem.ProductTypeName = element.Name;
            this.billItem.GSTPercentage = element.GSTPercentage;
            this.billItem.GSTType = element.GSTType;
          }
        })
        if (this.showProductExpDate === true) {
          this.billItem.ProductExpDate = this.billItem.ProductName.split("/")[1];
        }
        this.billItem.ProductName = this.billItem.ProductName.toUpperCase();
        this.billItem.Barcode = this.item.Barcode;
        this.billItem.HSNCode = this.sampleBillItem.HSNCode;

        //  check temp count
        if (this.item.Barcode !== null && this.item.BarCodeCount !== 0) {
          if (this.billItemList.length !== 0 && this.billItem.ProductName !== "") {
            let itemCount = 0;
            this.billItemList.forEach(element => {
              if (element.ProductName === this.billItem.ProductName && element.ID === null) {
                itemCount = itemCount + element.Quantity;
              }
            })
            this.item.BarCodeCount = this.item.BarCodeCount - itemCount;
          }
        }

        if (this.billItem.WholeSale === true) {
          this.billItem.UnitPrice = this.item.WholeSalePrice;
        } else if (this.billItem.PreOrder === true) {
          this.billItem.UnitPrice = this.item.RetailPrice;

        } else {
          this.billItem.UnitPrice = this.item.RetailPrice;
        }
        // this.billItem.GSTPercentage = this.item.GSTPercentage;
        // this.billItem.GSTPercentage = 0;

        this.billItem.GSTAmount = 0;
        if (this.billItem.Option === 'Full Glass') {
          this.billItem.Quantity = 2;
        } else {
          this.billItem.Quantity = 0;

        }
        this.billItem.Quantity = 0;

        this.billItem.TotalAmount = this.billItem.UnitPrice * this.billItem.Quantity;
        this.billItem.SubTotal = this.billItem.UnitPrice * this.billItem.Quantity;
        // if (this.billItemList.length !== 0) {
        //   this.billItem.GSTType = this.billItemList[0].GSTType;
        // } else {
        //   this.billItem.GSTType = "None";
        // }
        if (this.billItem.PreOrder === true) {

          this.data1 = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

        }

      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    }
  }

  getProductDataByBarCodeNo1() {
    this.loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
    if (this.loggedInShop && this.loggedInShop.ShopID !== null ) {
      
      if(this.billItem.Manual === false){
        this.spinner.show(); 

      this.companyService.getProductDataByBarCodeNo(this.searchBarCode, this.billItem.PreOrder, this.shopMode).subscribe(data1 => {
        this.item = data1.result;
        console.log(  this.item );
        
        console.log(this.item, "kkk")
        this.spinner.hide();
        if (this.item.Barcode === null ) {
          // alert("Product Not Available in this Shop for Selected Barcode for Transfer.\n Please Check the Barcode.");
          Swal.fire({
            icon: 'error',
            title: 'Product Not Available in this Shop for Selected Barcode for Transfer.',
            text: ' Please Check the Barcode. ',
            footer: ''
          });
        }
        this.selectedProduct = this.item.ProductTypeName;
        this.billItem.ProductName = "";
        this.billItem.ProductName = this.item.ProductName.toUpperCase();

        // this.xferItem.ProductName = this.item.ProductName;
        this.billItem.Barcode = this.item.Barcode;
        this.billItem.BarCodeCount = this.item.BarCodeCount;
        this.billItem.TransferCount = 0;
        this.billItem.TransferToShop = null;
        this.billItem.TransferFromShop = this.loggedInShop.ShopID;
        this.billItem.TransferStatus = "";
        // this.billItem.GSTPercentage = 0;
        this.billItem.Quantity = 0;
        this.billItem.UnitPrice = this.item.UnitPrice;
        if (this.billItem.WholeSale === true) {
          this.billItem.UnitPrice = this.item.WholeSalePrice;
        } else {
          this.billItem.UnitPrice = this.item.RetailPrice;
        }
        if (this.item.Barcode !== null && this.item.BarCodeCount !== 0) {
          if (this.billItemList.length !== 0 && this.billItem.ProductName !== "") {
            let itemCount = 0;
            this.billItemList.forEach(element => {
              if (element.ProductName === this.billItem.ProductName && element.ID === null) {
                itemCount = itemCount + element.Quantity;
              }
            })
            this.item.BarCodeCount = this.item.BarCodeCount - itemCount;
          }
        }

        this.prodList.forEach(e => {
          if (e.ID === this.item.ProductTypeID) {
            this.billItem.HSNCode = e.HSNCode;
            this.billItem.GSTPercentage = e.GSTPercentage;
            this.billItem.GSTType = e.GSTType;

          }
        })

        // if (this.billItemList.length !== 0) {
        //   this.billItem.GSTType = this.billItemList[0].GSTType;
        // } else {
        //   this.billItem.GSTType = "None";
        // }
        
        // this.selectedProduct = this.item.Spec[0].ProductName;
        // this.billItem.ProductName = "";
        this.spinner.hide();

      }, (err) => {
        this.spinner.hide();

        console.log(err);
      });
    }
    else{
      Swal.fire({
        icon: 'error',
        title: 'Product Not Available in this Shop.',
        text: ' ',
        footer: ''
      });
    }
  }
    else {
      // alert("Please Select the Shop from Which To Tranfer Products.");
      Swal.fire({
        icon: 'error',
        title: 'Please Select the Shop from Which To Tranfer Products.',
        text: ' ',
        footer: ''
      });
    }
  }



  getBarCodeList(index) {
    let searchString = "";
  let don = "/";
    // this.specList.forEach((element, i) => {
    //   if (i <= index) {
    //     searchString = searchString + "/" + element.SelectedValue;
    //   }
    // });


    this.specList.forEach((element, i) => {
      if (element.SelectedValue !== '') {
        searchString = searchString + don + element.SelectedValue;
      }else{
        searchString = searchString  + element.SelectedValue;
      }
    });
    // this.billItem.ProductName = searchString;

    // searchString = searchString.splice(1);
    if (this.billItem.PreOrder) {

      this.companyService.getPreOrderBarCodeList(searchString.substring(1), this.selectedProduct).subscribe(data => {
        this.barCodeList = data.result;


        if (this.barCodeList.length === 0 && this.billItem.PreOrder === true) {
          // this.addPreOrderButton = true;
          this.showPreOderFeild = false;
        } else if (this.barCodeList.length !== 0 && this.billItem.PreOrder === true) {
          this.showPreOderFeild = true;
        }
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    } else if (this.billItem.Manual) {
      this.showPreOderFeild = false;
    } else {
      this.companyService.getBarCodeList(searchString.substring(1), this.selectedProduct, this.shopMode).subscribe(data => {
        this.barCodeList = data.result;
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    }
  }

  setSelectedProductName(i) {
    this.selectedProduct = this.barCodeList[i].ProductName;
  }

  showNotification(colorName, text, placementFrom, placementAlign) {

    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'

    });
  }

  generateBill(mode) {
    this.spinner.show();

    this.body.customer = this.selectedCustomer;
    this.body.billMaster = this.selectedBillMaster;
    this.body.billItemList = this.billItemList;
    this.body.serviceList = this.serviceList;
    this.body.paidList = this.paidList;
    this.body.unpaidList = this.unpaidList;
    this.body.loggedInShop = this.loggedInShop;
    this.body.loggedInCompany = this.loggedInCompany;
    this.body.loggedInCompanySetting = this.loggedInCompanySetting;
    this.body.loggedInUser = this.loggedInUser;
    this.body.billMaster.showPower = this.showPower;
    this.companyService.generateBill(mode, this.body).subscribe(data => {
      this.spinner.hide();

      if (mode === "Invoice") {
        this.selectedBillMaster.Invoice = data.result;
        const url = this.selectedBillMaster.Invoice;
        this.BillLink = url;
        window.open(url, "_blank");
        console.log( this.BillLink,' this.BillLink');
        

      } else if (mode === "Receipt") {
        this.selectedBillMaster.Receipt = data.result;
        const url = this.selectedBillMaster.Receipt;
        this.BillLink = url;
        window.open(url, "_blank");
        console.log( this.BillLink,' this.BillLink');
      }
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  calculateFields11(fieldName, mode) {
    if (isNaN(Number(this.item.UnitPrice)) === true) {
      alert("please fill up integer value");
      this.item.UnitPrice = 0;
    }
    if (isNaN(Number(this.item.Quantity)) === true) {
      alert("please fill up integer value");
      this.item.Quantity = 0;
    }
    if (isNaN(Number(this.item.DiscountPercentage)) === true) {
      alert("please fill up integer value");
      this.item.DiscountPercentage = 0;
    }
    if (isNaN(Number(this.item.DiscountAmount)) === true) {
      alert("please fill up integer value");
      this.item.DiscountAmount = 0;
    }
    if (isNaN(Number(this.item.GSTPercentage)) === true) {
      alert("please fill up integer value");
      this.item.GSTPercentage = 0;
    } else {

      switch (mode) {
        case 'subTotal':
          if (this.item.Quantity === null || this.item.Quantity === '') {
            this.item.Quantity = 0;
          } else {
            this.item.GSTAmount = (+this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount) -
              ((+this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount) / (1 + +this.item.GSTPercentage / 100));
          }
          if (this.item.UnitPrice === null || this.item.UnitPrice === '') {
            this.item.UnitPrice = 0;
          }
          this.item.SubTotal = +this.item.Quantity * +this.item.UnitPrice - this.item.DiscountAmount;
          break;
        case 'discount':


          if (fieldName === 'DiscountPercentage') {
            if (this.item.DiscountPercentage === null || this.item.DiscountPercentage === '' || (Number(this.item.DiscountPercentage) > 100)) {
              alert("you can't give 100% above discount");
              this.item.DiscountPercentage = 0;
            } else {
              this.item.DiscountAmount = (+this.item.Quantity * +this.item.UnitPrice ) * +this.item.DiscountPercentage / 100;

            }
          }
          if (fieldName === 'DiscountAmount') {
            if (this.item.DiscountAmount === null || this.item.DiscountAmount === '') {
              // alert("you can't give SubTotal above discount");
              this.item.DiscountAmount = 0;
            }
            else {
              this.item.DiscountPercentage = 100 * +this.item.DiscountAmount /  (+this.item.Quantity * +this.item.UnitPrice );
             
            }
          }
          break;
        case 'gst':
          // if (fieldName === 'GSTPercentage') {
          //   if (this.item.GSTPercentage === null || this.item.GSTPercentage === '' || (Number(this.item.GSTPercentage) > 100 )){
          //     alert("you can't give 100% above GST");
          //     this.item.GSTPercentage = 0;
          //   }
          //  else{
          //   this.item.GSTAmount = (+this.item.Quantity * +this.item.UnitPrice - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
          //  } 
          // }
          // if (fieldName === 'GSTAmount') {
          //   if (this.item.GSTAmount === null || this.item.GSTAmount === '' ){
          //     this.item.GSTAmount = 0;
          //   }else{
          //     this.item.GSTPercentage =
          //     100 * +this.item.GSTAmount / (+this.item.Quantity * +this.item.UnitPrice - this.item.DiscountAmount);
          //   }
          // }
          if (!this.billItem.WholeSale) {
            if (fieldName === 'GSTPercentage') {
              this.item.GSTAmount = (+this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount) - ((+this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount) / (1 + +this.item.GSTPercentage / 100));
            }
            if (fieldName === 'GSTAmount') {
              this.item.GSTPercentage = 100 * +this.item.GSTAmount / (+this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount);
            }
          } else {
            if (fieldName === 'GSTPercentage') {
              if (this.item.GSTPercentage === null || this.item.GSTPercentage === '' || (Number(this.item.GSTPercentage) > 100)) {
                alert("you can't give 100% above GST");
                this.item.GSTPercentage = 0;
              }
              else {
                this.item.GSTAmount = (+this.item.Quantity * +this.item.UnitPrice - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
              }
            }
            if (fieldName === 'GSTAmount') {
              if (this.item.GSTAmount === null || this.item.GSTAmount === '') {
                this.item.GSTAmount = 0;
              } else {
                this.item.GSTPercentage = 100 * +this.item.GSTAmount / (+this.item.Quantity * +this.item.UnitPrice - this.item.DiscountAmount);
              }
            }
          }
          break;


        case 'chgst':
          if (fieldName === 'GSTPercentage') {
            this.charge.GSTAmount =
              +this.charge.Amount * +this.charge.GSTPercentage / 100;
          }
          if (fieldName === 'GSTAmount') {
            this.charge.GSTPercentage =
              100 * +this.charge.GSTAmount / (+this.charge.Amount);
          }
          break;

        case 'total':
          this.item.TotalAmount = +this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount;
          this.item.SubTotal = this.item.TotalAmount - +this.item.GSTAmount;
          break;
      }
    }


    if (!this.billItem.WholeSale) {
      this.item.TotalAmount = +this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount;
      this.item.SubTotal = this.item.TotalAmount - +this.item.GSTAmount;

    } else {
      this.item.SubTotal = +this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount;
      this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount;
    }



    this.item.GSTAmount = this.convertToDecimal(+this.item.GSTAmount, 2);
    this.item.GSTPercentage = this.convertToDecimal(+this.item.GSTPercentage, 2);
    this.item.DiscountAmount = this.convertToDecimal(+this.item.DiscountAmount, 2);
    this.item.DiscountPercentage = this.convertToDecimal(+this.item.DiscountPercentage, 2);
    this.item.TotalAmount = this.convertToDecimal(+this.item.TotalAmount, 2);
    this.item.SubTotal = this.convertToDecimal(+this.item.SubTotal, 2);

    // this.item.GSTAmount = +this.item.GSTAmount.toFixed(2);
    // this.item.GSTPercentage = +this.item.GSTPercentage.toFixed(2);
    // this.item.DiscountAmount =this.convertToDecimal(+this.item.DiscountAmount, 2);
    // this.item.DiscountPercentage = this.convertToDecimal(+this.item.DiscountPercentage, 2);
    // this.item.TotalAmount = +this.item.TotalAmount.toFixed(2);
    // this.item.SubTotal = this.convertToDecimal(+this.item.SubTotal, 2);

  }

  manualProduct() {
    if (this.category === 'Product') {
      this.spinner.show();
      if (this.selectedPurchaseMaster.ID !== null) { this.item.Status = 2; }
      this.item.ProductName = "";
      this.specList.forEach(element => {
        this.item.ProductName = this.item.ProductName + element.SelectedValue + "/"  ;
      });
      this.item.ProductName = this.item.ProductName.substring(0, this.item.ProductName.length - 1);

      this.item.Spec = this.specList;
      this.item.Manual = true;
      this.item.Status = 2;
      this.itemList.unshift(this.item);
      this.calculateGrandTotal1();

      this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
      if (this.billItem.Manual === true) {
        this.selectedPurchaseMaster.Manual = true;
      }

      // let tableName = "";
      // this.billItem.ProductTypeName = this.selectedProduct;
      // if (this.selectedProduct.toUpperCase() === "LENS") {
      //   tableName = "spectacle_rx";
      //   if (this.billItem.PreOrder !== true) { this.billItem.SupplierID = -1; } else { this.billItem.SupplierID = 0; }
      // } else { tableName = "contact_lens_rx"; }

      // const parem = [{ CustomerID: this.selectedCustomer.ID, op: "=" }, { Family: this.billItem.Family, op: "=" }];
      // this.companyService.getShortListByParamNew(tableName, parem).subscribe(data1 => {

      // });

      this.itemList.forEach(e => {
        let tableName = "";
        if (e.ProductTypeName.toUpperCase() === "LENS" || e.ProductTypeName.toUpperCase() === "CONTACT LENS" || e.ProductTypeName.toUpperCase()) {
          if (e.ProductTypeName.toUpperCase() === "LENS" || e.ProductTypeName.toUpperCase()) {
            tableName = "spectacle_rx";
          } else {
            tableName = "contact_lens_rx";
          }
          const parem = [{ CustomerID: this.selectedCustomer.ID, op: "=" }, { Family: e.Family, op: "=" }];
        this.companyService.getShortListByParamNewBill(tableName, parem).subscribe(data1 => {
          e.MeasurementID = JSON.stringify(data1.result[0])
        });
        } else {
          e.MeasurementID = null
        }
        



      })

      this.data1.PurchaseMaster = this.selectedPurchaseMaster;
      this.data1.PurchaseDetail = JSON.stringify(this.itemList);



      this.data1.Charge = this.chargeList;
      this.data1.PurchaseMaster.page = 'bill';



      this.companyService.savePurchase('Purchase', this.data1).subscribe(data1 => {
        this.item.Barcode = 'ManualProduct';
        this.billItemList.push(this.item);
        console.log(this.billItemList, "manularrrr")
        this.billItemList.forEach(el => {
          if (el.ID === null && el.Manual === true) {
            this.prodList.forEach(e => {
              if (el.ProductTypeName === e.Name) {
                el.HSNCode = e.HSNCode;
              }
            })
          }
        })
        // this.selectedBillMaster = this.item;
        this.calculateGrandTotal();
        this.itemList = [];
        this.tempItem = { Item: null, Spec: null };
        this.item = {
          ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
          Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
          DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Warranty: '', Remark: '', Multiple: false, RetailPrice: 0.00,
          WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '', Status: 1
        };
       
        this.specList = [];
        this.selectedProduct = "";
        this.billItem.Manual = true;


        this.item.HSNCode = ""
        this.data1 = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

        this.spinner.hide();
        this.showPreOderFeild = true;
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        this.spinner.hide();
      });

    }


  }


  addPreOrderItem(v) {
    this.addItem1();
  }

  addItem1() {
    // this.tempItem.Item = this.item;
    // this.tempItem.Spec = this.specList;
    if (this.category === 'Product') {
      if (this.selectedPurchaseMaster.ID !== null) { this.item.Status = 2; }
      this.item.ProductName = "";
      this.specList.forEach(element => {
        this.item.ProductName = this.item.ProductName + element.SelectedValue + "/";

      });
      this.item.ProductName = this.item.ProductName.substring(0, this.item.ProductName.length - 1);
      this.companyService.getExistingProduct(this.item).subscribe(data => {
        const x = data.result;
        if (x.length > 0 && x[0].CompanyID !== null) {
          this.item.BaseBarCode = x[0].BaseBarCode;
          this.item.NewBarcode = x[0].MaxBarcode;
          // alert('This product with the same Retail Price was added previously. Existing Barcode series will be used');
          Swal.fire({
            icon: 'error',
            title: 'This product with the same Retail Price was added previously. Existing Barcode series will be used',
            text: ' ',
            footer: ''
          });
        }
        this.item.RetailPrice = Number(this.item.UnitPrice)
        this.item.Spec = this.specList;
        this.itemList.push(this.item);
        // this.billItem = JSON.parse(JSON.stringify(this.sampleBillItem));

        this.calculateGrandTotal1();
        this.tempItem = { Item: null, Spec: null };
        this.item = {
          ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
          Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
          DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
          WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '', Status: 1
        };

        this.onSubmit11();

        this.selectedProduct = "";
        this.specList = [];
        this.showProductExpDate = false;
        this.billItem.WholeSale = true;


      }, (err) => {
        console.log(err);
      });
    }

    if (this.category === 'Charges') {
      if (this.selectedPurchaseMaster.ID !== null) { this.charge.Status = 2; }
      this.chargeList.push(this.charge);
      this.calculateGrandTotal();
      this.charge = {
        ID: null, ChargeType: null, CompanyID: null, Description: '', Amount: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
        GSTType: 'None', TotalAmount: 0.00, Status: 1
      };
    }


  }

  calculateGrandTotal1() {
    this.selectedPurchaseMaster.Quantity = 0;
    this.selectedPurchaseMaster.SubTotal = 0;
    this.selectedPurchaseMaster.DiscountAmount = 0;
    this.selectedPurchaseMaster.GSTAmount = 0;
    this.selectedPurchaseMaster.TotalAmount = 0;

    this.itemList.forEach(element => {
      if (element.Status !== 0) {
        this.selectedPurchaseMaster.Quantity = +this.selectedPurchaseMaster.Quantity + +element.Quantity;
        this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.SubTotal;
        this.selectedPurchaseMaster.DiscountAmount = +this.selectedPurchaseMaster.DiscountAmount + +element.DiscountAmount;
        this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
        this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
    });

    this.chargeList.forEach(element => {
      if (element.Status !== 0) {
        this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.Amount;
        this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
        this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
    });


  }

  onSubmit11() {
    this.spinner.show();

    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    if (this.billItem.PreOrder === true) {
      this.selectedPurchaseMaster.preOrder = true;
    } else if (this.billItem.Manual === true) {
      this.selectedPurchaseMaster.Manual = true;
    }
    this.data1.PurchaseMaster = this.selectedPurchaseMaster;
    this.data1.PurchaseDetail = JSON.stringify(this.itemList);

    this.data1.Charge = this.chargeList;
    this.data1.PurchaseMaster.page = 'bill';

    this.companyService.savePurchase('Purchase', this.data1).subscribe(data1 => {
      
      // this.router.navigate(['/inventory/purchaselist']);
      this.selectedProduct = JSON.parse(this.data1.PurchaseDetail)[this.itemList.length - 1].ProductTypeName;
      this.specList = JSON.parse(this.data1.PurchaseDetail)[this.itemList.length - 1].Spec;
      let searchString = "";

      this.specList.forEach((element, i) => {
        searchString = searchString + "/" + element.SelectedValue;
      });

      this.item.UnitPrice = 0;
      this.companyService.getPreOrderBarCodeList(searchString.substring(1), this.selectedProduct).subscribe(data => {
        this.barCodeList = data.result;
        console.log(this.barCodeList, 'this.barCodeListthis.barCodeList');
        this.searchBarCode = this.barCodeList[0].Barcode;
        this.specList = [];
        this.getProductDataByBarCodeNo();
        this.spinner.hide();

      }, (err) => {
        console.log(err);
      });
      // this.getFieldSupportData(0);
      // this.getfieldList();
      this.spinner.hide();
      this.showPreOderFeild = true;
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
    });
  }


  generateOrderForm(data) {
    this.spinner.show();

    let data1 = { body: data, customer: this.selectedCustomer, Shop: this.loggedInShop, Company: this.loggedInCompanySetting, billList :this.billItemList }
    this.companyService.generateOrderForm('generateOrderForm', data1).subscribe(data => {
      this.spinner.hide();
      const url = this.env.apiUrl + data;
      console.log(data);
      window.open(url, "_blank");
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  customerNote() {
    this.spinner.show();
    let CustomerNoteTemp = [];
    //  get credit not for paid list 
    const parem = [{ BillMasterID: this.id, op: "=" }];
    this.companyService.getExtendedListByParamNew('PaymentDetail', parem).subscribe(data => {
      console.log(data.result, 'CustomerNoteTemp');

      data.result.forEach(ele => {
        if (ele.PaymentMode === 'Customer Return' && ele.Credit === 'Credit') {
          CustomerNoteTemp.push(ele);
        }
      });
      let data1 = { applyPayment: this.applyPayment, customerID: this.id2, customerDetail: this.selectedCustomer, billItemList: this.billItemList, Shop: this.loggedInShop, paidList: CustomerNoteTemp, Company: this.loggedInCompanySetting }
      if (CustomerNoteTemp.length !== 0) {
        this.companyService.customerNote('customerNote', data1).subscribe(data => {
          this.spinner.hide();
          const url = data;
          this.pdfLink = url;
          console.log(data);
          window.open(url, "_blank");
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }

    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
    //  end

    // tempPaid.forEach(ele => {
    //   if (ele.PaymentMode === 'Customer Return') {
    //     CustomerNoteTemp.push(ele);
    //   }
    // });
    // let total = null;
    //    total = this.companyService.getCredit(this.id2, 'Customer').subscribe(data => {
    //       this.applyPayment.CustomerCredit = data.result;
    //     });

  }
  sendCreditwh(mode, e) {

    let temp = JSON.parse(this.loggedInCompanySetting.WhatsappSetting);
    if (mode === 'credit') {
      let Smsw = ''
      if(temp !== '' && temp !== null && temp !== 'null'){
        Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Credit Note')].MessageText1;
      }else{
        Smsw = ''
      }
      
      let Smsw1 = ''
      if(Smsw !==  ''){
       Smsw1 = Smsw
      }else{
       Smsw1 = 'Save Your Credit note copy.'
      }
      var msg = `Hi ${this.selectedCustomer.Name},%0A` +
      `${Smsw1}%0A`+
        `Save your Credit note link: ${this.pdfLink}%0A` +
        `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0A${this.loggedInShop.Website}`;
      var mob = "91" + this.selectedCustomer.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank","link")
      setTimeout(function () { window.close();}, 3000,"link");
    }
    
    else {
   
      let Smsw = ''
      if(temp !== '' && temp !== null && temp !== 'null'){
        Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Bill FinalDelivery')].MessageText1;
      }else{
        Smsw = ''
      }
      
      let Smsw1 = ''
      if(Smsw !==  ''){
       Smsw1 = Smsw
      }else{
       Smsw1 = 'Thanks you for being our valued customer. We are so grateful for the pleasure of serving you and hope we met your expectations. Please Visit Again.'
      }
      var msg = `Hi ${this.selectedCustomer.Name},%0A` +
      `${Smsw1}%0A`+
        `Open Bill : ${this.BillLink}%0A`+
        `${this.loggedInShop.Name}${this.loggedInShop.AreaName}%0A`+
        `${this.loggedInShop.MobileNo1}%0A`+
        `${this.loggedInShop.Website}%0A`+
        `Type Hii And Download Your Bill`;
      var mob = "91" + this.selectedCustomer.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
      console.log(msg, "msgmsgmsgmsg")
      
    }

  }

  
  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => {
      this.gstList = data.result;
      this.gstdividelist = [];
      data.result.forEach(ele => {
        if (ele.Name.toUpperCase() !== 'CGST-SGST') {
          let obj = { GstType: '', Amount: 0 };
          obj.GstType = ele.Name;
          this.gstdividelist.push(obj);

        }
      })
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getReward(id2) {
    let whereList = '';
    let date = new Date();
    let expirydate = moment(date).format('YYYY-MM-DD');
    this.rewardFilter.ExpiryDate = expirydate;
    if (this.rewardFilter.ExpiryDate !== '' && this.rewardFilter.ExpiryDate !== null) {
      let date = new Date();
      let date1 = moment(date).format('YYYY-MM-DD')
      whereList = whereList + ' and ExpiryDate > ' + `'${this.rewardFilter.ExpiryDate}'`;
    }
    if (this.rewardFilter.Status !== '') {
      whereList = whereList + ' and Status = ' + `'${this.rewardFilter.Status}'`;
    }
    this.rewardFilter.CustomerID = this.id2;
    if (this.rewardFilter.CustomerID !== null) {
      whereList = whereList + ' and CustomerID = ' + `'${this.rewardFilter.CustomerID}'`;
    }
    this.companyService.getGenericListByParem('filterReward', whereList).subscribe(data => {
      console.log(data.result[0].RewardPayment, 'whereListwhereListwhereListwhereListwhereList');
      this.applyPayment.RewardPayment = data.result[0].RewardPayment;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  selectAllProductStatus() {
    if (this.TempProductStatus === false) {
      this.billItemList.forEach(ele => {
        ele.ProductStatus = true;
      })
    } else if (this.TempProductStatus === true) {
      this.billItemList.forEach(ele => {
        ele.ProductStatus = false;
      })
    }
  }

  singleSelectP(i) {
    if (this.billItemList[i].ProductStatus === true) {
      this.billItemList[i].ProductStatus = false;

    } else if (this.billItemList[i].ProductStatus === false) {
      this.billItemList[i].ProductStatus = true;

    }
  }


  sendCusemail() {
    // this.companyService.saveBill(this.dataCust.CompanyID, 'Billing').subscribe(data => {
    // this.adminService.sendEmail(data.result, 'customerbill').subscribe(data2 => {
    //   this.showNotification(
    //     'bg-red',
    //     'Mail Send.',
    //     'top',
    //     'right'
    //   ); 
    // }, (err) => { console.log(err);

    // });
    // }, (err) => { console.log(err);            
    // });
    let temp = { Name: this.selectedCustomer.Name, Email: this.selectedCustomer.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1, ShopWebsite: this.loggedInShop.Website, Billlink: this.BillLink };
    console.log(temp);
    this.adminService.sendEmail(temp, 'customerbill').subscribe(data2 => {
      this.showNotification(
        'bg-red',
        'Mail Send.',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);

    });
  }


  sendCreditemail() {
    let temp = { Name: this.selectedCustomer.Name, Email: this.selectedCustomer.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1, Pdflink: this.pdfLink };
    console.log(temp);
    this.adminService.sendEmail(temp, 'customerCreditnote').subscribe(data2 => {
      this.showNotification(
        'bg-red',
        'Mail Send.',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);

    });
  }

  updateProductStatus() {
    this.spinner.show();
    this.companyService.updateProductStatus(this.id, this.billItemList).subscribe(data => {
      this.router.navigate(['/sale/billing', this.id, this.id2]);
      // this.ngOnInit();
      this.getBillData(this.id);


      this.spinner.hide();

    }, (err) => {
      console.log(err);
    });



  }

  lenQty() {
    // if(this.billItem.PreOrder !== true) {
    this.billItem.Quantity = 1;
    if (this.billItem.Option === 'Full Glass') {
      this.billItem.Quantity = this.billItem.Quantity * 2;
    } else if (this.billItem.Quantity !== 1) {
      this.billItem.Quantity = 1;
    }
    this.calculateFields('Quantity', 'subTotal');
    // }
  }

  AddSetsDiscount() {
    // if(this.tmpTotalamt === 0 && this.selectedBillMaster.TotalAmount > Number(this.selectedBillMaster.AddlDiscount)  ){
    //   this.tmpTotalamt = this.selectedBillMaster.DueAmount;
    //   this.selectedBillMaster.DueAmount = this.selectedBillMaster.DueAmount - Number(this.selectedBillMaster.AddlDiscount)
    // }else if(this.selectedBillMaster.TotalAmount > Number(this.selectedBillMaster.AddlDiscount)){
    //   this.selectedBillMaster.DueAmount = this.tmpTotalamt - Number(this.selectedBillMaster.AddlDiscount)
    // }else if ( Number(this.selectedBillMaster.AddlDiscount) < this.selectedBillMaster.TotalAmount  ) {
    //   this.selectedBillMaster.AddlDiscount = 0; 
    //   this.selectedBillMaster.DueAmount = this.selectedBillMaster.TotalAmount;
    //   this.tmpTotalamt  = 0;
    //   alert("You Due ")
    // }
    let TotalAmount = this.selectedBillMaster.TotalAmount;
    let AddlDiscount = Number(this.selectedBillMaster.AddlDiscount);
    let DueAmount = this.selectedBillMaster.DueAmount;

    if (TotalAmount < AddlDiscount) {
      alert("You Can't Give More Amt");
      this.selectedBillMaster.AddlDiscount = 0;
    } else if (TotalAmount > AddlDiscount) {
      this.selectedBillMaster.DueAmount = this.selectedBillMaster.TotalAmount - this.selectedBillMaster.AddlDiscount;
    } else if (TotalAmount == AddlDiscount) {
      this.selectedBillMaster.DueAmount = this.selectedBillMaster.TotalAmount - this.selectedBillMaster.AddlDiscount;

    }
  }


  setPo() {
    console.log(this.billItem.PreOrder);
    if (this.billItem.PreOrder === false) {
      this.billItem.Po = 1
    } else {
      this.billItem.Po = 1
    }
    
  }

  extrapay(mode){
    if(mode === 'extrapay'){
      if(this.applyPayment.PaidAmount > this.applyPayment.PayableAmount){

        Swal.fire({
          title: 'Alert',
          text: "You Are Peying More Than The Customer Amount!",
          icon: 'warning',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'OK!'
        })
      }
    }

  }

}

