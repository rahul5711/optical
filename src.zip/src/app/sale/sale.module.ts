import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { SaleRoutingModule } from './sale-routing.module';
import { CustomerComponent } from './customer.component';
import { CustomerListComponent } from './customer-list.component';
import { BillingComponent } from './billing.component';
import { BillingListComponent } from './billing-list.component';
import {MatRadioModule} from '@angular/material/radio';
import {MatListModule} from '@angular/material/list';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { ProductItemFilterBill} from './../filter/prodItemFilterBill';
import { DoctorManagementComponent } from './doctor-management.component';
import { CashRegisterComponent } from './cash-register.component';
import { CommissionComponent } from './commission.component';
import { CommissionInvoiceComponent } from './commission-invoice.component';
import { CommissionListComponent } from './commission-list.component';
import { DoctorListComponent } from './doctor-list.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NameFilterCustomer} from './../filter/nameFilterCustomer';
import {WebcamModule} from 'ngx-webcam';
import { AutoFoucsDirectivesDirective } from './auto-foucs-directives.directive';
// import { NgxPaginationModule } from 'ngx-pagination';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [ CustomerComponent, CustomerListComponent, BillingComponent, BillingListComponent,NameFilterCustomer, 
    ProductItemFilterBill,
    DoctorManagementComponent, CashRegisterComponent,CommissionComponent,CommissionListComponent,CommissionInvoiceComponent,
    DoctorListComponent,AutoFoucsDirectivesDirective ],
  imports: [
    NgbModule,
  
    WebcamModule,
    CommonModule,
    SaleRoutingModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSortModule,
    MatToolbarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatTabsModule,
    MaterialFileInputModule,
    NgxSpinnerModule,
    PerfectScrollbarModule,
    MatRadioModule,
    MatListModule,
    NgxMatSelectSearchModule,
    Ng2SearchPipeModule,
  ],
})
export class SaleModule { }
