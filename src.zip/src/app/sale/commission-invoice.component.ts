
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import 'rxjs/add/observable/fromPromise';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { DateAdapter } from '@angular/material/core';
import * as moment from 'moment';

@Component({
  selector: 'app-commission-invoice',
  templateUrl: './commission-invoice.component.html'
})
export class CommissionInvoiceComponent implements OnInit {

  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  selectedProduct: any;
  specList: any = []; 
  fitterList: any[];
  shopList: any[];
  item: any;
  category = 'Product';
  disableAddButtons = true;

  itemList = [];
  

  selectedCommissioneMaster: any = {
    ID: null, UserID: null, UserName: null, UserType: null,  CompanyID: null, GSTNo: null,  InvoiceNo: null, PaymentStatus: null, PurchaseDate: null, 
    Quantity: null, ShopID: null, ShopName: null,AreaName:null, TotalAmount: null, Status: 1, CreatedBy: null, CreatedByEmp: null, CreatedOn: null, DueAmount: null
  };

  commissionList: any[];


  constructor(private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private changeDectectorRef: ChangeDetectorRef,
    private dateAdapter: DateAdapter<any>

    // private toastrService: ToastrService,
  ) {
  }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  public userType = this.route.snapshot.paramMap.get('userType');
  ngOnInit() {
    this.dateAdapter.setLocale('hi-IN');
    if (this.id !== 0) {
      // this.spinner.show();
      this.companyService.getCommissionInvoiceFullDataByID(this.id, this.userType).subscribe(data => {
        this.selectedCommissioneMaster = data.result.CommissionMaster;
        this.selectedCommissioneMaster.PurchaseDate = moment(data.result.CommissionMaster.PurchaseDate).format('YYYY-MM-DD');
        console.log(data.result.CommissionMaster , 'data.result.CommissionMaster');
        this.itemList = data.result.CommissionDetail;
        // this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        // this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }

  }


  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}

