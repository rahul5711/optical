import { Component, OnInit} from '@angular/core';
import { CompanyService } from '../services/company.service';
import { AdminService } from '../services/admin.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import {WebcamImage} from './../modules/webcam/domain/webcam-image';
import {WebcamUtil} from './../modules/webcam/util/webcam.util';
import {WebcamInitError} from './../modules/webcam/domain/webcam-init-error';
import {Observable, Subject} from 'rxjs';
import * as moment from 'moment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { User} from '../model/User';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  dispalyAllFields = true;
  dispalyExtraFields= false;
  showUpload = false;
  Exdata = 'spectacle';
   // toggle webcam on/off
   public showWebcam = true;
   public allowCameraSwitch = true;
   public multipleWebcamsAvailable = false;
   public deviceId: string;
   public videoOptions: MediaTrackConstraints = {

   };
   spesave = false;
   cutmbox = false;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission= JSON.parse(localStorage.getItem('Permission'));
 editCustomerList = false;
  addCustomerList = false;
  deleteCustomerList = false;
  searchList = [];
  customerList: any;
  agrfield: boolean;
  OtherList: any;
  constructor(private companyService: CompanyService,
              private adminService: AdminService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private spinner: NgxSpinnerService,
              private route: ActivatedRoute,
              private snackBar: MatSnackBar,
              private compressImage: CompressImageService

  ) { }

  fileName: any;
  stringUrl1: any;
  public errors: WebcamInitError[] = [];

    // latest snapshot
    public webcamImage: WebcamImage = null;
    private trigger: Subject<void> = new Subject<void>();

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  TotalCustomer = 0;
  data1: any = {
    ID: null, Idd:0, Sno:"", TotalCustomer:"",VisitDate:"", Name: null, CompanyID: null, MobileNo1: "", MobileNo2: "", PhoneNo: "", Address: "", GSTNo: "", Email: "",
    PhotoURL: "", DOB: "", Age:"", Anniversary: "", RefferedByDoc: "", ReferenceType: "",Gender: "", Category: "", Other:"", Remarks:"", Status: 1, CreatedBy: null,
    UpdatedBy: null, CreatedOn: null, UpdatedOn: null
  };

  docList: any;
  temp: any;
  temp1:any;
  tempCYL:any;
  tempSPH :any;
  tempVA:any;
  tempCYL1:any;
  tempSPH1:any;
  tempVA1:any;
  tempCYL2:any;
  tempSPH2:any;
  tempVA3:any;
  tempSPH4:any;
  tempCYL5 :any;

  spectacle: any = {
    ID: null, CustomerID: this.id, REDPSPH: '', Reminder: '6', REDPCYL: '', REDPAxis: '', REDPVA: '', LEDPSPH: '', LEDPCYL: '', LEDPAxis: '',
    LEDPVA: '', RENPSPH: '', RENPCYL: '', RENPAxis: '', RENPVA: '', LENPSPH: '', LENPCYL: '', LENPAxis: '', LENPVA: '', REPD: '', LEPD: '',
    R_Addition: '', L_Addition: '', R_Prism: '', L_Prism: '', Lens: '', Shade: '', Frame: '', VertexDistance: '', RefractiveIndex: '',
    FittingHeight: '', ConstantUse: false, NearWork: false, RefferedByDoc: 'Self', DistanceWork: false, UploadBy: 'Upload', PhotoURL: '', FileURL: '', Family: 'Self',
    ExpiryDate: null
  };

  clens: any = {
    ID: null, CustomerID: this.id, REDPSPH: '', REDPCYL: '', REDPAxis: '', REDPVA: '', LEDPSPH: '', LEDPCYL: '', LEDPAxis: '',
    LEDPVA: '', RENPSPH: '', RENPCYL: '', RENPAxis: '', RENPVA: '', LENPSPH: '', LENPCYL: '', LENPAxis: '', LENPVA: '', REPD: '', LEPD: '',
    R_Addition: '', L_Addition: '', R_KR: '', L_KR: '', R_HVID: '', L_HVID: '', R_CS: '', L_CS: '', R_BC: '', L_BC: '',
    R_Diameter: '', L_Diameter: '', BR: '', Material: '', Modality: '', RefferedByDoc: 'Self', Other: '', ConstantUse: false,
    NearWork: false, DistanceWork: false, Multifocal: false, PhotoURL: '', FileURL: '', Family: 'Self'
  };

  other: any = {
    ID: null, CustomerID: this.id, BP: '', Sugar: '', IOL_Power: '', RefferedByDoc: 'Self', Operation: '', R_VN: '', L_VN: '', R_TN: '', L_TN: '',
    R_KR: '', L_KR: '', Treatment: '', Diagnosis: '', Family: 'Self'
  };

  familyList: any;
  newFamily = { ID: null, CompanyID: this.loggedInCompany.ID, CustomerID: this.id, Name: "" };
  printData: any = { customer: null, loggedInShop: null, loggedInCompany: null, loggedInCompanySetting: null };
  showAdd = false;
  customerImage: any;
  spectLink = '';
  contLink = '';
  otherLink = '';
  spectacleImage: any;
  clensImage: any;
  showDoctorAdd = false;
  newDoctor: any = {
    ID: null, CompanyID: null,  Name: '', Designation: '', Qualification: null, HospitalName: null, MobileNo1: null,
    MobileNo2: null, PhoneNo: null, Email: null, Address: null, Branch: null, Landmark: null, PhotoURL: null, DoctorType: null,
    DoctorLoyalty: null, LoyaltyPerPatient: null, LoginPermission: 0,
    LoginName: '', Password: '', Status: 1, CreatedBy: null, UpdatedBy: null, CreatedOn: null, UpdatedOn: null
  };
  disableSuperAdminFields = false;
  toggleChecked = false;
  stringUrl: string;
  color: ThemePalette = 'primary';
  dpsphList: any;
  dpcylList: any;
  dpvaList: any;
  npvaList: any;
  CustomerEyeTesting : '';
  spectacleList :any =  [];
  contactLensList: any;
  otherRxList: any;
  ReferenceList:any;
  GenderList:any;

  MaxAmount = 0;
  CustomerCategory = [];
  categoryType: any;
  srcBox = true;
  param = {Name: '', MobileNo1: '' , Sno:''};


  dataSPH: any = [
    { Name: '+25.00'},
    { Name: '+24.75'},
    { Name: '+24.50'},
    { Name: '+24.25'},
    { Name: '+24.00'},
    { Name: '+23.75'},
    { Name: '+23.50'},
    { Name: '+23.25'},
    { Name: '+23.00'},
    { Name: '+22.75'},
    { Name: '+22.50'},
    { Name: '+22.25'},
    { Name: '+22.00'},
    { Name: '+21.75'},
    { Name: '+21.50'},
    { Name: '+21.25'},
    { Name: '+21.00'},
    { Name: '+20.75'},
    { Name: '+20.50'},
    { Name: '+20.25'},
    { Name: '+20.00'},
    { Name: '+19.75'},
    { Name: '+19.50'},
    { Name: '+19.25'},
    { Name: '+19.00'},
    { Name: '+18.75'},
    { Name: '+18.50'},
    { Name: '+18.25'},
    { Name: '+18.00'},
    { Name: '+17.75'},
    { Name: '+17.50'},
    { Name: '+17.25'},
    { Name: '+17.00'},
    { Name: '+16.75'},
    { Name: '+16.50'},
    { Name: '+16.25'},
    { Name: '+16.00'},
    { Name: '+15.75'},
    { Name: '+15.50'},
    { Name: '+15.25'},
    { Name: '+15.00'},
    { Name: '+14.75'},
    { Name: '+14.50'},
    { Name: '+14.25'},
    { Name: '+14.00'},
    { Name: '+13.75'},
    { Name: '+13.50'},
    { Name: '+13.25'},
    { Name: '+13.00'},
    { Name: '+12.75'},
    { Name: '+12.50'},
    { Name: '+12.25'},
    { Name: '+12.00'},
    { Name: '+11.75'},
    { Name: '+11.50'},
    { Name: '+11.25'},
    { Name: '+11.00'},
    { Name: '+10.75'},
    { Name: '+10.50'},
    { Name: '+10.25'},
    { Name: '+10.00'},
    { Name: '+9.75'},
    { Name: '+9.50'},
    { Name: '+9.25'},
    { Name: '+9.00'},
    { Name: '+8.75'},
    { Name: '+8.50'},
    { Name: '+8.25'},
    { Name: '+8.00'},
    { Name: '+7.75'},
    { Name: '+7.50'},
    { Name: '+7.25'},
    { Name: '+7.00'},
    { Name: '+6.75'},
    { Name: '+6.50'},
    { Name: '+6.25'},
    { Name: '+6.00'},
    { Name: '+5.75'},
    { Name: '+5.50'},
    { Name: '+5.25'},
    { Name: '+5.00'},
    { Name: '+4.75'},
    { Name: '+4.50'},
    { Name: '+4.25'},
    { Name: '+4.00'},
    { Name: '+3.75'},
    { Name: '+3.50'},
    { Name: '+3.25'},
    { Name: '+3.00'},
    { Name: '+2.75'},
    { Name: '+2.50'},
    { Name: '+2.25'},
    { Name: '+2.00'},
    { Name: '+1.75'},
    { Name: '+1.50'},
    { Name: '+1.25'},
    { Name: '+1.00'},
    { Name: '+0.75'},
    { Name: '+0.50'},
    { Name: '+0.25'},
    { Name: 'PLANO'},
    { Name: '-0.25'},
    { Name: '-0.50'},
    { Name: '-0.75'},
    { Name: '-1.00'},
    { Name: '-1.25'},
    { Name: '-1.50'},
    { Name: '-1.75'},
    { Name: '-2.00'},
    { Name: '-2.25'},
    { Name: '-2.50'},
    { Name: '-2.75'},
    { Name: '-3.00'},
    { Name: '-3.25'},
    { Name: '-3.50'},
    { Name: '-3.75'},
    { Name: '-4.00'},
    { Name: '-4.25'},
    { Name: '-4.50'},
    { Name: '-4.75'},
    { Name: '-5.00'},
    { Name: '-5.25'},
    { Name: '-5.50'},
    { Name: '-5.75'},
    { Name: '-6.00'},
    { Name: '-6.25'},
    { Name: '-6.50'},
    { Name: '-6.75'},
    { Name: '-7.00'},
    { Name: '-7.25'},
    { Name: '-7.50'},
    { Name: '-7.75'},
    { Name: '-8.00'},
    { Name: '-8.25'},
    { Name: '-8.50'},
    { Name: '-8.75'},
    { Name: '-9.00'},
    { Name: '-9.25'},
    { Name: '-9.50'},
    { Name: '-9.75'},
    { Name: '-10.00'},
    { Name: '-10.25'},
    { Name: '-10.50'},
    { Name: '-10.75'},
    { Name: '-11.00'},
    { Name: '-11.25'},
    { Name: '-11.50'},
    { Name: '-11.75'},
    { Name: '-12.00'},
    { Name: '-12.25'},
    { Name: '-12.50'},
    { Name: '-12.75'},
    { Name: '-13.00'},
    { Name: '-13.25'},
    { Name: '-13.50'},
    { Name: '-13.75'},
    { Name: '-14.00'},
    { Name: '-14.25'},
    { Name: '-14.50'},
    { Name: '-14.75'},
    { Name: '-15.00'},
    { Name: '-15.25'},
    { Name: '-15.50'},
    { Name: '-15.75'},
    { Name: '-16.00'},
    { Name: '-16.25'},
    { Name: '-16.50'},
    { Name: '-16.75'},
    { Name: '-17.00'},
    { Name: '-17.25'},
    { Name: '-17.50'},
    { Name: '-17.75'},
    { Name: '-18.00'},
    { Name: '-18.25'},
    { Name: '-18.50'},
    { Name: '-18.75'},
    { Name: '-19.00'},
    { Name: '-19.25'},
    { Name: '-19.50'},
    { Name: '-19.75'},
    { Name: '-20.00'},
    { Name: '-20.25'},
    { Name: '-20.50'},
    { Name: '-20.75'},
    { Name: '-21.00'},
    { Name: '-21.25'},
    { Name: '-21.50'},
    { Name: '-21.75'},
    { Name: '-22.00'},
    { Name: '-22.25'},
    { Name: '-22.50'},
    { Name: '-22.75'},
    { Name: '-23.00'},
    { Name: '-23.25'},
    { Name: '-23.50'},
    { Name: '-23.75'},
    { Name: '-24.00'},
    { Name: '-24.25'},
    { Name: '-24.50'},
    { Name: '-24.75'},
    { Name: '-25.00'},
    
    

  ];

  dataCYL: any = [
    { Name: '-10.00'},
    { Name: '-9.75'},
    { Name: '-9.50'},
    { Name: '-9.25'},
    { Name: '-9.00'},
    { Name: '-8.75'},
    { Name: '-8.50'},
    { Name: '-8.25'},
    { Name: '-8.00'},
    { Name: '-7.75'},
    { Name: '-7.50'},
    { Name: '-7.25'},
    { Name: '-7.00'},
    { Name: '-6.75'},
    { Name: '-6.50'},
    { Name: '-6.25'},
    { Name: '-6.00'},
    { Name: '-5.75'},
    { Name: '-5.50'},
    { Name: '-5.25'},
    { Name: '-5.00'},
    { Name: '-4.75'},
    { Name: '-4.50'},
    { Name: '-4.25'},
    { Name: '-4.00'},
    { Name: '-3.75'},
    { Name: '-3.50'},
    { Name: '-3.25'},
    { Name: '-3.00'},
    { Name: '-2.75'},
    { Name: '-2.50'},
    { Name: '-2.25'},
    { Name: '-2.00'},
    { Name: '-1.75'},
    { Name: '-1.50'},
    { Name: '-1.25'},
    { Name: '-1.00'},
    { Name: '-0.75'},
    { Name: '-0.50'},
    { Name: '-0.25'},
    { Name: 'PLANO'},
    { Name: '+0.25'},
    { Name: '+0.50'},
    { Name: '+0.75'},
    { Name: '+1.00'},
    { Name: '+1.25'},
    { Name: '+1.50'},
    { Name: '+1.75'},
    { Name: '+2.00'},
    { Name: '+2.25'},
    { Name: '+2.50'},
    { Name: '+2.75'},
    { Name: '+3.00'},
    { Name: '+3.25'},
    { Name: '+3.50'},
    { Name: '+3.75'},
    { Name: '+4.00'},
    { Name: '+4.25'},
    { Name: '+4.50'},
    { Name: '+4.75'},
    { Name: '+5.00'},
    { Name: '+5.25'},
    { Name: '+5.50'},
    { Name: '+5.75'},
    { Name: '+6.00'},
    { Name: '+6.25'},
    { Name: '+6.50'},
    { Name: '+6.75'},
    { Name: '+7.00'},
    { Name: '+7.25'},
    { Name: '+7.50'},
    { Name: '+7.75'},
    { Name: '+8.00'},
    { Name: '+8.25'},
    { Name: '+8.50'},
    { Name: '+8.75'},
    { Name: '+9.00'},
    { Name: '+9.25'},
    { Name: '+9.50'},
    { Name: '+9.75'},
    { Name: '+10.00'},
    
  ];

  dataPVA: any = [
    { Name: '6/6'},
    { Name: '6/6 P'},
{ Name: '6/9'},
{ Name: '6/9 P'},
{ Name: '6/12'},
{ Name: '6/12 P'},
{ Name: '6/18'},
{ Name: '6/18 P'},
{ Name: '6/24'},
{ Name: '6/24 P'},
{ Name: '6/30'},
{ Name: '6/30 P'},
{ Name: '6/36'},
{ Name: '6/36 P'},
{ Name: '6/60'},
{ Name: '6/60 P'},

  ];

  dataNVA: any = [
  { Name: 'N5' },
  { Name: 'N6' },
  { Name: 'N8' },
  { Name: 'N10' },
  { Name: 'N12' },
  { Name: 'N18' },
  { Name: 'N36' },

  ];

  ngOnInit() {
   
    this.spinner.show();
    if (this.id === 0){
      this.spinner.show();
      this.data1.VisitDate = moment().format('YYYY-MM-DD')

      // this.companyService.getExtendedListByCompany1('CustomerFullListAll', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
      //   this.customerList = res.result;
      //   this.data1.Idd = this.customerList.length + 1 ; 
      // }, (err) => {
      // });

      this.companyService.customeridd('CustomerIDD', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
        this.data1.Idd   = res.result[0].idd + 1;
     
      }, (err) => {
      });
      
    }
    if (this.id !== 0) {
      this.spinner.show();
      this.companyService.getShortDataByID('Customer', this.id).subscribe(data => {
        this.data1 = data.result;
        if (data.result.DOB === '0000-00-00') {
          this.data1.DOB = null;
        }
        if (data.result.Anniversary === '0000-00-00') {
          this.data1.Anniversary = null;
        }
        this.customerImage = this.sanitize(this.data1.PhotoURL);
        this.getContactLensList();
        this.getMaxBillingByCustomer();
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Data Not Saved.',
          'top',
          'right'
        );
      });
      this.getFamily();
      this.companyService.geListByOtherID('spectacle_rx', this.id).subscribe(res => {
        this.spectacleList = res.result;
        if(this.spectacleList.length !== 0){
          this.spectacle = this.spectacleList[0]
        } 
      }, (err) => {
        console.log(err);
      });

      this.companyService.geListByOtherID('contact_lens_rx', this.id).subscribe(res => {
        this.contactLensList = res.result;
        if(this.contactLensList.length !== 0){
          this.clens = this.contactLensList[0]
        }
      }, (err) => {
        console.log(err);
      });

      this.companyService.geListByOtherID('other_rx', this.id).subscribe(res => {
        this.otherRxList = res.result;
        if(this.otherRxList.length !== 0){
          this.other = this.otherRxList[this.otherRxList.length - 1]
        }
        
      }, (err) => {
        console.log(err);
      });
    }
    this.srcBox = true;
    this.spinner.show();
   
    this.getReferenceList();
    this.getDoctorList();
   
    this. getOtherList();
this.permission.forEach(element => {    
      if (element.ModuleName === 'CustomerList') {
             this.editCustomerList = element.Edit;
             this.addCustomerList = element.Add;
             this.deleteCustomerList = element.Delete;
           }
         });
    
    // this.getCustomerList()

    // this.getDPCYL();
    // this.getDPVA();
    // this.getNPVA();
    this.getSpactacleList();
    this.UploadType('Upload');


    // this.getContactLensList();
    this.getOtherRxList();

    WebcamUtil.getAvailableVideoInputs()
      .then((mediaDevices: MediaDeviceInfo[]) => {
        this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
      });
      this.spinner.hide();
      
  }
  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
    } else { return null; }
  }

 

  getMaxBillingByCustomer() {
    if(this.id !== 0) {
    this.companyService.geListByOtherID1('MaxCount', this.id, this.loggedInShop.ShopID).subscribe(res => {
      if(res.result[0].MaxAmount === null) {
        this.MaxAmount = 0;
      } else {
      this.MaxAmount = res.result[0].MaxAmount;
      }
    

      this.getCustomerCategoryByID(this.loggedInShop.ShopID);
     
    }, (err) => {
      this.spinner.hide();
     
    });
  }
  }

  getCustomerCategoryByID(id) {
    this.companyService.geListByOtherID('CustomerCategory' , id).subscribe(data => {
      this.CustomerCategory = data.result;
      console.log(data);
      
      this.CustomerCategory.forEach(ele => {
        let form = 0;
        let to = 0;
        form = Number(ele.Fromm);
        to = Number(ele.Too);
        if(form <= this.MaxAmount && to >= this.MaxAmount )  {
          this.categoryType = ele.Category;
          
        } 
      }) 

    }, (err) => { console.log(err);
                  this.spinner.show();
    });
  }


  // getCustomerList() {
  //   this.spinner.show();
  //   this.companyService.getExtendedListByCompany1('CustomerFullListAll', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
  //     this.customerList = res.result;
  //     // this.data1.Sno = Number(this.customerList[0].Sno) + 1;
  //     // this.TotalCustomer = this.customerList.length ;

  //     this.spinner.hide();
      
  //     this.showNotification(
  //       'bg-green',
  //       'Data Loaded successfully',
  //       'top',
  //       'right'
  //     );
  //   }, (err) => {
  //     this.spinner.hide();
  //     this.showNotification(
  //       'bg-red',
  //       'Data Not Loaded.',
  //       'top',
  //       'right'
  //     );
  //   });
  // }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getReferenceList() {
    this.companyService.getSupportMasterList('ReferenceBy').subscribe(data => { 
      this.ReferenceList = data.result;
      this.spinner.hide();
      
    }, (err) => {
      this.spinner.hide();
    
    });
  }

  getOtherList() {
    this.companyService.getSupportMasterList('Other').subscribe(data => { 
      this.OtherList = data.result;
      this.spinner.hide();
      
    }, (err) => {
      this.spinner.hide();
    
    });
  }

  // getGenderList() {
  //   this.companyService.getSupportMasterList('Gender').subscribe(data => { 
  //     this.GenderList = data.result;
  //     this.spinner.hide();
      
  //   }, (err) => {
  //     this.spinner.hide();
      
  //   });
  // }



  calculate(mode:any, x:any, y:any){
    let k = 0.00;
    let a = 0.00;
  
    if (mode === 'Lens'){
      // right spectacle calculate start
      if (x === 'RD')
      { if(this.spectacle.R_Addition !== ''){
        this.spectacle.R_Addition  = Number(this.spectacle.RENPSPH)  - Number(this.spectacle.REDPSPH)
        if(this.spectacle.R_Addition >= 0){
          this.spectacle.R_Addition = '+' + this.spectacle.R_Addition.toFixed(2).toString()
        }else{
          this.spectacle.R_Addition =  this.spectacle.R_Addition.toFixed(2).toString().replace("-", "+")
        }
        this.spectacle.RENPCYL = this.spectacle.REDPCYL;
        this.spectacle.RENPAxis = this.spectacle.REDPAxis;
      }
       
      } 
      if (x === 'R' ){
        if (this.spectacle.R_Addition !== ''){
          this.spectacle.RENPSPH = Number(this.spectacle.REDPSPH) + Number(this.spectacle.R_Addition)
          if(this.spectacle.RENPSPH >= 0){
            this.spectacle.RENPSPH = '+' + this.spectacle.RENPSPH.toFixed(2).toString()
          }else{
            this.spectacle.RENPSPH =  this.spectacle.RENPSPH.toFixed(2).toString()
          }
          this.spectacle.RENPCYL = this.spectacle.REDPCYL;
          this.spectacle.RENPAxis = this.spectacle.REDPAxis; 
        }else{
          this.spectacle.RENPSPH = this.spectacle.REDPSPH
        }
      }
      if (x === 'RN' ){
        if (this.spectacle.RENPSPH !== '' ){
          this.spectacle.R_Addition  =  Number(this.spectacle.REDPSPH) -  Number(this.spectacle.RENPSPH) 
          if(this.spectacle.R_Addition >= 0){
            this.spectacle.R_Addition = '+' + this.spectacle.R_Addition.toFixed(2).toString().replace("-", "+")
          }else{
            this.spectacle.R_Addition =   this.spectacle.R_Addition.toFixed(2).toString().replace("-", "+")
          }
          this.spectacle.RENPCYL = this.spectacle.REDPCYL;
          this.spectacle.RENPAxis = this.spectacle.REDPAxis; 
        } else{
          this.spectacle.R_Addition = ''
        }
      }
      // right this.spectacle calculate end
      // left this.spectacle calculate start
      if (x === 'LD')
      { if(this.spectacle.L_Addition !== ''){
        this.spectacle.L_Addition  = Number(this.spectacle.LENPSPH)  - Number(this.spectacle.LEDPSPH)
        if(this.spectacle.L_Addition >= 0){
          this.spectacle.L_Addition = '+' + this.spectacle.L_Addition.toFixed(2).toString()
        }else{
          this.spectacle.L_Addition =  this.spectacle.L_Addition.toFixed(2).toString().replace("-", "+")
        }
        this.spectacle.LENPCYL = this.spectacle.LEDPCYL;
        this.spectacle.LENPAxis = this.spectacle.LEDPAxis;
      }
       
      } 
      if (x === 'L' ){
        if (this.spectacle.L_Addition !== ''){
          this.spectacle.LENPSPH = Number(this.spectacle.LEDPSPH) + Number(this.spectacle.L_Addition)
          if(this.spectacle.LENPSPH >= 0){
            this.spectacle.LENPSPH = '+' + this.spectacle.LENPSPH.toFixed(2).toString()
          }else{
            this.spectacle.LENPSPH =  this.spectacle.LENPSPH.toFixed(2).toString()
          }
           this.spectacle.LENPCYL = this.spectacle.LEDPCYL;
           this.spectacle.LENPAxis = this.spectacle.LEDPAxis; 
        }else{
          this.spectacle.LENPSPH = this.spectacle.LEDPSPH
        }
       }
      if (x === 'LN'){
       if (this.spectacle.LENPSPH !== '' ){
          this.spectacle.L_Addition  =  Number(this.spectacle.LEDPSPH) -  Number(this.spectacle.LENPSPH) 
          if(this.spectacle.L_Addition >= 0){
            this.spectacle.L_Addition = '+' + this.spectacle.L_Addition.toFixed(2).toString().replace("-", "+")
          }else{
            this.spectacle.L_Addition =   this.spectacle.L_Addition.toFixed(2).toString().replace("-", "+")
          }
          this.spectacle.LENPCYL = this.spectacle.LEDPCYL;
          this.spectacle.LENPAxis = this.spectacle.LEDPAxis; 
        } else{
          this.spectacle.L_Addition = ''
        }
      }
      // left this.spectacle calculate end

    }
    else{
      // right contact calculate end
      if (x === 'CRD' && y === 0)
        { if(this.clens.R_Addition !== ''){
        this.clens.R_Addition  = Number(this.clens.RENPSPH)  - Number(this.clens.REDPSPH)
        if(this.clens.R_Addition >= 0){
          this.clens.R_Addition = '+' + this.clens.R_Addition.toFixed(2).toString()
        }else{
          this.clens.R_Addition =  this.clens.R_Addition.toFixed(2).toString().replace("-", "+")
        }
        this.clens.RENPCYL = this.clens.REDPCYL;
        this.clens.RENPAxis = this.clens.REDPAxis;
        }
      } 
      if (x === 'CR' && y === 0){
      let CR = 0.00
         if (this.clens.R_Addition !== ''){
        this.clens.RENPSPH = Number(this.clens.REDPSPH) + Number(this.clens.R_Addition)
        if(this.clens.RENPSPH >= 0){
          this.clens.RENPSPH = '+' + this.clens.RENPSPH.toFixed(2).toString()
        }else{
          this.clens.RENPSPH =  this.clens.RENPSPH.toFixed(2).toString()
        }
        this.clens.RENPCYL = this.clens.REDPCYL;
        this.clens.RENPAxis = this.clens.REDPAxis; 
         }else{
          this.clens.RENPSPH = this.clens.REDPSPH
         }
      }
      if (x === 'CRN' && y === 0){
        if (this.clens.RENPSPH !== '' ){
        this.clens.R_Addition  =  Number(this.clens.REDPSPH) -  Number(this.clens.RENPSPH) 
        if(this.clens.R_Addition >= 0){
          this.clens.R_Addition = '+' + this.clens.R_Addition.toFixed(2).toString().replace("-", "+")
        }else{
          this.clens.R_Addition =   this.clens.R_Addition.toFixed(2).toString().replace("-", "+")
        }
        this.clens.RENPCYL = this.clens.REDPCYL;
        this.clens.RENPAxis = this.clens.REDPAxis; 
        } else{
        this.clens.R_Addition = ''
        } 
      }
      // right contact calculate end
      // left contact calculate start
      if (x === 'CLD' && y === 0)
      { if(this.clens.L_Addition !== ''){
        this.clens.L_Addition  = Number(this.clens.LENPSPH)  - Number(this.clens.LEDPSPH)
        if(this.clens.L_Addition >= 0){
          this.clens.L_Addition = '+' + this.clens.L_Addition.toFixed(2).toString()
        }else{
          this.clens.L_Addition =  this.clens.L_Addition.toFixed(2).toString().replace("-", "+")
        }
        this.clens.LENPCYL = this.clens.LEDPCYL;
        this.clens.LENPAxis = this.clens.LEDPAxis;
      }
       
      } 
      if (x === 'CL' && y === 0){
        if (this.clens.L_Addition !== ''){
          this.clens.LENPSPH = Number(this.clens.LEDPSPH) + Number(this.clens.L_Addition)
          if(this.clens.LENPSPH >= 0){
            this.clens.LENPSPH = '+' + this.clens.LENPSPH.toFixed(2).toString()
          }else{
            this.clens.LENPSPH =  this.clens.LENPSPH.toFixed(2).toString()
          }
           this.clens.LENPCYL = this.clens.LEDPCYL;
           this.clens.LENPAxis = this.clens.LEDPAxis; 
        }else{
          this.spectacle.LENPSPH = this.spectacle.LEDPSPH
        }
       }
      if (x === 'CLN' && y === 0){
       if (this.clens.LENPSPH !== '' ){
          this.clens.L_Addition  =  Number(this.clens.LEDPSPH) -  Number(this.clens.LENPSPH) 
          if(this.clens.L_Addition >= 0){
            this.clens.L_Addition = '+' + this.clens.L_Addition.toFixed(2).toString().replace("-", "+")
          }else{
            this.clens.L_Addition =   this.clens.L_Addition.toFixed(2).toString().replace("-", "+")
          }
          this.clens.LENPCYL = this.clens.LEDPCYL;
          this.clens.LENPAxis = this.clens.LEDPAxis; 
        } else{
          this.clens.L_Addition = ''
        }
      }
      // left contact calculate end
    }  
  }

  getFamily() {
    this.companyService.geListByOtherID('Family', this.id).subscribe(data => {
      this.familyList = data.result;
      
    }, (err) => {
    });
  }

  saveFamily() {
    let count = 0;
    this.familyList.forEach(element => {
      if (element.Name.toLowerCase() === this.newFamily.Name.toLowerCase() ){count = count + 1; }

    });
    if (count === 0 && this.newFamily.Name !== ''){
    this.companyService.saveData('Family', this.newFamily).subscribe(res => {
      this.getFamily();
    }, (err) => {
    });
  } else {
    //  alert ("Duplicate or Empty Values are not allowed");
    Swal.fire({
      icon: 'error',
      title: 'Duplicate or Empty Values are not allowed',
      text: '',
      footer: ''
    });
  this.newDoctor.Name = ""; }
}

  getDoctorList() {
    this.companyService.getShortListByCompany('Doctor', 1).subscribe(data => {
      this.docList = data.result;
    }, (err) => {

    });
  }

  saveDoctor() {
    let count = 0;
    this.docList.forEach(element => {
      if (element.Name.toLowerCase() === this.newDoctor.Name.toLowerCase() ){count = count + 1; }

    });
    if (count === 0 && this.newDoctor.Name !== ''){
    this.newDoctor.CompanyID = this.loggedInCompany.ID;
    this.adminService.saveData('Doctor', this.newDoctor).subscribe(data1 => {
      this.getDoctorList();
    }, (err) => { });
  } else { alert ("Duplicate or Empty Values are not allowed");
  this.newDoctor.Name = ""; }
}

 

  uploadImage(e,mode) {
    let image: File = e.target.files[0]
    console.log(`Image size before compressed: ${image.size} bytes.`)
    this.compressImage.compress(image)
      .pipe(take(1)).subscribe(compressedImage => {
        console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
        const frmData = new FormData();
        frmData.append('file', compressedImage);
        this.adminService.uploadFile(frmData).subscribe(data => {
          switch (mode) {
            case "User":
              this.data1.PhotoURL = data.fileName;
              this.customerImage = this.sanitize(this.data1.PhotoURL);
              break;
            case "spectacle":
              this.spectacle.PhotoURL = data.fileName;
              this.spectacleImage = this.sanitize(this.spectacle.PhotoURL);
              break;
            case "clens":
              this.clens.PhotoURL = data.fileName;
              this.clensImage = this.sanitize(this.clens.PhotoURL);
              break;
            default:
              break;
          }
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Image successfully Uploaded',
            'bottom',
            'right'
          );
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Image Not Uploaded.',
            'bottom',
            'right'
          );
        });
  })}

  onSubmit() {
    if (this.searchList.length === 1 && this.param.MobileNo1 !== '' && this.id === 0) {
      let yes = confirm("are you sure you want to save duplicate entry");
      if (yes) {
        this.onSubmit1();
      }
    } else {
      this.onSubmit1();
    }
  }

  onSubmit1() {
    this.spinner.show();
  
      this.companyService.saveData('Customer', this.data1).subscribe(data1 => {
        if(data1.result.insertId !== 0) {
          this.id = data1.result.insertId;
          this.newFamily.CustomerID = this.id;
          this.spectacle.CustomerID = this.id;
          this.clens.CustomerID = this.id;
          this.other.CustomerID = this.id;
          this.router.navigate(['/sale/customer', data1.result.insertId ]);
         
          this.companyService.getShortDataByID('Customer', this.id).subscribe(data => {
            this.data1 = data.result;
            this.spinner.hide();
            this.customerImage = this.sanitize(this.data1.PhotoURL);
            this.getContactLensList();
            Swal.fire({
              title: "Save",
              text: "Save Data Successfully",
              icon: "success",
            });
          }, (err) => {
            console.log(err);
            
          });
          this.getFamily();
          
    
        } else {
          // this.router.navigate(['/sale/customer-list']);
          this.spinner.hide();
    
          this.router.navigate(['/sale/customer', this.id ]);
    
    
        }
          // this.router.navigate(['/sale/customer', data1.result.insertId ]);
         
        }, (err) => {
          console.log(err);
        
        });
   
    this.spinner.hide();
  }

  saveSpectacleRX() {
    this.spesave = true;
    this.spinner.show();
    this.spectacle.VisitNo = 0;
    if (this.spectacle.Family == ""){this.spectacle.Family = "Self"; }
   
if (this.spectacle.UploadBy === 'WebCam') {this.uploadFile1();}
 
  this.spectacle.ExpiryDate = moment().add(Number(this.spectacle.Reminder), 'M').format('YYYY-MM-DD');
    this.companyService.saveData('spectacle_rx', this.spectacle).subscribe(res => {
   
      this.getSpactacleList();
      this.spesave =  false;
      this.showNotification(
        'bg-green',
        'Data saved successfully',
        'top',
        'right'
      );
      this.spinner.hide();
    }, (err) => {
      console.log(err);
    });
  }
  
  

  saveContactLensRX() {
    if (this.clens.Family == ""){this.clens.Family = "Self"; }
    this.companyService.saveData('contact_lens_rx', this.clens).subscribe(res => {
      this.getContactLensList();
      this.showNotification(
        'bg-green',
        'Data saved successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.showNotification(
        'bg-red',
        'Data Not Saved.',
        'top',
        'right'
      );
    });
  }

  saveOtherRX() {
    if (this.other.Family == ""){this.other.Family = "Self"; }
    this.companyService.saveData('other_rx', this.other).subscribe(res => {
      this.getOtherRxList();
      this.showNotification(
        'bg-green',
        'Data saved successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.showNotification(
        'bg-red',
        'Data Not Saved.',
        'top',
        'right'
      );
    });
  }

  getSpactacleList() {
    this.spinner.show();

    this.companyService.geListByOtherID('spectacle_rx', this.id).subscribe(res => {
      this.spectacleList = res.result;
      this.spinner.hide();

      console.log(this.spectacleList ,)
    }, (err) => {
      console.log(err);
    });
  }

  getContactLensList() {
    this.companyService.geListByOtherID('contact_lens_rx', this.id).subscribe(res => {
      this.contactLensList = res.result;
    }, (err) => {
      console.log(err);
    });
  }

  getOtherRxList() {
    this.companyService.geListByOtherID('other_rx', this.id).subscribe(res => {
      this.otherRxList = res.result;
    }, (err) => {
      console.log(err);
    });
  }

  // getDPSPH() {
  //   this.adminService.getSupportMasterList('DPSPH').subscribe(res => {
  //     this.dpsphList = res;
  //     // if(this.id === 0 && this.dpsphList.CustomerID !== 0){
  //     // this.spectacle.REDPSPH = 'PLANO'
  //     // }

  //   }, (err) => {this.id === 0
  //     console.log(err);
  //   });
  // }

  // getDPCYL() {
  //   this.adminService.getSupportMasterList('DPCYL').subscribe(res => {
  //     this.dpcylList = res;
  //   }, (err) => {
  //     console.log(err);
  //   });
  // }

  // getDPVA() {
  //   this.adminService.getSupportMasterList('DPVA').subscribe(res => {
  //     this.dpvaList = res;
  //   }, (err) => {
  //     console.log(err);
  //   });
  // }

  // getNPVA() {
  //   this.adminService.getSupportMasterList('NPVA').subscribe(res => {
  //     this.npvaList = res;
  //   }, (err) => {
  //     console.log(err);
  //   });
  // }

  selectRow(mode, i){

    switch (mode) {
      case 'spectacle':
        this.spectacle = this.spectacleList[i];
        this.spectacleImage = this.sanitize(this.spectacle.PhotoURL);
        break;
        case 'clens':
        this.clens = this.contactLensList[i];
        this.clensImage = this.sanitize(this.clens.PhotoURL);
        break;
        case 'other':
        this.other = this.otherRxList[i];
        break;
      

      default:
        break;
    }

    if (this.spectacle.UploadBy === 'WebCam') {
      this.stringUrl1 = this.sanitize(this.spectacle.PhotoURL);
      this.UploadType('WebCam');

    } else {
      this.UploadType('Upload');
    }

  
  }



  onLensSave() {
    this.companyService.saveData('Customer', this.data1).subscribe(data1 => {
      this.router.navigate(['/sale/costomerList']);
      this.showNotification(
        'bg-green',
        'Data saved successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Data Not Saved.',
        'top',
        'right'
      );
    });
  }

  printCL(i) {
    this.spinner.show();
    this.printData.Customer = this.data1;
    this.printData.Measurement = this.contactLensList[i];
    this.printData.loggedInShop = this.loggedInShop;
    this.printData.loggedInCompany = this.loggedInCompany;
    this.printData.loggedInCompanySetting = this.loggedInCompanySetting;

    this.companyService.printLens('CL', this.printData).subscribe(data1 => {
      this.contactLensList[i].FileURL = data1.result;
      const url =  this.contactLensList[i].FileURL;
      this.contLink = url;
      window.open(url, "_blank");
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Could not Print.',
        'top',
        'right'
      );
    });
  }

  printSL(i) {
    this.spinner.show();

    this.printData.Customer = this.data1;
    this.printData.Measurement = this.spectacleList[i];
    this.printData.loggedInShop = this.loggedInShop;
    this.printData.loggedInCompany = this.loggedInCompany;
    this.printData.loggedInCompanySetting = this.loggedInCompanySetting;

    this.companyService.printLens('SL', this.printData).subscribe(data1 => {
      this.spectacleList[i].FileURL = data1.result;
      const url =  this.spectacleList[i].FileURL;
      this.spectLink = url;
      window.open(url, "_blank");
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Could not Print.',
        'top',
        'right'
      );
    });

  }

  printOT(i) {
    this.spinner.show();

    this.printData.Customer = this.data1;
    this.printData.Measurement = this.otherRxList[i];
    this.printData.loggedInShop = this.loggedInShop;
    this.printData.loggedInCompany = this.loggedInCompany;
    this.printData.loggedInCompanySetting = this.loggedInCompanySetting;
    this.printData.spectacleList = this.spectacleList[0];
    this.printData.contactLensList = this.contactLensList[0];
    this.printData.exdata = this.Exdata;
    this.companyService.printLens('OL', this.printData).subscribe(data1 => {
      this.otherRxList[i].FileURL = data1.result;
      const url =  this.otherRxList[i].FileURL;
      this.otherLink = url;
      window.open(url, "_blank");
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Could not Print.',
        'top',
        'right'
      );
    });

  }


  openURL(mode, x) {
    let url = "";

    url = this.env.apiUrl + x.FileURL;
    window.open(url, '_blank');
  }

  UploadType(type) {
    if(type === 'Upload') {
      this.showUpload = true;
    } else {
      this.showUpload = false;

    }
  }

  uploadFile1() {
    
    this.fileName = 'Customer' + '-' + this.data1.ID + moment();
    this.spectacle.PhotoURL = 'customer/' + Object.assign(this.fileName) + '.png';
    // console.log(this.worker.Picture);
    this.companyService.uploadFile(this.webcamImage, this.fileName, 'customer').subscribe(
    (data) => { }, (err) => {
      console.log(err);
    }
  );
  }

  calculateAge() {
    if (this.data1.DOB) {
      // this.agrfield = true;
      var timeDiff = Math.abs(Date.now() - new Date(this.data1.DOB).getTime());
      this.data1.Age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);    
  }}

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

  public triggerSnapshot(): void {
    this.trigger.next();
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleInitError(error: WebcamInitError): void {
    this.errors.push(error);
  }

  public handleImage(webcamImage: WebcamImage): void {

    this.webcamImage = webcamImage;
  }

  public cameraWasSwitched(deviceId: string): void {
    this.deviceId = deviceId;
  }

  public get triggerObservable(): Observable<void> {
    return this.trigger.asObservable();
  }

  alertfn(value) {
    if (value === 'REDPSPH' && this.spectacle.REDPSPH == '') {
      this.temp= 'PLANO';
    }
  }

  customerSearch(searchKey, mode) {
   this.param = {Name: '', MobileNo1: '',Sno:''};
    if(mode === 'Name') {
      this.param.Name = searchKey;
    } else if(mode === 'MobileNo1') {
      this.param.MobileNo1 = searchKey;
    }
    else if(mode === 'Sno') {
      this.param.Sno = searchKey;
    }
    let searchParam = JSON.stringify(this.param);
    this.companyService.geListByOtherID('CustomerSearch', searchParam).subscribe(data1 => {
      this.searchList = data1.result;
    

      if(searchKey === '') {
        this.searchList = [];
      } 
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Could not Print.',
        'top',
        'right'
      );
    });
  
  }

  getdatasearch(id) {
    this.spinner.show();
    this.id = id;
    this.router.navigate(['/sale/customer', id ]);
    this.spectacle.CustomerID = this.id;
      this.clens.CustomerID = this.id;
      this.other.CustomerID = this.id;
      this.spinner.show();
    this.ngOnInit();
    
    if (this.id !== 0) {
      this.srcBox = true;
      this.spinner.show();
     
      this.companyService.getShortDataByID('Customer', this.id).subscribe(data => {
        this.data1 = data.result;
        
        if (data.result.DOB === '0000-00-00') {
          this.data1.DOB = null;
        }
        if (data.result.Anniversary === '0000-00-00') {
          this.data1.Anniversary = null;
        }
        this.spinner.hide();
        this.srcBox = false;

        this.customerImage = this.sanitize(this.data1.PhotoURL);
        this.getContactLensList();
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Data Not Saved.',
          'top',
          'right'
        );
      });
      this.getFamily();

    }
    // this.getDoctorList();
    // this.getDPSPH();
    // this.getDPCYL();
    // this.getDPVA();
    // this.getNPVA();
    this.getSpactacleList();
    this.UploadType('Upload');
    this.getContactLensList();
    this.getOtherRxList()
    this.companyService.geListByOtherID('spectacle_rx', this.id).subscribe(res => {
      this.spectacleList = res.result;
      if(this.spectacleList.length !== 0){
        this.spectacle = this.spectacleList[this.spectacleList.length - 1];

      }
      
    }, (err) => {
      console.log(err);
    });

    this.companyService.geListByOtherID('contact_lens_rx', this.id).subscribe(res => {
      this.contactLensList = res.result;
      if(this.contactLensList.length !== 0){
        this.clens = this.contactLensList[this.contactLensList.length - 1]
      }
    }, (err) => {
      console.log(err);
    });

    this.companyService.geListByOtherID('other_rx', this.id).subscribe(res => {
      this.otherRxList = res.result;
      if(this.otherRxList.length !== 0){
        this.other = this.otherRxList[this.otherRxList.length - 1]
      }
    }, (err) => {
      console.log(err);
    });

    WebcamUtil.getAvailableVideoInputs()
      .then((mediaDevices: MediaDeviceInfo[]) => {
        this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
      });
      
  }


  NewVisit(){
    this.spectacle = {
      ID: null, CustomerID: this.id, REDPSPH: '', Reminder: '6', REDPCYL: '', REDPAxis: '', REDPVA: '', LEDPSPH: '', LEDPCYL: '', LEDPAxis: '',
      LEDPVA: '', RENPSPH: '', RENPCYL: '', RENPAxis: '', RENPVA: '', LENPSPH: '', LENPCYL: '', LENPAxis: '', LENPVA: '', REPD: '', LEPD: '',
      R_Addition: '', L_Addition: '', R_Prism: '', L_Prism: '', Lens: '', Shade: '', Frame: '', VertexDistance: '', RefractiveIndex: '',
      FittingHeight: '', ConstantUse: false, NearWork: false, RefferedByDoc: 'Self', DistanceWork: false, UploadBy: 'Upload', PhotoURL: '', FileURL: '', Family: 'Self'
    };
    this.clens = {
      ID: null, CustomerID: this.id, REDPSPH: '', REDPCYL: '', REDPAxis: '', REDPVA: '', LEDPSPH: '', LEDPCYL: '', LEDPAxis: '',
      LEDPVA: '', RENPSPH: '', RENPCYL: '', RENPAxis: '', RENPVA: '', LENPSPH: '', LENPCYL: '', LENPAxis: '', LENPVA: '', REPD: '', LEPD: '',
      R_Addition: '', L_Addition: '', R_KR: '', L_KR: '', R_HVID: '', L_HVID: '', R_CS: '', L_CS: '', R_BC: '', L_BC: '',
      R_Diameter: '', L_Diameter: '', BR: '', Material: '', Modality: '', RefferedByDoc: 'Self', Other: '', ConstantUse: false,
      NearWork: false, DistanceWork: false, Multifocal: false, PhotoURL: '', FileURL: '', Family: 'Self'
    };
  
    this.other= {
      ID: null, CustomerID: this.id, BP: '', Sugar: '', IOL_Power: '', RefferedByDoc: 'Self', Operation: '', R_VN: '', L_VN: '', R_TN: '', L_TN: '',
      R_KR: '', L_KR: '', Treatment: '', Diagnosis: '', Family: 'Self'
    };
  
  }

  

  sendSpecemail(i){
    let temp = {Name: this.data1.Name, Email: this.data1.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website, spectaclelist: this.env.apiUrl + this.spectacleList[i].FileURL};
    
     this.adminService.sendEmail(temp, 'spectacleLens').subscribe(data2 => {
       this.showNotification(
         'bg-red',
         'Mail Send.',
         'top',
         'right'
       ); 
     }, (err) => { console.log(err);
                   
     });
  }

  sendContemail(i){
    let temp = {Name: this.data1.Name, Email: this.data1.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website, contactlens: this.env.apiUrl + this.contactLensList[i].FileURL};
  
     this.adminService.sendEmail(temp, 'contactLens').subscribe(data2 => {
       this.showNotification(
         'bg-red',
         'Mail Send.',
         'top',
         'right'
       ); 
     }, (err) => { console.log(err);
                   
     });
  }

  sendOtheremail(i){
    let temp = {Name: this.data1.Name, Email: this.data1.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website, OtherRx: this.env.apiUrl + this.otherRxList[i].FileURL};
    
     this.adminService.sendEmail(temp, 'OtherRxLens').subscribe(data2 => {
       this.showNotification(
         'bg-red',
         'Mail Send.',
         'top',
         'right'
       ); 
     }, (err) => { console.log(err);
                   
     });
  }


  sendSpecewh(i ,mode) {
    let temp = JSON.parse(this.loggedInCompanySetting.WhatsappSetting);
    let Smsw = ''
    if(temp !== '' && temp !== null && temp !== 'null'){
      Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Eye Prescription')].MessageText1;
    }else{
      Smsw = ''
    }
    
    let Smsw1 = ''
    if(Smsw !==  ''){
     Smsw1 = Smsw
    }else{
     Smsw1 = 'We know the world is full of choices. Thank you for choosing us! For your Eye Testing. We hope you like our services.'
    }
   
    if(mode === "spectacle"){
     
      var msg = `Hi ${this.data1.Name} %0A`+ 
      `${Smsw1}%0A`+
      `Open Prescription : ${this.spectacleList[i].FileURL} %0A`
      +  
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}%0APlease give your valuable Review for us %0A`
        + `Type HI, and download your Prescription`;
       var mob = "91" + this.data1.MobileNo1 ;
      var url = ` https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     } else if(mode === "contact"){
      var msg = `Hi ${this.data1.Name},%0A`+ 
      `${Smsw1}%0A`+ 
       `Open Prescription : ${this.contactLensList[i].FileURL}%0A`+ 
      `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}%0APlease give your valuable Review for us %0A`
      + `Type HI, and download your Prescription `;
       var mob = "91" + this.data1.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     } else if(mode === "otherx"){
      var msg = `Hi ${this.data1.Name},%0A`+ 
      `${Smsw1}%0A`+
      `Open Prescription : ${this.otherRxList[i].FileURL} %0A`+ 
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}%0APlease give your valuable Review for us %0A`
       + `Type HI, and download your Prescription `;
       var mob = "91" + this.data1.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     }
  }


  ClearData(){
    
    this.customerImage = '';
    this.data1 ={
      ID: null, Idd:0, Sno:"", TotalCustomer:"",VisitDate:"", Name: null, CompanyID: null, MobileNo1: "", MobileNo2: "", PhoneNo: "", Address: "", GSTNo: "", Email: "",
      PhotoURL: " ", DOB: "", Age:"", Anniversary: "", RefferedByDoc: "", ReferenceType: "",Gender: "", Category: "", Other:"", Remarks:"", Status: 1, CreatedBy: null,
      UpdatedBy: null, CreatedOn: null, UpdatedOn: null
    };
    this.spectacle = {
      ID: null, CustomerID: this.id, REDPSPH: '', Reminder: '6', REDPCYL: '', REDPAxis: '', REDPVA: '', LEDPSPH: '', LEDPCYL: '', LEDPAxis: '',
      LEDPVA: '', RENPSPH: '', RENPCYL: '', RENPAxis: '', RENPVA: '', LENPSPH: '', LENPCYL: '', LENPAxis: '', LENPVA: '', REPD: '', LEPD: '',
      R_Addition: '', L_Addition: '', R_Prism: '', L_Prism: '', Lens: '', Shade: '', Frame: '', VertexDistance: '', RefractiveIndex: '',
      FittingHeight: '', ConstantUse: false, NearWork: false, RefferedByDoc: 'Self', DistanceWork: false, UploadBy: 'Upload', PhotoURL: '', FileURL: '', Family: 'Self',
      ExpiryDate: null
    };
  
    this.clens = {
      ID: null, CustomerID: this.id, REDPSPH: '', REDPCYL: '', REDPAxis: '', REDPVA: '', LEDPSPH: '', LEDPCYL: '', LEDPAxis: '',
      LEDPVA: '', RENPSPH: '', RENPCYL: '', RENPAxis: '', RENPVA: '', LENPSPH: '', LENPCYL: '', LENPAxis: '', LENPVA: '', REPD: '', LEPD: '',
      R_Addition: '', L_Addition: '', R_KR: '', L_KR: '', R_HVID: '', L_HVID: '', R_CS: '', L_CS: '', R_BC: '', L_BC: '',
      R_Diameter: '', L_Diameter: '', BR: '', Material: '', Modality: '', RefferedByDoc: 'Self', Other: '', ConstantUse: false,
      NearWork: false, DistanceWork: false, Multifocal: false, PhotoURL: '', FileURL: '', Family: 'Self'
    };
  
    this.other = {
      ID: null, CustomerID: this.id, BP: '', Sugar: '', IOL_Power: '', RefferedByDoc: 'Self', Operation: '', R_VN: '', L_VN: '', R_TN: '', L_TN: '',
      R_KR: '', L_KR: '', Treatment: '', Diagnosis: '', Family: 'Self'
    };
    
    console.log(this.data1," this.data1")
    this.spinner.show();
    this.id = 0;
    this.router.navigate(['/sale/customer', 0 ]);
    this.spinner.hide();
    this.ngOnInit()
    

  }


}
function Functionsss() {
  throw new Error('Function not implemented.');
}

