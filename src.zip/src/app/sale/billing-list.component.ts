import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Shop} from '../model/Shop';
import { CompanyService} from '../services/company.service';
import {DomSanitizer} from '@angular/platform-browser';

import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import { PaginationService } from '../services/pagination.service';

import { map, filter, debounceTime, distinctUntilChanged, elementAt } from 'rxjs/operators';
import { fromEvent, Subscription } from 'rxjs';

@Component({
  selector: 'app-billing-list',
  templateUrl: './billing-list.component.html',
  styleUrls: ['./billing-list.component.css']
})
export class BillingListComponent implements OnInit, AfterViewInit {
  @ViewChild('searching') searching: ElementRef | any;
  term = "";

  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  permission= JSON.parse(localStorage.getItem('Permission'));
loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));

  editBillingList = false;
  addBillingList = false;
  deleteBillingList = false;
  stringUrl: string;
  dataList: any;
  customerList = [];
  shopList: any;
  header: any;
  UpdatePaymentMode = false;
  PaymentModesList: any;
  totalAmount = 0;
  dueAmount = 0;
  page = 4;

  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0
  currency = {Symbol: 'INR', Format: '1.2-2' };

data: any = {cash: "", customer_return:"", bhim:"", cheque:"", paytm:"", card:"", g_pay:"",};

  data1: any = {ShopID: '', PaymentStatus:'',ShopID1:''};
  plusIcon = false;
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute,
    private pagination: PaginationService) { }

    public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);

  ngOnInit() {
    this.spinner.show();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'BillingList') {
             this.editBillingList = element.Edit;
             this.addBillingList = element.Add;
             this.deleteBillingList = element.Delete;
           }
         });
   this.getList()
        
   
   
    this.getShopList();
    // if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
    //   this.data1.ShopID = this.loggedInShop.ShopID;
    //   this.getShopListByID();
    // } else {
    //   this.getShopList();

    // }
    this.getPaymentModesList();
  }
  
  onPageChange(pageNum: number): void {
    this.pageSize = this.itemsPerPage*(pageNum - 1);
    }

    changePagesize(num: number): void {
      this.itemsPerPage = this.pageSize + num;
      }

      getList(){
        this.spinner.show()
        let parem = {};
        if (this.id !== 0 ) {
          this.plusIcon = true;
        }
        if (this.id !== 0 ){
          parem = { CustomerID: this.id}; 
        }
         else {
          parem = {ShopID: this.loggedInShop.ShopID }; 
          }
        const dtm = {
          currentPage: this.currentPage,
          itemsPerPage: this.itemsPerPage,
          params : parem
        }
        this.pagination.getList('BillMaster', dtm).subscribe(res => {
          
          this.collectionSize = res.count;
          this.dataList = res.result;
          this.totalCalculation(this.dataList);
          
          if (this.id !== 0 && this.dataList.length !== 0){this.header = "Bill List for " + this.dataList[0].CustomerName;   } 
          else {this.header = "Bill List"; }
          this.spinner.hide()
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          this.spinner.hide()
          this.showNotification(
            'bg-red',
            'Data Not Loaded.',
            'top',
            'right'
          );
        });
      }

  // getShopListByID() {
  //   this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
  //     console.log(data.result , 'shoplistttt');
  //     this.shopList.push(data.result);
  //     if(this.shopList.length === 1) {
  //       this.data1.ShopID = this.shopList[0].ID
  //     }
  //     this.spinner.hide();

  //   }, (err) => {
  //     console.log(err);
  //     this.spinner.hide();
  //     // this.showFailure(err, 'Error Loading Data.');
  //     this.showNotification(
  //         'bg-red',
  //         'Error Loading Data.',
  //         'top',
  //         'right'
  //       );
  //   });
  // }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => { 
      this.shopList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  paymentHistory(ID){
    this.spinner.show();
    this.companyService.geListByOtherID('CustomerPaymentHistory' , ID).subscribe(data => {
      this.customerList = data.result;
      this.spinner.hide();
      console.log( this.customerList," this.customerList")
    
    }, (err) => { console.log(err);
                  this.spinner.hide();
                
    });
  }

  totalCalculation(data) {
    for (var i = 0; i < data?.length; i++) {
      this.totalAmount  = this.totalAmount + parseInt(data[i].TotalAmount);
      this.dueAmount  = this.dueAmount + parseInt(data[i].DueAmount);
    }
    console.log(this.totalAmount, 'this.totalAmountthis.totalAmountthis.totalAmount');
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        if(this.dataList[i].Quantity == 0) {
        this.companyService.deleteData('BillMaster', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )}
        else {
          Swal.fire({
            title: 'Alert',
            text: "you can not delete this invoice, please delete product first!",
            icon: 'warning',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK!'
          })
        }
      }
    })
  }

  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => { 
      this.PaymentModesList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }


  // deleteItem(i){
  //   let yes = confirm("Are you sure want to delete");
  //   if (yes) {
  //   this.companyService.deleteData('BillMaster', this.dataList[i].ID).subscribe(data => {
  //   this.dataList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  // }
  //   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

  filterDataByParam() {
    this.companyService.filterDataByParam(this.data1, 'BillMaster').subscribe(data => { 
      this.dataList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  updatePaymentMode(data) {
    this.spinner.show();
    this.companyService.saveData('updatePaymentHistory' , data).subscribe(data => {
      this.UpdatePaymentMode = false;

      this.spinner.hide();
    this.showNotification(
        'bg-green',
        'Data Update successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                
    });
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }


   ngAfterViewInit() {
    // server-side search
    this.spinner.show()
    fromEvent(this.searching.nativeElement, 'keyup').pipe(

      // get value
      map((event: any) => {
        return event.target.value;
      }),

      // if character length greater then 2
      // filter(res => res.length > 2),

      // Time in milliseconds between key events
      debounceTime(1000),

      // If previous query is different from current
      distinctUntilChanged(),
      // tap((event: KeyboardEvent) => {
      //     console.log(event)
      //     console.log(this.input.nativeElement.value)
      //   })
      // subscription for response
    ).subscribe((text: string) => {
  //  const name = e.target.value;
    let data = {
      searchQuery: text.trim(),

    }

  console.log(data);
  if (data.searchQuery !== "") {
    let parem = {};
    if (this.id !== 0 ) {
      this.plusIcon = true;
    }
    if (this.id !== 0 ){
      parem = { CustomerID: this.id}; 
    }
     else {
      parem = {ShopID: this.loggedInShop.ShopID }; 
      }
    const dtm = {
      currentPage: 1,
      itemsPerPage: 50000,
      params : parem,
      searchQuery: data.searchQuery 

    }
    this.pagination.getsearchList('BillMaster', dtm).subscribe(res => {
      this.spinner.hide()
      this.collectionSize = res.count;
      this.dataList = res.result;
      this.totalCalculation(this.dataList);
      
      if (this.id !== 0 && this.dataList.length !== 0)
      {this.header = "Bill List for " + this.dataList[0].CustomerName;   } 

      else {this.header = "Bill List"; }
      this.spinner.hide()
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide()
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  } else {
    this.getList()
  }
 
    
    

    });

    

  }

  sendMsgOdr(data, mode) {

if(data.CustomerMob == ""){
  Swal.fire({
    title: 'Alert',
    icon: 'warning',
    text: 'Message Not Send , Moblie Number Not Exist' ,
    footer: '' ,       
  });
}else{
    let temp = JSON.parse(this.loggedInCompanySetting.SmsSetting);
    let val = '';
    let CustomerName = data.CustomerName;
    let phoneNo = data.CustomerMob;
    let CustomerOrder = data.InvoiceNo;
    let ShopName = this.loggedInShop.Name;
    let ContactNo = this.loggedInShop.MobileNo1;
    let OrderPDFLink = data.Invoice;
    let CustomerOrderNo = data.InvoiceNo;
    let BillPDFLink = data.Receipt;
    let CustomerCreditNote = '';
    let Website = this.loggedInCompany.Website;
    let senderID = this.loggedInCompanySetting.SenderID;
    let msgAPIKey = this.loggedInCompanySetting.MsgAPIKey;
    let message = '';
    let templateID = '';
  
    if(mode === "orderPending"){
  let Sms = temp[temp.findIndex(element => element.MessageName === 'Billing (Order Ready)')].MessageText;
  templateID  = temp[temp.findIndex(element => element.MessageName === 'Billing (Order Ready)')].MessageID;
  message = eval('`'+Sms+'`');
 
    Swal.fire({
      title: 'Are you sure?',
      text: message,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Send it!'
    }).then((result) => {
      if (result.isConfirmed) {
        if(data.CustomerMob) {
          this.companyService.sendSms1(phoneNo, message, templateID , senderID, msgAPIKey).subscribe(data => {
            console.log(data,'datadatadata');
        Swal.fire(
          'Send SMS',
          'Send SMS Order Ready success',
          'success'
        )})}
       
      }
    })
   
 
    
    
    }
   }
  }
}
