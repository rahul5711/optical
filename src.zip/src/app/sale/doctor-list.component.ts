import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import { PaginationService } from '../services/pagination.service';


@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html'
})
export class DoctorListComponent implements OnInit {
  term:any;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  permission= JSON.parse(localStorage.getItem('Permission'));
  editDoctorList = false;
  addDoctorList = false;
  deleteDoctorList = false;
  dataList: any;
  stringUrl: string;
  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0
  page = 4;
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private pagination: PaginationService) { }

    gridview = true; 

  ngOnInit() {
    this.spinner.show();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'DoctorList') {
             this.editDoctorList = element.Edit;
             this.addDoctorList = element.Add;
             this.deleteDoctorList = element.Delete;
           }
         });
         this.getList();
  
  }
  onPageChange(pageNum: number): void {
    this.pageSize = this.itemsPerPage*(pageNum - 1);
    }
  
    changePagesize(num: number): void {
      this.itemsPerPage = this.pageSize + num;
      }
      getList(){
        this.spinner.show()
        const dtm = {
          currentPage: this.currentPage,
          itemsPerPage: this.itemsPerPage 
        }
        this.pagination.getList('DoctorFullList', dtm).subscribe(res => {
          
          this.collectionSize = res.count;
          this.dataList = res.result;
          this.spinner.hide()
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          this.spinner.hide()
          this.showNotification(
            'bg-red',
            'Data Not Loaded.',
            'top',
            'right'
          );
        });
      }
  santizePictureList() {
    this.dataList.forEach(element => {
      element.PhotoURL = this.sanitize(element.PhotoURL);
    });
  }

  sanitize(imgName: string) {
    if (imgName !== "null" && imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
    } else {
      this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
    return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('DoctorFullList', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  // deleteItem(i){
  //   let yes = confirm("Are you sure want to delete");
  //   if (yes) {
  //   this.companyService.deleteData('Doctor', this.dataList[i].ID).subscribe(data => {
  //   this.dataList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  // }
  //   }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}


