import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-cash-register',
  templateUrl: './cash-register.component.html',
  styleUrls: ['./cash-register.component.css']
})
export class CashRegisterComponent implements OnInit {
  dispalyAllFields = false;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  filter: any = { ShopID: this.loggedInShop.ID, date1: null };

  cashRegister = { ID: null, CompanyID: this.loggedInCompany.ID, ShopID: this.loggedInShop.ID, OpeningBalance: 0.00, ClosingBalance: 0.00, OpeningBalanceCashCounter: 0.00, ClosingBalanceCashCounter: 0.00,OpeningBalancePettyCase: 0.00, ClosingBalancePettyCase: 0.00, OpenTime: null, ClosedTime: null, CreatedBy: '', UpdatedBy: '', sale: 0, Doctor: 0, Employee: 0,Fitter: 0 , Supplier: 0, customerreturn: 0, expenseCashCounter: 0, CashCounterwithdrawal: 0};
  pettyCashList: any;
  displaySubmitText = 'Open Register';
  deposit = 0;
  withdrawal = 0;
  sale = 0;
  purchase = 0;
  PaymentList: any;
  DoctorPaymentList: any;
  EmployeePaymentList: any;
  SupplierPaymentList: any;
  fitterPaymentList: any;
  deposit1 = 0;
  expense = 0;
  expenseCash = 0;
  expensePetty = 0;
  expenseCashCounter = 0;
  PettyCaseToday = 0;
  PettyCaseOld = 0;
  Doctor = 0;
  Employee = 0;
  Supplier = 0;
  Fitter = 0;
  customerreturn = 0;
  CashCounterwithdrawal = 0;
  depositpettycash = 0
  ExpenseList: any;
  constructor(private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
  ) { }

  ngOnInit() {
    this.getCashRegister();
    if (this.loggedInShop.ShopStatus === 1) { this.displaySubmitText = 'Close Register' } else { this.displaySubmitText = 'Open Register' }
  }

  getPettyCash() {
    if (this.loggedInShop.ShopStatus === 1) {
      this.filter.date1 = this.cashRegister.OpenTime;
      this.spinner.show();
      this.companyService.getSearchDataByFilterForCashRegister('PettyCash', this.filter).subscribe(data => {
        console.log(data , 'data');
        
        this.pettyCashList = data.PettyCash;
        if ( this.pettyCashList.length !== 0) {
          
        this.pettyCashList.forEach(element => {
          if (element.CreditType === 'Deposit') { this.deposit = this.deposit + element.Amount }
        
          if (element.CashType === 'PettyCash' && element.CreditType === 'Withdrawal') 
          {
            this.withdrawal = this.withdrawal + element.Amount 
           }
        
          
        });
        }

        this.PaymentList = data.PaymentMaster; 
        
        if (this.PaymentList.length !== 0) {
          
        this.PaymentList.forEach(element => {
          if (element.CreditType === 'Credit') { this.sale = this.sale + +element.PaidAmount };
          if (element.CreditType === 'Debit') { this.customerreturn = this.customerreturn + +element.PaidAmount };
        });
      }

      this.DoctorPaymentList = data.DoctorTodayPayment; 
        if (this.DoctorPaymentList.length !== 0) {
        this.DoctorPaymentList.forEach(element => {
          if (element.CreditType === 'Debit') { this.Doctor = this.Doctor + +element.PaidAmount };
        });
      }

      this.EmployeePaymentList = data.EmployeeTodayPayment; 
        if (this.EmployeePaymentList.length !== 0) {
        this.EmployeePaymentList.forEach(element => {
          if (element.CreditType === 'Debit') { this.Employee = this.Employee + +element.PaidAmount };
        });
      }

      this.fitterPaymentList = data.FitterTodayPayment; 
        if (this.fitterPaymentList.length !== 0) {
        this.fitterPaymentList.forEach(element => {
          if (element.CreditType === 'Debit') { this.Fitter = this.Fitter + +element.PaidAmount };
        });
      }

      this.SupplierPaymentList = data.SupplierTodayPayment; 
        if (this.SupplierPaymentList.length !== 0) {
        this.SupplierPaymentList.forEach(element => {
          if (element.CreditType === 'Debit') { this.Supplier = this.Supplier + +element.PaidAmount };
        });
      }

      this.ExpenseList = data.ExpenseCash;
        if(this.ExpenseList[0].Amount !== null) {
          this.expensePetty = this.ExpenseList[0].Amount

        }

        if (data.ExpenseCashCounter[0].Amount !== null) {
          
          this.expenseCashCounter = data.ExpenseCashCounter[0].Amount
        }

        if (data.PettyCashwithdrawal[0].Amount !== null) {
          
          this.CashCounterwithdrawal = data.PettyCashwithdrawal[0].Amount
        }

        if(data.PettyCashToday[0].Amount !== null) {

          this.PettyCaseToday = data.PettyCashToday[0].Amount
  
          }

          if (data.PettyCashOld[0].Amount !== null) {
            this.PettyCaseOld = data.PettyCashOld[0].Amount
            
          }
          this.spinner.hide();

      }, (err) => {
        console.log(err);
        this.spinner.hide();
      });
      
     
      
      
     
     
     
     
    

      
     
    }
  }

  

  getCashRegister() {
    this.spinner.show();
    this.companyService.getCashRegisterData().subscribe(data => {
      this.spinner.hide();
      if (data.result.length !== 0) {
        if (this.loggedInShop.ShopStatus === 1) {
          this.cashRegister = data.result[0];
        } else {
          this.cashRegister = { ID: null, CompanyID: this.loggedInCompany.ID, ShopID: this.loggedInShop.ID, OpeningBalance: data.result[0].ClosingBalance, ClosingBalance: 0.00,OpeningBalanceCashCounter: data.result[0].ClosingBalanceCashCounter, ClosingBalanceCashCounter: 0.00,OpeningBalancePettyCase: data.result[0].ClosingBalancePettyCase, ClosingBalancePettyCase: 0.00, OpenTime: null, ClosedTime: null, CreatedBy: null, UpdatedBy: null, sale: 0, Doctor: 0, Employee: 0,Fitter: 0 , Supplier: 0, customerreturn: 0, expenseCashCounter: 0, CashCounterwithdrawal: 0  };
        }
      } else {
        this.cashRegister = { ID: null, CompanyID: this.loggedInCompany.ID, ShopID: this.loggedInShop.ID, OpeningBalance: 0.00, ClosingBalance: 0.00,  OpeningBalanceCashCounter: 0.00, ClosingBalanceCashCounter: 0.00, OpeningBalancePettyCase: 0.00, ClosingBalancePettyCase: 0.00, OpenTime: null, ClosedTime: null, CreatedBy: null, UpdatedBy: null, sale: 0, Doctor: 0, Employee: 0,Fitter: 0 , Supplier: 0, customerreturn: 0, expenseCashCounter: 0, CashCounterwithdrawal: 0 };
      }
      this.getPettyCash();
    }, (err) => {
      console.log(err);
      this.spinner.hide();
    });
  }
  // sale - expenseCashCounter - Doctor - Employee - Fitter - Supplier - customerreturn - CashCounterwithdrawal
  // PettyCaseToday - expensePetty - withdrawal
  saveCashRegister() {
    let x = true;
    if (this.loggedInShop.ShopStatus === 1) {
      this.loggedInShop.ShopStatus = 0
      this.cashRegister.UpdatedBy = this.loggedInUser.Name;
      this.cashRegister.ClosingBalance = this.cashRegister.OpeningBalance + this.sale - this.expenseCashCounter - this.Doctor - this.Employee - this.Fitter - this.Supplier - this.customerreturn - this.CashCounterwithdrawal + this.PettyCaseToday - this.expensePetty - this.withdrawal;
      this.cashRegister.ClosingBalanceCashCounter = this.cashRegister.OpeningBalanceCashCounter +  this.sale - this.expenseCashCounter - this.Doctor - this.Employee - this.Fitter - this.Supplier - this.customerreturn - this.CashCounterwithdrawal;
      this.cashRegister.ClosingBalancePettyCase = this.cashRegister.OpeningBalancePettyCase + this.PettyCaseToday - this.expensePetty - this.withdrawal;
       this.cashRegister.sale = this.sale;  
       this.cashRegister.Doctor = this.Doctor;  
       this.cashRegister.Employee =  this.Employee;
       this.cashRegister.Fitter = this.Fitter; 
       this.cashRegister.Supplier =  this.Supplier; 
       this.cashRegister.customerreturn = this.customerreturn;  
       this.cashRegister.expenseCashCounter = this.expenseCashCounter; 
       this.cashRegister.CashCounterwithdrawal = this.CashCounterwithdrawal; 
      if(this.cashRegister.ClosingBalance < 0){ 
        
        alert("your closing Balance is negative. Please add any missing Petty Cash Entry before Closing the Register"); x = false }
        else {
          
      alert("your Closing Cash Balance is " + this.cashRegister.ClosingBalance);
        }
    } else {
      this.spinner.show();
      this.loggedInShop.ShopStatus = 1;
      const openingBalance = this.cashRegister.OpeningBalance;
      const openingBalanceCashCounter = this.cashRegister.OpeningBalanceCashCounter;
      const openingBalancePettyCase = this.cashRegister.OpeningBalancePettyCase;
      this.cashRegister = { ID: null, CompanyID: this.loggedInCompany.ID, ShopID: this.loggedInShop.ID, OpeningBalance: openingBalance, ClosingBalance: 0.00,OpeningBalanceCashCounter: openingBalanceCashCounter, ClosingBalanceCashCounter: 0.00,OpeningBalancePettyCase: openingBalancePettyCase, ClosingBalancePettyCase : 0.00, OpenTime: null, ClosedTime: null, CreatedBy: this.loggedInUser.Name, UpdatedBy: this.loggedInUser.Name, sale: 0, Doctor: 0, Employee: 0,Fitter: 0 , Supplier: 0, customerreturn: 0, expenseCashCounter: 0, CashCounterwithdrawal: 0 };
      this.spinner.hide();
    }

if(x){
    this.companyService.saveData('CashRegister', this.cashRegister).subscribe(data => {
      this.companyService.saveData('Shop', this.loggedInShop).subscribe(data => {
        localStorage.removeItem('LoggedINShop');
        
        localStorage.setItem('LoggedINShop', JSON.stringify(this.loggedInShop));
        this.router.navigate(['/admin/companyDashboard']);
      }, (err) => {
        console.log(err);
      });
    }, (err) => {
      console.log(err);
    });
  }
  
  }




  onSubmit() {
    this.spinner.show();

  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
