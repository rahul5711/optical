import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerListComponent } from './customer-list.component';
import { CustomerComponent } from './customer.component';
import { BillingListComponent } from './billing-list.component';
import { BillingComponent } from './billing.component';
import { DoctorManagementComponent } from './doctor-management.component';
import { DoctorListComponent } from './doctor-list.component';
import { CashRegisterComponent } from './cash-register.component';
import { CommissionComponent } from './commission.component';
import { CommissionListComponent } from './commission-list.component';
import { CommissionInvoiceComponent } from './commission-invoice.component';

const routes: Routes = [
  { path: '',
children: [
  { path: 'customer-list', component: CustomerListComponent },
  { path: 'customer/:id', component: CustomerComponent },
  { path: 'billinglist/:id', component: BillingListComponent },
  { path: 'billing/:id/:id2', component: BillingComponent },
  { path: 'doctor/:ID', component: DoctorManagementComponent },
  { path: 'doctor-list', component: DoctorListComponent },
  { path: 'commission-list/:id/:userType', component: CommissionListComponent },
  { path: 'commission-invoice/:id/:userType', component: CommissionInvoiceComponent },
  { path: 'cash-register', component: CashRegisterComponent },
  { path: 'commission', component: CommissionComponent}

]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SaleRoutingModule { }
