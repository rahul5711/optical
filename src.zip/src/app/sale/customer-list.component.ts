import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from '../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import * as XLSX from 'xlsx';
import { PaginationService } from '../services/pagination.service';
import { map, filter, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { fromEvent, Subscription } from 'rxjs';


@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css'],
})
export class CustomerListComponent implements OnInit, AfterViewInit {
  @ViewChild('searching') searching: ElementRef | any;
  
  fileName1 = 'CustomerListExcel.xlsx';
  fileName = 'Cust_Power_ListExcel.xlsx';
  
  term = "";
  page = 4;
  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0

  env = environment;
  stringUrl: string;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));

  editCustomerList = false;
  addCustomerList = false;
  deleteCustomerList = false;
  spectacleList: any;
  ExcelArray = [];

  constructor(private companyService: CompanyService,
    private snackBar: MatSnackBar,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private pagination: PaginationService) { }

  customerList: any ;
  gridview = true;
 

  ngOnInit() {
    // this.getCustomerList();
    this.permission.forEach(element => {
      if (element.ModuleName === 'CustomerList') {
        this.editCustomerList = element.Edit;
        this.addCustomerList = element.Add;
        this.deleteCustomerList = element.Delete;
      }
    });
    this.spinner.show();
    this.getList()
  }
  
  onPageChange(pageNum: number): void {
    this.pageSize = this.itemsPerPage*(pageNum - 1);
  }

  changePagesize(num: number): void {
    this.itemsPerPage = this.pageSize + num;
  }

  // getSpactacleList() {
   
  //   this.companyService.geListByOtherID('spectacle_rx', this.id).subscribe(res => {
  //     this.spectacleList = res.result;
  //   }, (err) => {
  //     console.log(err);
  //   });
  
  // }

  // getContactLensList() {
  //   this.companyService.geListByOtherID('contact_lens_rx', this.id).subscribe(res => {
  //     this.contactLensList = res.result;
  //   }, (err) => {
  //     console.log(err);
  //   });
  // }

  getList(){
    this.spinner.show()
    const dtm = {
      currentPage: this.currentPage,
      itemsPerPage: this.itemsPerPage 
    }
      this.pagination.getList('CustomerFullList', dtm).subscribe(res => { 
      this.collectionSize = res.count;
      this.customerList = res.result;
      this.spinner.hide()
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide()
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getCustomerList() {
    this.spinner.show();
    this.companyService.getExtendedCustomerListBy('CustomerFullList', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
    this.customerList = res.result;
      // this.itemsPerPage = res.itemsPerPage;
    console.log(this.customerList, ' this.customerList')
      // this.modifyExcel();
    this.spinner.hide();
      //  this.santizePictureList();
    this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  // santizePictureList() {
  //   this.customerList.forEach(element => {
  //     element.PhotoURL = this.sanitize(element.PhotoURL);
  //   });
  // }
  // sanitize(imgName: string) {
  //   if (imgName !== "null" && imgName !== '') {
  //     this.stringUrl = this.env.apiUrl + imgName;
  //   } else {
  //     this.stringUrl = this.env.apiUrl + 'no-image.jpg';
  //   }
  //   return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
  // }

  deleteItem(i) {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('Customer', this.customerList[i].ID).subscribe(data => {
          this.customerList.splice(i, 1);
          this.showNotification(
            'bg-green',
            'Data Deleted Successfully',
            'top',
            'right'
          );
        }, (err) => {
          this.showNotification(
            'bg-red',
            'Could Not Delete Data.',
            'top',
            'right'
          );
        });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }


  exportEx1(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportccc');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
    // ws['!cols'] = [];
    // ws['!cols'][0] = { hidden: true };
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
 
    /* save to file */  
    XLSX.writeFile(wb, this.fileName1);
 
  }

  
  // deleteItem(i){
  //   let yes = confirm("Are you sure want to delete");
  //   if (yes) {
  //   this.companyService.deleteData('Customer', this.customerList[i].ID).subscribe(data => {
  //   this.customerList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  // }
  //   }


  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


  ngAfterViewInit() {
    // server-side search
    this.spinner.show()
    fromEvent(this.searching.nativeElement, 'keyup').pipe(

      // get value
      map((event: any) => {
        return event.target.value;
      }),

      // if character length greater then 2
      // filter(res => res.length > 2),

      // Time in milliseconds between key events
      debounceTime(1000),

      // If previous query is different from current
      distinctUntilChanged(),
      // tap((event: KeyboardEvent) => {
      //     console.log(event)
      //     console.log(this.input.nativeElement.value)
      //   })
      // subscription for response
    ).subscribe((text: string) => {
  //  const name = e.target.value;
    let data = {
      searchQuery: text.trim(),

    }

    if(data.searchQuery !== "") {
      this.spinner.show()
      const dtm = {
        currentPage: 1,
        itemsPerPage: 50000,
        searchQuery: data.searchQuery 

      }
      this.pagination.getsearchList('CustomerFullList', dtm).subscribe(res => {
        
        this.collectionSize = res.count;
        this.customerList = res.result;
        
        this.spinner.hide()
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        this.spinner.hide()
        this.showNotification(
          'bg-red',
          'Data Not Loaded.',
          'top',
          'right'
        );
      });
    } else {
      this.getList()
    }

    });

    

  }

}
