import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { CompanyService } from '../../services/company.service';
import { PoService } from '../../services/po.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../environments/environment';
import { MatSelect } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';

@Component({
  selector: 'app-dummy-po',
  templateUrl: './dummy-po.component.html',
  styleUrls: ['./dummy-po.component.css']
})

export class DummyPoComponent implements OnInit {



  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
checkInvoiceNo = [];
  gstList: any;
  year = moment(new Date()).format('YY');
  month = moment(new Date()).format('MM');
  partycode = '';
  type = '*';
  Addinvoice: boolean;
  tempQty = 0;
  urlAss= '';

  constructor( private companyService: CompanyService,
               private poService: PoService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private spinner: NgxSpinnerService,
              private snackBar: MatSnackBar,
              private route: ActivatedRoute,
              private changeDectectorRef: ChangeDetectorRef

    // private toastrService: ToastrService,
  ) {
      // qz.api.setSha256Type(data => sha256(data));
      // qz.api.setPromiseType(resolver => new Promise(resolver));
  }
  
 
  checked = false;
  fontOptions = '1000';
  fontSize = 14;
  fontSizem = 10;
  textMargin = 0;
  margin = 0;
  marginTop = 10;
  marginTopm = 2;

  marginTops = 0;
  marginBottom = 0;
  marginLeft = 0;
  marginLeft1 = 0;
  marginRight = 0;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));

  editPurchaseList = false;
  addPurchaseList = false;
  deletePurchaseList = false;
  preOrder = false;
  chargeOptions: any;
  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  specList: any = [];
  prodList: any[];
  supplierList: any[];
  shopList: any[];
  item: any;
  charge: any;
  category = 'Product';
  disableAddButtons = false;
  barcodeList: any;
  wholedisvs = false;
  selectedItemPrint: any = { BarCode: null, ProductName: null , UnitPrice :null, UniqueBarcode: null, shopName: null, Quantity:null };
  tempItem = { Item: null, Spec: null };
  itemList = [];
  barcodeListt = []
  chargeList = [];
  historyList = [];
  data = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  selectedPurchaseMaster: any = {
    ID: null, SupplierID: null, SupplierName: null, CompanyID: null, GSTNo: null, ShopID: null, ShopName: null, PurchaseDate: null,
    PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0, DiscountAmount: 0,
    GSTAmount: 0, TotalAmount: 0, preOrder:false,
  };


  sampleitem: any = {
    ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
    Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
    DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
    WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '',  Status: 1, BrandType: false
  };


  samplecharge: any = {
    ID: null, PurchaseID: null, ChargeType: null, CompanyID: null, Description: '', Amount: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
    GSTType: '', TotalAmount: 0.00 , Status: 1 };

    gstLock = false;
    gstperLock = false;
  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
    gstdividelist = [];
    sgst = 0;
    cgst = 0;
    details = [];

  ngOnInit() {
    this.searchData();

    if (this.loggedInCompany.WholeSale === 'true' ) {
      this.sampleitem.WholeSalePrice = 0 
    }else{
      this.sampleitem.WholeSalePrice = 0;
    }
    if (this.loggedInCompany.RetailPrice === 'true' ) {
      this.sampleitem.RetailPrice = ''
    }else{
      this.sampleitem.RetailPrice = 0;
    }
    if (this.id == 0){
      this.selectedPurchaseMaster.PurchaseDate = moment().format('YYYY-MM-DD');
    }

    this.onPageLoad();
    // console.log(this.year , this.month , 'month');
    if (this.loggedInCompany.WholeSale === 'true'  ) {
      this.item.WholeSale = true;
      this.wholedisvs = true
    
    } else {
      this.item.WholeSale = false
      this.wholedisvs = true

    }
    
    if (this.loggedInCompany.WholeSale === 'true' && this.loggedInCompany.RetailPrice === 'true') {
      this.item.WholeSale = false;
      this.wholedisvs = false
    }
    
    // if (this.loggedInCompany.RetailPrice === 'true' ) {
    //   this.item.WholeSale = false;
    //   this.wholedisvs = false

    // } else{
    //   this.item.WholeSale = true;
    //   this.wholedisvs = true

    // }
    this.item.BrandType = false
  }

  onPageLoad(){
    this.spinner.show();
       this.permission.forEach(element => {    
      if (element.ModuleName === 'PurchaseList') {
             this.editPurchaseList = element.Edit;
             this.addPurchaseList = element.Add;
             this.deletePurchaseList = element.Delete;
           }
         });
    if (this.id !== 0) {
      this.spinner.show();
      this.poService.getPurchaseFullDataByID(this.id).subscribe(data => {
        this.selectedPurchaseMaster = data.result.PurchaseMaster;
        this.selectedPurchaseMaster.SupplierName = data.result.PurchaseMaster.SupplierName ? data.result.PurchaseMaster.SupplierName: data.result.PurchaseMaster.Sname;
        this.itemList = data.result.PurchaseDetail;
        this.chargeList = data.result.Charge;
        console.log( data);
        
        // if(this.supplierList[index].Sno !== null) {
        //   this.partycode = this.supplierList[index].Sno;
        //   } else {
        //     this.partycode = '0'; 
        //   }
        this.calculateGrandTotal();

        // this.item.GSTType = this.itemList[0].GSTType;
      this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        this.spinner.hide();

        // this.showFailure(err, 'Error Loading Data.');
        
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    } else {
      this.selectedPurchaseMaster.PurchaseDate = moment(new Date()).format('YYYY-MM-DD');
    }

    this.getProductList();
    this.getGstList();
        this.getSupplierList();
    this.getShopList();
    this.getChargerOptions();
    this.item = this.sampleitem;
    this.charge = this.samplecharge;
    
    this.showNotification(
      'bg-green',
      'Data Loaded successfully',
      'top',
      'right'
    );
    if(this.id == 0) {
      this.spinner.hide();

    }
    // this.initQZ();
  }

  deleteItem(category, i){
    if (category === "Product"){
      if (this.itemList[i].ID === null){
        this.itemList.splice(i, 1);
      } else {
        this.itemList[i].Status = 0;
        this.calculateGrandTotal();
      }

    } else if (category === "Charge"){
      if (this.chargeList[i].ID === null){
        this.chargeList.splice(i, 1);
      } else {
        this.chargeList[i].Status = 0;
      }
    }
    this.calculateGrandTotal();
  }

  

  RestoreProduct(category, i) {
    this.itemList[i].Status = 1;
    this.calculateGrandTotal();

  }

  selectItem(i){
    this.item = this.itemList[i];
    this.category = 'Product';
    this.selectedProduct = this.item.ProductTypeName;
  }

  selectCharge(i){
    this.charge = this.chargeList[i];
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product',1).subscribe(data => {
      this.prodList = data.result;
      
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  paymentHistory(){
    this.spinner.show();
    this.companyService.geListByOtherID('PaymentHistory' ,this.id).subscribe(data => {
      this.historyList = data.result;
      this.spinner.hide();
    }, (err) => { console.log(err);
                  this.spinner.hide();
                 
    });
  }

  onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === 1) {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == 2) {
      event = event.toTitleCase()
    }
    return event;
  }

  getChargerOptions(){
    this.companyService.getShortListByCompany('ChargerMaster',1).subscribe(data => {
      this.chargeOptions = data.result;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => { 
      this.gstList = data.result;
      this.gstdividelist = [];
      data.result.forEach(ele => {
     
        if(ele.Name.toUpperCase() !== 'CGST-SGST'){
          let obj = {GstType: '', Amount: 0};
          obj.GstType = ele.Name;
          this.gstdividelist.push(obj);

        }
      })
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      // this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  setValues(){
    this.chargeOptions.forEach(element => {
        if (element.ID === this.charge.ChargeType){
      this.charge.Price = element.Price;
      this.charge.Description = element.Description;
      this.charge.GSTAmount = element.GSTAmount;
      this.charge.GSTPercentage = element.GSTPercentage;
      this.charge.GSTType = element.GSTType;
      this.charge.TotalAmount = element.TotalAmount;
        }
    });
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier',1).subscribe(data => {
      this.supplierList = data.result;
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  calculateFields2(fieldName, mode) { 
    if(this.item.GSTType !== "") {
      this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
      if (fieldName === 'DiscountPercentage') { 
        this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
        // this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - +this.item.DiscountAmount;
      }
      if (fieldName === 'DiscountAmount') { 
        this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity/100; 

        
        // this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount;
      }
      // this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity/100; 
      this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - +this.item.DiscountAmount;
      this.item.GSTAmount =
            (+this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
            this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount;
    }
  }


  calculateFields(fieldName, mode) {
  if(isNaN(Number(this.item.UnitPrice)) === true) {
    alert("please fill up integer value");
    this.item.UnitPrice = 0;
  }
  if(isNaN(Number(this.item.Quantity)) === true) {
    alert("please fill up integer value");
    this.item.Quantity = 0;
  } 
  if(isNaN(Number(this.item.DiscountPercentage)) === true) {
    alert("please fill up integer value");
    this.item.DiscountPercentage = 0;
  }
  if(isNaN(Number(this.item.DiscountAmount)) === true) {
    alert("please fill up integer value");
    this.item.DiscountAmount = 0;
  }
  if(isNaN(Number(this.item.GSTPercentage)) === true) {
    alert("please fill up integer value");
    this.item.GSTPercentage = 0;
  }
  if(isNaN(Number(this.item.GSTAmount)) === true) {
    alert("please fill up integer value");
    this.item.GSTAmount = 0;
    this.item.GSTPercentage = 0;
  } else {
    switch (mode) {
      case 'subTotal':
        this.item.SubTotal = +this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount;
        break;
      case 'discount':
        if (fieldName === 'DiscountPercentage') { 
          if(Number(this.item.DiscountPercentage) > 100 ) {
            alert("you can't give 100% above discount");
            this.item.DiscountPercentage = 0;
            this.item.DiscountAmount = 0;
            this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount;
          } else {
          this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
          // this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity; 

          this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - +this.item.DiscountAmount;
          }
        }
        if (fieldName === 'DiscountAmount') {
          if(Number(this.item.DiscountAmount) > Number(this.item.SubTotal)) {
            alert("you can't give SubTotal above discount");
            this.item.DiscountAmount = 0
           
          }else{
            this.item.DiscountPercentage = 100 * +this.item.DiscountAmount / (+this.item.Quantity * +this.item.UnitPrice);
            // this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
            this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount;
          }
          // this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity/100; 
        

        }
        break;
      case 'gst':
        if (fieldName === 'GSTPercentage') {
          if(Number(this.item.GSTPercentage) > 100 ) {
            alert("you can't give 100% above discount");
            this.item.GSTAmount = 0;
          }
            else{
              this.item.GSTAmount =(+this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
            }
         
        }
        if (fieldName === 'GSTAmount') {
          this.item.GSTPercentage =100 * +this.item.GSTAmount / (+this.item.SubTotal);
        }
        break;

        case 'chgst':
          if (fieldName === 'GSTPercentage') {
            this.charge.GSTAmount = (+this.charge.Price) * +this.charge.GSTPercentage / 100;
          }
          if (fieldName === 'GSTAmount') {
            this.charge.GSTPercentage = 100 * +this.charge.GSTAmount / (+this.charge.Price);
          }
          break;
      case 'total':
        this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount;
        break;
        case 'chtotal':
          this.charge.TotalAmount = +this.charge.Price + +this.charge.GSTAmount;
          break;
    }
    if(this.item.GSTType !== "") {
      this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
      this.item.GSTAmount =
      (+this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
      this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount;

    }

    this.item.GSTAmount = this.convertToDecimal(+this.item.GSTAmount, 2);
    this.item.GSTPercentage = this.convertToDecimal(+this.item.GSTPercentage, 0);
    this.item.DiscountAmount = this.convertToDecimal(+this.item.DiscountAmount, 2);
    this.item.DiscountPercentage = this.convertToDecimal(+this.item.DiscountPercentage, 0);
    this.item.TotalAmount = this.convertToDecimal(+this.item.TotalAmount, 2);
    this.item.SubTotal = this.convertToDecimal(+this.item.SubTotal, 2);

    // this.item.GSTAmount = +this.item.GSTAmount.toFixed(2);
    // this.item.GSTPercentage = +this.item.GSTPercentage.toFixed(0);
    // this.item.DiscountAmount = +this.item.DiscountAmount.toFixed(2);
    // this.item.DiscountPercentage = +this.item.DiscountPercentage.toFixed(0);
    // this.item.TotalAmount = +this.item.TotalAmount.toFixed(2);
    // this.item.SubTotal = +this.item.SubTotal.toFixed(2);

    // this.calculateFields2(fieldName, mode);
  }
  }


  convertToDecimal(num, x) {
    return Number(Math.round(parseFloat(num + 'e' + x)) + 'e-' + x);
  }


  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  addItem() {
    // this.spinner.show();

    // this.tempItem.Item = this.item;
    // this.tempItem.Spec = this.specList;
    if (this.category === 'Product'){
      if (this.selectedPurchaseMaster.ID !== null){this.item.Status = 2; }
      this.item.ProductName = "";
      this.item.ProductExpDate = "0000-00-00";
      this.specList.forEach(element => {
if(element.SelectedValue !== "") {
        this.item.ProductName = this.item.ProductName  + element.SelectedValue + "/";
}
        if(element.FieldType === "Date") {
          this.item.ProductExpDate = element.SelectedValue;
        }

    });
 
      this.item.ProductName = this.item.ProductName.substring(0, this.item.ProductName.length - 1);
      this.item.BaseBarCode = null;
      this.item.NewBarcode = null;
      this.companyService.getExistingProduct(this.item).subscribe(data => {
        const x = data.result;

        if(this.id === 0){
          this.checkInvoicNo();
        }
        if(x[0].BaseBarCode !== null) {
          this.item.BaseBarCode = null;
          this.item.NewBarcode = null;
        }
        if (x.length > 0 && x[0].CompanyID !== null && x[0].BaseBarCode !== null){ 
          this.item.BaseBarCode = x[0].BaseBarCode;
          this.item.NewBarcode = x[0].MaxBarcode;
          // alert('This product with the same Retail Price was added previously. Existing Barcode series will be used');
          if(this.item.Quantity !== 0) {
          Swal.fire({
            icon: 'error',
            title: 'This product with the same Retail Price was added previously. Existing Barcode series will be used',
            text: ' ',
            footer: ''
          });
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Please Enter Quantity',
            text: ' ',
            footer: ''
          });
        }
                          }
        this.item.Spec = this.specList;
        let NewBarcode = '';
        if(this.loggedInCompanySetting.year === 'true') {
          NewBarcode = NewBarcode.concat(this.year);
        }  
        if (this.loggedInCompanySetting.month === 'true') {
          NewBarcode = NewBarcode.concat(this.month);

        } 
        if (this.loggedInCompanySetting.partycode === 'true') {
          NewBarcode = NewBarcode.concat(this.partycode);
        }
         if (this.loggedInCompanySetting.type === 'true' && this.item.GSTType !== 'None' && this.item.GSTPercentage !== 0 ) {
          NewBarcode = NewBarcode.concat(this.type);
        }
        if (this.loggedInCompanySetting.type === 'true' && this.item.GSTType === 'None' && this.item.GSTPercentage === 0 ) {
          NewBarcode = NewBarcode.concat("/");
        }
        NewBarcode = NewBarcode.concat(this.partycode);
        let unitpReverse = this.item.UnitPrice.toString().split('').reverse().join('').toString();
        NewBarcode = NewBarcode.concat(unitpReverse);
        NewBarcode = NewBarcode.concat(this.partycode);
        this.item.UniqueBarcode = NewBarcode;
        if(this.item.GSTPercentage === 0 || this.item.GSTPercentage === '0' ) {
          this.item.GSTType = 'None';
        }
        let DQty = 0;
        if (this.item.Quantity !== 0 && this.item.Quantity !== "0") {
        

        this.itemList.forEach(ele => {
          if(ele.ID === null) {
            if(ele.ProductName === this.item.ProductName && ele.RetailPrice === this.item.RetailPrice && ele.UnitPrice === this.item.UnitPrice) {
              ele.Quantity = Number(ele.Quantity) + Number(this.item.Quantity);
              ele.SubTotal = Number(ele.SubTotal) + Number(this.item.SubTotal);
              ele.TotalAmount = Number(ele.TotalAmount) + Number(this.item.TotalAmount);
              ele.GSTAmount = Number(ele.GSTAmount) + Number(this.item.GSTAmount);
              ele.DiscountAmount = Number(ele.DiscountAmount) + Number(this.item.DiscountAmount);
              DQty = 1;
            }
          }
        })
        if(DQty === 0){
          this.itemList.unshift(this.item);
        }

        }

        this.calculateGrandTotal();
        this.tempItem = { Item: null, Spec: null };
        DQty = 0
        if (this.gstLock === false && this.gstperLock === false ) {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:false, BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };
        } else if (this.gstLock === true && this.gstperLock === false) {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: this.item.GSTType, TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:false,BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };

        } else if (this.gstLock === false && this.gstperLock === true) {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: this.item.GSTPercentage, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:false, BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };
        } else {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: this.item.GSTPercentage, GSTAmount: 0.00, GSTType: this.item.GSTType, TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:false, BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };
            this.item.BaseBarCode = null;
            this.item.NewBarcode = null;  
            
        }
        if(this.loggedInCompany.WholeSale === 'true'){
          if (this.item.WholeSale === false || this.item.WholeSale === 'false' ) {
             this.item.WholeSale = true;
          } 
        }
 
// if(this.item.WholeSale === true ){
//     this.item.WholeSale = true;
//   }
//    if(this.item.WholeSale === false){
//     this.item.WholeSale = false;
//   }
        if (this.selectedProduct !== null || this.selectedProduct !== '') {
          this.prodList.forEach(element => {
              if (element.Name === this.selectedProduct){ this.item.ProductTypeID = element.ID; }
            });

          }

            // this.selectedProduct = '';
            // this.specList = [];
        

        // this.selectedProduct = "";
        // this.specList = [];
        this.specList.forEach(element => {
          if(element.CheckBoxValue === false || element.CheckBoxValue === undefined) {
            element.SelectedValue = '';
          } else {
            element.SelectedValue = element.SelectedValue;
          }
        });

       }, (err) => {
         console.log(err);
       });
  }

    if (this.category === 'Charges'){
      if (this.selectedPurchaseMaster.ID !== null){this.charge.Status = 2; }
      this.charge.ID = null;
      this.chargeList.push(this.charge);
      this.calculateGrandTotal();
      this.charge = {
      ID: null, ChargeType: null, CompanyID: null, Description: '', Amount: 0.00, Price: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
      GSTType: '', TotalAmount: 0.00, Status: 1 };
  }
  this.calculateGrandTotal();
 
  


  }

  notifyGst() {
    if(this.item.GSTPercentage !== 0 && this.item.GSTPercentage !== "0") {
     if(this.item.GSTType === 'None') {
      alert("please select GstType");
     }
    }
  }

  calculateGrandTotal(){
    this.selectedPurchaseMaster.Quantity = 0;
    this.selectedPurchaseMaster.SubTotal = 0;
    this.selectedPurchaseMaster.DiscountAmount = 0;
    this.selectedPurchaseMaster.GSTAmount = 0;
    this.selectedPurchaseMaster.TotalAmount = 0;
    this.sgst = 0;
    this.cgst = 0;
    this.gstdividelist.forEach(ele => {
        ele.Amount = 0;
    })
    this.itemList.forEach(element => {
      if (element.Status !== 0){
      this.selectedPurchaseMaster.Quantity = +this.selectedPurchaseMaster.Quantity + +element.Quantity;
      this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.SubTotal;
      this.selectedPurchaseMaster.DiscountAmount = +this.selectedPurchaseMaster.DiscountAmount + +element.DiscountAmount;
      this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
      this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
      this.gstdividelist.forEach(ele => {
        if(element.GSTType === ele.GstType && element.Status !== 0 && element.GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(element.GSTAmount);
        }
      })
      if(element.Status !== 0 && element.GSTType.toUpperCase() === 'CGST-SGST') {
       
         this.sgst +=  Number(element.GSTAmount) / 2 ;
         this.cgst +=  Number(element.GSTAmount) / 2 ;

      }
    });

    // this.chargeList.forEach(element => {
    //   if (element.Status !== 0){
    //     if(element.ID === null) {
    //       this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.Price;

    //     } else {
    //       this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.Amount;

    //     }
    //   this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
    //   this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
    //   }
    //   this.gstdividelist.forEach(ele => {
    //     if(element.GSTType === ele.GstType && element.Status !== 0 && element.GSTType.toUpperCase() !== 'CGST-SGST') {
    //       ele.Amount += Number(element.GSTAmount);
    //     } 
    //   })
    //    if(element.Status !== 0 && element.GSTType.toUpperCase() === 'CGST-SGST') {
    //     this.sgst +=  Number(element.GSTAmount) / 2 ;
    //     this.cgst +=  Number(element.GSTAmount) / 2 ;
    //   }
    // });
    
  }


  getSupplierDetails(event) {
    const index = this.supplierList.findIndex(element => element.Name === event.value);
    this.selectedPurchaseMaster.SupplierID = this.supplierList[index].ID;
    this.selectedPurchaseMaster.SupplierName = this.supplierList[index].Name;
    this.selectedPurchaseMaster.GSTNo = this.supplierList[index].GSTNo;

    if(this.supplierList[index].Sno !== null) {
    this.partycode = this.supplierList[index].Sno;
    } else {
      this.partycode = '0'; 
    }
  }

  // getPreorderPurchaseList(){
  //   this.companyService.getPreorderPurchaseList('Purchase', this.selectedPurchaseMaster.SupplierID, this.selectedPurchaseMaster.ShopID).subscribe(data => {
  //    this.itemList = data.result;
  //     this.spinner.hide();
  //     this.showNotification(
  //       'bg-green',
  //       'Data Loaded successfully',
  //       'top',
  //       'right'
  //     );
  //   }, (err) => {
  //     console.log(err);
  //     // this.showFailure(err, 'Error Loading Data.');
  //     this.spinner.hide();
  //     this.showNotification(
  //       'bg-red',
  //       'Error Loading Data.',
  //       'top',
  //       'right'
  //     );
  //   });
  // }

  getfieldList() {
    if (this.selectedProduct !== null || this.selectedProduct !== '') {
    this.prodList.forEach(element => {
        if (element.Name === this.selectedProduct){ 
          this.item.ProductTypeID = element.ID; 
          this.item.GSTPercentage = element.GSTPercentage;
          this.item.GSTType = element.GSTType;
        }
      });
    
    this.item.ProductTypeName = this.selectedProduct;
   
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
        this.specList = data.result;
        this.getSptTableData();
        this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
       
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  displayAddField(i) {
    this.specList[i].DisplayAdd = 1;
    this.specList[i].SelectedValue = '';

  }

  saveFieldData(i) {
    this.specList[i].DisplayAdd = 0;
    let count = 0;
    this.specList[i].SptTableData.forEach(element => {
      if (element.TableValue.toLowerCase() === this.specList[i].SelectedValue.toLowerCase()) { count = count + 1; }

    });
    if (count !== 0 || this.specList[i].SelectedValue === '') { 
      // alert("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: ' ',
        footer: ''
      });
     } else {
      const Ref = this.specList[i].Ref;
      let RefValue = 0;
      if (Ref !== 0) {
        this.specList.forEach((element, j) => {
          if (element.FieldName === Ref) { RefValue = element.SelectedValue; }
        });
      }

      this.spinner.show();
      this.companyService.saveProductSupportData(this.specList[i].SelectedValue, RefValue, this.specList[i].SptTableName)
        .subscribe(data => {
          this.companyService.getProductSupportData(this.specList[i].SptTableName, RefValue).subscribe(data1 => {
            this.specList[i].SptTableData = data1.result;
            this.specList[i].SptFilterData = data1.result;
            this.spinner.hide();
            this.showNotification(
              'bg-green',
              'Data Saved successfully',
              'top',
              'right'
            );
          }, (err) => {
            console.log(err);
            // this.showFailure(err, 'Error Loading Data.');
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Error not saved Data.',
              'top',
              'right'
            );
          });
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Data not saved.',
            'top',
            'right'
          );
        });
    }

  }

  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 14) {
      this.addItem();
    }
    if (event.keyCode === 17) {
      this.onSubmit();
    }
  }

  onSubmit() {

  if(this.selectedPurchaseMaster.preOrder !== true ) {
     
    this.spinner.show();
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.PurchaseDetail = JSON.stringify(this.itemList);

    this.data.Charge = this.chargeList;
    // this.spinner.hide();
  
    alert("If there is a lot of items, then press the top side back button, your data will be saved in the back side process and you should check the view product inventory of product save")
   
    this.poService.savePurchase('Purchase', this.data).subscribe(data1 => {
    
      this.spinner.hide();
      if(this.selectedPurchaseMaster.preOrder === 'true') {
        this.router.navigate(['/inventory/preorderlist']);
        this.spinner.hide();
  
      }
      else {
      this.router.navigate(['po/dummypo-list' , data1.pMasterID]);
      }
      this.id = data1.pMasterID;
      this.poService.getPurchaseFullDataByID(data1.pMasterID).subscribe(data => {
        this.selectedPurchaseMaster = data.result.PurchaseMaster;
        this.itemList = data.result.PurchaseDetail;
        this.chargeList = data.result.Charge;
        this.selectedProduct = "";
        this.specList = [];
        this.item.GSTType = "";
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    }); 
  } else {
    this.spinner.show();
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.PurchaseDetail = JSON.stringify(this.itemList);
    this.data.PurchaseMaster.page = 'purchase';
    this.data.Charge = this.chargeList;
    this.poService.savePurchase('Purchase', this.data).subscribe(data1 => {
      // this.showNotification(
      //   'bg-green',
      //   'Data save po successfully',
      //   'top',
      //   'right'
      // );
      this.spinner.hide();
        this.router.navigate(['/inventory/preorderlist']);
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    }); 
  }
  
  }

  updatedPurchase(){
    this.spinner.show();
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.Charge = this.chargeList;
    let items = [];
    this.itemList.forEach(ele => {
      if(ele.ID === null || ele.Status == 0 && ele.UpdatedBy === null) {
        ele.UpdatedBy = this.loggedInUser.ID;
        items.push(ele);
      }
    })
    this.data.PurchaseDetail = JSON.stringify(items);
if(items.length !== 0) {
  alert("If there is a lot of items, then press the top side back button, your data will be saved in the back side process and you should check the view product inventory of product save")
  
    this.poService.updatePurchase('Purchase', this.data).subscribe(data1 => {
      this.id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
      this.onPageLoad();
      this.item.UnitPrice = 0;
      this.item.Quantity = 0;
      this.item.DiscountPercentage = 0;
      this.item.DiscountAmount = 0;
      this.item.SubTotal = 0;
      this.item.GSTPercentage = 0;
      this.item.GSTAmount = 0;
      this.item.GSTType = null;
      this.item.TotalAmount = 0;
      this.item.RetailPrice = '';
      this.item.WholeSalePrice = 0;
      this.selectedProduct = "";
      this.specList = [];
      this.item.GSTType = "None";
      this.item.UniqueBarcode = '';
      this.selectedProduct = '';
      // this.router.navigate(['/inventory/purchaselist']);
      // this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    });
  } else {
    // this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    // this.data.PurchaseMaster = this.selectedPurchaseMaster;
    // this.data.Charge = this.chargeList;
    // const index = this.supplierList.findIndex(element => element.ID === this.selectedPurchaseMaster.SupplierID);
 
    // if(this.supplierList[index].Sno !== null) {
    // this.partycode = this.supplierList[index].Sno;
    // } else {
    //   this.partycode = '0'; 
    // }
    // this.itemList.forEach(ele => {
    //   let NewBarcode = '';
    //   if(this.loggedInCompanySetting.year === 'true') {
    //     NewBarcode = NewBarcode.concat(this.year);
    //   }  
    //   if (this.loggedInCompanySetting.month === 'true') {
    //     NewBarcode = NewBarcode.concat(this.month);

    //   } 
    //   if (this.loggedInCompanySetting.partycode === 'true') {
    //     NewBarcode = NewBarcode.concat(this.partycode);
    //   }
    //    if (this.loggedInCompanySetting.type === 'true' && ele.GSTType !== 'None' && ele.GSTPercentage !== 0 ) {
    //     NewBarcode = NewBarcode.concat(this.type);
    //   }
    //   if (this.loggedInCompanySetting.type === 'true' && ele.GSTType === 'None' && ele.GSTPercentage === 0 ) {
    //     NewBarcode = NewBarcode.concat("/");
    //   }
    //   NewBarcode = NewBarcode.concat(this.partycode);
    //   let unitpReverse = ele.UnitPrice.toString().split('').reverse().join('').toString();
    //   NewBarcode = NewBarcode.concat(unitpReverse);
    //   NewBarcode = NewBarcode.concat(this.partycode);
    //   ele.UniqueBarcode = NewBarcode;
    // })
    // this.data.PurchaseDetail = JSON.stringify(this.itemList);
    // console.log(this.itemList,'SupplierIDSupplierID');
    
    // PurchaseOne
    this.poService.updatePurchase('Purchase', this.data).subscribe(data1 => {
      this.id = parseInt(this.route.snapshot.paramMap.get('id'), 10);

      this.onPageLoad();
      this.item.UnitPrice = 0;
      this.item.Quantity = 0;
      this.item.DiscountPercentage = 0;
      this.item.DiscountAmount = 0;
      this.item.SubTotal = 0;
      this.item.GSTPercentage = 0;
      this.item.GSTAmount = 0;
      this.item.GSTType = null;
      this.item.TotalAmount = 0;
      this.item.RetailPrice = '';
      this.item.WholeSalePrice = 0;
      this.selectedProduct = "";
      this.specList = [];
      this.item.GSTType = "None";
      this.item.UniqueBarcode = '';
      this.selectedProduct = '';
    
      // this.router.navigate(['/inventory/purchaselist']);
      // this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    });
    this.spinner.hide();

  }
  }


  checkInvoicNo() {
    let Param = {"SupplierName": this.selectedPurchaseMaster.SupplierName , InvoiceNo: this.selectedPurchaseMaster.InvoiceNo.trim()};
    // console.log(Param , 'InvoiceNo');
    this.companyService.getcheckInvoicNo(JSON.stringify(Param)).subscribe(data1 => {
      this.checkInvoiceNo = data1.data;
      if (this.checkInvoiceNo.length !== 0) {
        
        Swal.fire({
          icon: 'error',
          title: 'Duplicate InvoiceNo not Allowed',
          text: '',
          footer: ''
        });
        this.selectedPurchaseMaster.InvoiceNo = null;
      }      
    }, (err) => {
      console.log(err);      
    });
  }
   //  printer

  



 




  // get getBarcodelist
  getBarcodelist(data){
    this.companyService.getSearchBarCodeFilter(data.ID, true, '').subscribe(data => {
      this.barcodeList = data.data;
      this.tempQty = 0;

      this.barcodeList.forEach(element => {
        this.getPrintBySelectedItem(element);
      });
    }, (err) => {
      console.log(err);
    });

  }

  allPrint() {
    this.itemList.forEach(ele => {
      this.getBarcodelist(ele);
    })
  }

  getPrintBySelectedItem(data){
    
    // this.selectedItemPrint.Quantity = data.Quantity;
    // this.tempQty = this.tempQty + 1; 

    this.selectedItemPrint.BarCode = data.Barcode;
    this.selectedItemPrint.ProductName = data.ProductName.split("/")[1];
    this.selectedItemPrint.ProductNames = data.ProductName.split("/")[2].substr(0, 15);
    this.selectedItemPrint.retailprice = data.RetailPrice;
    this.selectedItemPrint.uniqueBarcode = data.UniqueBarcode;
    this.selectedItemPrint.shopName = data.BarcodeShopName;

    this.changeDectectorRef.detectChanges();
 
    console.log('THISISMYDATA', this.tempQty);

 
  }
  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

  barcodePrint(data) {
    this.spinner.show();
    this.companyService.getSearchBarCodeFilter(data.ID, true, '').subscribe(data => {
      this.companyService.BarcodePrint('barcodePrint', data.data[0]).subscribe(data => {
        this.spinner.hide();
        const url =  data;
        window.open(url, "_blank");
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    }, (err) => {
      console.log(err);
    });
  }

  barcodePrintAll() {
  if(this.barcodeListt.length != 0) {
   let tempItem = [];
   let len = 0;
   this.spinner.show();
    this.barcodeListt.forEach(ele => {
      if(ele.Status !== 0) {
        len = len + 1;
      this.companyService.getSearchBarCodeFilter(ele.ID, true, '').subscribe(data => {
        if(data.data.length != 0) {        
          tempItem.push(data.data[0]);
        } else {
          len = len - 1;
        }
        if(len === tempItem.length) {
          this.companyService.BarcodePrintAll('barcodePrint', tempItem).subscribe(data => {
            this.spinner.hide();
            const url =  data;
            window.open(url, "_blank");
          }, (err) => {
            console.log(err);
            this.showNotification(
              'bg-red',
              'Error Loading Data',
              'top',
              'right'
            );
          });

        }

      }, (err) => {
        console.log(err);
      });
    }
    })
  } else {
    alert('please select product');
  }

    
  }

  selectBarcode(type) {
 if(type === 'all') {
   if(this.checked === true) {
     this.checked = false;
   } else {
    this.checked = true;

   }
   this.barcodeListt = [];

   this.spinner.show();
   this.itemList.forEach((ele, i) => {
     if(this.checked === true) {
     if(ele.Status !== 0) {
      ele.Checked = 1;
      ele.index = i;
      this.barcodeListt.push(ele);
     }
     } else {
      ele.Checked = 0;
      this.barcodeListt = [];

     }
   })
   this.spinner.hide();

 }
  }

  PoPDF(){
    
    let data1: any = { Shop: this.loggedInShop, Company: this.loggedInCompanySetting, selectedPurchaseMaster:this.selectedPurchaseMaster,sampleitem:this.sampleitem, samplecharge:this.samplecharge ,itemList:[] }
    this.itemList.forEach(e => {
      if (e.Status === 1) {
        data1.itemList.push(e)
      }
    })
   
    this.spinner.show();
    this.companyService.PurchasePDF(' ', data1).subscribe(data => {
      this.spinner.hide();
      const url = this.env.apiUrl + data;
      this.urlAss = url;
      window.open(url, "_blank");

    }, (err) => { console.log(err);
               
    });
  }
  getBarCodeList(index) {
    let searchString = "";
  let don = "/";
    this.specList.forEach((element, i) => {
      if (element.SelectedValue !== '') {
        searchString = searchString + don + element.SelectedValue;
      }else{
        searchString = searchString  + element.SelectedValue;
      }
    });
    this.details.forEach(e=>{
      if(e.ProductName ===  searchString.substring(1)){
        this.item.UnitPrice = e.UnitPrice
      }
      console.log(this.item.UnitPrice);
    })
  }
  singleSelectBarcode(i) {
    if(this.itemList[i].Checked === false || this.itemList[i].Checked === 0 ) {
      this.itemList[i].index = i;
      this.barcodeListt.push(this.itemList[i]);

    } else if(this.itemList[i].Checked === true || this.itemList[i].Checked === 1 ) {
      // this.barcodeListt.forEach(el => {
      //   if(this.itemList[i].ID === el.ID) {
      //     this.barcodeListt.splice(el, 1);
      //   }
      // })

      this.barcodeListt.forEach((el, iind)=> {
        if(this.barcodeListt[iind].index === i) {
          this.barcodeListt.splice(iind, 1);
        }
      })
     

    }
    console.log(this.barcodeListt);

  }

  
  searchData() {
    let whereList = '';
    this.details = []
    this.companyService.getGenericListByParem('PreorderfullList', whereList ).subscribe(data => {
    
    this.details = data.result
    
console.log( this.details);


    }, (err) => {
      console.log(err);
    });
  }
  

}
