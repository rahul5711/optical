import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fitter-po',
  templateUrl: './fitter-po.component.html',
  styleUrls: ['./fitter-po.component.sass']
})
export class FitterPoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
