import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DummyPoListComponent } from './dummy-po-list/dummy-po-list.component';
import { DummyPoComponent } from './dummy-po/dummy-po.component';
import { FitterPoComponent } from './fitter-po/fitter-po.component';
import { SupplierPoListComponent } from './supplier-po-list/supplier-po-list.component';
import { SupplierPoComponent } from './supplier-po/supplier-po.component';

const routes: Routes = [
  { path: '',
  children: [
    { path: 'supplierpo', component: SupplierPoComponent },
    { path: 'fitterpo', component: FitterPoComponent },
    { path: 'supplierpo-list', component: SupplierPoListComponent },
    { path: 'dummypo-list/:id', component: DummyPoComponent},
    { path: 'dummypo-list', component: DummyPoListComponent},

  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PoRoutingModule { }
