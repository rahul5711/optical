import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from 'src/app/services/admin.service';
import { CompanyService } from 'src/app/services/company.service';
import { PaginationService } from 'src/app/services/pagination.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-supplier-po',
  templateUrl: './supplier-po.component.html',
  styleUrls: ['./supplier-po.component.css']
})
export class SupplierPoComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  term = "";
  supplierList: any;
  shopList: any;
  searchValue: any;
  modex = "";
  savedb = false;
  ChangeUnitPrice = false;
  filtersList: any;
  details = [];
  urlAss= '';
  supplier = 'All';
  supplierID: any;
  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0
  productList: any;
  UnitPrice = '';
  Barcode = '';

  constructor(
    private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private toastrService: ToastrService,
    private pagination: PaginationService
  ) { }
  btnUnassigned = false;
  btnAssigned = false;
  mode = "Unassigned";
  editlist = false;
  filter = { FromDate: '', ToDate: '',supplier :'All',ShopID:'All' }
  printData: any = { supplier: null, filterList: null, supplierList:null, loggedInShop: null, loggedInCompany: null, loggedInCompanySetting: null };

  ngOnInit(): void {

    this.Search(this.mode)
    this.getSupplierList();
    this.getShopList();


  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 1).subscribe(data => {
      this.supplierList = data.result;
    }, (err) => {
      console.log(err);
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();

    });
  }

  Search(mode: any) {
    this.spinner.show();
    this.btnFn(mode);

    let whereList = '';
    if (this.filter.FromDate !== '' && this.filter.FromDate !== null) {
      let FromDate = moment(this.filter.FromDate).format('YYYY-MM-DD')
      whereList = whereList + ' and BillMaster.BillDate between ' + `'${FromDate}'`;
    }
    if (this.filter.ToDate !== '' && this.filter.ToDate !== null) {
      let ToDate = moment(this.filter.ToDate).format('YYYY-MM-DD')
      whereList = whereList + ' and ' + `'${ToDate}'`;
    }
    if (this.filter.supplier !== null &&  this.filter.supplier !== 'All'){
      whereList = whereList + ' and BarcodeMaster.SupplierID = ' +  this.filter.supplier ; }

      if (this.filter.ShopID !== null &&  this.filter.ShopID !== 'All' &&  this.filter.ShopID !== 'Other' &&  this.filter.ShopID !== 'Main') {
        whereList = whereList + ' and BarcodeMaster.ShopID = ' + this.filter.ShopID;
      }
    console.log(whereList);


    const dtm = {
      where: whereList,
      currentPage: this.currentPage,
      itemsPerPage: this.itemsPerPage,
      shop: this.filter.ShopID,
    }

    this.pagination.getPreOrderStatus(mode, dtm).subscribe(data => {
    this.spinner.show();

      this.collectionSize = data.count;
     this.productList= data.result;
     console.log( this.productList, 'po');
     this.spinner.hide();

    }, (err) => {
      console.log(err);
    });

  }


  //For Btn Color
  btnFn(mode) {
    this.mode = mode;
    if (mode == 'Unassigned') {
      this.btnUnassigned = true;
      this.btnAssigned = false;
    } else if (mode == 'Assigned') {
      this.btnUnassigned = false;
      this.btnAssigned = true;
    }

  }
  //For Btn Color

  validate(v, event) {
    if (v.Sel === 0 || v.Sel === null) {
      // event.target.parentNode.parentNode.style = 'background-color:none';
      v.Sel = 1;

    } else {
      // event.target.parentNode.parentNode.style = 'background-color:green;color:white;';
      v.Sel = 0;
    }

  }
  multicheck() {
    for (var i = 0; i < this.productList.length; i++) {
      const index = this.productList.findIndex((x => x === this.productList[i]));
      if (this.productList[index].Sel == null || this.productList[index].Sel === 0) {
        this.productList[index].Sel = 1;
      } else {
        this.productList[index].Sel = 0;
      }
    }
  }
  Reset(){
    this.filter = { FromDate: '', ToDate: '',supplier : 'All' ,ShopID:'All'}
    this.Search(this.mode);
  }


  setPreOrderProducts(modeX) {

    let missingType = '';
    let submit = true;
    this.filtersList = this.productList.filter(d => d.Sel === 1);

    if (this.filtersList.length > 0) {

      switch (modeX) {
        case "Assign":
          this.filtersList.forEach(element => {
            element.SupplierID = this.supplierID;
            element.PreOrder = 1;
            element.Po = 1;

          });
          break;
        case "Cancel":
          this.filtersList.forEach(element => {
            element.SupplierID = 0;
            element.PreOrder = 1;
            element.Po = 1;

          });
          break;
          case "Save DB":
          this.filtersList.forEach(element => {
            this.supplierID = element.SupplierID;
            element.Po = 3;
            this.savedb = true;

          });
          break;
          case "QC Cancel":
          this.filtersList.forEach(element => {
            element.PreOrder = 1;
            element.Po = 1;


          });
          break;
        case "QC Done":
          this.filtersList.forEach(element => {
            element.PreOrder = 3;
            element.Po = 3;

          });
          break;

      }


      if(submit){
      this.spinner.show();
      this.printData.supplier = this.supplierList[this.supplierList.findIndex(element => { return element.ID === this.supplierID; })];

      this.printData.filterList = this.filtersList;
      this.printData.loggedInShop = this.loggedInShop;
      this.printData.loggedInCompany = this.loggedInCompany;
      this.printData.loggedInCompanySetting = this.loggedInCompanySetting;
      console.log(this.printData,'this.printData');

      this.companyService.setPreOrderStatusPo(this.printData, modeX).subscribe(data => {
        this.spinner.hide();
        switch (modeX) {
          case "Assign":
            alert("Email Sent Successfully");
            this.Search('Assigned');
            break;
          case "Cancel":
            this.Search('Unassigned');
            break;
          case "QC Done":
            this.Search('Assigned');
            break;
            case "QC Cancel":
            this.Search('Assigned');
            break;
            case "Save DB":
            this.Search('Unassigned');
            this.savedb = false;
            break;
        }


      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        // this.spinner.hide();

      });
    }
    }
    else {
      // alert("Please Select One or More Products from the List")

     }
  }


  AssignSupplierPDF(){

    this.spinner.show();

    this.filtersList = this.productList.filter(d => d.Sel === 1);
      if(this.filtersList.length > 0)
      {let data1: any = { Shop: this.loggedInShop, Company: this.loggedInCompanySetting, productList:this.filtersList }
        this.companyService.AssignSupplierPDF(' ', data1).subscribe(data => {

          const url = this.env.apiUrl + data;
          this.urlAss = url;
          window.open(url, "_blank");
          this.spinner.hide();
        }, (err) => { console.log(err);

        });
      }



  }

  // filterD() {
  //   const tempD = [];
  //    if( this.supplier !== 'All') {
  //     let whereList = '';
  //     if (this.filter.FromDate !== '' && this.filter.FromDate !== null) {
  //       let FromDate = moment(this.filter.FromDate).format('YYYY-MM-DD')
  //       whereList = whereList + ' and DATE_FORMAT(BarcodeMaster.CreatedOn, "%Y-%m-%d")  between ' + `'${FromDate}'`;
  //     }
  //     if (this.filter.ToDate !== '' && this.filter.ToDate !== null) {
  //       let ToDate = moment(this.filter.ToDate).format('YYYY-MM-DD')
  //       whereList = whereList + ' and ' + `'${ToDate}'`;
  //     }

  //     const dtm = {
  //       where: whereList,
  //       currentPage: this.currentPage,
  //       itemsPerPage: this.itemsPerPage
  //     }
  //      this.pagination.getPreOrderStatus('Assigned',dtm).subscribe(data => {
  //        let tempArray = [];
  //        data.result.forEach(el => {
  //          el.DeliveryDate = moment(el.DeliveryDate).format(`${this.loggedInCompanySetting.DateFormat}`);
  //          tempArray.push(el);
  //        })
  //        this.productList = tempArray;
  //        console.log(this.productList,'this.productListthis.productList');

  //        this.productList.forEach(ele => {
  //        if( ele.SupplierID == this.supplier) {
  //          tempD.push(ele);
  //        }
  //      })
  //      this.productList = tempD;

  //      }, (err) => {
  //        console.log(err);
  //      });
  //      // this.productList.forEach(ele => {
  //      //   if(ele.FitterID == this.fitter) {
  //      //     tempD.push(ele);
  //      //   }
  //      // })
  //      // this.productList = tempD;
  //    } else if( this.supplier !== 'All') {
  //      this.spinner.show();
  //      this.Search('Assigned');
  //    }
  //  }


  updateUnitPriceValue(data: any, i: any) {

   this.productList[i].GSTAmount = (+this.productList[i].UnitPrice * +this.productList[i].Qty - (this.productList[i].DiscountAmount ? this.productList[i].DiscountAmount : 0)) * +this.productList[i].GSTPercentage / 100;

   this.productList[i].TotalAmount = (+this.productList[i].UnitPrice * +this.productList[i].Qty - (this.productList[i].DiscountAmount ? this.productList[i].DiscountAmount : 0)) + +this.productList[i].GSTAmount;


  }

  pdf() {
    let data1: any = { Shop: this.loggedInShop, Company: this.loggedInCompanySetting, productList:this.productList }

    this.spinner.show();
    this.companyService.AssignSupplierPDF(' ', data1).subscribe(data => {
      this.spinner.hide();
      const url = this.env.apiUrl + data;
      this.urlAss = url;
      window.open(url, "_blank");

    }, (err) => { console.log(err);

    });
  }
}
