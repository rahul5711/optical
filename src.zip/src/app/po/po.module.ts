import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PoRoutingModule } from './po-routing.module';
import { SupplierPoComponent } from './supplier-po/supplier-po.component';
import { FitterPoComponent } from './fitter-po/fitter-po.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort';
import { MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { NameFilterPo} from './../filter/nameFilterPo';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SupplierPoListComponent } from './supplier-po-list/supplier-po-list.component';
import { DummyPoComponent } from './dummy-po/dummy-po.component';
import { DummyPoListComponent } from './dummy-po-list/dummy-po-list.component';

@NgModule({ 
  declarations: [SupplierPoComponent, FitterPoComponent,NameFilterPo, SupplierPoListComponent, DummyPoComponent, DummyPoListComponent],
  imports: [
    NgbModule,
    PoRoutingModule,
    CommonModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSortModule,
    MatToolbarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatTabsModule,
    MaterialFileInputModule,
    MatSlideToggleModule,
    NgxSpinnerModule,
    PerfectScrollbarModule,
    NgxMatSelectSearchModule,
  
  ]
})
export class PoModule { }
