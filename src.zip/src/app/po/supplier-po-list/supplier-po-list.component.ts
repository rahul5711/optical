import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from 'src/app/services/admin.service';
import { CompanyService } from 'src/app/services/company.service';
import { PaginationService } from 'src/app/services/pagination.service';
import { environment } from 'src/environments/environment';
import * as moment from 'moment';

@Component({
  selector: 'app-supplier-po-list',
  templateUrl: './supplier-po-list.component.html',
  styleUrls: ['./supplier-po-list.component.sass']
})
export class SupplierPoListComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  mode = "QC Checked";
  filter = { FromDate: '', ToDate: '',supplier :'All',ShopID:'All' }
  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0
  productList: any;
  supplierList: any;
  shopList: any;
  urlAss = '';
  details = [];
  constructor(
    private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private toastrService: ToastrService,
    private pagination: PaginationService
  ) { }

  ngOnInit(): void {
    this.spinner.show();
this.searchData();
    this.Search(this.mode)
    this.getSupplierList();
    this.getShopList();
    this.spinner.hide();

  }
  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 1).subscribe(data => {
      this.supplierList = data.result;
    }, (err) => {
      console.log(err);
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
     
    });
  }
  Search(mode: any) {
    this.spinner.show();

    let whereList = '';
    if (this.filter.FromDate !== '' && this.filter.FromDate !== null) {
      let FromDate = moment(this.filter.FromDate).format('YYYY-MM-DD')
      whereList = whereList + ' and DATE_FORMAT(BarcodeMaster.CreatedOn, "%Y-%m-%d")  between ' + `'${FromDate}'`;
    }
    if (this.filter.ToDate !== '' && this.filter.ToDate !== null) {
      let ToDate = moment(this.filter.ToDate).format('YYYY-MM-DD')
      whereList = whereList + ' and ' + `'${ToDate}'`;
    }
    if (this.filter.supplier !== null &&  this.filter.supplier !== 'All'){
      whereList = whereList + ' and BarcodeMaster.SupplierID = ' +  this.filter.supplier ; }

      if (this.filter.ShopID !== null &&  this.filter.ShopID !== 'All') {
        whereList = whereList + ' and BarcodeMaster.ShopID = ' + this.filter.ShopID;
      }
    const dtm = {
      where: whereList,
      currentPage: this.currentPage,
      itemsPerPage: this.itemsPerPage
    }

    this.pagination.getPreOrderStatus(mode, dtm).subscribe(data => {
    this.spinner.show();

      this.collectionSize = data.count;
     this.productList = data.result;
     console.log( this.productList, 'po');
     this.spinner.hide();

    }, (err) => {
      console.log(err);
    });

  }
  Reset(){
    this.filter = { FromDate: '', ToDate: '',supplier : 'All' ,ShopID:'All'}
    this.Search(this.mode);
  }


  AssignSupplierPDF(){
    
    const temp = [];
    this.productList.forEach(element => {
   
    
        this.details.forEach(e => {
          if (e.BarCode === element.Barcode) {
            element.UnitPrice = e.UnitPrice;
            element.GSTPercentage = e.GSTPercentage;
            element.DiscountAmount = e.DiscountAmount;
          }

        })
        element.GSTAmount = (+element.UnitPrice * +element.Qty - (element.DiscountAmount ? element.DiscountAmount : 0)) * +element.GSTPercentage / 100;
        element.TotalAmount = (+element.UnitPrice * +element.Qty - (element.DiscountAmount ? element.DiscountAmount : 0)) + +element.GSTAmount;
        temp.push(element);
     
    });
    this.spinner.show();
    this.companyService.AssignSupplierPDF(' ', temp).subscribe(data => {
      this.spinner.hide();
      const url = this.env.apiUrl + data;
      this.urlAss = url;
      window.open(url, "_blank");

    }, (err) => { console.log(err);
               
    });
  }
  // multicheck() {
  //   for (var i = 0; i < this.productList.length; i++) {
  //     const index = this.productList.findIndex((x => x === this.productList[i]));
  //     if (this.productList[index].Sel == null || this.productList[index].Sel === 0) {
  //       this.productList[index].Sel = 1;
  //     } else {
  //       this.productList[index].Sel = 0;
  //     }
  //   }
  // }
  // validate(v, event) {
  //   if (v.Sel === 0 || v.Sel === null) {
  //     // event.target.parentNode.parentNode.style = 'background-color:none';
  //     v.Sel = 1;
  
  //   } else {
  //     // event.target.parentNode.parentNode.style = 'background-color:green;color:white;';
  //     v.Sel = 0;
  //   }
 
  // }
  searchData() {
    let whereList = '';
    this.details = []
    this.companyService.getGenericListByParem('PreorderfullList', whereList ).subscribe(data => {
    this.details = data.result
console.log(data.result,'baar');
console.log( this.details[0].UnitPrice,'ISORIA');



    }, (err) => {
      console.log(err);
    });
  }
}
