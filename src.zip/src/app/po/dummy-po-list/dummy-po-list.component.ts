import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService} from '../../services/company.service';
import {DomSanitizer} from '@angular/platform-browser';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from '../../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import { PaginationService } from '../../services/pagination.service';
import { map, filter, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { fromEvent, Subscription } from 'rxjs';

@Component({
  selector: 'app-dummy-po-list',
  templateUrl: './dummy-po-list.component.html',
  styleUrls: ['./dummy-po-list.component.sass']
})
export class DummyPoListComponent implements OnInit {

  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));

  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private pagination: PaginationService
  ) { }
  env = environment;

  dataList: any[];
  page = 4;
  header: any;
  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0
  ngOnInit() {
  
        this.spinner.show();
        const dtm = {
          currentPage: this.currentPage,
          itemsPerPage: this.itemsPerPage 
        }
        this.pagination.getList('PurchaseMasterPo', dtm).subscribe(data => {
          this.spinner.hide(); 
          this.collectionSize = data.count;
          this.dataList = data.result;
          console.log(this.dataList,'kkk')
          this.header = "Dummy Po List"; 
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => { console.log(err);
                      this.spinner.hide();
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
    }


    getList(){
      this.spinner.show()
      const dtm = {
        currentPage: this.currentPage,
        itemsPerPage: this.itemsPerPage 
      }
      this.pagination.getList('PurchaseMasterPo', dtm).subscribe(res => {
        
        this.collectionSize = res.count;
        this.dataList = res.result;
     
        this.spinner.hide()
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        this.spinner.hide()
        this.showNotification(
          'bg-red',
          'Data Not Loaded.',
          'top',
          'right'
        );
      });
    }


    convertDate(date){
  
      return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
     }
     
    showNotification(colorName, text, placementFrom, placementAlign) {
  
      this.snackBar.open(text, '', {
        duration: 2000,
        // verticalPosition: placementFrom,
        horizontalPosition: 'left',
        panelClass: colorName,
        verticalPosition: 'bottom'
        
      });
    }

}
