import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DummyPoListComponent } from './dummy-po-list.component';

describe('DummyPoListComponent', () => {
  let component: DummyPoListComponent;
  let fixture: ComponentFixture<DummyPoListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DummyPoListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DummyPoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
