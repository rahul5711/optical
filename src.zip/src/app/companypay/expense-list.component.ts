import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';

@Component({
  selector: 'app-expense-list',
  templateUrl: './expense-list.component.html'
})
export class ExpenseListComponent implements OnInit {
  term:any;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission= JSON.parse(localStorage.getItem('Permission'));

  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  editExpenseList = false;
  addExpenseList = false;
  deleteExpenseList = false;
  dataList: any;
  searchValue :any;
  stringUrl: string;
  range: string;
  disableDates: boolean;
  filter: any =  {PaymentMode: 'All', date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), Category: 'All',  };
  PaymentModesList: any;
  depList: any;
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute) { }

    gridview = true;

  ngOnInit() {
    this.getPaymentModesList();
    this.getDepartmentList();
    this.range = 'Today';
    this.getDateRange();
    this.spinner.show();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ExpenseList') {
             this.editExpenseList = element.Edit;
             this.addExpenseList = element.Add;
             this.deleteExpenseList = element.Delete;
           }
         });
    this.companyService.getExtendedListByCompany1('Expense',this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
      this.dataList = data.result;
      console.log(this.dataList)

      this.santizePictureList();
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top', 
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
    // this.searchData();
  }

  santizePictureList() {
    this.dataList.forEach(element => {
      element.PhotoURL = this.sanitize(element.PhotoURL);
    });
  }

  sanitize(imgName: string) {
    if (imgName !== "null" && imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
    } else {
      this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
    return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
  }
  getDepartmentList(){
    this.companyService.getShortListByCompany('CategoryType', 1).subscribe(data => {
        this.depList = data.result;
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }


  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => { 
      this.PaymentModesList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
      }

      searchData() {
        this.spinner.show();
        let whereList = '';
      
        if (this.filter.date1 !== '' && this.filter.date1 !== null){
        let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
        whereList = whereList + ' and DATE_FORMAT(Expense.CreatedOn, "%Y-%m-%d")  between' +  `'${date1}'`; }
        if (this.filter.date2 !== '' && this.filter.date2 !== null){
          let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
          whereList = whereList + 'and' + `'${date2}'`; }
        if (this.filter.PaymentMode !== 0 && this.filter.PaymentMode !== null && this.filter.PaymentMode !== 'All'){
          whereList = whereList + ' and Expense.PaymentMode = ' + `'${this.filter.PaymentMode}'` ; }
        if (this.filter.Category !== 0 && this.filter.Category !== null && this.filter.Category !== 'All'){
          whereList = whereList + ' and Expense.Category = ' + `'${this.filter.Category}'` ; }
  
            this.companyService.getGenericListByParem('FilterExpense', whereList ).subscribe(data => {
              this.dataList = data.result;
    ;
        this.spinner.hide();
          
        }, (err) => {
          console.log(err);
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('Expense', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  // deleteItem(i){
  //   let yes = confirm("Are you sure want to delete");
  //   if (yes) {
  //   this.companyService.deleteData('Expense', this.dataList[i].ID).subscribe(data => {
  //   this.dataList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  // }
  //   }


  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
