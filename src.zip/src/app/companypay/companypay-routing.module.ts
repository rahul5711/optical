import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ExpenseComponent } from './expense.component';
import { ExpenseListComponent } from './expense-list.component';
import { PayrollComponent } from './payroll.component';
import { PayrollListComponent } from './payroll-list.component';
import { PaymentComponent } from './payment.component';
import { PaymentListComponent } from './payment-list.component';
import { PettyCashComponent } from './petty-cash.component';
import { PettyCashListComponent } from './petty-cash-list.component';

const routes: Routes = [

    
    { path: 'expense/:ID', component: ExpenseComponent },
    { path: 'expense-list', component: ExpenseListComponent },
    { path: 'payroll/:ID', component: PayrollComponent },
    { path: 'payroll-list', component: PayrollListComponent },
    { path: 'payment/:ID', component: PaymentComponent },
    { path: 'payment-list/:id/:paymentType', component: PaymentListComponent },
    { path: 'petty-cash/:ID', component: PettyCashComponent },
    { path: 'petty-cash-list', component: PettyCashListComponent },



];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanypayRoutingModule { }
