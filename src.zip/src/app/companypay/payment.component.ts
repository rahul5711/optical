
import { Component, OnInit } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { CompanyService } from '../services/company.service';
import * as moment from 'moment';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html'
})
export class PaymentComponent implements OnInit {

  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));

  public id =  parseInt(this.route.snapshot.paramMap.get('ID'), 10);

  data1: any = {ID: null, CustomerID: null, CompanyID: this.loggedInCompany.CompanyID, PaymentType: null,
    ShopID: this.loggedInShop.ShopID, CreditType: 'Debit', PaymentDate: null,
  PayableAmount: null, PaidAmount: null, CustomerCredit: null, PaymentMode: null, CardNo: null,
  PaymentReferenceNo: null, Comments: null, Status: 1, CreatedBy: null, CreatedOn: null , UpdatedBy: null,
    UpdatedOn: null, pendingPaymentList: {} };
    searchValue : any;
dataList: any;
payeeList: any;
  PaymentModesList: any;


  constructor( private companyService: CompanyService,
               private router: Router,
               private sanitizer: DomSanitizer,
               private spinner: NgxSpinnerService,
               private route: ActivatedRoute,
               private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.getPaymentModesList();
  }


  onPaymentSubmit(){
    this.spinner.show();
    this.data1.CompanyID = this.loggedInCompany.ID;
    this.data1.ShopID = this.loggedInShop.ShopID;
    this.data1.pendingPaymentList = this.dataList;
    let x = '';
    if(this.data1.PaymentType === 'Employee'){
      x = 'Employee1'
    } else if(this.data1.PaymentType === 'Customer') {
      x = 'ReturnCustomerPayment'

    } else {
      x= this.data1.PaymentType
    }
    this.companyService.applyPayment('Payment', x , this.data1).subscribe(data1 => {
      this.spinner.hide();
      this.data1.PaidAmount = 0; this.data1.PayableAmount = 0; this.data1.CustomerCredit = 0;
      this.getUnpaidList();
      this.showNotification(
        'bg-green',
        'Payment Applied Successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getUnpaidList(){
    const tableName = this.data1.PaymentType + 'MasterToApplyPayment';
    this.spinner.show();
    this.companyService.getCredit(this.data1.CustomerID, this.data1.PaymentType).subscribe(data => {
      this.data1.CustomerCredit = data.result;
      this.spinner.hide();
    });
    this.spinner.show();
    this.companyService.getExtendedListByID(tableName, this.data1.CustomerID).subscribe(data => {
      this.dataList = data.result;
      console.log(this.dataList);
      
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      // this.dataList = tempArray;
      this.data1.PayableAmount = 0;
      this.dataList.forEach(element => {
        if (element.DueAmount === null){
          element.DueAmount = element.TotalAmount; 
        }
        this.data1.PayableAmount = this.data1.PayableAmount +parseFloat(element.DueAmount);
      });
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }


  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => { 
      this.PaymentModesList = data.result;
      console.log(this.PaymentModesList)
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  getPayeeList() {
    let mode = '';
    if (this.data1.PaymentType === 'Vendor'){mode = 'Supplier'} 
    else if(this.data1.PaymentType === 'Employee') { mode = 'User'}
    else if(this.data1.PaymentType === 'Fitter') { mode = 'Fitter'}  
    else if(this.data1.PaymentType === 'Customer') { mode = 'Customer'}  

    else {mode = this.data1.PaymentType}
    this.companyService.getShortListByCompany(mode, 0).subscribe(data => {
      this.payeeList = data.result;
console.log(this.payeeList,'hohoho')
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }
   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}


