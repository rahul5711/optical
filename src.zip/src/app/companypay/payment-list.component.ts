import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';


@Component({
  selector: 'app-payment-list',
  templateUrl: './payment-list.component.html'
})

export class PaymentListComponent implements OnInit {
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));

  stringUrl: string;
  dataList: any;
  shopList: any;
  header: any;
  term: any;
  PaymentDetail = [];
  currency = { Symbol: 'INR', Format: '1.2-2' };
  disableDates: boolean;

  filter: any = { SupplierName: 'All', FitterName: 'All', EmployeeName: 'All', DoctorName: 'All', }
  filter2: any = { date1: moment().startOf('month').format('YYYY-MM-DD'),date2: moment().add(2, 'days').format('YYYY-MM-DD'),};

  data1: any = { ShopID: '', PaymentStatus: '', PaymentType: 'Supplier', };
  parem = {};
  SupplierList: any;
  FitterList: any;
  DoctorList: any;
  EmployeeList: any;
  range: string;

  constructor(
    private companyService: CompanyService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute) { }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  public payee = this.route.snapshot.paramMap.get('paymentType');
  searchValue: any;
  showSupplier = false;
  showFitter = false;
  showDoctor = false;
  showEmployee = false;
  totalAmount = 0;
  cash = 0;
  g_pay = 0;
  card = 0;
  paytm = 0;
  cheque = 0;
  bhim = 0;
  customer_return = 0;
  Customer_Reward = 0;
  paymentDetailList: any;
  DueAmount: any = 0;
  PayableAmount: any = 0;
  PaymentModesList: any;

  ngOnInit() {
    this.range = 'Today';
    this.getDateRange();
    if(this.payee === undefined) {
        this.payee = 'Supplier';
    }
    this.spinner.show();
    this.getList();
    this.getSupplierList();
    this.getFitterList();
    this.getDoctorList();
    this.getEmployeeList();
    this.getPaymentModesList();
  }

  getList() {
    if (this.id === 0) {
      this.parem = { "PaymentMaster.ShopID": this.loggedInShop.ShopID };
    } else {
      this.parem = { "PaymentMaster.CustomerID": this.id, "PaymentMaster.ShopID": this.loggedInShop.ShopID };
    }
    if (this.payee === 'Supplier') {
      this.showSupplier = true;
      this.showFitter = false;
      this.showEmployee = false;
      this.showDoctor = false;
    } else if (this.payee === 'Fitter') {
      this.showFitter = true;
      this.showSupplier = false;
      this.showEmployee = false;
      this.showDoctor = false;
    } else if (this.payee === 'Employee') {
      this.showEmployee = true;
      this.showSupplier = false;
      this.showFitter = false;
      this.showDoctor = false;
    } else if (this.payee === 'Doctor') {
      this.showDoctor = true;
      this.showSupplier = false;
      this.showFitter = false;
      this.showEmployee = false;
    }
  }

  getDateRange() {
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD');
    if (this.range === 'Custom Range') { this.disableDates = false } else { this.disableDates = true }
    switch (this.range) {
      case "Today":
        d1 = moment().format('YYYY-MM-DD');
        d2 = moment().format('YYYY-MM-DD');
        break;
      case "Yesterday":
        d1 = moment().subtract(1, 'days').format('YYYY-MM-DD');
        d2 = moment().subtract(1, 'days').format('YYYY-MM-DD');
        break;
      case "This Week":
        d1 = moment().startOf('week').format('YYYY-MM-DD');
        d2 = moment().format('YYYY-MM-DD');
        break;
      case "Last Week":
        d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD');
        d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD');
        break;
      case "This Month":
        d1 = moment().startOf('month').format('YYYY-MM-DD');
        d2 = moment().format('YYYY-MM-DD');
        break;
      case "Last Month":
        d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD');
        d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD');
        break;
      case "This Quarter":
        d1 = moment().startOf('quarter').format('YYYY-MM-DD');
        d2 = d2 = moment().format('YYYY-MM-DD');
        break;
      case "Last Quarter":
        d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD');
        d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD');
        break;
      case "This Year":
        d1 = moment().startOf('year').format('YYYY-MM-DD');
        d2 = d2 = moment().format('YYYY-MM-DD');
        break;
      case "Last Year":
        d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD');
        d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD');
        break;

      default:

        break;
    }
    this.filter2.date1 = d1;
    this.filter2.date2 = d2;
  }

  searchData() {
    this.dataList = [];
    this.paymentDetailList = [];
    this.totalAmount = 0;
    this.PayableAmount = 0;
    this.DueAmount = 0;
    this.cash = 0;
    this.g_pay = 0;
    this.card = 0;
    this.paytm = 0;
    this.cheque = 0;
    this.bhim = 0;
    this.Customer_Reward = 0;
    this.customer_return = 0;
    this.spinner.show();

    let whereList = '';
    if (this.filter2.date1 !== '' && this.filter2.date1 !== null) {
      let date1 = moment(this.filter2.date1).format('YYYY-MM-DD')
      whereList = whereList + ' and DATE_FORMAT(PaymentMaster.PaymentDate, "%Y-%m-%d")  between' + `'${date1}'`;
    }
    if (this.filter2.date2 !== '' && this.filter2.date2 !== null) {
      let date2 = moment(this.filter2.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`;
    }

    let tableName = '';
    if (this.payee === "Supplier") {
      tableName = 'FilterPaymentMasterSupplier';
      if (this.filter.SupplierName !== 'All') {
        whereList = whereList + ' and PaymentMaster.CustomerID =' + `'${this.filter.SupplierName}'`;
      }
    } else if (this.payee === "Fitter") {
      tableName = 'FilterPaymentMasterFitter';
      if (this.filter.FitterName !== 'All') {
        whereList = whereList + ' and PaymentMaster.CustomerID =' + `'${this.filter.FitterName}'`;
      }
    } else if (this.payee === "Doctor") {
      tableName = 'FilterPaymentMasterDoctor';
      if (this.filter.DoctorName !== 'All') {
        whereList = whereList + ' and PaymentMaster.CustomerID =' + `'${this.filter.DoctorName}'`;
      }
    } else if (this.payee === "Employee") {
      tableName = 'FilterPaymentMasterEmployee';
      if (this.filter.EmployeeName !== 'All') {
        whereList = whereList + ' and PaymentMaster.CustomerID =' + `'${this.filter.EmployeeName}'`;
      }
    }
    this.companyService.getGenericListByParem(tableName, whereList).subscribe(data => {
      let tempArray = [];
      data.result.forEach(el => {
        el.PaymentDate = moment(el.PaymentDate).format(`${this.loggedInCompanySetting.DateFormat}`);
        tempArray.push(el);
      })
      this.dataList = tempArray;
      this.totalCalculation(this.dataList);
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  totalCalculation(data) {
    this.paymentDetailList = [];
    for (var i = 0; i < data.length; i++) {
      this.totalAmount = this.totalAmount + data[i].PaidAmount;
      this.PayableAmount = this.PayableAmount + data[i].PayableAmount;
      this.DueAmount = this.DueAmount + data[i].Due;
      if (data[i].PaymentMode === 'Customer Reward') {
        this.Customer_Reward = this.Customer_Reward + data[i].PaidAmount;
      }
      if (data[i].PaymentMode === 'Customer Return') {
        var negative = data[i].PaidAmount.toString()[0]
        if (negative !== '-') {
          this.customer_return = this.customer_return + data[i].PaidAmount;
        }
      }
    }


    this.PaymentModesList.forEach((ele: { Name: string; }) => {
      let obj = { Mode: '', Amount: 0 };
      obj.Mode = ele.Name;
      data.forEach(el => {
        if (ele.Name === el.PaymentMode && el.PaymentMode !== 'Customer Reward' && el.PaymentMode !== 'Customer Return') {
          obj.Amount += Number(el.PaidAmount);
        }
      })
      this.paymentDetailList.push(obj);
      obj = { Mode: '', Amount: 0 };
    })
  }

  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => {
      this.PaymentModesList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    } , (err) => {
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Data Not Loaded.',
          'top',
          'right'
        );
      });
  }

  dataFiltter() {
    const temp = [];
    if (this.payee === 'Supplier' && this.filter.SupplierName !== 'All') {
      this.dataList.forEach(element => {
        if (element.PaymentType === 'Supplier' && element.CustomerID === this.filter.SupplierName) {
          temp.push(element);
        }
      });
    } else if (this.filter.SupplierName === 'All') {
      this.getList();
    }

    if (this.payee === 'Fitter' && this.filter.FitterName !== 'All') {
      this.dataList.forEach(element => {
        if (element.PaymentType === 'Fitter' && element.CustomerID === this.filter.FitterName) {
          temp.push(element);
        }
      });
    } else if (this.filter.FitterName === 'All') {
      this.getList();
    }

    if (this.payee === 'Employee' && this.filter.EmployeeName !== 'All') {
      this.dataList.forEach(element => {
        if (element.PaymentType === 'Employee' && element.CustomerID === this.filter.EmployeeName) {
          temp.push(element);
        }
      });
    } else if (this.filter.EmployeeName === 'All') {
      this.getList();
    }

    if (this.payee === 'Doctor' && this.filter.DoctorName !== 'All') {
      this.dataList.forEach(element => {
        if (element.PaymentType === 'Doctor' && element.CustomerID === this.filter.DoctorName) {
          temp.push(element);
        }
      });
    } else if (this.filter.DoctorName === 'All') {
      this.getList();
    }
    this.dataList = temp;

  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getSupplierList() {
    this.companyService.getExtendedListByCompany1('SupplierfullListAll', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
      this.SupplierList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getFitterList() {
    this.companyService.getExtendedListByCompany1('FitterFullListAll', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
      this.FitterList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getDoctorList() {
    this.companyService.getExtendedListByCompany1('DoctorFullListAll', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
      this.DoctorList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getEmployeeList() {
    this.companyService.getExtendedListByCompany1('UserFullListAll', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
      this.EmployeeList = data.result;
      console.log(data)
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  deleteItem(i) {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('PurchaseMaster', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
            'bg-green',
            'Data Deleted Successfully',
            'top',
            'right'
          );
        }, (err) => {
          this.showNotification(
            'bg-red',
            'Could Not Delete Data.',
            'top',
            'right'
          );
        });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
    this.snackBar.open(text, '', {
      duration: 2000,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'

    });
  }

  filterDataByParam() {
    this.companyService.filterDataByParam(this.data1, 'PurchaseMaster').subscribe(data => {
      this.dataList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  convertDate(date) {
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
  }

  paymentHistory(ID) {
    this.spinner.show();
    this.companyService.geListByOtherID('PaymentDetail', ID).subscribe(data => {
      this.PaymentDetail = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      this.spinner.hide();
    });
  }

}
