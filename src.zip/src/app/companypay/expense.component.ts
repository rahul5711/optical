import { Component, OnInit } from '@angular/core';
import { AdminService} from '../services/admin.service';
import { CompanyService} from '../services/company.service';

import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import {FormControl} from '@angular/forms';
import * as moment from 'moment';

@Component({
  selector: 'app-expense',
  templateUrl: './expense.component.html'
})
export class ExpenseComponent implements OnInit {
  term:any;
  myControl = new FormControl();
  selectItem:string;
  searchValue : any;
  show = true;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  public id =  parseInt(this.route.snapshot.paramMap.get('ID'), 10);
  permission= JSON.parse(localStorage.getItem('Permission'));
  editExpenseList = false;
  addExpenseList = false;
  deleteExpenseList = false;

data1: any = { ID : null,EmployeeID: null, CompanyID : null, ShopID : null, Name:'', Category : null, SubCategory : null, Amount : null, PaymentMode : null, InvoiceNo: null,
PaymentRefereceNo : null, Comments : null, Status : 1, CreatedBy: null, UpdatedBy: null, CreatedOn: null, UpdatedOn: null
};

userShop: any = {ID: null, UserID: this.id, ShopID: null, RoleID: null, Status: 1, CreatedOn: null, CreatedBy: null};

userImage: any;
usershopList: any;
  disableSuperAdminFields = false;
  toggleChecked = false;
  stringUrl: string;
  shopList = [];
  roleList: any;
  color: ThemePalette = 'primary';
  selectedDepartment: any;
  selectedDepartmentHead: any;
  depList: any;
  showAdd = false;
  newDepartment = {ID: null, CompanyID: null, Name: "", DepartmentHead: "", ShopID: this.data1.ShopID, Status: 1};
  PaymentModesList: any;

constructor(private adminService: AdminService,
            private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private spinner: NgxSpinnerService,
            private route: ActivatedRoute,
            private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.data1.ExpenseDate = moment(new Date()).format('YYYY-MM-DD');
    this.getDepartmentList();
      this.permission.forEach(element => {    
      if (element.ModuleName === 'ExpenseList') {
             this.editExpenseList = element.Edit;
             this.addExpenseList = element.Add;
             this.deleteExpenseList = element.Delete;
           }
         });
    if (this.loggedInUser.UserGroup !== 'SuperAdmin'){this.disableSuperAdminFields = true; }

    if (this.id !== 0) {
    this.spinner.show();
    this.adminService.getDataByID(this.id, 'getExpenseByID' , 'Expense').subscribe(data => {
      this.data1 = data.result;
      this.data1.ShopID = Number(data.result.ShopID);
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
      this.userImage = this.sanitize(this.data1.PhotoURL);
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }
  if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
    this.getShopListByID();
  } else {
   
    this.getShopList();

  }
  this. getPaymentModesList();
  }
  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
  }
 
  getChng(val){
    this.selectItem = val.target.value;
     console.log(val.target.value);
  }

  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => { 
      this.PaymentModesList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => { 
      this.shopList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.data1.ShopID = this.shopList[0].ID
      }
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }


  uploadImage(e){
    const frmData = new FormData();
    frmData.append('file', e.target.files[0]);
    this.adminService.uploadFile(frmData).subscribe(data => {

    this.data1.PhotoURL = data.fileName;
    this.userImage = this.sanitize(this.data1.PhotoURL);
    this.showNotification(
      'bg-green',
      'Image successfully Uploaded',
      'top',
      'right'
    );

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }


  onSubmit() {
      this.spinner.show();
      this.data1.CompanyID = this.loggedInCompany.ID;
      this.adminService.saveData('Expense', this.data1).subscribe(data1 => {
        this.data1.ID = data1.result.insertId;
        if(data1.result.insertId === 0) {
        this.data1.EmployeeID = this.id;
        } else {
          this.data1.EmployeeID = data1.result.insertId;;

        }
        this.companyService.applyPayment('Payment', 'Expense', this.data1).subscribe(data2 => {
          this.spinner.hide();
          this.router.navigate(['/companypay/expense-list']);
        }, (err) => { this.spinner.hide();});
        this.showNotification(
          'bg-green',
          'Data Saved successfully',
          'top',
          'right'
        );
      }, (err) => { console.log(err);
                    this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Data Not Saved.',
                      'top',
                      'right'
                    );
      });
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


  showData(){
    this.depList.forEach(element => {
      if (element.Name === this.selectedDepartment) {this.selectedDepartmentHead = element.DepartmentHead; this.selectedDepartment = element.ID; }
    });
  }

  getDepartmentList(){
    this.companyService.getShortListByCompany('CategoryType', 1).subscribe(data => {
        this.depList = data.result;
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }

  saveDepartment(){
    let count = 0;
    this.depList.forEach(element => {
      if (element.Name.toLowerCase() === this.newDepartment.Name.toLowerCase() ){count = count + 1; }

    });
    if (count === 0 && this.newDepartment.Name !== ''){
      this.companyService.saveData('CategoryType', this.newDepartment).subscribe(data => {
        this.newDepartment.Name = "";
        this.getDepartmentList();
        }, (err) => { console.log(err);
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
    }else { alert ("Duplicate or Empty Values are not allowed");
    this.newDepartment.Name = ""; }
  }

}
