import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';


@Component({
  selector: 'app-petty-cash-list',
  templateUrl: './petty-cash-list.component.html'
})
export class PettyCashListComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  editPettyCashList = false;
  addPettyCashList = false;
  deletePettyCashList = false;
  dataList: any;
  term: any;
  stringUrl: string;
  employeeList: any;
  searchValue : any;
  filter: any =  {EmployeeID: 'All', CreditType: 'All',  };
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.getEmployeeList();
    this.spinner.show();
    this.permission.forEach(element => {
      if (element.ModuleName === 'PettyCashlList') {
        this.editPettyCashList = element.Edit;
        this.addPettyCashList = element.Add;
        this.deletePettyCashList = element.Delete;
      }
    });
    // this.companyService.getExtendedListByCompany1('PettyCash',this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
    //   this.dataList = data.result;
    //   this.spinner.hide();
    //   this.showNotification(
    //     'bg-green',
    //     'Data Loaded successfully',
    //     'top',
    //     'right'
    //   );
    // }, (err) => {
    //   this.spinner.hide();
    //   this.showNotification(
    //     'bg-red',
    //     'Data Not Loaded.',
    //     'top',
    //     'right'
    //   );
    // });
    this.searchData();
  }
  getEmployeeList() {
    this.companyService.getShortListByCompany('User', 1).subscribe(data => {
      this.employeeList = data.result;
      this.spinner.hide();
    }, (err) => {
      this.spinner.hide();
      this.showNotification('bg-red','Data Not Loaded.', 'top', 'right' );
    });
  }
  searchData() {
    let whereList = '';
    if (this.filter.EmployeeID !== 0 && this.filter.EmployeeID !== null && this.filter.EmployeeID !== 'All'){
      whereList = whereList + ' and PettyCash.EmployeeID = ' +  this.filter.EmployeeID; }
       if (this.filter.CreditType !== 0 && this.filter.CreditType !== null && this.filter.CreditType !== 'All'){
        whereList = whereList + ' and PettyCash.CreditType = ' +  `'${this.filter.CreditType}'`; }
    

    this.companyService.getGenericListByParem('FilterPetty', whereList ).subscribe(data => {
   
      let tempArray = [];
      data.result.forEach(el => {
        el.CreatedOn = moment(el.CreatedOn).format(`${this.loggedInCompanySetting.DateFormat}`);
        tempArray.push(el);
      })
      this.dataList = tempArray;
      console.log(this.dataList)
     
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }
   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }
  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('PettyCash', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }


  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}

