import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-payroll-list',
  templateUrl: './payroll-list.component.html'
})
export class PayrollListComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  editpayrollList = false;
  addpayrollList = false;
  deletepayrollList = false;
  dataList: any;
  term:any;
  stringUrl: string;
  searchValue : any;
  filter: any =  {Month: 'All',Year: 'All', EmployeeID: 'All'};
  userList: any;
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute) { }

    gridview = true;

  ngOnInit() {
    this.getuserList();
    this.spinner.show();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'PayrollList') {
             this.editpayrollList = element.Edit;
             this.addpayrollList = element.Add;
             this.deletepayrollList = element.Delete;
           }
         });
    // this.companyService.getExtendedListByCompany1('Payroll',this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
    //   this.dataList = data.result;

    //   this.santizePictureList();
    //   this.spinner.hide();
    //   this.showNotification(
    //     'bg-green',
    //     'Data Loaded successfully',
    //     'top', 
    //     'right'
    //   );
    // }, (err) => {
    //   this.spinner.hide();
    //   this.showNotification(
    //     'bg-red',
    //     'Data Not Loaded.',
    //     'top',
    //     'right'
    //   );
    // });
    this.searchData();
  }

  santizePictureList() {
    this.dataList.forEach(element => {
      element.PhotoURL = this.sanitize(element.PhotoURL);
    });
  }

  getuserList() {
    this.companyService.getShortListByCompany('User',1).subscribe(data => {
      this.userList = data.result;
    this.spinner.hide();

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  sanitize(imgName: string) {
    if (imgName !== "null" && imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
    } else {
      this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
    return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('Payroll', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  searchData() {
    let whereList = '';
    if (this.filter.EmployeeID !== 0 && this.filter.EmployeeID !== null && this.filter.EmployeeID !== 'All'){
      whereList = whereList + ' and Payroll.EmployeeID = ' +  this.filter.EmployeeID; }
      if (this.filter.Month !== 0 && this.filter.Month !== null && this.filter.Month !== 'All'){
        whereList = whereList + ' and Payroll.Month = ' +  `'${this.filter.Month}'`;}
        if (this.filter.Year !== 0 && this.filter.Year !== null && this.filter.Year !== 'All'){
          whereList = whereList + ' and Payroll.Year = ' + `'${this.filter.Year}'`; }

    this.companyService.getGenericListByParem('FilterPayroll', whereList ).subscribe(data => {
      this.dataList = data.result;
      console.log(this.dataList)
     
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  // deleteItem(i){
  //   let yes = confirm("Are you sure want to delete");
  //   if (yes) {
  //   this.companyService.deleteData('Payroll', this.dataList[i].ID).subscribe(data => {
  //   this.dataList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  // }
  //   }


  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}

