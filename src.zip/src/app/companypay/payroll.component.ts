import { Component, OnInit } from '@angular/core';

import { AdminService} from '../services/admin.service';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { CompanyService } from '../services/company.service';
import {FormControl} from '@angular/forms';
@Component({
  selector: 'app-payroll',
  templateUrl: './payroll.component.html'
})
export class PayrollComponent implements OnInit {
  myControl = new FormControl();
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));

  public id =  parseInt(this.route.snapshot.paramMap.get('ID'), 10);
  permission= JSON.parse(localStorage.getItem('Permission'));
  editpayrollList = false;
  addpayrollList = false;
  deletepayrollList = false;
  searchValue : any;

data1: any = { ID : null, CompanyID : null, ShopID : null, EmployeeID : null, Month : '', Year : '', LeaveDays : '', Salary : '',
Comments : '',  PaymentMode: null, PaymentRefereceNo: null, Status : 1, CreatedBy: null, UpdatedBy: null, CreatedOn: null, UpdatedOn: null,
};

userShop: any = {ID: null, UserID: this.id, ShopID: null, RoleID: null, Status: 1, CreatedOn: null, CreatedBy: null};

userImage: any;
usershopList: any;
  disableSuperAdminFields = false;
  toggleChecked = false;
  stringUrl: string;
  shopList: any;
  roleList: any;
  employeeList: any;
  color: ThemePalette = 'primary';
  dataList: any;
  PaymentModesList: any;
constructor(private adminService: AdminService,
            private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private spinner: NgxSpinnerService,
            private route: ActivatedRoute,
            private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.spinner.show();
    this.getPaymentModesList();
    this.getEmployeeList();
     this.permission.forEach(element => {    
      if (element.ModuleName === 'payrollList') {
             this.editpayrollList = element.Edit;
             this.addpayrollList = element.Add;
             this.deletepayrollList = element.Delete;
           }
         });
    if (this.loggedInUser.UserGroup !== 'SuperAdmin'){this.disableSuperAdminFields = true; }

    if (this.id !== 0) {
    this.spinner.show();
    this.adminService.getDataByID(this.id, 'getPayrollByID' , 'Payroll').subscribe( data => {
      this.data1 = data.result;

      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
      this.userImage = this.sanitize(this.data1.PhotoURL);
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }
 
  }
  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
  }

  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => { 
      this.PaymentModesList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getEmployeeList() {
    this.companyService.getShortListByCompany('User', 1).subscribe(data => {
      this.employeeList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  uploadImage(e){
    const frmData = new FormData();
    frmData.append('file', e.target.files[0]);
    this.adminService.uploadFile(frmData).subscribe(data => {

    this.data1.PhotoURL = data.fileName;
    this.userImage = this.sanitize(this.data1.PhotoURL);
    this.showNotification(
      'bg-green',
      'Image successfully Uploaded',
      'top',
      'right'
    );

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }


  onSubmit() {
      this.spinner.show();
      this.data1.CompanyID = this.loggedInCompany.ID;
      this.adminService.saveData('Payroll', this.data1).subscribe(data1 => {
        this.data1.ID = data1.result.insertId;
        if(this.data1.ID === 0) {
          this.data1.ID = this.id;
        }
        this.companyService.applyPayment('Payment', 'Employee', this.data1).subscribe(data2 => {
          this.router.navigate(['/companypay/payroll-list']);
        }, (err) => { });
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Saved successfully',
          'top',
          'right'
        );  
      }, (err) => { console.log(err);
                    this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Data Not Saved.',
                      'top',
                      'right'
                    );
      });
  }

  getPayrollData(ID){
    this.companyService.getExtendedListByID('Payroll', ID).subscribe(data => {
      this.dataList = data.result;
      console.log(data)
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top', 
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}

