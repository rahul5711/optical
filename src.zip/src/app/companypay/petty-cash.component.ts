import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { CompanyService } from '../services/company.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';

@Component({
  selector: 'app-petty-cash',
  templateUrl: './petty-cash.component.html'
})
export class PettyCashComponent implements OnInit {
  OpeningBalances = 0;
  CashCounterwithdrawal = 0;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  public id = parseInt(this.route.snapshot.paramMap.get('ID'), 10);
  Balance = 0;
  editpayrollList = false;
  addpayrollList = false;
  deletepayrollList = false;
  dataList: any;
  term: any;
  data1: any = {
    ID: null, CompanyID: this.loggedInCompany.ID, ShopID: this.loggedInShop.ID, EmployeeID: null,CashType:'', CreditType: '', Amount: 0.00,
    Comments: '', Status: 1, CreatedBy: null, UpdatedBy: null, CreatedOn: null, UpdatedOn: null,
  };


  usershopList: any;
  searchValue :any;
  disableSuperAdminFields = false;
  toggleChecked = false;
  stringUrl: string;
  shopList: any;
  roleList: any;
  editPettyCashList = false;
  addPettyCashList = false;
  deletePettyCashList = false;
  employeeList: any;
  color: ThemePalette = 'primary';
  filter: any =  {EmployeeID: 'All', CreditType: 'All',  ShopID:'All'};
  sumdis = true
  constructor(private companyService: CompanyService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    if(this.loggedInShop.ShopStatus === 0){
      this.sumdis = false
      Swal.fire({
        title: 'Alert',
        icon: 'warning',
        text: 'PLEASE OPEN YOUR CASH REGISTER FIRST " ' ,
        footer: '' ,       
      });
      
    }
    this.getListExp();
    this.permission.forEach(element => {
      if (element.ModuleName === 'PettyCashlList') {
        this.editPettyCashList = element.Edit;
        this.addPettyCashList = element.Add;
        this.deletePettyCashList = element.Delete;
      }
    });

    if (this.id !== 0) {
      this.spinner.show();
      this.companyService.getDataByID(this.id, 'getPettyCashByID', 'PettyCash').subscribe(data => {
        this.data1 = data.result;
    

        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
        
      }, (err) => { console.log(err);
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Data Not Loaded.',
          'top',
          'right'
        );
});

    }
    this.getEmployeeList();
    
    // this.searchData();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }
  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }
  // msg(){
  //   if(this.loggedInShop.ShopStatus === 0){
  //     this.sumdis = false
  //     Swal.fire({
  //       title: 'Alert',
  //       icon: 'warning',
  //       text: 'PLEASE OPEN YOUR CASH REGISTER FIRST',
  //       footer: '' ,       
  //     });
      
  //   }
  // }
  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result, 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.data1.ShopID = this.shopList[0].ID
      }
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getEmployeeList() {
    this.companyService.getShortListByCompany('User', 1).subscribe(data => {
      this.employeeList = data.result;
      this.spinner.hide();
    }, (err) => {
      this.spinner.hide();
      this.showNotification('bg-red','Data Not Loaded.', 'top', 'right' );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  onSubmit() {
    this.spinner.show();
    this.data1.CompanyID = this.loggedInCompany.ID;
    if(this.data1.CreditType === 'Withdrawal'){
      if(this.Balance < Number(this.data1.Amount)){
        this.spinner.hide();
        return   this.showNotification(
        'bg-Red','You Do Not Have Enough Balance', 'top', 'right');
      }
    }
  
    this.companyService.saveData('PettyCash', this.data1).subscribe(data1 => {
      this.Balance = 0;
      this.spinner.hide();
      this.showNotification(
        'bg-green','Data Saved successfully', 'top', 'right');
      this.router.navigate(['/companypay/petty-cash/0']);
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification('bg-red','Data Not Saved.','top','right');
    });
    this.getListExp()
  }

  // searchData() {
  //   let whereList = '';
  //   if (this.filter.EmployeeID !== 0 && this.filter.EmployeeID !== null && this.filter.EmployeeID !== 'All'){
  //     whereList = whereList + ' and PettyCash.EmployeeID = ' +  this.filter.EmployeeID; }

  //      if (this.filter.CreditType !== 0 && this.filter.CreditType !== null && this.filter.CreditType !== 'All'){
  //       whereList = whereList + ' and PettyCash.CreditType = ' +  `'${this.filter.CreditType}'`; }

  //       if (this.filter.ShopID !== 0 && this.filter.ShopID !== null && this.filter.ShopID !== 'All'){
  //         whereList = whereList + ' and PettyCash.ShopID = ' +  `'${this.filter.ShopID}'`; }
    

  //   this.companyService.getGenericListByParem('FilterPetty', whereList ).subscribe(data => {
   
    
  //     this.dataList = data.result;
  //     console.log(this.dataList)
     
  //   this.spinner.hide();

  //   }, (err) => {
  //     console.log(err);
  //   this.spinner.hide();
  //     this.showNotification(
  //       'bg-red',
  //       'Error Loading Data',
  //       'top',
  //       'right'
  //     );
  //   });
  // }
  editPetty(ID){
    this.spinner.show();
    this.companyService.getDataByID(ID, 'getPettyCashByID', 'PettyCash').subscribe(data => {
      this.data1 = data.result;


      this.spinner.hide();
      this.showNotification('bg-green', 'Data Loaded successfully', 'top', 'right');
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification('bg-red','Data Not Loaded.','top','right');
    });
  }

  getListExp(){
    let tab =  moment().format('YYYY-MM-DD');
    this.companyService.getExtendedListByCompany1('PettyCash',this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
        this.dataList = data.result;
  
      console.log(this.dataList)
      this.spinner.hide();
      this.router.navigate(['/companypay/petty-cash/0']);
    });
  }

  

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   } 

   getAvailableBalance(){
    let whereList = '';
    this.data1.CreditType = '';
   
      if (this.data1.ShopID !== '' && this.data1.ShopID !== null ){
        whereList = whereList + ' and PettyCash.ShopID = ' +  `'${this.data1.ShopID}'` }
       
          this.companyService.getGenericListByParem('AvailableBalance', whereList ).subscribe(data => {
            let Deposit = 0;
            let Withdrawal = 0;
            console.log(data);
            if(data.result.length !== 0){
                data.result.forEach(ele=>{
                  if(ele.CreditType === 'Withdrawal'){
                    Withdrawal = ele.Amount ? ele.Amount : 0
                  }else{
                    Deposit = ele.Amount ? ele.Amount : 0
                  }
                })
            } 
            this.Balance =  Deposit - Withdrawal;
            // Deposit = data.result[0]?.Amount ? data.result[0]?.Amount : 0
            // Withdrawal = data.result[1]?.Amount ? data.result[1]?.Amount : 0
           //this.Balance =  Deposit - Withdrawal;
           //console.log(this.Balance);
            this.spinner.hide();
          }, (err) => {
            console.log(err);
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Error Loading Data',
              'top',
              'right'
            );
          });
         
         
       
   }

   getAvailableBalance1(){
    let whereList = '';
    this.data1.CreditType = '';
      if (this.data1.ShopID !== '' && this.data1.ShopID !== null ){
        whereList = whereList + ' and CashRegister.ShopID = ' +  `'${this.data1.ShopID}'` }
          this.companyService.getGenericListByParem('AvailableBalance1', whereList ).subscribe(data => {
            this.OpeningBalances = data.result[0].OpeningBalance
            this.CashCounterwithdrawal = data.result[0].CashCounterwithdrawal
            console.log(this.OpeningBalances);
            
            let Deposit = data.result[0].OpeningBalance;
            let Withdrawal = 0;
            console.log(data);
            if(data.result.length !== 0){
                data.result.forEach(ele=>{
                  if(ele.CreditType === 'Withdrawal'){
                    Withdrawal = ele.Amount ? ele.Amount : 0
                  }else{
                    Deposit = ele.OpeningBalance ? ele.OpeningBalance : 0
                  }
                })
            } 
            this.Balance  =  Deposit - Withdrawal;
            // Deposit = data.result[0]?.Amount ? data.result[0]?.Amount : 0
            // Withdrawal = data.result[1]?.Amount ? data.result[1]?.Amount : 0
           //this.Balance =  Deposit - Withdrawal;
           //console.log(this.Balance);
            this.spinner.hide();
          }, (err) => {
            console.log(err);
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Error Loading Data',
              'top',
              'right'
            );
          });
            
   }
  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}

