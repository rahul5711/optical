import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

import { CompanypayRoutingModule } from './companypay-routing.module';
import { ExpenseComponent } from './expense.component';
import { ExpenseListComponent } from './expense-list.component';
import { PayrollComponent } from './payroll.component';
import { PayrollListComponent } from './payroll-list.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { PaymentComponent } from './payment.component';
import { PaymentListComponent } from './payment-list.component';
import { PettyCashComponent } from './petty-cash.component';
import { PettyCashListComponent } from './petty-cash-list.component';
import { NamesFilter} from './../filter/namesFilter';
import { NamesFilterPay} from './../filter/namesFilterpay';
import {MatChipsModule} from '@angular/material/chips';
import {MatAutocompleteModule} from '@angular/material/autocomplete';

import { AutoFoucsDirectivesDirective } from './auto-foucs-directives.directive';


@NgModule({
  declarations: [
    ExpenseComponent,ExpenseListComponent ,PayrollComponent,PayrollListComponent,NamesFilter, PaymentComponent,PaymentListComponent,PettyCashComponent,
    PettyCashListComponent,NamesFilterPay,AutoFoucsDirectivesDirective
  ],
  imports: [
    CommonModule,
    MatChipsModule,
    MatAutocompleteModule,
    CompanypayRoutingModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSortModule,
    MatToolbarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatTabsModule,
    MaterialFileInputModule,
    
    MatSlideToggleModule,
    NgxSpinnerModule,
    PerfectScrollbarModule,
    NgxMatSelectSearchModule,
    Ng2SearchPipeModule,
    
  ]
})
export class CompanypayModule { }
