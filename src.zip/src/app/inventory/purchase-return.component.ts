import { Component, OnInit } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-purchase-return',
  templateUrl: './purchase-return.component.html'
})
export class PurchaseReturnComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));

  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
 loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  viewSupplier = this.permission[this.permission.findIndex((element) => element.ModuleName = "Supplier")];
  editPurchaseReturn: any;
  addPurchaseReturn: any;
  deletePurchaseReturn: any;
  specList: any;
  selectedProduct: any;


  constructor(
    private companyService: CompanyService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
  ) { }
  data = { ProductCategory : 0, SupplierID: 0, ShopID: 0, PurchaseID: 0, Barcode: "", CurrentStatus : "Available",ProductName: ''
};
searchValue: any;
summaryList: [];
supplierList: any[];
shopList = [];
prodList: any[];
tempPurchaseDetail: any;
returnQuantity = 0;
remark = '';
  ngOnInit() {
    this.spinner.show();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'PurchaseReturn') {
             this.editPurchaseReturn = element.Edit;
             this.addPurchaseReturn = element.Add;
             this.deletePurchaseReturn = element.Delete;
           }
         });
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.data.ShopID = this.loggedInShop.ShopID;
      this.getInventoryData();
      this.getShopListByID();
    } else {
      this.getInventoryData();
      this.getShopList();

    }
    this.getProductList();
    this.getSupplierList();
  }

  getInventoryData(){
    let whereList = '';
    if (this.data.ProductCategory !== 0){
    whereList = whereList + ' and PurchaseDetail.ProductTypeID = ' +  this.data.ProductCategory; 
    this.filter();
  }
    if (this.data.ProductName !== '') {
      whereList = whereList + ' and PurchaseDetail.ProductName Like ' + '"' + this.data.ProductName + '%"';
    }
    if (this.data.ShopID !== 0){
      whereList = whereList + ' and BarcodeMaster.ShopID = ' +  this.data.ShopID; }
    if (this.data.SupplierID !== 0){
      whereList = whereList + ' and PurchaseMaster.SupplierID = ' +  this.data.SupplierID ; }
    if (this.data.Barcode !== ''){
      whereList = whereList + ' and BarcodeMaster.Barcode Like ' + '"' + this.data.Barcode + '%"' ; }
    if (this.data.CurrentStatus !== ''){
      whereList = whereList + ' and BarcodeMaster.CurrentStatus = ' + '"' + this.data.CurrentStatus + '"'; }
     
    this.spinner.show();
    this.companyService.getGenericListByParem('ProductInventory', whereList).subscribe(data => {
      this.summaryList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product', 0).subscribe(data => {
      this.prodList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  filter() {
    let productName = '';
    this.specList.forEach(element => {
      if (productName === '') {
        productName = element.SelectedValue;
      } else if (element.SelectedValue !== '') {
        productName += '/' + element.SelectedValue;
      }
    });
    this.data.ProductName = productName;
  }

  getfieldList() {
    if(this.data.ProductCategory !== 0){
    this.prodList.forEach(element => {
      if (element.ID === this.data.ProductCategory) {
        this.selectedProduct = element.Name;
      }
    })
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }else {
    this.specList = [];
    this.data.ProductName = '';
    this.data.ProductCategory = 0;
  }
}

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 0).subscribe(data => {
      this.supplierList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.data.ShopID = this.shopList[0].ID
      }
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  validate(s, event) {
    this.tempPurchaseDetail = s;
    this.returnQuantity = 0;
    console.log(this.tempPurchaseDetail , 'this.tempPurchaseDetail');
  }

  purchasereturn() {
    if(this.returnQuantity <= this.tempPurchaseDetail.Count) {
      this.tempPurchaseDetail.ReturnQuantity = this.returnQuantity;
      this.tempPurchaseDetail.Remark = this.remark;
      this.companyService.purchaseReturn('', this.tempPurchaseDetail).subscribe(data => {
        this.getInventoryData();
      }, (err) => {
        console.log(err);
      });
     
    }else{
      alert("Reqested Item Quantity not available. Please change the Quantity");
      this.returnQuantity = 0;
    }
   

  }

  checkReturn() {
    if(this.returnQuantity > this.tempPurchaseDetail.Count) {
      alert("Reqested Item Quantity not available. Please change the Quantity");
      this.returnQuantity = 0;
    }
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


}
