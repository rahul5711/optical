import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSelect } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';


@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})
export class PurchaseComponent implements OnInit {
  @ViewChild('myDiv') myDiv: ElementRef;
  @ViewChild('myDiv1') myDiv1: ElementRef;
  @ViewChild('myDiv2') myDiv2: ElementRef;
  @ViewChild('myDiv3') myDiv3: ElementRef;


  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
checkInvoiceNo = [];
  gstList: any;
  year = moment(new Date()).format('YY');
  month = moment(new Date()).format('MM');
  partycode = '';
  type = '*';
  Addinvoice: boolean;
  tempQty = 0;
  urlAss= '';
  BarcodeQuantity = 0;
  constructor(private companyService: CompanyService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private spinner: NgxSpinnerService,
              private snackBar: MatSnackBar,
              private route: ActivatedRoute,
              private changeDectectorRef: ChangeDetectorRef

    // private toastrService: ToastrService,
  ) {
      // qz.api.setSha256Type(data => sha256(data));
      // qz.api.setPromiseType(resolver => new Promise(resolver));
  }
  
 
  checked = false;
  fontOptions = '1000';
  fontSize = 14;
  fontSizem = 10;
  textMargin = 0;
  margin = 0;
  marginTop = 10;
  marginTopm = 2;

  marginTops = 0;
  marginBottom = 0;
  marginLeft = 0;
  marginLeft1 = 0;
  marginRight = 0;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));

  editPurchaseList = false;
  addPurchaseList = false;
  deletePurchaseList = false;
  preOrder = false;
  chargeOptions: any;
  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  specList: any = [];
  prodList: any[];
  supplierList: any = [];
  shopList: any[];
  item: any;
  charge: any;
  category = 'Product';
  disableAddButtons = false;
  barcodeList: any;
  wholedisvs = false;
  selectedItemPrint: any = { BarCode: null, ProductName: null , UnitPrice :null, UniqueBarcode: null, shopName: null, Quantity:null };
  tempItem = { Item: null, Spec: null };
  itemList = [];
  barcodeListt = []
  chargeList = [];
  historyList = [];
  data = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  selectedPurchaseMaster: any = {
    ID: null, SupplierID: null, SupplierName: null, CompanyID: null, GSTNo: null, ShopID: null, ShopName: null, PurchaseDate: null,
    PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0, DiscountAmount: 0,
    GSTAmount: 0, TotalAmount: 0, preOrder:false,
  };


  sampleitem: any = {
    ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
    Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
    DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
    WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, NewBarcode: '',  Status: 1, BrandType: false
  };


  samplecharge: any = {
    ID: null, PurchaseID: null, ChargeType: null, Name:'', CompanyID: null, Description: '', Amount: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
    GSTType: '', TotalAmount: 0.00 , Status: 1 };

    gstLock = false;
    gstperLock = false;
  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
    gstdividelist = [];
    sgst = 0;
    cgst = 0;
  ngOnInit() {
    if (this.loggedInCompany.WholeSale === 'true' ) {
      this.sampleitem.WholeSalePrice = 0 
    }else{
      this.sampleitem.WholeSalePrice = 0;
    }
    if (this.loggedInCompany.RetailPrice === 'true' ) {
      this.sampleitem.RetailPrice = 0
    }else{
      this.sampleitem.RetailPrice = 0;
    }
    if (this.id == 0){
      this.selectedPurchaseMaster.PurchaseDate = moment().format('YYYY-MM-DD');
    }

    this.onPageLoad();
    // console.log(this.year , this.month , 'month');
    if (this.loggedInCompany.WholeSale === 'true'  ) {
      this.item.WholeSale = true;
      this.wholedisvs = true
    
    } else {
      this.item.WholeSale = false
      this.wholedisvs = true

    }
    
    if (this.loggedInCompany.WholeSale === 'true' && this.loggedInCompany.RetailPrice === 'true') {
      this.item.WholeSale = false;
      this.wholedisvs = false
    }
    
    // if (this.loggedInCompany.RetailPrice === 'true' ) {
    //   this.item.WholeSale = false;
    //   this.wholedisvs = false

    // } else{
    //   this.item.WholeSale = true;
    //   this.wholedisvs = true

    // }
    this.item.BrandType = false
  }

  onPageLoad(){
    this.spinner.show();
       this.permission.forEach(element => {    
      if (element.ModuleName === 'PurchaseList') {
             this.editPurchaseList = element.Edit;
             this.addPurchaseList = element.Add;
             this.deletePurchaseList = element.Delete;
           }
         });
    if (this.id !== 0) {
      this.spinner.show();
      this.companyService.getPurchaseFullDataByID(this.id).subscribe(data => {
        this.selectedPurchaseMaster = data.result.PurchaseMaster;
        this.itemList = data.result.PurchaseDetail;
        this.chargeList = data.result.Charge;
        console.log( this.chargeList);
        
        // if(this.supplierList[index].Sno !== null) {
        //   this.partycode = this.supplierList[index].Sno;
        //   } else {
        //     this.partycode = '0'; 
        //   }
        this.calculateGrandTotal();

        this.supplierList.forEach(ele => {
          if(ele.ID === this.selectedPurchaseMaster.SupplierID) {
            if(ele.Sno !== null) {
              this.partycode = ele.Sno; 
            } else {
              this.partycode = '0';
            }
          }
        })
        // this.item.GSTType = this.itemList[0].GSTType;
      this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        this.spinner.hide();

        // this.showFailure(err, 'Error Loading Data.');
        
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    } else {
      this.selectedPurchaseMaster.PurchaseDate = moment(new Date()).format('YYYY-MM-DD');
    }

    this.getProductList();
    this.getGstList();
        this.getSupplierList();
    this.getShopList();
    this.getChargerOptions();
    this.item = this.sampleitem;
    this.charge = this.samplecharge;
    
    this.showNotification(
      'bg-green',
      'Data Loaded successfully',
      'top',
      'right'
    );
    if(this.id == 0) {
      this.spinner.hide();

    }
    // this.initQZ();
  }

  deleteItem(category, i){
    if (category === "Product"){
      if (this.itemList[i].ID === null){
        this.itemList.splice(i, 1);
      } else {
        this.companyService.getExtendedListByID('BarcodeCount', this.itemList[i].ID).subscribe(data => {
          this.spinner.hide();
          if(this.itemList[i].Quantity == data.result[0].BarCodeCount) {
            this.itemList[i].Status = 0;
            this.calculateGrandTotal();

          } else {
            alert("you can't delete this product because one item already sold");
          }
        }, (err) => {
          console.log(err);
        });
      }

    } else if (category === "Charge"){
      if (this.chargeList[i].ID === null){
        this.chargeList.splice(i, 1);
      } else {
        this.chargeList[i].Status = 0;
      }
    }
    this.calculateGrandTotal();
  }

  

  RestoreProduct(category, i) {
    this.itemList[i].Status = 1;
    this.calculateGrandTotal();

  }

  selectItem(i){
    this.item = this.itemList[i];
    this.category = 'Product';
    this.selectedProduct = this.item.ProductTypeName;
  }

  selectCharge(i){
    this.charge = this.chargeList[i];
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product',1).subscribe(data => {
      this.prodList = data.result;
      
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  paymentHistory(){
    this.spinner.show();
    this.companyService.geListByOtherID('PaymentHistory' ,this.id).subscribe(data => {
      this.historyList = data.result;
      this.spinner.hide();
    }, (err) => { console.log(err);
                  this.spinner.hide();
                 
    });
  }

  onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === 1) {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == 2) {
      event = event.toTitleCase()
    }
    return event;
  }

  getChargerOptions(){
    this.companyService.getShortListByCompany('ChargerMaster',1).subscribe(data => {
      this.chargeOptions = data.result;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => { 
      this.gstList = data.result;
      this.gstdividelist = [];
      data.result.forEach(ele => {
        if(ele.Name.toUpperCase() !== 'CGST-SGST'){
          let obj = {GstType: '', Amount: 0};
          obj.GstType = ele.Name;
          this.gstdividelist.push(obj);
        }
      })
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      // this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  setValues(){
    this.chargeOptions.forEach(element => {
        if (element.ID === this.charge.ChargeType){
      this.charge.Name = element.Name;
      this.charge.Price = element.Price;
      this.charge.Description = element.Description;
      this.charge.GSTAmount = element.GSTAmount;
      this.charge.GSTPercentage = element.GSTPercentage;
      this.charge.GSTType = element.GSTType;
      this.charge.TotalAmount = element.TotalAmount;
        }
    });
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier',1).subscribe(data => {
      this.supplierList = data.result;
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  calculateFields2(fieldName, mode) { 
    if(this.item.GSTType !== "") {
      this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
      if (fieldName === 'DiscountPercentage') { 
        this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
        // this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - +this.item.DiscountAmount;
      }
      if (fieldName === 'DiscountAmount') { 
        this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity/100; 

        
        // this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount;
      }
      // this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity/100; 
      this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - +this.item.DiscountAmount;
      this.item.GSTAmount =
            (+this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
            this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount;
    }
  }


  calculateFields(fieldName, mode) {
  if(isNaN(Number(this.item.UnitPrice)) === true) {
    alert("please fill up integer value");
    this.item.UnitPrice = 0;
  }
  if(isNaN(Number(this.item.Quantity)) === true) {
    alert("please fill up integer value");
    this.item.Quantity = 0;
  } 
  if(isNaN(Number(this.item.DiscountPercentage)) === true) {
    alert("please fill up integer value");
    this.item.DiscountPercentage = 0;
  }
  if(isNaN(Number(this.item.DiscountAmount)) === true) {
    alert("please fill up integer value");
    this.item.DiscountAmount = 0;
  }
  if(isNaN(Number(this.item.GSTPercentage)) === true) {
    alert("please fill up integer value");
    this.item.GSTPercentage = 0;
  }
  if(isNaN(Number(this.item.GSTAmount)) === true) {
    alert("please fill up integer value");
    this.item.GSTAmount = 0;
    this.item.GSTPercentage = 0;
  } else {
    switch (mode) {
      case 'subTotal':
        this.item.SubTotal = +this.item.Quantity * +this.item.UnitPrice - +this.item.DiscountAmount;
        break;
      case 'discount':
        if (fieldName === 'DiscountPercentage') { 
          if(Number(this.item.DiscountPercentage) > 100 ) {
            alert("you can't give 100% above discount");
            this.item.DiscountPercentage = 0;
            this.item.DiscountAmount = 0;
            this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount;
          } else {
          this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
          // this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity; 

          this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - +this.item.DiscountAmount;
          }
        }
        if (fieldName === 'DiscountAmount') {
          if(Number(this.item.DiscountAmount) > Number(this.item.SubTotal)) {
            alert("you can't give SubTotal above discount");
            this.item.DiscountAmount = 0
           
          }else{
            this.item.DiscountPercentage = 100 * +this.item.DiscountAmount / (+this.item.Quantity * +this.item.UnitPrice);
            // this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
            this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount;
          }
          // this.item.DiscountPercentage =  +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity/100; 
        

        }
        break;
      case 'gst':
        if (fieldName === 'GSTPercentage') {
          if(Number(this.item.GSTPercentage) > 100 ) {
            alert("you can't give 100% above discount");
            this.item.GSTAmount = 0;
          }
            else{
              this.item.GSTAmount =(+this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
            }
         
        }
        if (fieldName === 'GSTAmount') {
          this.item.GSTPercentage =100 * +this.item.GSTAmount / (+this.item.SubTotal);
        }
        break;

        case 'chgst':
          if (fieldName === 'GSTPercentage') {
            this.charge.GSTAmount = (+this.charge.Price) * +this.charge.GSTPercentage / 100;
          }
          if (fieldName === 'GSTAmount') {
            this.charge.GSTPercentage = 100 * +this.charge.GSTAmount / (+this.charge.Price);
          }
          break;
      case 'total':
        this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount;
        break;
        case 'chtotal':
          this.charge.TotalAmount = +this.charge.Price + +this.charge.GSTAmount;
          break;
    }
    if(this.item.GSTType !== "") {
      this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
      this.item.GSTAmount =
      (+this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
      this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount;

    }

    this.item.GSTAmount = this.convertToDecimal(+this.item.GSTAmount, 2);
    this.item.GSTPercentage = this.convertToDecimal(+this.item.GSTPercentage, 0);
    this.item.DiscountAmount = this.convertToDecimal(+this.item.DiscountAmount, 2);
    this.item.DiscountPercentage = this.convertToDecimal(+this.item.DiscountPercentage, 2);
    this.item.TotalAmount = this.convertToDecimal(+this.item.TotalAmount, 2);
    this.item.SubTotal = this.convertToDecimal(+this.item.SubTotal, 2);

    // this.item.GSTAmount = +this.item.GSTAmount.toFixed(2);
    // this.item.GSTPercentage = +this.item.GSTPercentage.toFixed(0);
    // this.item.DiscountAmount = +this.item.DiscountAmount.toFixed(2);
    // this.item.DiscountPercentage = +this.item.DiscountPercentage.toFixed(0);
    // this.item.TotalAmount = +this.item.TotalAmount.toFixed(2);
    // this.item.SubTotal = +this.item.SubTotal.toFixed(2);

    // this.calculateFields2(fieldName, mode);
  }
  }


  convertToDecimal(num, x) {
    return Number(Math.round(parseFloat(num + 'e' + x)) + 'e-' + x);
  }


  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  addItem() {
    // this.spinner.show();

    // this.tempItem.Item = this.item;
    // this.tempItem.Spec = this.specList;
    if (this.category === 'Product'){
      if (this.selectedPurchaseMaster.ID !== null){this.item.Status = 2; }
      this.item.ProductName = "";
      this.item.ProductExpDate = "0000-00-00";
      this.specList.forEach(element => {
if(element.SelectedValue !== "") {
        this.item.ProductName = this.item.ProductName  + element.SelectedValue + "/";
}
        if(element.FieldType === "Date") {
          this.item.ProductExpDate = element.SelectedValue;
        }

    });
 
      this.item.ProductName = this.item.ProductName.substring(0, this.item.ProductName.length - 1);
      this.item.BaseBarCode = null;
      this.item.NewBarcode = null;
      this.companyService.getExistingProduct(this.item).subscribe(data => {
        const x = data.result;

        if(this.id === 0){
          this.checkInvoicNo();
        }
        if(x[0].BaseBarCode !== null) {
          this.item.BaseBarCode = null;
          this.item.NewBarcode = null;
        }
        if (x.length > 0 && x[0].CompanyID !== null && x[0].BaseBarCode !== null){ 
          this.item.BaseBarCode = x[0].BaseBarCode;
          this.item.NewBarcode = x[0].MaxBarcode;
          // alert('This product with the same Retail Price was added previously. Existing Barcode series will be used');
          if(this.item.Quantity !== 0) {
          Swal.fire({
            icon: 'error',
            title: 'This product with the same Retail Price was added previously. Existing Barcode series will be used',
            text: ' ',
            footer: ''
          });
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Please Enter Quantity',
            text: ' ',
            footer: ''
          });
        }
                          }
        this.item.Spec = this.specList;
        let NewBarcode = '';
        if(this.loggedInCompanySetting.year === 'true') {
          NewBarcode = NewBarcode.concat(this.year);
        }  
        if (this.loggedInCompanySetting.month === 'true') {
          NewBarcode = NewBarcode.concat(this.month);

        } 
        if (this.loggedInCompanySetting.partycode === 'true') {
          NewBarcode = NewBarcode.concat(this.partycode);
        }
         if (this.loggedInCompanySetting.type === 'true' && this.item.GSTType !== 'None' && this.item.GSTPercentage !== 0 ) {
          NewBarcode = NewBarcode.concat(this.type);
        }
        if (this.loggedInCompanySetting.type === 'true' && this.item.GSTType === 'None' && this.item.GSTPercentage === 0 ) {
          NewBarcode = NewBarcode.concat("/");
        }
        NewBarcode = NewBarcode.concat(this.partycode);
        let unitpReverse = this.item.UnitPrice.toString().split('').reverse().join('').toString();
        NewBarcode = NewBarcode.concat(unitpReverse);
        NewBarcode = NewBarcode.concat(this.partycode);
        this.item.UniqueBarcode = NewBarcode;
        if(this.item.GSTPercentage === 0 || this.item.GSTPercentage === '0' ) {
          this.item.GSTType = 'None';
        }
        let DQty = 0;
        if (this.item.Quantity !== 0 && this.item.Quantity !== "0") {
        

        this.itemList.forEach(ele => {
          if(ele.ID === null) {
            if(ele.ProductName === this.item.ProductName && ele.RetailPrice === this.item.RetailPrice && ele.UnitPrice === this.item.UnitPrice) {
              ele.Quantity = Number(ele.Quantity) + Number(this.item.Quantity);
              ele.SubTotal = Number(ele.SubTotal) + Number(this.item.SubTotal);
              ele.TotalAmount = Number(ele.TotalAmount) + Number(this.item.TotalAmount);
              ele.GSTAmount = Number(ele.GSTAmount) + Number(this.item.GSTAmount);
              ele.DiscountAmount = Number(ele.DiscountAmount) + Number(this.item.DiscountAmount);
              DQty = 1;
            }
          }
        })
        if(DQty === 0){
          this.itemList.unshift(this.item);
        }

        }

        this.calculateGrandTotal();
        this.tempItem = { Item: null, Spec: null };
        DQty = 0
        if (this.gstLock === false && this.gstperLock === false ) {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:this.item.WholeSale, BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };
        } else if (this.gstLock === true && this.gstperLock === false) {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: this.item.GSTType, TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:this.item.WholeSale,BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };

        } else if (this.gstLock === false && this.gstperLock === true) {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: this.item.GSTPercentage, GSTAmount: 0.00, GSTType: 'None', TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:this.item.WholeSale, BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };
        } else {
          this.item = {
            ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: this.selectedProduct, ProductTypeID: null, UnitPrice: 0.00,
            Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
            DiscountAmount: 0.00, GSTPercentage: this.item.GSTPercentage, GSTAmount: 0.00, GSTType: this.item.GSTType, TotalAmount: 0.00, Multiple: false, RetailPrice: '',
            WholeSalePrice: 0, Ledger: true, WholeSale:this.item.WholeSale, BaseBarCode: null, NewBarcode: '', Status: 1, BrandType: false, UniqueBarcode: ''
            };
            this.item.BaseBarCode = null;
            this.item.NewBarcode = null;  
            
        }
        // if(this.loggedInCompany.WholeSale === 'true'){
        //   if (this.item.WholeSale === false || this.item.WholeSale === 'false' ) {
        //      this.item.WholeSale = true;
        //   } 
        // }
 
if(this.item.WholeSale === true ){
    this.item.WholeSale = true;
  }
   if(this.item.WholeSale === false){
    this.item.WholeSale = false;
  }
        if (this.selectedProduct !== null || this.selectedProduct !== '') {
          this.prodList.forEach(element => {
              if (element.Name === this.selectedProduct){ this.item.ProductTypeID = element.ID; }
            });

          }

            // this.selectedProduct = '';
            // this.specList = [];
        

        // this.selectedProduct = "";
        // this.specList = [];
        this.specList.forEach(element => {
          if(element.CheckBoxValue === false || element.CheckBoxValue === undefined) {
            element.SelectedValue = '';
          } else {
            element.SelectedValue = element.SelectedValue;
          }
        });

       }, (err) => {
         console.log(err);
       });
  }

    if (this.category === 'Charges'){
      if (this.selectedPurchaseMaster.ID !== null){this.charge.Status = 2; }
      this.charge.ID = null;
      this.chargeList.push(this.charge);
      this.calculateGrandTotal();
      this.charge = {
      ID: null, ChargeType: null, CompanyID: null, Description: '', Amount: 0.00, Price: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
      GSTType: '', TotalAmount: 0.00, Status: 1 };
  }
  this.calculateGrandTotal();
 
  


  }

  notifyGst() {
    if(this.item.GSTPercentage !== 0 && this.item.GSTPercentage !== "0") {
     if(this.item.GSTType === 'None') {
      alert("please select GstType");
     }
    }
  }

  calculateGrandTotal(){
    this.selectedPurchaseMaster.Quantity = 0;
    this.selectedPurchaseMaster.SubTotal = 0;
    this.selectedPurchaseMaster.DiscountAmount = 0;
    this.selectedPurchaseMaster.GSTAmount = 0;
    this.selectedPurchaseMaster.TotalAmount = 0;
    this.sgst = 0;
    this.cgst = 0;
    this.gstdividelist.forEach(ele => {
        ele.Amount = 0;
    })
    this.itemList.forEach(element => {
      if (element.Status !== 0){
      this.selectedPurchaseMaster.Quantity = +this.selectedPurchaseMaster.Quantity + +element.Quantity;
      this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.SubTotal;
      this.selectedPurchaseMaster.DiscountAmount = +this.selectedPurchaseMaster.DiscountAmount + +element.DiscountAmount;
      this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
      this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
      this.gstdividelist.forEach(ele => {
        if(element.GSTType === ele.GstType && element.Status !== 0 && element.GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(element.GSTAmount);
        }
      })
      if(element.Status !== 0 && element.GSTType.toUpperCase() === 'CGST-SGST') {
       
         this.sgst +=  Number(element.GSTAmount) / 2 ;
         this.cgst +=  Number(element.GSTAmount) / 2 ;

      }
    });

    this.chargeList.forEach(element => {
      if (element.Status !== 0){
        if(element.ID === null) {
          this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.Price;

        } else {
          this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.Amount;

        }
      this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
      this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
      this.gstdividelist.forEach(ele => {
        if(element.GSTType === ele.GstType && element.Status !== 0 && element.GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(element.GSTAmount);
        } 
      })
       if(element.Status !== 0 && element.GSTType.toUpperCase() === 'CGST-SGST') {
        this.sgst +=  Number(element.GSTAmount) / 2 ;
        this.cgst +=  Number(element.GSTAmount) / 2 ;
      }
    });
    
  }


  getSupplierDetails(event) {
    const index = this.supplierList.findIndex(element => element.Name === event.value);
    this.selectedPurchaseMaster.SupplierID = this.supplierList[index].ID;
    this.selectedPurchaseMaster.SupplierName = this.supplierList[index].Name;
    this.selectedPurchaseMaster.GSTNo = this.supplierList[index].GSTNo;

    if(this.supplierList[index].Sno !== null) { 
    this.partycode = this.supplierList[index].Sno;
    } else {
      this.partycode = '0'; 
    }
  }

  // getPreorderPurchaseList(){
  //   this.companyService.getPreorderPurchaseList('Purchase', this.selectedPurchaseMaster.SupplierID, this.selectedPurchaseMaster.ShopID).subscribe(data => {
  //    this.itemList = data.result;
  //     this.spinner.hide();
  //     this.showNotification(
  //       'bg-green',
  //       'Data Loaded successfully',
  //       'top',
  //       'right'
  //     );
  //   }, (err) => {
  //     console.log(err);
  //     // this.showFailure(err, 'Error Loading Data.');
  //     this.spinner.hide();
  //     this.showNotification(
  //       'bg-red',
  //       'Error Loading Data.',
  //       'top',
  //       'right'
  //     );
  //   });
  // }

  getfieldList() {
    if (this.selectedProduct !== null || this.selectedProduct !== '') {
    this.prodList.forEach(element => {
        if (element.Name === this.selectedProduct){ 
          this.item.ProductTypeID = element.ID; 
          this.item.GSTPercentage = element.GSTPercentage;
          this.item.GSTType = element.GSTType;
        }
      });
    this.item.ProductTypeName = this.selectedProduct;
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
        this.specList = data.result;
        this.getSptTableData();
        this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  displayAddField(i) {
    this.specList[i].DisplayAdd = 1;
    this.specList[i].SelectedValue = '';

  }

  saveFieldData(i) {
    this.specList[i].DisplayAdd = 0;
    let count = 0;
    this.specList[i].SptTableData.forEach(element => {
      if (element.TableValue.toLowerCase() === this.specList[i].SelectedValue.toLowerCase()) { count = count + 1; }

    });
    if (count !== 0 || this.specList[i].SelectedValue === '') { 
      // alert("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: ' ',
        footer: ''
      });
     } else {
      const Ref = this.specList[i].Ref;
      let RefValue = 0;
      if (Ref !== 0) {
        this.specList.forEach((element, j) => {
          if (element.FieldName === Ref) { RefValue = element.SelectedValue; }
        });
      }

      this.spinner.show();
      this.companyService.saveProductSupportData(this.specList[i].SelectedValue, RefValue, this.specList[i].SptTableName)
        .subscribe(data => {
          this.companyService.getProductSupportData(this.specList[i].SptTableName, RefValue).subscribe(data1 => {
            this.specList[i].SptTableData = data1.result;
            this.specList[i].SptFilterData = data1.result;
            this.spinner.hide();
            this.showNotification(
              'bg-green',
              'Data Saved successfully',
              'top',
              'right'
            );
          }, (err) => {
            console.log(err);
            // this.showFailure(err, 'Error Loading Data.');
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Error not saved Data.',
              'top',
              'right'
            );
          });
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Data not saved.',
            'top',
            'right'
          );
        });
    }

  }

  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 14) {
      this.addItem();
    }
    if (event.keyCode === 17) {
      this.onSubmit();
    }
  }

  onSubmit() {

  if(this.selectedPurchaseMaster.preOrder !== true ) {
     
    this.spinner.show();
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.PurchaseDetail = JSON.stringify(this.itemList);

    this.data.Charge = this.chargeList;
    // this.spinner.hide();
  
    alert("If there is a lot of items, then press the top side back button, your data will be saved in the back side process and you should check the view product inventory of product save")
   
    this.companyService.savePurchase('Purchase', this.data).subscribe(data1 => {
    
      this.spinner.hide();
      if(this.selectedPurchaseMaster.preOrder === 'true') {
        this.router.navigate(['/inventory/preorderlist']);
        this.spinner.hide();
  
      }
      else {
      this.router.navigate(['/inventory/purchase' , data1.pMasterID]);
      }
      this.id = data1.pMasterID;
      this.companyService.getPurchaseFullDataByID(data1.pMasterID).subscribe(data => {
        this.selectedPurchaseMaster = data.result.PurchaseMaster;
        this.itemList = data.result.PurchaseDetail;
        this.chargeList = data.result.Charge;
        this.selectedProduct = "";
        this.specList = [];
        this.item.GSTType = "";
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    }); 
  } else {
    this.spinner.show();
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.PurchaseDetail = JSON.stringify(this.itemList);
    this.data.PurchaseMaster.page = 'purchase';
    this.data.Charge = this.chargeList;
    this.companyService.savePurchase('Purchase', this.data).subscribe(data1 => {
      // this.showNotification(
      //   'bg-green',
      //   'Data save po successfully',
      //   'top',
      //   'right'
      // );
      this.spinner.hide();
        this.router.navigate(['/inventory/preorderlist']);
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    }); 
  }
  
  }

  updatedPurchase(){
    this.spinner.show();
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.Charge = this.chargeList;
    let items = [];
    this.itemList.forEach(ele => {
      if(ele.ID === null || ele.Status == 0 && ele.UpdatedBy === null) {
        ele.UpdatedBy = this.loggedInUser.ID;
        items.push(ele);
      }
    })
    this.data.PurchaseDetail = JSON.stringify(items) ;
if(items.length !== 0) {
  alert("If there is a lot of items, then press the top side back button, your data will be saved in the back side process and you should check the view product inventory of product save")
  console.log(this.data,'josn');

  // const datum = [
  //   {
  //    "name": "SONATA SLEEK 7128SL03 GENTS WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "SONATA SLEEK 7128WL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "SONATA SLEEK 7131SL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE CONNECT SMARTWATCH[BLACK]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE ENGAGE SMARTWATCH[BLACK]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE ENGAGE SMARTWATCH[GOLD BLACK]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE MAX BUZZ [BLACK]",
  //    "balance": 4
  //   },
  //   {
  //    "name": "TAGG VERVE MAX BUZZ SMARTWATCH[GOLD BLACK]",
  //    "balance": 3
  //   },
  //   {
  //    "name": "TAGG VERVE MAX BUZZ SMARTWATCH[GREY]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE MAX SMARTWATCH[BLACK]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE MAX SMARTWATCH[GOLD BLACK]",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TAGG VERVE MAX SMARTWATCH[SILVER GREY",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE NEO SMARTWATCH[BLACK]",
  //    "balance": 3
  //   },
  //   {
  //    "name": "TAGG VERVE NEO SMARTWATCH[GREY]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TAGG VERVE SENSE SMARTWATCH[BLACKGREY]",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TAGG VERVE SMARTWATCH[GREEN]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX A304 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX A500 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TI000U90100 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TI000U90300 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TW000BW09 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TW000EL10 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TW000LS26 LADIES WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TIMEX TW000R433 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TW000S812 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TW000T616 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TW0TG6400 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TW0TL9305 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TWEG16501 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TWEG16519 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TWEG18504  GENTS CHRONOGRAPH WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TWEL13101 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TWESK1003T DIGITAL WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TIMEX TWESK1201T DIGITAL WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1578BM02 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1585 SL08 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1585SL07C GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1585SL10B GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1585SM05C GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1593SL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1636YM01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1640SL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1644YM01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1648YM GENTS WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 1648YM01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1648YM03 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1650BM GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1650YM06 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1713BM01 GENTS WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 1715YM01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1729SM05 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1733KM02 CHRONOGRAPH GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1734KM01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1734SL02 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1735SL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1735SM02 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1737SL02 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1737SM02 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1756NL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1770SL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1770SL01 GENTSB WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1775BM GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1777BM02 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1802SL03 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1802SL09 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1806SL03 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1823SL01 GENTS WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 1824KM01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 1824WL01 GENTS WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 1854SL01 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2131YM09 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2455WM01 RAGA LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2457SM01 LADIES WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 2480KM01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2480SM02 LADIES WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 2481SL07 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2481SL08 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2481SL11 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2482SL02 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2486SM01 LADIES WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 2521BM01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2570SM04 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2570SM07 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2574YL LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2576YM01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2593SL LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2594SL01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2597YM01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2598YL03 LADIES WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "TITAN 2598YM02 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2602BM03 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2617SL01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2617SM02 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2626SL01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2635SM01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2638WM01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2639SL03 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2639WL01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 2648SM02 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN 9151YMO1 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN CHRONOGRAPH GENTS 1734KM02 WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN RAGA 2553WM01 LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TITAN SUNGLASSES CM310BR1P",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX BY TIMEX TM0TG7109 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG6900T GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7100 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7102 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7200 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7202 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7300 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7403 GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7815T GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG7816T GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG8200T GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TM0TG8202T GENTS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TMTL10504T LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TMTL10901T LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TMTL11101T LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "TMX TMTL11200T LADIES WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZEBRONICS FIT1220CH SMARTWATCH[GOLD]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZEBRONICS FIT4220CH SMARTWATCH[GRAY]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZEBRONICS FIT8220CH SMARTWATCH[BLUE]",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZEBRONICS ZEB-FITME SMARTWATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZOOP 26019PP01W KIDS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZOOP 3025PP03 KIDS WATCH",
  //    "balance": 2
  //   },
  //   {
  //    "name": "ZOOP 3025PP25 KIDS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZOOP 4048PP25W KIDS WATCH",
  //    "balance": 1
  //   },
  //   {
  //    "name": "ZOOP C4005PP02 KIDS WATCH",
  //    "balance": 1
  //   }
  //  ]

  //  const d = []

  //  datum.forEach(e => {
  //   d.push(
  //     {
  //       "ID": null,
  //       "PurchaseID": null,
  //       "CompanyID": null,
  //       "ProductName": "PRODUCT/" + e.name,
  //       "ProductTypeName": "PRODUCT",
  //       "ProductTypeID": 648,
  //       "UnitPrice": 0,
  //       "Quantity": e.balance.toString(),
  //       "SubTotal": 0,
  //       "DiscountPercentage": 0,
  //       "DiscountAmount": 0,
  //       "GSTPercentage": 0,
  //       "GSTAmount": 0,
  //       "GSTType": "None",
  //       "TotalAmount": 0,
  //       "Multiple": false,
  //       "RetailPrice": 0,
  //       "WholeSalePrice": 0,
  //       "Ledger": true,
  //       "WholeSale": false,
  //       "BaseBarCode": null,
  //       "NewBarcode": null,
  //       "Status": 2,
  //       "BrandType": false,
  //       "ProductExpDate": "0000-00-00",
  //       "Spec": [
  //           {
  //               "SpecID": 2478,
  //               "ProductName": "PRODUCT",
  //               "Required": 1,
  //               "CompanyID": 96,
  //               "FieldName": "TYPE",
  //               "Seq": "1",
  //               "FieldType": "DropDown",
  //               "Ref": "0",
  //               "SptTableName": "TYPE2389461",
  //               "SptTableData": [
  //                   {
  //                       "ID": 18262,
  //                       "TableName": "TYPE2389461",
  //                       "RefID": "0",
  //                       "TableValue": "PRODUCT",
  //                       "Status": 1,
  //                       "UpdatedOn": null,
  //                       "UpdatedBy": null
  //                   }
  //               ],
  //               "SelectedValue": "",
  //               "DisplayAdd": 0,
  //               "EnteredValue": "",
  //               "SptFilterData": [
  //                   {
  //                       "ID": 18262,
  //                       "TableName": "TYPE2389461",
  //                       "RefID": "0",
  //                       "TableValue": "PRODUCT",
  //                       "Status": 1,
  //                       "UpdatedOn": null,
  //                       "UpdatedBy": null
  //                   }
  //               ]
  //           },
  //           {
  //               "SpecID": 2479,
  //               "ProductName": "PRODUCT",
  //               "Required": 1,
  //               "CompanyID": 96,
  //               "FieldName": "DESCRIPTION",
  //               "Seq": "2",
  //               "FieldType": "Text",
  //               "Ref": "0",
  //               "SptTableName": "",
  //               "SptTableData": null,
  //               "SelectedValue": "",
  //               "DisplayAdd": 0,
  //               "EnteredValue": "",
  //               "SptFilterData": null
  //           }
  //       ],
  //       "UniqueBarcode": "22121/101",
  //       "UpdatedBy": 494
  //   }
  //   )
  //  })
  //  this.data.PurchaseDetail = JSON.stringify(d)
  //  console.log(this.data.PurchaseDetail , 'dthis.data.PurchaseDetail');
   


  
    this.companyService.updatePurchase('Purchase', this.data).subscribe(data1 => {
      this.id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
      this.onPageLoad();
      this.item.UnitPrice = 0;
      this.item.Quantity = 0;
      this.item.DiscountPercentage = 0;
      this.item.DiscountAmount = 0;
      this.item.SubTotal = 0;
      this.item.GSTPercentage = 0;
      this.item.GSTAmount = 0;
      this.item.GSTType = null;
      this.item.TotalAmount = 0;
      this.item.RetailPrice = '';
      this.item.WholeSalePrice = 0;
      this.selectedProduct = "";
      this.specList = [];
      this.barcodeListt = [];
      this.item.GSTType = "None";
      this.item.UniqueBarcode = '';
      this.selectedProduct = '';
      // this.router.navigate(['/inventory/purchaselist']);
      // this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    });
  } else {
    // this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    // this.data.PurchaseMaster = this.selectedPurchaseMaster;
    // this.data.Charge = this.chargeList;
    // const index = this.supplierList.findIndex(element => element.ID === this.selectedPurchaseMaster.SupplierID);
 
    // if(this.supplierList[index].Sno !== null) {
    // this.partycode = this.supplierList[index].Sno;
    // } else {
    //   this.partycode = '0'; 
    // }
    // this.itemList.forEach(ele => {
    //   let NewBarcode = '';
    //   if(this.loggedInCompanySetting.year === 'true') {
    //     NewBarcode = NewBarcode.concat(this.year);
    //   }  
    //   if (this.loggedInCompanySetting.month === 'true') {
    //     NewBarcode = NewBarcode.concat(this.month);

    //   } 
    //   if (this.loggedInCompanySetting.partycode === 'true') {
    //     NewBarcode = NewBarcode.concat(this.partycode);
    //   }
    //    if (this.loggedInCompanySetting.type === 'true' && ele.GSTType !== 'None' && ele.GSTPercentage !== 0 ) {
    //     NewBarcode = NewBarcode.concat(this.type);
    //   }
    //   if (this.loggedInCompanySetting.type === 'true' && ele.GSTType === 'None' && ele.GSTPercentage === 0 ) {
    //     NewBarcode = NewBarcode.concat("/");
    //   }
    //   NewBarcode = NewBarcode.concat(this.partycode);
    //   let unitpReverse = ele.UnitPrice.toString().split('').reverse().join('').toString();
    //   NewBarcode = NewBarcode.concat(unitpReverse);
    //   NewBarcode = NewBarcode.concat(this.partycode);
    //   ele.UniqueBarcode = NewBarcode;
    // })
    // this.data.PurchaseDetail = JSON.stringify(this.itemList);
    // console.log(this.itemList,'SupplierIDSupplierID');
    
    // PurchaseOne
    this.companyService.updatePurchase('Purchase', this.data).subscribe(data1 => {
      this.id = parseInt(this.route.snapshot.paramMap.get('id'), 10);

      this.onPageLoad();
      this.item.UnitPrice = 0;
      this.item.Quantity = 0;
      this.item.DiscountPercentage = 0;
      this.item.DiscountAmount = 0;
      this.item.SubTotal = 0;
      this.item.GSTPercentage = 0;
      this.item.GSTAmount = 0;
      this.item.GSTType = null;
      this.item.TotalAmount = 0;
      this.item.RetailPrice = '';
      this.item.WholeSalePrice = 0;
      this.selectedProduct = "";
      this.specList = [];
      this.item.GSTType = "None";
      this.item.UniqueBarcode = '';
      this.selectedProduct = '';
      this.barcodeListt = [];
      // this.router.navigate(['/inventory/purchaselist']);
      // this.spinner.hide();
     
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    });
    this.spinner.hide();

  }
  }


  checkInvoicNo() {
    let Param = {"SupplierName": this.selectedPurchaseMaster.SupplierName , InvoiceNo: this.selectedPurchaseMaster.InvoiceNo.trim()};
    // console.log(Param , 'InvoiceNo');
    this.companyService.getcheckInvoicNo(JSON.stringify(Param)).subscribe(data1 => {
      this.checkInvoiceNo = data1.data;
      if (this.checkInvoiceNo.length !== 0) {
        
        Swal.fire({
          icon: 'error',
          title: 'Duplicate InvoiceNo not Allowed',
          text: '',
          footer: ''
        });
        this.selectedPurchaseMaster.InvoiceNo = null;
      }      
    }, (err) => {
      console.log(err);      
    });
  }
   //  printer

  



  PrintData() {

  // tslint:disable-next-line:max-line-length
  // const dataToPrint = '<html>' + this.myDiv.nativeElement.innerHTML + '</html>';

  var dataToPrint; 
  if(this.loggedInCompanySetting.BarCode === '3'){
    dataToPrint = '<html>' + this.myDiv.nativeElement.innerHTML + '</html>';
  }else if (this.loggedInCompanySetting.BarCode === '2'){
    dataToPrint = '<html>' + this.myDiv1.nativeElement.innerHTML + '</html>';
  }else if (this.loggedInCompanySetting.BarCode === '1'){
    dataToPrint = '<html>' + this.myDiv2.nativeElement.innerHTML + '</html>';
  }else if (this.loggedInCompanySetting.BarCode === '0'){
    dataToPrint = '<html>' + this.myDiv3.nativeElement.innerHTML + '</html>';
  }

    // const code = '12345';

    // convenience method
    // const chr = function(n) { return String.fromCharCode(n); };

    // const barcode = '\x1D' + 'h' + chr(80) +   //barcode height
    //     '\x1D' + 'f' + chr(0) +              //font for printed number
    //     '\x1D' + 'k' + chr(69) + chr(code.length) + code + chr(0); //code39

  const data = [{
      type: 'pixel',
      format: 'html',
       flavor: 'plain', // or 'file' if using a URL
      data: dataToPrint,
      // options: { length: 'ESCPOS', dotDensity: 'double' }
    }]; 
  }




  // get getBarcodelist
  getBarcodelist(data){
    this.companyService.getSearchBarCodeFilter(data.ID, true, '').subscribe(data => {
      this.barcodeList = data.data;
      this.tempQty = 0;

      this.barcodeList.forEach(element => {
        this.getPrintBySelectedItem(element);
      });
    }, (err) => {
      console.log(err);
    });

  }

  allPrint() {
    this.itemList.forEach(ele => {
      this.getBarcodelist(ele);
    })
  }

  getPrintBySelectedItem(data){
    
    // this.selectedItemPrint.Quantity = data.Quantity;
    // this.tempQty = this.tempQty + 1; 

    this.selectedItemPrint.BarCode = data.Barcode;
    this.selectedItemPrint.ProductName = data.ProductName.split("/")[1];
    this.selectedItemPrint.ProductNames = data.ProductName.split("/")[2].substr(0, 15);
    this.selectedItemPrint.retailprice = data.RetailPrice;
    this.selectedItemPrint.uniqueBarcode = data.UniqueBarcode;
    this.selectedItemPrint.shopName = data.BarcodeShopName;

    this.changeDectectorRef.detectChanges();
    console.log('THISISMYDATA', this.myDiv.nativeElement.innerHTML);
    console.log('THISISMYDATA', this.tempQty);

    this.PrintData();
  }
  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

  barcodePrint(data) {
    this.spinner.show();
    this.companyService.getSearchBarCodeFilter(data.ID, true, '').subscribe(data => {
      this.companyService.BarcodePrint('barcodePrint', data.data[0]).subscribe(data => {
        this.spinner.hide();
        const url =  data;
        window.open(url, "_blank");
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    }, (err) => {
      console.log(err);
    });
  }

 

  barcodePrintAll() {
  if(this.barcodeListt.length != 0) {
   let tempItem = [];
   let len = 0;
   let Qty = 0;
   this.spinner.show();
    this.barcodeListt.forEach(ele => {
      if(ele.Status !== 0) {
        len = len + 1;
        Qty = Qty + ele.Quantity;
      this.companyService.getSearchBarCodeFilter(ele.ID, true, '').subscribe(data => {
        if(data.data.length != 0) {        
          tempItem.push(data.data[0]);
        } else {
          len = len - 1;
        }
        console.log(Qty,'qqqqqq');
        if(Qty < 201){
          if(len === tempItem.length) {
            this.companyService.BarcodePrintAll('barcodePrint', tempItem).subscribe(data => {
              this.spinner.hide();
              const url =  data;
              window.open(url, "_blank");
            }, (err) => {
              console.log(err);
              this.showNotification(
                'bg-red',
                'Error Loading Data',
                'top',
                'right'
              );
            });
  
          }
        }else{
          alert('You Can Not Print More Then 200 Qty')
          this.spinner.hide();
        }
        
       

      }, (err) => {
        console.log(err);
      });
    }
    })
  } else {
    alert('please select product');
  }

    
  }

  selectBarcode(type) {
 if(type === 'all') {
   if(this.checked === true) {
     this.checked = false;
   } else {
    this.checked = true;

   }
   this.barcodeListt = [];

   this.spinner.show();
   this.itemList.forEach((ele, i) => {
     if(this.checked === true) {
     if(ele.Status !== 0) {
      ele.Checked = 1;
      ele.index = i;
      this.barcodeListt.push(ele);
     }
     } else {
      ele.Checked = 0;
      this.barcodeListt = [];

     }
   })
   this.spinner.hide();

 }
  }

  PoPDF(){
    
    let data1 = { Shop: this.loggedInShop, Company: this.loggedInCompanySetting, selectedPurchaseMaster:this.selectedPurchaseMaster,sampleitem:this.sampleitem, samplecharge:this.samplecharge ,itemList:this.itemList }
   console.log(data1,'data1data1data1');
   
    this.spinner.show();
    this.companyService.PurchasePDF(' ', data1).subscribe(data => {
      this.spinner.hide();
      const url = this.env.apiUrl + data;
      this.urlAss = url;
      window.open(url, "_blank");

    }, (err) => { console.log(err);
               
    });
  }

  singleSelectBarcode(i) {
    if(this.itemList[i].Checked === false || this.itemList[i].Checked === 0 ) {
      this.itemList[i].index = i;
      this.barcodeListt.push(this.itemList[i]);

    } else if(this.itemList[i].Checked === true || this.itemList[i].Checked === 1 ) {
      // this.barcodeListt.forEach(el => {
      //   if(this.itemList[i].ID === el.ID) {
      //     this.barcodeListt.splice(el, 1);
      //   }
      // })

      this.barcodeListt.forEach((el, iind)=> {
        if(this.barcodeListt[iind].index === i) {
          this.barcodeListt.splice(iind, 1);
        }
      })
     

    }
    console.log(this.barcodeListt);

  }

  tempBarcode: any;

  barcodeprintbyQty(data:any) {
    this.tempBarcode = data;
    
  }

  BarcodeQty(){
    if (Number(this.BarcodeQuantity) >= 201) {
      alert('You Can Not Print More Then 200 Qty')
      return
    }


    let tempItem = [];
    let tempItem2 = [];
   let len = 0;
    this.spinner.show()
    this.companyService.getSearchBarCodeFilter(this.tempBarcode.ID, true, '').subscribe(data => {
      if(data.data.length != 0) { 
        len = len + 1       
        tempItem.push(data.data[0]);
      } else {
        len = len - 1;
      }
      
        if(len === tempItem.length) {
          tempItem[0].Quantity = Number(this.BarcodeQuantity) 
          tempItem.forEach(ele => {
            if(ele.ProductTypeName !== 'SUNGLASSES' && ele.ProductTypeName !== 'SUNGLASS'){
              let ProductFullName = ele.ProductName
              let ProductName = ele.ProductName.split("/")[1];
              if(ele.CompanyID != '9'){
                  let ProductNames = ele.ProductName.split("/")[2].substr(0, 15);
                  ele.ProductNames = ProductNames;
              }
              ele.ProductFullName = ProductFullName;
              ele.ProductName = ProductName;
          } else {
              let ProductFullName = ele.ProductName
              let ProductName = ele.ProductName.split("/")[0];
              if(ele.CompanyID != '9'){
                  let ProductNames = ele.ProductName.split("/")[2].substr(0, 15);
                  ele.ProductNames = ProductNames;
              }
              ele.ProductFullName = ProductFullName;
              ele.ProductName = ProductName;
          }
          }) 
          
          for(var i = 0; i < Number(this.BarcodeQuantity); i++ ) {
            tempItem2.push(tempItem[0]);
            
          }
          // console.log(tempItem2 , tempItem2.length);
          
          // this.spinner.hide()
          // return
          this.companyService.BarcodePrintAlls('barcodePrint', tempItem2).subscribe(data => {
            this.spinner.hide();
            const url =  data;
            window.open(url, "_blank");
          }, (err) => {
            console.log(err);
            this.showNotification(
              'bg-red',
              'Error Loading Data',
              'top',
              'right'
            );
          });

        }
      
      
     

    }, (err) => {
      console.log(err);
    });    

    
  }
  // BarcodeQty(){
  //   if (Number(this.BarcodeQuantity) >= 201) {
  //     alert('You Can Not Print More Then 200 Qty')
  //     return
  //   }


  //   let tempItem = [];
  //  let len = 0;
  //   this.spinner.show()
  //   this.companyService.getSearchBarCodeFilter(this.tempBarcode.ID, true, '').subscribe(data => {
  //     if(data.data.length != 0) { 
  //       len = len + 1       
  //       tempItem.push(data.data[0]);
  //     } else {
  //       len = len - 1;
  //     }
  //       if(len === tempItem.length) {
  //         tempItem[0].Quantity = Number(this.BarcodeQuantity)          
  //         this.companyService.BarcodePrintAll('barcodePrint', tempItem).subscribe(data => {
  //           this.spinner.hide();
  //           const url =  data;
  //           window.open(url, "_blank");
  //         }, (err) => {
  //           console.log(err);
  //           this.showNotification(
  //             'bg-red',
  //             'Error Loading Data',
  //             'top',
  //             'right'
  //           );
  //         });

  //       }
      
      
     

  //   }, (err) => {
  //     console.log(err);
  //   });    

    
  // }

  



}
