import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { ThemePalette } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import * as qz from 'qz-tray';
import { sha256 } from 'js-sha256';
import { KJUR, KEYUTIL, stob64, hextorstr } from 'jsrsasign';
import 'rxjs/add/observable/fromPromise';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';

@Component({
  selector: 'app-purchase-convert',
  templateUrl: './purchase-convert.component.html'
})
export class PurchaseConvertComponent implements OnInit {

  @ViewChild('myDiv') myDiv: ElementRef;
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  specList: any = [];
  supplierList: any[];
  shopList = [];
  item: any;
  category = 'Product';
  disableAddButtons = true;
  barcodeList: any;
  selectedItemPrint: any = { BarCode: null, ProductTypeName: null };
  tempItem = { Item: null, Spec: null };
  itemList = [];
  data = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  selectedPurchaseMaster: any = {
    ID: null, SupplierID: null, SupplierName: null, CompanyID: null, GSTNo: null, ShopID: 0, ShopName: null, PurchaseDate: null,
    PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0, DiscountAmount: 0,
    GSTAmount: 0, TotalAmount: 0
  };
  filterList: any[];
  gstList: any;
  checkInvoiceNo: any;
  gstdividelist = [];
  sgst: any = 0;
  cgst: any = 0;
  serverCount = 0;
count = 0;
offset = 0;
limit = 0;
pageParam = '';
year = moment(new Date()).format('YY');
month = moment(new Date()).format('MM');
partycode = '';
type = '*';
  constructor(private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private changeDectectorRef: ChangeDetectorRef

    // private toastrService: ToastrService,
  ) {
    // qz.api.setSha256Type(data => sha256(data));
    // qz.api.setPromiseType(resolver => new Promise(resolver));
  }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  ngOnInit() {


    this.onPageLoad();

    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
      this.getShopListByID();
    } else {


      this.getShopList();

    }
    this.getGstList();
  }

  onPageLoad() {
    this.spinner.show();
    this.selectedPurchaseMaster.PurchaseDate = moment(new Date()).format('YYYY-MM-DD');

    this.getSupplierList();
    this.showNotification(
      'bg-green',
      'Data Loaded successfully',
      'top',
      'right'
    );
  }

  onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 1).subscribe(data => {
      this.supplierList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  calculateFields(fieldName, mode, item) {

    switch (mode) {

      case 'subTotal':
        item.SubTotal = +item.Quantity * +item.UnitPrice - item.DiscountAmount;
        item.DiscountAmount = item.UnitPrice * item.Quantity * +item.DiscountPercentage / 100;
        item.GSTAmount =
          (+item.SubTotal - item.DiscountAmount) * +item.GSTPercentage / 100;
        break;
      case 'discount':
        if (fieldName === 'DiscountPercentage') {
          item.DiscountAmount = item.UnitPrice * item.Quantity * +item.DiscountPercentage / 100;
          item.SubTotal = item.UnitPrice * item.Quantity - item.DiscountAmount;

        }
        if (fieldName === 'DiscountAmount') {
          this.item.DiscountPercentage = +this.item.DiscountAmount * 100 / +this.item.UnitPrice * +this.item.Quantity / 100;
          // this.item.DiscountAmount = +this.item.UnitPrice * +this.item.Quantity  * +this.item.DiscountPercentage / 100; 
          this.item.SubTotal = +this.item.UnitPrice * +this.item.Quantity - this.item.DiscountAmount;

        }
        break;
      case 'gst':
        if (fieldName === 'GSTPercentage') {
          item.GSTAmount =
            (+item.SubTotal - item.DiscountAmount) * +item.GSTPercentage / 100;
        }
        if (fieldName === 'GSTAmount') {
          item.GSTPercentage =
            100 * +item.GSTAmount / (+item.SubTotal - item.DiscountAmount);
        }
        break;
      case 'total':
        item.TotalAmount = +item.SubTotal + +item.GSTAmount - +item.DiscountAmount;
        break;
    }
    item.TotalAmount = +item.SubTotal + +item.GSTAmount;
    // item.SubTotal = +item.SubTotal - +item.DiscountAmount;



  }

  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => {
      this.gstList = data.result;
      this.gstdividelist = [];
      data.result.forEach(ele => {

        if (ele.Name.toUpperCase() !== 'CGST-SGST') {
          let obj = { GstType: '', Amount: 0 };
          obj.GstType = ele.Name;
          this.gstdividelist.push(obj);

        }
      })
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result, 'shoplistttt');
      this.shopList.push(data.result);
      if (this.shopList.length === 1) {
        this.selectedPurchaseMaster.ShopID = this.shopList[0].ID
      }
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  calculateGrandTotal() {
    this.selectedPurchaseMaster.Quantity = 0;
    this.selectedPurchaseMaster.SubTotal = 0;
    this.selectedPurchaseMaster.DiscountAmount = 0;
    this.selectedPurchaseMaster.GSTAmount = 0;
    this.selectedPurchaseMaster.TotalAmount = 0;
    this.sgst = 0;
    this.cgst = 0;
    this.gstdividelist.forEach(ele => {
      ele.Amount = 0;
    })
    this.itemList.forEach(element => {
      if (element.sel === 1) {
        this.gstdividelist.forEach(ele => {
          if (element.GSTType === ele.GstType && element.Status !== 0 && element.GSTType.toUpperCase() !== 'CGST-SGST') {
            ele.Amount += Number(element.GSTAmount).toFixed(2);
          }
        })
        if (element.Status !== 0 && element.GSTType.toUpperCase() === 'CGST-SGST') {

          this.sgst += Number(element.GSTAmount) / 2;
          this.cgst += Number(element.GSTAmount) / 2;

        }

        this.selectedPurchaseMaster.Quantity = +this.selectedPurchaseMaster.Quantity + +element.Quantity;
        this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.SubTotal;
        this.selectedPurchaseMaster.DiscountAmount = +this.selectedPurchaseMaster.DiscountAmount + +element.DiscountAmount;
        this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
        this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;

        let NewBarcode = '';
        if (this.loggedInCompanySetting.year === 'true') {
          NewBarcode = NewBarcode.concat(this.year);
        }
        if (this.loggedInCompanySetting.month === 'true') {
          NewBarcode = NewBarcode.concat(this.month);

        }
        if (this.loggedInCompanySetting.partycode === 'true') {
          NewBarcode = NewBarcode.concat(this.partycode);
        }

        if (this.loggedInCompanySetting.type === 'true' && element.GSTType !== 'None' && element.GSTPercentage !== 0) {
          NewBarcode = NewBarcode.concat(this.type);
        }
        if (this.loggedInCompanySetting.type === 'true' && element.GSTType === 'None' && element.GSTPercentage === 0) {
          NewBarcode = NewBarcode.concat("/");
        }
        NewBarcode = NewBarcode.concat(this.partycode);
        let unitpReverse = element.UnitPrice.toString().split('').reverse().join('').toString();
        NewBarcode = NewBarcode.concat(unitpReverse);
        NewBarcode = NewBarcode.concat(this.partycode);
        element.UniqueBarcode = NewBarcode;

      }
      
    });
  }


  getSupplierDetails(event) {
    const index = this.supplierList.findIndex(element => element.Name === event.value);
    this.selectedPurchaseMaster.SupplierID = this.supplierList[index].ID;
    this.selectedPurchaseMaster.SupplierName = this.supplierList[index].Name;
    this.selectedPurchaseMaster.GSTNo = this.supplierList[index].GSTNo;
    if (this.supplierList[index].Sno !== null) {
      this.partycode = this.supplierList[index].Sno;
    } else {
      this.partycode = '0';
    }
  }

  getPreorderPurchaseList() {
    this.count = this.count + 1;
    this.limit = 10 ;
    this.offset = 0;

    this.pageParam = `LIMIT 50 OFFSET ${(this.count - 1) * 50}`
    

    this.spinner.show();
    this.companyService.getPreorderPurchaseList('PurchaseConvertPurchase', this.selectedPurchaseMaster.SupplierID, this.selectedPurchaseMaster.ShopID).subscribe(data => {
      let tempArray = [];
      data.result.sort((a:any, b:any) => a.ID > b.ID ? 1 : -1);
      data.result.forEach(el => {
        el.GSTAmount = (+el.UnitPrice * +el.Quantity - el.DiscountAmount) * +el.GSTPercentage / 100;
        el.TotalAmount = +el.SubTotal + +el.GSTAmount;

        tempArray.push(el);
      })
      this.itemList = tempArray;
      console.log(this.itemList)
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }
  
  

  


  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 17) {
      this.onSubmit();
    }
  }

  onSubmit() {
    let submit = false;
    this.filterList = this.itemList.filter(d => d.sel === 1);
    if (this.filterList.length > 0) {
      submit = true;
      this.filterList.forEach((ele) => {
        if (ele.TotalAmount === 0 || ele.TotalAmount === null) {
          submit = false
        }
      });
      if (!submit) { alert('One of the selected Item does not have Total Amount field Filled. Please correct before Submitting') }
    } else {
      submit = false;
      //  alert('No Items were selected.')
      Swal.fire({
        icon: 'error',
        title: 'No Items were selected.',
        text: ' Please Select Alteast One Item ',
        footer: ''
      });
    }
    if (this.selectedPurchaseMaster.InvoiceNo === null || this.selectedPurchaseMaster.InvoiceNo === '') {
      submit = false;
      // alert("Vendor Invoice No is required")
      Swal.fire({
        icon: 'error',
        title: 'Vendor Invoice No is required',
        text: ' Enter Vendor Invoice No ',
        footer: ''
      });
    }
    if (submit) {
      this.calculateGrandTotal();
      this.spinner.show()
      this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
      this.data.PurchaseMaster = this.selectedPurchaseMaster;
      this.data.PurchaseDetail = JSON.stringify(this.filterList);
      this.companyService.updatePurchase('Purchaseconvert', this.data).subscribe(data1 => {
        this.router.navigate(['/inventory/purchaselist/0']);
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data submitted successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Data not submitted.',
          'top',
          'right'
        );
      });

    }
  }

  multicheck() {
    for (var i = 0; i < this.itemList.length; i++) {
      const index = this.itemList.findIndex((x => x === this.itemList[i]));
      if (this.itemList[index].sel == null || this.itemList[index].sel === 0) {
        this.itemList[index].sel = 1;
      } else {
        this.itemList[index].sel = 0;
      }
    }
  }

  validate(v, event) {
    if (v.sel === 0 || v.sel === null) {
      // event.target.parentNode.parentNode.style = 'background-color:none';
      v.sel = 1;
    } else {
      // event.target.parentNode.parentNode.style = 'background-color:green;color:white;';
      v.sel = 0;

    }
  }


  checkInvoicNo() {

    let Param = { "SupplierName": this.selectedPurchaseMaster.SupplierName, InvoiceNo: this.selectedPurchaseMaster.InvoiceNo.trim() };
    // console.log(Param , 'InvoiceNo');
    this.companyService.getcheckInvoicNo(JSON.stringify(Param)).subscribe(data1 => {
      this.checkInvoiceNo = data1.data;


      if (this.checkInvoiceNo.length !== 0) {

        Swal.fire({
          icon: 'error',
          title: 'Duplicate InvoiceNo not Allowed',
          text: '',
          footer: ''
        });
        this.selectedPurchaseMaster.InvoiceNo = null;
      }
    }, (err) => {
      console.log(err);
    });
  }

  alert() {
    alert("please select GstType");
  }

  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }
  convertDate(date) {
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
  }

  convertToDecimal(num, x) {
    return Number(Math.round(parseFloat(num + 'e' + x)) + 'e-' + x);
  }
  counter(mode){

    if (mode === 'pre' && this.count != 0){
      // this.count = this.count - 1
      // this.pageParam = `LIMIT ${this.limit} OFFSET ${this.offset}`
    }else if (mode === 'next'){
      // this.itemList = [];
     const count = this.count + 1
     const limit = this.limit + 10;
     const offset = limit - this.limit  ;
      this.pageParam = `LIMIT 50 OFFSET ${(this.count) * 50}`
      this.count = count;
      this.limit = limit;
      this.offset = offset;
      
      this.spinner.show();
      this.companyService.getListByPage('PurchaseConvertPurchase', this.selectedPurchaseMaster.SupplierID, this.selectedPurchaseMaster.ShopID, this.pageParam).subscribe(data => {
       if (data.result.length !== 0) {
          data.result.forEach(el => {
          el.GSTAmount = (+el.UnitPrice * +el.Quantity - el.DiscountAmount) * +el.GSTPercentage / 100;
          el.TotalAmount = +el.SubTotal + +el.GSTAmount;
  
          this.itemList.unshift(el);
        })
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
        this.spinner.hide();

      } else {
        alert("you dont have enough data")
        this.count = this.count - 1
        this.spinner.hide();

      }

    
      }, (err) => {
        console.log(err);
       
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });

    }else{
      alert('You do not have more qty')
    }
   
    
  }
 

  showNotification(colorName, text, placementFrom, placementAlign) {

    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'

    });
  }
}

