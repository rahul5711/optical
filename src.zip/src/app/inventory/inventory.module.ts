import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InventoryRoutingModule } from './inventory-routing.module';
import { PurchaseComponent } from './purchase.component';
import { ProductTransferComponent } from './product-transfer.component';
import { SupplierComponent } from './supplier.component';
import { SupplierListComponent } from './supplier-list.component';
import { FitterComponent } from './fitter.component';
import { FitterListComponent } from './fitter-list.component';
import { PurchaseListComponent } from './purchase-list.component';
import { TransferHistoryComponent } from './transfer-history.component';
import { PreorderComponent } from './preorder.component';
import { PreorderHistoryComponent } from './preorder-history.component';
import { SummaryComponent } from './summary.component';
import { PurchaseConvertComponent } from './purchase-convert.component';
import { PurchaseReturnComponent } from './purchase-return.component';
import { FitterInvoiceComponent } from './fitter-invoice.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort';
import { MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { ProductItemFilterInv} from './../filter/prodItemFilterInv';
import { SearchItemFilterInv} from './../filter/searchItemFilterInv';

import { NameFilter} from './../filter/nameFilter';

import { QzTrayService } from './../services/qz-tray.service';
import { NgxBarcodeModule } from 'ngx-barcode';
import { SearchComponent } from './search.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FitterDetailsComponent } from './fitter-details.component';
import {FitterInvoiceListComponent} from './fitter-invoice-list.component';
import { PreorderListComponent } from './preorder-list.component';
import { AutoFoucsDirectivesDirective } from './auto-foucs-directives.directive';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [ PurchaseComponent, ProductTransferComponent, SupplierComponent,PurchaseReturnComponent, SupplierListComponent,
    FitterComponent, FitterListComponent,PurchaseListComponent, TransferHistoryComponent, PreorderComponent, PreorderHistoryComponent,
    SummaryComponent,FitterInvoiceComponent, ProductItemFilterInv,SearchItemFilterInv, NameFilter, SearchComponent,PurchaseConvertComponent, 
    FitterDetailsComponent, FitterInvoiceListComponent,PreorderListComponent,AutoFoucsDirectivesDirective],
  imports: [
    CommonModule,
    NgbModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    MatTableModule,
    NgxBarcodeModule,
    MatPaginatorModule,
    MatFormFieldModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSortModule,
    MatToolbarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatTabsModule,
    MaterialFileInputModule,
    InventoryRoutingModule,
    MatSlideToggleModule,
    NgxSpinnerModule,
    PerfectScrollbarModule,
    NgxMatSelectSearchModule,
    Ng2SearchPipeModule,
  ],
  providers: [     
    QzTrayService
  ]
})
export class InventoryModule { }
