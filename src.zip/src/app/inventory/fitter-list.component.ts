import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService} from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-fitterlist',
  templateUrl: './fitter-list.component.html'
})
export class FitterListComponent implements OnInit {

  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  term:any;
  dataList: any;
  gridview = true;
  stringUrl: string;
  env = environment;
  editFitterList: any;
  addFitterList: any;
  deleteFitterList: any;
  constructor( private companyService: CompanyService, private spinner: NgxSpinnerService, private sanitizer: DomSanitizer,
               private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute) { }


  ngOnInit() { 
     this.permission.forEach(element => {    
    if (element.ModuleName === 'FitterList') {
           this.editFitterList = element.Edit;
           this.addFitterList = element.Add;
           this.deleteFitterList = element.Delete;
         }
       });
    this.spinner.show();
    this.getListData();
  }

  getListData() {
    this.spinner.show();
    const subs: Subscription =  this.companyService.getExtendedListByCompany1('FitterFullList', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe({
      next: (res: any) => {
        this.dataList = res.result;
        this.spinner.hide();
      },
      error: (err: any) => {
        console.log(err.msg);
      },
      complete: () => subs.unsubscribe(),
    });
   
  }

  filterDatatable(event) {
    console.log(event);
  }

  santizePictureList() {
    this.dataList.forEach(element => {
    element.PhotoURL = this.sanitize(element.PhotoURL);
   });
  }

sanitize(imgName: string) {
  if (imgName !== "null" && imgName !== '') {
    this.stringUrl = this.env.apiUrl + imgName;
   } else {
     this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
  return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
}

deleteItem(i){
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      const subs: Subscription = this.companyService.deleteData('Fitter', this.dataList[i].ID).subscribe({
        next: (res: any) => {
          this.dataList.splice(i, 1);
          Swal.fire(
              'Deleted!',
              'Your file has been deleted.',
              'success'
            )
        this.showNotification(
          'bg-green',
          'Data Saved successfully',
          'top',
          'right'
        );
      },
      error: (err: any) => {
        console.log(err.msg);
        this.showNotification(
          'bg-red',
          'Data Not Saved.',
          'top',
          'right'
        );
      },
      complete: () => subs.unsubscribe(),
    });
    }
  })
}

convertDate(date){
  return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
 }

showNotification(colorName, text, placementFrom, placementAlign) {
  this.snackBar.open(text, '', {
    duration: 2000,
    // verticalPosition: placementFrom,
    horizontalPosition: 'left',
    panelClass: colorName,
    verticalPosition: 'bottom'
    
  });
}
}
