import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PurchaseComponent } from './purchase.component';
import { SupplierComponent } from './supplier.component';
import { PurchaseListComponent} from './purchase-list.component';
import { SupplierListComponent} from './supplier-list.component';
import { FitterComponent } from './fitter.component';
import { FitterListComponent } from './fitter-list.component';
import { ProductTransferComponent } from './product-transfer.component';
import { PreorderComponent } from './preorder.component';
import { PreorderHistoryComponent } from './preorder-history.component';
import { SummaryComponent } from './summary.component';
import { SearchComponent } from './search.component';
import { PurchaseConvertComponent } from './purchase-convert.component';
import { FitterDetailsComponent } from './fitter-details.component';
import {FitterInvoiceListComponent} from './fitter-invoice-list.component';
import { PurchaseReturnComponent } from './purchase-return.component';
import { FitterInvoiceComponent } from './fitter-invoice.component';
import { PreorderListComponent } from './preorder-list.component';


const routes: Routes = [
  { path: '',
  children: [
    { path: '', component: SupplierComponent },
    { path: 'supplier/:id', component: SupplierComponent },
     { path: 'supplierlist', component: SupplierListComponent },
     { path: 'preorderlist', component: PreorderListComponent },

     { path: 'fitter/:id', component: FitterComponent },
     { path: 'fitterlist', component: FitterListComponent },
     { path: 'fitterdetails', component: FitterDetailsComponent },

     { path: 'purchase/:id', component: PurchaseComponent },
     { path: 'purchaselist/:id', component: PurchaseListComponent },
     { path: 'fitterinvoicelist/:id', component: FitterInvoiceListComponent },
     { path: 'purchaseconvert', component: PurchaseConvertComponent },
     { path: 'purchasereturn', component: PurchaseReturnComponent },

     { path: 'transfer-product', component: ProductTransferComponent },
     { path: 'pre-order', component: PreorderComponent },
     { path: 'pre-order-history', component: PreorderHistoryComponent },
     { path: 'Summary', component: SummaryComponent },
     { path: 'search', component: SearchComponent},
     { path: 'fitter-invoice/:id', component: FitterInvoiceComponent },
  ]}
  ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InventoryRoutingModule { }
