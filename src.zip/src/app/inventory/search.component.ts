import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSelect } from '@angular/material/select';
import 'rxjs/add/observable/fromPromise';
import { NgxSpinnerService } from "ngx-spinner";



import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  @ViewChild('myDiv') myDiv: ElementRef;
  @ViewChild('myDiv1') myDiv1: ElementRef;
  @ViewChild('myDiv2') myDiv2: ElementRef;
  @ViewChild('myDiv3') myDiv3: ElementRef;


  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));

  black = '#000';
  selectedItemPrint: any = { BarCode: null, ProductName: null , retailprice :null, uniqueBarcode: null, shopName: null };
  selectedCustomer = {
    ID: null, Name: null, CompanyID: null, MobileNo1: "", MobileNo2: "", PhoneNo: "", Address: "", GSTNo: "", Email: "",
    PhotoURL: "", DOB: "", Anniversary: "", RefferedByDoc: "", ReferenceType: "", Category: "", Status: 1, CreatedBy: null,
    UpdatedBy: null, CreatedOn: null, UpdatedOn: null
  };

  options = { WholeSale: false, Manual: false, PreOrder: false };
  payableAmount = 0;
  serviceOptions: any;

  applyPayment = {
    ID: 26, CustomerID: null, CompanyID: null, ShopID: null, CreditType: 'Credit', PaymentDate: null,
    PayableAmount: null, PaidAmount: null, CustomerCredit: null, PaymentMode: null, CardNo: null,
    PaymentReferenceNo: null, Comments: null, Status: 1, CreatedBy: null, CreatedOn: null, UpdatedBy: null,
    UpdatedOn: null, pendingPaymentList: {}
  };
  
  width = 2;
  fontOptions = '1000';
  fontSize = 14;
  fontSizem = 10;
  textMargin = 0;
  margin = 0;
  marginTop = 10;
  marginTopm = 2;

  marginTops = 0;
  marginBottom = 0;
  marginLeft = 65;
  marginLeft1 = 0;
  marginRight = 0;
  UpdateBarcode = false;
  UpdateStatus = false;
  shopMode = false;
  searchBarCode: any;
  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  selectedBarCode: any;
  specList: any = [];
  prodList: any[];
  supplierList: any[];
  shopList: any[];
  item: any;
  service: any;
  category = 'Product';
  disableAddButtons = true;
  tempItem = { Item: null, Spec: null };
  itemList = [];
  serviceList = [];
  SearchBarCodeList = [];
  data = { billMaster: null, Product: null, billDetail: null, service: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  currency = { Symbol: 'INR', Format: '1.2-2' };
  selectedBillMaster: any = {
    ID: null, CustomerID: null, CustomerName: null, CompanyID: null, PurchaseDate: new Date(), GSTNo: null, ShopID: null,
    ShopName: null, BillDate: new Date(), PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0,
    DiscountAmount: 0, GSTAmount: 0, TotalAmount: 0.00, DueAmount: 0.00, AddlDiscount: 0.00, Invoice: null, Receipt: null
  };

  sampleBillItem: any = {
    ID: null, ProductName: null, ProductTypeName: null, ProductTypeID: null, UnitPrice: 0.00,
    Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
    DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'IGST', TotalAmount: 0.00,
    BaseBarCode: null, Barcode: null, Manual: false, PreOrder: false, Ledger: true, WholeSale: false
  };

  sampleitem: any = {
    ID: null, ProductName: null, ProductTypeName: null, ProductTypeID: null, UnitPrice: 0.00,
    Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
    DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'IGST', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
    WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, Manual: false, PreOrder: false
  };
  billItem: any;
  body = {
    customer: null, billMaster: null, billItemList: null, serviceList: null, paidList: null, unpaidList: null,
    loggedInShop: null, loggedInCompany: null
  };
  sampleService: any = {
    ID: null, PurchaseID: null, Name: null, CompanyID: null, Description: null, Price: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
    GSTType: '', TotalAmount: 0.00
  };
  barCodeList: any;
  billItemList = [];
  unpaidList = [{ InvoiceNo: 'No Pending Invoice', TotalAmount: 0.00, DueAmount: 0.00 }];
  paidList = [{ PaymentMode: 'No previous Payment', PaymentDate: null, Amount: 0.00 }];

  billdata = [];
  invoiceLink: any;
  disableApplyPaymentButton: boolean;
  enableallprint = false;



  constructor(private companyService: CompanyService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute,
    private changeDectectorRef: ChangeDetectorRef
  ) {
    // qz.api.setSha256Type(data => sha256(data));
    // qz.api.setPromiseType(resolver => new Promise(resolver));
  }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  public id2 = parseInt(this.route.snapshot.paramMap.get('id2'), 10);

  ngOnInit() {
    console.log(this.loggedInShop.ID , 'shopid');
    // if (this.id2 !== 0) {
    this.companyService.getShortDataByID('Customer', this.id2).subscribe(data => {
      // this.selectedCustomer = data.result;
      // this.selectedBillMaster.CustomerID = this.selectedCustomer.ID;
      // // this.selectedBillMaster.CustomerName = this.selectedCustomer.Name;
      // this.selectedBillMaster.CompanyID = this.selectedCustomer.CompanyID;
      // this.selectedBillMaster.GSTNo = this.selectedCustomer.GSTNo;
      // this.selectedBillMaster.PaymentStatus = 'unpaid';
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
    // }

    // if (this.id !== 0){
    this.getBillData(this.id);
    this.getPendingPayments(this.id2);
    this.getPreviousPayments(this.id);
    // }

    this.getProductList();
    this.getserviceOptions();
    // this.getSupplierList();
    this.getShopList();
    this.item = this.sampleitem;
    this.billItem = JSON.parse(JSON.stringify(this.sampleBillItem));
    this.service = this.sampleService;

    // this.initQZ();

  }

  getBillData(ID) {
    this.spinner.show();
    this.companyService.getBillData(ID).subscribe(data => {
      this.spinner.hide();
      this.selectedBillMaster = data.billMaster;
      this.billItemList = data.billDetail;
      this.serviceList = this.data.service;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === 1) {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == 2) {
      event = event.toTitleCase()
    }
    return event;
  }

  getSearchBarCodeFilter(PurchaseDetailID) {
    this.spinner.show();
    this.companyService.getSearchBarCodeFilter(PurchaseDetailID, this.shopMode, 'search').subscribe(data => {
      this.spinner.hide();
      this.SearchBarCodeList = data.data;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }



  getPreviousPayments(ID) {

    const parem = [{ BillMasterID: ID, op: "=" }];
    this.companyService.getExtendedListByParamNew('PaymentDetail', parem).subscribe(data => {
      this.paidList = data.result;
      if (this.paidList.length === 0) { this.paidList = [{ PaymentMode: 'No previous Payment', PaymentDate: null, Amount: 0.00 }]; }
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }


  getPendingPayments(ID) {

    const parem = [{ CustomerID: ID, op: "=" }, { PaymentStatus: "paid", op: "<>" }];
    this.spinner.show();
    this.companyService.getShortListByParamNew('BillMaster', parem).subscribe(data => {
      this.spinner.hide();
      this.unpaidList = data.result;
      if (this.unpaidList.length === 0) { this.unpaidList = [{ InvoiceNo: 'No Pending Invoice', TotalAmount: 0.00, DueAmount: 0.00 }]; }
      this.applyPayment.PayableAmount = this.unpaidList.reduce((a, b) => {
        return a + b.DueAmount;
      }, 0);
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product', 1).subscribe(data => {
      this.prodList = data.result;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getserviceOptions() {
    this.companyService.getShortListByCompany('ServiceMaster', 1).subscribe(data => {
      this.serviceOptions = data.result;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  setValues() {
    this.serviceOptions.forEach(element => {
      if (element.ID === this.service.ServiceType) {
        this.service = element;
      }
    });
  }

  calculateFields1(fieldName, mode) {

    switch (mode) {
      case 'subTotal':
        this.billItem.SubTotal = +this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount;
        break;
      case 'discount':
        if (fieldName === 'DiscountPercentage') {
          this.billItem.DiscountAmount = +this.billItem.SubTotal * +this.billItem.DiscountPercentage / 100;
          this.billItem.SubTotal =
            +this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount;
          if (!this.billItem.WholeSale) { this.billItem.TotalAmount = this.item.SubTotal; } else {
            this.billItem.TotalAmount = this.item.SubTotal + +this.billItem.GSTAmount;
          }
        }
        if (fieldName === 'DiscountAmount') {
          this.billItem.DiscountPercentage = 100 * +this.billItem.DiscountAmount / +this.billItem.SubTotal;
        }
        this.billItem.SubTotal =
          +this.billItem.Quantity * +this.billItem.UnitPrice - this.billItem.DiscountAmount;
        if (!this.billItem.WholeSale) { this.billItem.TotalAmount = this.item.SubTotal; } else {
          this.billItem.TotalAmount = this.item.SubTotal + +this.billItem.GSTAmount;
        }
        break;
      case 'gst':
        if (fieldName === 'GSTPercentage') {
          this.billItem.GSTAmount =
            (+this.billItem.SubTotal - this.billItem.DiscountAmount) * +this.billItem.GSTPercentage / 100;
        }
        if (fieldName === 'GSTAmount') {
          this.billItem.GSTPercentage =
            100 * +this.billItem.GSTAmount / (+this.billItem.SubTotal - this.billItem.DiscountAmount);
        }
        break;
      case 'chgst':
        if (fieldName === 'GSTPercentage') {
          this.service.GSTAmount =
            +this.service.Amount * +this.service.GSTPercentage / 100;
        }
        if (fieldName === 'GSTAmount') {
          this.service.GSTPercentage =
            100 * +this.service.GSTAmount / (+this.service.Amount);
        }
        break;
      case 'total':
        this.billItem.TotalAmount = +this.billItem.SubTotal - +this.billItem.GSTAmount - +this.billItem.DiscountAmount;
        break;
      case 'chtotal':
        this.service.TotalAmount = +this.service.GSTAmount + +this.service.Amount;
        break;
    }
  }


  calculateFields(fieldName, mode) {
    switch (mode) {
      case 'subTotal':
        this.billItem.SubTotal = +this.billItem.Quantity * +this.billItem.UnitPrice;
        break;
      case 'discount':
        if (fieldName === 'DiscountPercentage') {
          this.billItem.DiscountAmount = +this.billItem.Quantity * +this.billItem.UnitPrice * +this.billItem.DiscountPercentage / 100;
        }
        if (fieldName === 'DiscountAmount') {
          this.billItem.DiscountPercentage = 100 * +this.billItem.DiscountAmount / (+this.billItem.Quantity * +this.billItem.UnitPrice);
        }
        break;
      case 'gst':
        if (fieldName === 'GSTPercentage') {
          this.billItem.GSTAmount = (+this.billItem.Quantity *
            +this.billItem.UnitPrice - +this.billItem.DiscountAmount) - ((+this.billItem.Quantity *
              +this.billItem.UnitPrice - +this.billItem.DiscountAmount) / (1 + +this.billItem.GSTPercentage / 100));
        }
        if (fieldName === 'GSTAmount') {
          this.billItem.GSTPercentage =
            100 * +this.billItem.GSTAmount / (+this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount);
        }
        break;
    }
    if (!this.billItem.WholeSale) {
      this.billItem.TotalAmount = +this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount;
      this.billItem.SubTotal = this.billItem.TotalAmount - +this.billItem.GSTAmount;

    } else {
      this.billItem.SubTotal = +this.billItem.Quantity * +this.billItem.UnitPrice - +this.billItem.DiscountAmount;
      this.billItem.TotalAmount = +this.billItem.SubTotal + +this.billItem.GSTAmount;
    }
    this.billItem.GSTAmount = this.convertToDecimal(+this.billItem.GSTAmount, 0);
    this.billItem.GSTPercentage = this.convertToDecimal(+this.billItem.GSTPercentage, 2);
    this.billItem.DiscountAmount = this.convertToDecimal(+this.billItem.DiscountAmount, 0);
    this.billItem.DiscountPercentage = this.convertToDecimal(+this.billItem.DiscountPercentage, 2);
    this.billItem.TotalAmount = this.convertToDecimal(+this.billItem.TotalAmount, 0);
    this.billItem.SubTotal = this.convertToDecimal(+this.billItem.SubTotal, 0);
  }

  convertToDecimal(num, x) {
    return Number(Math.round(parseFloat(num + 'e' + x)) + 'e-' + x);
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  addItem() {
    // this.tempItem.Item = this.item;
    // this.tempItem.Spec = this.specList;
    if (this.category === 'Product') {
      // this.billItem.ProductName = "";

      this.billItemList.push(this.billItem);
      this.billItem = JSON.parse(JSON.stringify(this.sampleBillItem));

      this.selectedProduct = "";
      this.specList = [];

    }

    if (this.category === 'Services') {
      this.serviceList.push(this.service);
      this.service = {
        ID: null, Name: null, CompanyID: null, Description: null, Price: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
        GSTType: '', TotalAmount: 0.00
      };
    }

    this.selectedBillMaster.Quantity = 0;
    this.selectedBillMaster.SubTotal = 0;
    this.selectedBillMaster.DiscontAmount = 0;
    this.selectedBillMaster.GSTAmount = 0;
    this.selectedBillMaster.TotalPrice = 0;

    this.billItemList.forEach(element => {
      this.selectedBillMaster.Quantity = +this.selectedBillMaster.Quantity + +element.Quantity;
      this.selectedBillMaster.SubTotal = +this.selectedBillMaster.SubTotal + +element.SubTotal;
      this.selectedBillMaster.DiscountAmount = +this.selectedBillMaster.DiscountAmount + +element.DiscountAmount;
      this.selectedBillMaster.GSTAmount = +this.selectedBillMaster.GSTAmount + +element.GSTAmount;
      this.selectedBillMaster.TotalAmount = +this.selectedBillMaster.TotalAmount + +element.TotalAmount;
    });

    this.serviceList.forEach(element => {
      this.selectedBillMaster.SubTotal = +this.selectedBillMaster.SubTotal + +element.Amount;
      this.selectedBillMaster.GSTAmount = +this.selectedBillMaster.GSTAmount + +element.GSTAmount;
      this.selectedBillMaster.TotalAmount = +this.selectedBillMaster.TotalAmount + +element.TotalAmount;
    });
  }

  getSupplierDetails(event) {
    const index = this.supplierList.findIndex(element => element.Name === event.value);
    this.selectedBillMaster.SupplierID = this.supplierList[index].ID;
    this.selectedBillMaster.SupplierName = this.supplierList[index].Name;
    this.selectedBillMaster.GSTNo = this.supplierList[index].GSTNo;
  }

  getfieldList() {
    this.enableallprint = false;

    if (this.selectedProduct !== null || this.selectedProduct !== '') {
      this.prodList.forEach(element => {
        if (element.Name === this.selectedProduct) { this.item.ProductTypeID = element.ID; }
      });
      this.item.ProductTypeName = this.selectedProduct;
      this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
        this.specList = data.result;
        this.getSptTableData();
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.spinner.show();
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }
    });

  }

  displayAddField(i) {
    this.specList[i].DisplayAdd = 1;
  }

  saveFieldData(i) {
    this.specList[i].DisplayAdd = 0;
    let count = 0;
    this.specList[i].SptTableData.forEach(element => {
      if (element.TableValue.toLowerCase() === this.specList[i].SelectedValue.toLowerCase()) { count = count + 1; }

    });
    if (count !== 0 || this.specList[i].SelectedValue === '') {
      //  alert("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: ' ',
        footer: ''
      });
    } else {
      const Ref = this.specList[i].Ref;
      let RefValue = 0;
      if (Ref !== 0) {
        this.specList.forEach((element, j) => {
          if (element.FieldName === Ref) { RefValue = element.SelectedValue; }
        });
      }
      this.spinner.show();
      this.companyService.saveProductSupportData(this.specList[i].SelectedValue, RefValue, this.specList[i].SptTableName)
        .subscribe(data => {
          this.companyService.getProductSupportData(this.specList[i].SptTableName, RefValue).subscribe(data1 => {
            this.showNotification(
              'bg-green',
              'Data Saved Sucessfully',
              'top',
              'right'
            );
            this.specList[i].SptTableData = data1.result;
            this.specList[i].SptFilterData = data1.result;
            this.spinner.hide();
          }, (err) => {
            console.log(err);
            this.showNotification(
              'bg-red',
              'Error Loading Data',
              'top',
              'right'
            );
          });
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
    }

  }

  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 14) {
      this.addItem();
    }
    if (event.keyCode === 17) {
      this.onSubmit();
    }
  }

  CheckAvailableQuantity() {
    if (this.billItem.PreOrder) {
      // alert("This item is being Pre-Ordered. Temporary Inventory will be created till the Item is delivered to Shop");
      Swal.fire({
        icon: 'error',
        title: 'This item is being Pre-Ordered. Temporary Inventory will be created till the Item is delivered to Shop',
        text: ' ',
        footer: ''
      });
    }
    if (!this.billItem.PreOrder && this.billItem.Quantity > this.item.BarCodeCount) {
      // alert("Reqested Item Quantity not available. Please change the Quantity");
      Swal.fire({
        icon: 'error',
        title: 'Reqested Item Quantity not available. Please change the Quantity',
        text: ' ',
        footer: ''
      });
      this.billItem.Quantity = 0;
    }
  }

  onSubmit() {
    this.spinner.show();
    this.selectedBillMaster.ShopID = this.loggedInShop.ShopID;
    this.data.billMaster = this.selectedBillMaster;
    this.data.billDetail = this.billItemList;
    this.data.service = this.serviceList;
    this.companyService.saveBill('Billing', this.data).subscribe(data1 => {
      this.spinner.hide();
      this.selectedBillMaster.ID = data1.result;
      this.getBillData(this.selectedBillMaster.ID);
      this.getPendingPayments(this.selectedBillMaster.CustomerID);
      this.getPreviousPayments(this.selectedBillMaster.ID);
      this.showNotification(
        'bg-green',
        'Data Saved Successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  onPaymentSubmit() {
    this.spinner.show();
    this.disableApplyPaymentButton = true;
    this.applyPayment.pendingPaymentList = this.unpaidList;
    this.companyService.applyPayment('Payment', 'Customer', this.applyPayment).subscribe(data1 => {
      this.spinner.hide();
      this.getBillData(this.selectedBillMaster.ID);
      this.getPendingPayments(this.selectedBillMaster.CustomerID);
      this.getPreviousPayments(this.selectedBillMaster.ID);
      this.disableApplyPaymentButton = false;
      this.showNotification(
        'bg-green',
        'Payment Applied Successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }


  getProductDataByBarCodeNo(mode) {
    this.enableallprint = false;
    if(mode === 'SearchBarCode'){
      this.enableallprint = true;
    }else if(mode === 'SelectBarcode') {
      this.enableallprint = true;
    }
    
    this.companyService.getProductDataByBarCodeNo(this.searchBarCode.trim(), this.billItem.PreOrder, this.shopMode).subscribe(data1 => {
      this.item = data1.result;
      this.getSearchBarCodeFilter(data1.result.Barcode);
      if (this.item.Barcode === null) {
        // alert("Incorrect Barcode OR Product not available in this Shop");
        Swal.fire({
          icon: 'error',
          title: 'Incorrect Barcode OR Product not available in this Shop',
          text: ' Please Enter Correct Barcode ',
          footer: ''
        });
      }
      else if (this.item.BarCodeCount === 0) {
        // alert("Item not available in Inventoty. You can Pre-Order");
        Swal.fire({
          icon: 'error',
          title: 'Item not available in Inventoty.',
          text: '  You can Pre-Order ',
          footer: ''
        });
      }
      this.billItem.ProductName = "";
      this.item.Spec.forEach(element => {
        this.billItem.ProductName = this.billItem.ProductName + "/" + element.SelectedValue;
      });
      this.billItem.ProductName = this.billItem.ProductName.substring(1);
      this.billItem.Barcode = this.item.Barcode;
      if (this.billItem.WholeSale === true) { this.billItem.UnitPrice = this.item.WholeSalePrice; } else { this.billItem.UnitPrice = this.item.RetailPrice; }
      this.billItem.GSTPercentage = this.item.GSTPercentage;
      this.billItem.GSTAmount = 0;
      this.billItem.GSTType = this.item.GSTType;
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getBarCodeList(index) {
    this.spinner.show();
    
    let searchString = "";

    this.specList.forEach((element, i) => {
      if (i <= index) {
        searchString = searchString + "/" + element.SelectedValue;
      }
    });

    // searchString = searchString.splice(1);

    this.companyService.getBarCodeList1(searchString.substring(1), this.selectedProduct, this.shopMode, this.loggedInShop.ID).subscribe(data => {
      this.barCodeList = data.result;
      // this.filtersearch();
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  setSelectedProductName(i) {
    this.selectedProduct = this.barCodeList[i].ProductName;
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
    this.snackBar.open(text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName
    });
  }

  generateBill(mode) {

    this.body.customer = this.selectedCustomer;
    this.body.billMaster = this.selectedBillMaster;
    this.body.billItemList = this.billItemList;
    this.body.serviceList = this.serviceList;
    this.body.paidList = this.paidList;
    this.body.unpaidList = this.unpaidList;
    this.body.loggedInShop = this.loggedInShop;
    this.body.loggedInCompany = this.loggedInCompany;
    this.companyService.generateBill(mode, this.body).subscribe(data => {
      if (mode === "Invoice") {
        this.selectedBillMaster.Invoice = data.result;
        const url = this.env.apiUrl + this.selectedBillMaster.Invoice;
        window.open(url, "_blank");
      } else if (mode === "Receipt") {
        this.selectedBillMaster.Receipt = data.result;
        const url = this.env.apiUrl + this.selectedBillMaster.Receipt;
        window.open(url, "_blank");
      }
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }



  //  printer





  PrintData() {

    // tslint:disable-next-line:max-line-length
    var dataToPrint; 
if(this.loggedInCompanySetting.BarCode === '2'){
  dataToPrint = '<html>' + this.myDiv.nativeElement.innerHTML + '</html>';
}else if (this.loggedInCompanySetting.BarCode === '1'){
  dataToPrint = '<html>' + this.myDiv1.nativeElement.innerHTML + '</html>';
}else if (this.loggedInCompanySetting.BarCode === '0'){
  dataToPrint = '<html>' + this.myDiv2.nativeElement.innerHTML + '</html>';
}else if (this.loggedInCompanySetting.BarCode === '3'){
  dataToPrint = '<html>' + this.myDiv3.nativeElement.innerHTML + '</html>';
}
    // const code = '12345';

    // convenience method
    // const chr = function(n) { return String.fromCharCode(n); };

    // const barcode = '\x1D' + 'h' + chr(80) +   //barcode height
    //     '\x1D' + 'f' + chr(0) +              //font for printed number
    //     '\x1D' + 'k' + chr(69) + chr(code.length) + code + chr(0); //code39

    const data = [{
      type: 'pixel',
      format: 'html',
      flavor: 'plain', // or 'file' if using a URL
      data: dataToPrint,
      // options: { length: 'ESCPOS', dotDensity: 'double' }
    }];


    
  }
  ngAfterViewInit() {
    // this.dtTrigger.next();
    // console.log(this.myDiv.nativeElement.innerHTML);
  }



  getPrintBySelectedItem(data) {
    this.selectedItemPrint.BarCode = data.Barcode;
    this.selectedItemPrint.ProductName = data.ProductName.split("/")[1];
    this.selectedItemPrint.ProductNames = data.ProductName.split("/")[2].substr(0, 15);
    this.selectedItemPrint.retailprice = data.RetailPrice;
    this.selectedItemPrint.uniqueBarcode = data.UniqueBarcode;
    this.selectedItemPrint.shopName = data.BarcodeShopName;


    this.changeDectectorRef.detectChanges();
    console.log('THISISMYDATA', this.myDiv.nativeElement.innerHTML);
    this.PrintData();
    console.log(data,'huhuhuh')
  } 

  getPrintBySelectedItem1(data) {
    this.selectedItemPrint.BarCode = data.Barcode;
    this.selectedItemPrint.ProductName = data.ProductName.split("/")[1];
    this.selectedItemPrint.ProductNames = data.ProductName.split("/")[2].substr(0, 15);
    this.selectedItemPrint.retailprice = data.RetailPrice;
    this.selectedItemPrint.uniqueBarcode = data.UniqueBarcode;
    this.selectedItemPrint.shopName = data.BarcodeShopName;
  }

  getPrintBySelectedItem2() {
    this.changeDectectorRef.detectChanges();
    console.log('THISISMYDATA', this.myDiv.nativeElement.innerHTML);
    this.PrintData();
  }

  updatedataa(data) {
    this.companyService.saveData('BarcodeMaster', data).subscribe(data => {
      this.showNotification(
        'bg-green',
        'Bar Code SuccessFully Update',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  updateBarcode(data) {
    console.log(data, 'update');
    this.companyService.saveData('BarcodeMaster', data).subscribe(data => {
      this.showNotification(
        'bg-green',
        'Bar Code SuccessFully Update',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  printAllBarcodes(){
    this.SearchBarCodeList.forEach(ele => {
      this.getPrintBySelectedItem(ele); 
    })
  }

 
  filtersearch() {
    this.SearchBarCodeList = [];

    this.barCodeList.forEach(element => {
      this.spinner.show();
      this.companyService.getProductDataByBarCodeNo(element.Barcode, this.billItem.PreOrder, this.shopMode).subscribe(data => {
        this.spinner.show();

        this.companyService.getSearchBarCodeFilter(data.result.Barcode, this.shopMode, 'search').subscribe(data1 => {

          data1.data.forEach(element1 => {
            this.SearchBarCodeList.push(element1);

          });
          this.spinner.hide();


        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }, (err) => {
        console.log(err);
      });
      this.spinner.hide();
    });


  }

  barcodePrint(i) {
    this.spinner.show();
    this.SearchBarCodeList[i].Quantity = 1;
    this.companyService.BarcodePrint('barcodePrint', this.SearchBarCodeList[i]).subscribe(data => {
      this.spinner.hide();
      const url =  data;
      window.open(url, "_blank");
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  barcodePrintAll() {
    this.spinner.show();
    this.SearchBarCodeList[0].Quantity = this.SearchBarCodeList.length;
    this.companyService.BarcodePrint('barcodePrint', this.SearchBarCodeList[0]).subscribe(data => {
      this.spinner.hide();
      const url =  data;
      window.open(url, "_blank");
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  // barcodePrintAll() {
  //   let tempItem = [];
  //   let len = 0;
  //   this.spinner.show();
  //    this.SearchBarCodeList.forEach(ele => {
  //      if(ele.Status !== 0) {
  //        len = len + 1;
  //      this.companyService.getSearchBarCodeFilter(ele.ID, true, '').subscribe(data => {
  //        tempItem.push(data.data[0]);
  //        if(len === tempItem.length) {
  //          this.companyService.BarcodePrintAll('barcodePrint', tempItem).subscribe(data => {
  //            this.spinner.hide();
  //            const url =  data;
  //            window.open(url, "_blank");
  //          }, (err) => {
  //            console.log(err);
  //            this.showNotification(
  //              'bg-red',
  //              'Error Loading Data',
  //              'top',
  //              'right'
  //            );
  //          });
 
  //        }
 
  //      }, (err) => {
  //        console.log(err);
  //      });
  //    }
  //    })
 
     
  //  }

}


