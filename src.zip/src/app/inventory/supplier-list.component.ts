import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService} from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import * as XLSX from 'xlsx';
import { NgbButtonLabel } from '@ng-bootstrap/ng-bootstrap';

import { PaginationService } from '../services/pagination.service';


@Component({
  selector: 'app-supplierlist',
  templateUrl: './supplier-list.component.html'
})
export class SupplierListComponent implements OnInit {
  fileName= 'SupplierListExcel.xlsx';

  term:any;
  dataList: any;
  gridview = true;
  stringUrl: string;
  env = environment;
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));

  deleteSupplierList = false;
  addSupplierList = false;
  editSupplierList = false;
  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0
  page = 4;

  constructor( private companyService: CompanyService, private spinner: NgxSpinnerService, private sanitizer: DomSanitizer,
               private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute,private pagination: PaginationService) { }


  ngOnInit() {
    this.spinner.show();
    this.getList();
    this.spinner.hide();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'SupplierList') {
             this.editSupplierList = element.Edit;
             this.addSupplierList = element.Add;
             this.deleteSupplierList = element.Delete;
           }
         });

}
onPageChange(pageNum: number): void {
  this.pageSize = this.itemsPerPage*(pageNum - 1);
  }

  changePagesize(num: number): void {
    this.itemsPerPage = this.pageSize + num;
    }
    getList(){
      this.spinner.show()
      const dtm = {
        currentPage: this.currentPage,
        itemsPerPage: this.itemsPerPage 
      }
      this.pagination.getList('SupplierfullList', dtm).subscribe(res => {
        
        this.collectionSize = res.count;
        this.dataList = res.result;
        this.spinner.hide()
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        this.spinner.hide()
        this.showNotification(
          'bg-red',
          'Data Not Loaded.',
          'top',
          'right'
        );
      });
    }

    

  getListData() {
    this.companyService.getExtendedListByCompany1('SupplierfullList', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
      
      // let tempArray = [];
      // res.result.forEach(el => {
      //   el.DOB = moment(el.DOB).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   el.Anniversary = moment(el.Anniversary).format(`${this.loggedInCompanySetting.DateFormat}`);

      //   tempArray.push(el);
      // })
      this.dataList = res.result;
      console.log(this.dataList);
      this.santizePictureList();
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  filterDatatable(event) {
    console.log(event);
  }
  santizePictureList() {
    this.dataList.forEach(element => {
    element.PhotoURL = this.sanitize(element.PhotoURL);
  });
  }
sanitize(imgName: string) {
  if (imgName !== "null" && imgName !== '') {
    this.stringUrl = this.env.apiUrl + imgName;
   } else {
     this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
  return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
}
exportEx(): void
{
  /* pass here the table id */
  let element = document.getElementById('exportSup');
  const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  ws['!cols'] = [];
  ws['!cols'][0] = { hidden: true };
  /* generate workbook and add the worksheet */
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

  /* save to file */  
  XLSX.writeFile(wb, this.fileName);

}


deleteItem(i){
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      this.companyService.deleteData('Supplier', this.dataList[i].ID).subscribe(data => {
        this.dataList.splice(i, 1);
        
        }, (err) => {
        this.showNotification(
        'bg-red',
        'Could Not Delete Data.',
        'top',
        'right'
        );
        });
      Swal.fire(
        'Deleted!',
        'Your file has been deleted.',
        'success'
      )
    }
  })
}

convertDate(date){
  return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);

  
 }



  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


}
