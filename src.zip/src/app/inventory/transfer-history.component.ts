import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { NgForm } from '@angular/forms';
import { CompanyService} from '../services/company.service';
import { DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ToastrService } from 'ngx-toastr';
import { ThemePalette } from '@angular/material/core';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-transfer-history',
  templateUrl: './transfer-history.component.html'
})
export class TransferHistoryComponent implements OnInit {

  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
productList: any[];
specList: any;

newSpec: any = {ID : null, ProductName: '', Name : '', Seq: null,  Type: '', Ref: 0, SptTableName: ''  };
selectedProduct: any = '';
selectedHSNCode: any = '';
prodList: any[];
showAdd = false;
newProduct = {Name: "", HSNCode: ""};
fieldType: any[] = [{ID: 1, Name: "DropDown"}, {ID: 2, Name: "Text"}, {ID: 3, Name: "boolean"}];
  selectedProductID: any;

constructor(private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
// private toastrService: ToastrService,
) {}

  ngOnInit() {
    this.getProductList();
  }

  getProductList(){
    this.companyService.getShortListByCompany('Product', 0).subscribe(data => {
        this.prodList = data.result;
      }, (err) => { console.log(err);
                    this.showFailure(err, 'Error Loading Data.');
      });
  }


  getfieldList(){

    this.prodList.forEach(element => {
      if (element.Name === this.selectedProduct) {this.selectedHSNCode = element.HSNCode; this.selectedProductID = element.ID; }
    });

    if (this.selectedProduct !== null || this.selectedProduct !== '' ){
    this.companyService.getDataByName('ProductSpec', this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      }, (err) => { console.log(err);
                    this.showFailure(err, 'Error Loading Data.');
      });
    }
  }

  saveSpec(){
    if (this.newSpec.Name !== '' && this.newSpec.Type !== ''){
    this.newSpec.ProductName = this.selectedProduct;
    if (this.newSpec.Type === 'DropDown' && this.newSpec.SptTableName === ''){
        this.newSpec.SptTableName = this.newSpec.Name + Math.floor(Math.random() * 999999) + 1 ;
    }
    this.companyService.saveData('ProductSpec', this.newSpec).subscribe(data => {
      this.getfieldList();
      this.newSpec = {ID : null, ProductName: '', Name : '', Seq: null,  Type: '', Ref: 0, SptTableName: ''  };
      }, (err) => { console.log(err);
                    this.showFailure(err, 'Error Loading Data.');
      });
    } else
     {
      //  alert('Can not Save. Missing required fields');
      Swal.fire({
        icon: 'error',
        title: 'Can not Save. Missing Required Fields',
        text: ' Fill all Required Fields ',
        footer: ''
      });
     }

  }

  saveProduct(){
    if (this.newProduct.Name !== ''){
      this.companyService.saveData('Product', this.newProduct).subscribe(data => {
        this.getProductList();
        }, (err) => { console.log(err);
                      this.showFailure(err, 'Error Loading Data.');
        });
    }
  }

  deleteProductType(){

    this.companyService.deleteData('Product', this.selectedProductID).subscribe(data => {
      this.getProductList();
      }, (err) => { console.log(err);
                    this.showFailure(err, 'Error Loading Data.');
      });
  }

  generateTableName(){
    if (this.newSpec.Type === 'DropDown'){
    if (this.newSpec.SptTableName !== '' || this.newSpec.SptTableName !== null) {
      this.newSpec.SptTableName = this.newSpec.Name + Math.floor(Math.random() * 1000) + 1 ;
    }
  }
  }

  onSubmit() {
    // this.adminService.saveData('Company', this.data).subscribe(data => {
    //   if (this.id === 0){
    //     this.data1.CompanyID = data.insertId; }
    //   this.data1.UserGroup = 'CompanyAdmin';
    //   this.adminService.saveData('User', this.data1).subscribe(data1 => {
    //   }, (err) => { console.log(err);
    //                 this.showFailure(err, 'Error Loading Data.');
    //   });
    // }, (err) => { console.log(err);
    //               this.showFailure(err, 'Error Loading Data.');
    // });
  }

  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }

}

