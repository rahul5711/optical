import { Component, OnInit, ViewChild } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { AdminService } from '../services/admin.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ToastrService } from 'ngx-toastr';
import { ThemePalette } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';

@Component({
  selector: 'app-preorder',
  templateUrl: './preorder.component.html',
  styleUrls: ['./preorder.component.css']
  // styles: [
  //   `.bcolor {background-color:red; }`
  // ]
})
export class PreorderComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  assginfitterbtn = true;
  btnActive = false;
  btnUnassigned = false;
  btnAssigned = false;
  btnUnassignedFitter = false;
  btnChecked = false;
  filterList: any;
  fitter = 'All';
  supplier = 'All';
  FromDate = '';
  ToDate = '';
  printData: any = { supplier: null, filterList: null, supplierList:null, loggedInShop: null, loggedInCompany: null, loggedInCompanySetting: null };
  fitterList: any;
  lensTypeList: any;
  fitterRateCard: any;
  urlAss= '';
  range: any;
  disableDates: boolean = true;
  dataList1: any;
  savedb = false;
  details = [];
  constructor(
    private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private toastrService: ToastrService
  ) { }

  productList:any = [];
  mode = "Unassigned";
  modex = "";
  supplierList: any;
  searchValue: any;
  supplierID: any;
  fitterID: any;
  FilterTypes:any;
  

  filter: any =  {PaymentStatus: '', date1: moment().format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), };
  ngOnInit() {
    // this.range = 'Today';
    // this.getDateRange();

   
 
    const mode = 'Unassigned';
    this.getPreOrderProducts(mode);
    this.getSupplierList();
    this.getFitterList();
    this.getLensType();
    this.searchData();
  }
  // getDateRange(){
  //   let d1 = moment().startOf('month').format('YYYY-MM-DD');
  //   let d2 = moment().format('YYYY-MM-DD'); 
  //   if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
  //       switch (this.range) {
  //         case "Today":
  //           d1 = moment().format('YYYY-MM-DD');
  //           d2 = moment().format('YYYY-MM-DD');
  //           break;
  //         case "Yesterday":
  //           d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
  //           d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
  //           break;
  //         case "This Week":
  //           d1 = moment().startOf('week').format('YYYY-MM-DD'); 
  //           d2 = moment().format('YYYY-MM-DD');
  //           break;
  //         case "Last Week":
  //           d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
  //           d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
  //           break;
  //         case "This Month":
  //           d1 = moment().startOf('month').format('YYYY-MM-DD'); 
  //           d2 = moment().format('YYYY-MM-DD');
  //         break;
  //         case "Last Month":
  //           d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
  //           d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
  //           break;
  //         case "This Quarter":
  //           d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
  //           d2 = d2 = moment().format('YYYY-MM-DD');
  //           break;
  //         case "Last Quarter":
  //           d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
  //           d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
  //           break;
  //         case "This Year":
  //           d1 = moment().startOf('year').format('YYYY-MM-DD'); 
  //           d2 = d2 = moment().format('YYYY-MM-DD');
  //           break;
  //         case "Last Year":
  //           d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
  //           d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
  //           break;
                  
  //         default:
            
  //           break;
  //       }
  //       this.filter.date1 = d1;
  //       this.filter.date2 = d2;
   
  //     }

  //     searchData1() {
  //       this.spinner.show();
  //       let whereList = '';
      
      
  //           if (this.filter.date1 !== '' && this.filter.date1 !== null){
  //             let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
  //             whereList = whereList + ' and BillMaster.BillDate  between ' +  `'${date1}'`; }
  //             if (this.filter.date2 !== '' && this.filter.date2 !== null){
  //               let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
  //               whereList = whereList + ' and ' + `'${date2}'`; }
  //       this.companyService.getGenericListByParem('PreOrederFillter', whereList ).subscribe(data => {
        
  //         this.dataList1 = data.result;
  //   console.log(this.dataList1);
    
      
  //         this.spinner.hide();
    
  //       }, (err) => {
  //         console.log(err);
  //         this.spinner.hide();
  //         this.showNotification(
  //           'bg-red',
  //           'Error Loading Data',
  //           'top',
  //           'right'
  //         );
  //       });
  //     }


  getLensType() {
    this.companyService.getSupportMasterList('LensType').subscribe(res => {
      this.lensTypeList = res.result;
    }, (err) => {
      console.log(err);
    });
  }

  getFitterList() {
    this.companyService.getShortListByCompany('Fitter', 1).subscribe(data => {
      this.fitterList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getFitterData() {
    this.companyService.geListByOtherID('FitterRateCard', this.fitterID).subscribe(data => {
      this.fitterRateCard = data.result;
    }, (err) => {
    });
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 1).subscribe(data => {
      this.supplierList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getPreOrderProducts(mode) {
    this.btnFn(mode);
    // this.spinner.show();
    this.companyService.getPreOrderStatus(mode).subscribe(data => {
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.DeliveryDate = moment(el.DeliveryDate).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      this.productList = data.result;
      if(mode === 'UnassignedFitter'){
        this.productList.forEach(element => {
          if(element.LensType !== ''){
            element.LensType = 'NO';
          }else{
            element.LensType = '';
          }
        });
      }
      
console.log(this.productList,'this.productListthis.productList');
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  multicheck() {
    for (var i = 0; i < this.productList.length; i++) {
      const index = this.productList.findIndex((x => x === this.productList[i]));
      if (this.productList[index].Sel == null || this.productList[index].Sel === 0) {
        this.productList[index].Sel = 1;
      } else {
        this.productList[index].Sel = 0;
      }
    }
  }

  validate(v, event) {
    if (v.Sel === 0 || v.Sel === null) {
      // event.target.parentNode.parentNode.style = 'background-color:none';
      v.Sel = 1;
      if(v.LensType !== 'null') {
      }
    } else {
      // event.target.parentNode.parentNode.style = 'background-color:green;color:white;';
      v.Sel = 0;
    }
    this.btnenablefn('');
  }

  btnenablefn(v) {
    
    this.productList.forEach(ele => {
      if (ele.Sel === 1 && ele.LensType == 'null') {
        this.assginfitterbtn = true;
      } else if(ele.Sel === 1 && ele.LensType !== 'null') {
      this.assginfitterbtn = false;
    }  
    })
  }

  setPreOrderProducts(modeX) {

    let missingType = '';
    let submit = true;
    this.filterList = this.productList.filter(d => d.Sel === 1);
    if (this.filterList.length > 0) {

      switch (modeX) {
        case "Assign":
          this.filterList.forEach(element => {
            element.SupplierID = this.supplierID;
            element.PreOrder = 1;
          });
          break;
        case "Cancel":
          this.filterList.forEach(element => {
            element.SupplierID = 0;
            element.FitterID = 0;
            element.PreOrder = 1;
          });
          break;
          case "Save DB":
          this.filterList.forEach(element => {
            this.supplierID = element.SupplierID;
            this.fitterID = element.FitterID;
            this.savedb = true;

          });
          break;
          case "QC Cancel":
          this.filterList.forEach(element => {
            element.PreOrder = 2;

          });
          break;
        case "QC Done":
          this.filterList.forEach(element => {
            element.PreOrder = 3;
          });
          break;
        case "AssignFitter":
          this.filterList.forEach(element => {
            element.FitterID = this.fitterID;
            const i = this.fitterRateCard.findIndex((ele, i) => {
              return ele.LensType === element.LensType
            })
            if (i === -1) { missingType = missingType + element.LensType + " "; } else {
              element.FitterCost = this.fitterRateCard[i].Rate;
            }
            element.PreOrder = 2;
          });
           if (missingType !== ""){
            //  alert("Can not Assign Fitter as Selected Fitter Does not have Rates Available for LensType: " + missingType);
            const message = "Can not Assign Fitter as Selected Fitter Does not have Rates Available for LensType " + missingType;
            Swal.fire({
              icon: 'error',
              title: 'Error!',
              text: `${message}` ,
              footer: ''
            });
          submit = false;}
      }
      if(submit){
      this.spinner.show();
      this.printData.supplier = this.supplierList[this.supplierList.findIndex(element => { return element.ID === this.supplierID; })];
      this.printData.fitter = this.fitterList[this.fitterList.findIndex(element => { return element.ID === this.fitterID; })];
      this.printData.filterList = this.filterList;
      this.printData.loggedInShop = this.loggedInShop;
      this.printData.loggedInCompany = this.loggedInCompany;
      this.printData.loggedInCompanySetting = this.loggedInCompanySetting;
      this.assginfitterbtn = true;
      this.companyService.setPreOrderStatus(this.printData, modeX).subscribe(data => {
        this.spinner.hide();
        switch (modeX) {
          case "Assign":
            alert("Email Sent Successfully");
            this.getPreOrderProducts('Unassigned');
            break;
          case "AssignFitter":
            alert("Email Sent Successfully");
            this.getPreOrderProducts('UnassignedFitter');
            break;
          case "Cancel":
            this.getPreOrderProducts('Unassigned');
            break;
          case "QC Done":
            this.getPreOrderProducts('Assigned');
            break;
            case "QC Cancel":
            this.getPreOrderProducts('Assigned');
            break;
            case "Save DB":
            this.getPreOrderProducts('Assigned');
            this.savedb = false;
            break;
        }
    

      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        // this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }
    }
    else { 
      // alert("Please Select One or More Products from the List")
      Swal.fire({
        icon: 'error',
        title: 'Please Select One or More Products from the List',
        text: '',
        footer: ''
      });
     }
  }



  //For Btn Color
  btnFn(mode) {
    this.mode = mode;
    this.btnActive = false;
    if (mode == 'Unassigned') {
      this.btnUnassigned = true;
      this.btnAssigned = false;
      this.btnChecked = false;
      this.btnUnassignedFitter = false;
    } else if (mode == 'Assigned') {
      this.btnUnassigned = false;
      this.btnAssigned = true;
      this.btnChecked = false;
      this.btnUnassignedFitter = false;
    } else if (mode == 'QC Checked') {
      this.btnUnassigned = false;
      this.btnAssigned = false;
      this.btnChecked = true;
      this.btnUnassignedFitter = false;
    } else if (mode == 'UnassignedFitter') {
      this.btnUnassigned = false;
      this.btnUnassignedFitter = true;
      this.btnAssigned = false;
      this.btnChecked = false;
    }

  }
  //For Btn Color

  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }
  UpdateRemark(v){
    this.spinner.show();
  this.companyService.saveData('UpdateRemark', v).subscribe(data => {
    this.getPreOrderProducts('Assigned');
    this.spinner.hide();
 
    
  }, (err) => { console.log(err);
                this.spinner.hide();
                this.showNotification(
                  'bg-red',
                  'Data Not Saved.',
                  'top',
                  'right'
                );
  });
  }

  AssignFitterPDF(){
    
    const temp = [];
    this.productList.forEach(element => {
      if(element.Sel === 1){
        temp.push(element);
      }
    });
    this.spinner.show();
    this.companyService.AssignFitterPDF(' ', temp).subscribe(data => {
      this.spinner.hide();
      const url = this.env.apiUrl + data;
      this.urlAss = url;
      window.open(url, "_blank");

    }, (err) => { console.log(err);
               
    });
  }



  searchData() {
    let whereList = '';
    this.details = []
    this.companyService.getGenericListByParem('PreorderfullList', whereList ).subscribe(data => {
    
    this.details = data.result
console.log(data.result,'baar');
console.log( this.details[0].UnitPrice,'ISORIA');



    }, (err) => {
      console.log(err);
    });
  }

  AssignSupplierPDF(){
    
    const temp = [];
    this.productList.forEach(element => {
      if(element.Sel === 1){
        this.details.forEach(e => {
          if (e.BarCode === element.Barcode) {
            element.UnitPrice = e.UnitPrice;
            element.GSTPercentage = e.GSTPercentage;
            element.DiscountAmount = e.DiscountAmount;
          }

        })
        element.GSTAmount = (+element.UnitPrice * +element.Qty - (element.DiscountAmount ? element.DiscountAmount : 0)) * +element.GSTPercentage / 100;
        element.TotalAmount = (+element.UnitPrice * +element.Qty - (element.DiscountAmount ? element.DiscountAmount : 0)) + +element.GSTAmount;
        temp.push(element);
      }
    });
    this.spinner.show();
    this.companyService.AssignSupplierPDF(' ', temp).subscribe(data => {
      this.spinner.hide();
      const url = this.env.apiUrl + data;
      this.urlAss = url;
      window.open(url, "_blank");

    }, (err) => { console.log(err);
               
    });
  }



  WhAssignFitterPDF(){
      const url1 = this.urlAss;
      let data1 =  this.fitterList ;
      var msg = `Hi ${data1[0].Name},%0A`+
      `PDF ${url1}`
       var mob = "91" + data1[0].MobileNo1;
       var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
  // console.log(data)

  }

  WhAssignSupplierPDF(){
    const url1 = this.urlAss;
    let data1 =  this.supplierList ;
    var msg = `Hi ${data1[0].Name},%0A`+
    `PDF ${url1}`
     var mob = "91" + data1[0].MobileNo1;
     var url = `https://wa.me/${mob}?text=${msg}`;
  
    window.open(url, "_blank");
// console.log(data)

}

  filterD() {
   const tempD = [];
    if(this.fitter !== 'All' || this.supplier !== 'All') {
      this.companyService.getPreOrderStatus('Assigned').subscribe(data => {
        let tempArray = [];
        data.result.forEach(el => {
          el.DeliveryDate = moment(el.DeliveryDate).format(`${this.loggedInCompanySetting.DateFormat}`);
          tempArray.push(el);
        })
        this.productList = tempArray;
        console.log(this.productList,'this.productListthis.productList');
        
        this.productList.forEach(ele => {
        if(ele.FitterID == this.fitter || ele.SupplierID == this.supplier) {
          tempD.push(ele);
        }
      })
      this.productList = tempD;

      }, (err) => {
        console.log(err);      
      });
      // this.productList.forEach(ele => {
      //   if(ele.FitterID == this.fitter) {
      //     tempD.push(ele);
      //   }
      // })
      // this.productList = tempD;
    } else if(this.fitter === 'All' || this.supplier !== 'All') {
      this.spinner.show();
      this.getPreOrderProducts('Assigned');
    }
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

   
deleteItem(i){
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      this.companyService.deleteData('BarcodeMaster', this.productList[i].ID).subscribe(data => {
        this.productList.splice(i, 1);
        
        }, (err) => {
        this.showNotification(
        'bg-red',
        'Could Not Delete Data.',
        'top',
        'right'
        );
        });
      Swal.fire(
        'Deleted!',
        'Your file has been deleted.',
        'success'
      )
    }
  })
}

filterDate(){
 console.log(this.FromDate) 
 console.log(this.ToDate) 
 this.productList = this.productList.filter(e=>{
 return (e.BillDate >= this.FromDate && e.BillDate <= this.ToDate)
   
 }) 
}

resetDate(){
   this.FromDate = '';
   this.ToDate = '';
   this.getPreOrderProducts('Assigned');
   this.getPreOrderProducts('Unassigned');
}

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
