import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { AdminService } from '../services/admin.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { Subscription } from 'rxjs';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-fitter',
  templateUrl: './fitter.component.html'
})

export class FitterComponent implements OnInit {
  dispalyAllFields = true;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = localStorage.getItem('LoggedINCompany');
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  viewFitter = this.permission[this.permission.findIndex((element) => element.ModuleName = "Fitter")];




  data: any = {
    ID: null, ShopID: null, Name: null, MobileNo1: null, MobileNo2: null, PhoneNo: null, Address: null, Email: null, Website: null,
    GSTNo: null, CINNo: null, PhotoURL: null, Remark: null, ContactPerson: null, Fax: null, DOB: '', Anniversary: '',
    Status: 1, CreatedBy: null, CreatedOn: null, UpdatedBy: null, UpdatedOn: null
  };

  shopID: any;

  color: ThemePalette = 'primary';
  stringUrl: string;
  companyImage: any;
  lensTypeList: any[];
  rateCardList: any;
  shopList = [];
  assignShopList: any;
  rateCard: any = { ID: null, CompanyID: null, FitterID: null, LensType: null, Rate: 0 };
  assignShop: any = { ID: null, CompanyID: null, ShopID: null, FitterID: null };
  constructor(private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute,
    private compressImage: CompressImageService
  ) { }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);

  ngOnInit() {
    this.shopID = this.loggedInShop.ShopID;
    if (this.id !== 0) {
      this.spinner.show();
      // this.companyService.getDataByID(this.id, 'getFitterByID', 'Fitter').subscribe(data => {
      //   this.data = data.result;
      //   this.companyImage = this.sanitize(this.data.PhotoURL);
      //   this.spinner.hide();
      //   this.showNotification(
      //     'bg-green',
      //     'Data Loaded successfully',
      //     'top',
      //     'right'
      //   );
      // }, (err) => {
      //   console.log(err);
      //   this.spinner.hide();
      //   this.showNotification(
      //     'bg-red',
      //     'Data Not Loaded.',
      //     'top',
      //     'right'
      //   );
      // });

      const subs: Subscription = this.companyService.getDataByID(this.id, 'getFitterByID', 'Fitter').subscribe({
        next: (res: any) => {
          this.data = res.result;
          this.companyImage = this.sanitize(this.data.PhotoURL);
          this.spinner.hide();
        },
        error: (err: any) => {
          console.log(err.msg);
        },
        complete: () => subs.unsubscribe(),
      });

      this.getLensType();
      this.getRateCard();
      if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
        this.getShopListByID();
      } else {
        this.getShopList();

      }
      this.getAssignedShop();
    }
  }

  getLensType() {
    // this.companyService.getSupportMasterList('LensType').subscribe(res => {
    //   this.lensTypeList = res.result;
    // }, (err) => {
    //   console.log(err);
    // });
    const subs: Subscription = this.companyService.getSupportMasterList('LensType').subscribe({
      next: (res: any) => {
        this.lensTypeList = res.result;
      },
      error: (err: any) => {
        console.log(err.msg);
      },
      complete: () => subs.unsubscribe(),
    });
  }

  onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getRateCard() {
  
    const subs: Subscription = this.companyService.geListByOtherID('FitterRateCard', this.id).subscribe({
      next: (res: any) => {
        this.rateCardList = res.result;
      },
      error: (err: any) => {
        console.log(err.msg);
      },
      complete: () => subs.unsubscribe(),
    });
  }

  getAssignedShop() {
    const subs: Subscription = this.companyService.geListByOtherID('FitterAssignedShop', this.id).subscribe({
      next: (res: any) => {
        this.assignShopList = res.result;
      },
      error: (err: any) => {
        console.log(err.msg);
      },
      complete: () => subs.unsubscribe(),
    });
    
  }

  getShopList() {
   
    const subs: Subscription = this.companyService.getShortListByCompany('Shop', 1).subscribe({
      next: (res: any) => {
        this.shopList = res.result;
      },
      error: (err: any) => {
        console.log(err.msg);
      },
      complete: () => subs.unsubscribe(),
    });
    
  }

  getShopListByID() {
    const subs: Subscription = this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe({
      next: (res: any) => {
        this.shopList.push(res.result);
      },
      error: (err: any) => {
        console.log(err.msg);
      },
      complete: () => subs.unsubscribe(),
    });
    
  }

  saveRateCard() {
    this.rateCard.FitterID = this.id;
    let count = 0;
    this.rateCardList.forEach(element => {
      if (element.LensType.toLowerCase() === this.rateCard.LensType.toLowerCase()) { count = count + 1; }

    });
    if (count === 0 && this.rateCard.LensType !== null) {
      const subs: Subscription = this.companyService.saveData('FitterRateCard', this.rateCard).subscribe({
        next: (res: any) => {
          this.getRateCard();
        },
        error: (err: any) => {
          console.log(err.msg);
        },
        complete: () => subs.unsubscribe(),
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
    }
  }

  saveAssignedShop() {
    this.assignShop.FitterID = this.id;
    let count = 0;
    this.assignShopList.forEach(element => {
      if (element.ShopID === this.assignShop.ShopID) { count = count + 1; }

    });
    if (count === 0 && this.assignShop.ShopID !== null) {

      const subs: Subscription = this.companyService.saveData('FitterAssignedShop', this.assignShop).subscribe({
        next: (res: any) => {
          this.getAssignedShop();
        },
        error: (err: any) => {
          console.log(err.msg);
        },
        complete: () => subs.unsubscribe(),
      });

    } else {
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
    }
  }

  editRateCard(data) {
    Object.assign(this.rateCard = data);
  }

  editAssignedShop(data) {
    Object.assign(this.assignShop = data);
  }
  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
    } else { return null; }
  }

  // uploadImage(e, mode) {
  //   const frmData = new FormData();
  //   frmData.append('file', e.target.files[0]);
  //   this.adminService.uploadFile(frmData).subscribe(data => {
  //     this.data.PhotoURL = data.fileName;
  //     this.companyImage = this.sanitize(this.data.PhotoURL);
  //     this.showNotification(
  //       'bg-green',
  //       'Image successfully Uploaded',
  //       'top',
  //       'right'
  //     );
  //   }, (err) => {
  //     console.log(err);
  //     this.showNotification(
  //       'bg-red',
  //       'Image Not Uploaded.',
  //       'top',
  //       'right'
  //     );
  //   });
  // }
  uploadImage(e,mode) {
    let image: File = e.target.files[0]
    console.log(`Image size before compressed: ${image.size} bytes.`)
    this.compressImage.compress(image)
      .pipe(take(1)).subscribe(compressedImage => {
        console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
        const frmData = new FormData();
        frmData.append('file', compressedImage);
        this.adminService.uploadFile(frmData).subscribe(data => {
          this.data.PhotoURL = data.fileName;
          this.spinner.hide();
          this.companyImage = this.sanitize(this.data.PhotoURL);
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Image successfully Uploaded',
            'bottom',
            'right'
          );
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Image Not Uploaded.',
            'bottom',
            'right'
          );
        });
  })}

  onSubmit() {
    // this.spinner.show();
    // this.data.ShopID = this.shopID;
    // this.companyService.saveData('Fitter', this.data).subscribe(data => {
    //   this.spinner.hide();
    //   this.router.navigate(['/inventory/fitterlist']);
    //   this.showNotification(
    //     'bg-green',
    //     'Data Saved successfully',
    //     'top',
    //     'right'
    //   );
    // }, (err) => {
    //   console.log(err);
    //   this.spinner.hide();
    //   this.showNotification(
    //     'bg-red',
    //     'Data Not Saved.',
    //     'top',
    //     'right'
    //   );
    // });
    this.spinner.show();
    this.data.ShopID = this.shopID;
    const subs: Subscription = this.companyService.saveData('Fitter', this.data).subscribe({
      next: (res: any) => {
        this.spinner.hide();
        this.router.navigate(['/inventory/fitterlist']);
        this.showNotification(
          'bg-green',
          'Data Saved successfully',
          'top',
          'right'
        );
      },
      error: (err: any) => {
        console.log(err.msg);
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Data Not Saved.',
          'top',
          'right'
        );
      },
      complete: () => subs.unsubscribe(),
    });
  }

  deleteLens(i) {
    Swal.fire({
      title: 'Are you sure?',
      text: "Are you sure want to delete!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        const subs: Subscription = this.companyService.deleteData('FitterRateCard', this.rateCardList[i].ID).subscribe({
          next: (res: any) => {
            this.rateCardList.splice(i, 1);
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            this.showNotification(
              'bg-green',
              'Data Saved successfully',
              'top',
              'right'
            );
          },
          error: (err: any) => {
            console.log(err.msg);
            this.showNotification(
              'bg-red',
              'Data Not Saved.',
              'top',
              'right'
            );
          },
          complete: () => subs.unsubscribe(),
        });
        // this.companyService.deleteData('FitterRateCard', this.rateCardList[i].ID).subscribe(data => {
        //   this.rateCardList.splice(i, 1);
        //   this.showNotification(
        //     'bg-green',
        //     'Data Deleted Successfully',
        //     'top',
        //     'right'
        //   );
        // }, (err) => {
        //   this.showNotification(
        //     'bg-red',
        //     'Could Not Delete Data.',
        //     'top',
        //     'right'
        //   );
        // });
        // Swal.fire(
        //   'Deleted!',
        //   'Your file has been deleted.',
        //   'success'
        // )
      }
    })
  }

  
  deleteShop(i) {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        const subs: Subscription = this.companyService.deleteData('FitterAssignedShop', this.assignShopList[i].ID).subscribe({
          next: (res: any) => {
            this.assignShopList.splice(i, 1);
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            this.showNotification(
              'bg-green',
              'Data Saved successfully',
              'top',
              'right'
            );
          },
          error: (err: any) => {
            console.log(err.msg);
            this.showNotification(
              'bg-red',
              'Data Not Saved.',
              'top',
              'right'
            );
          },
          complete: () => subs.unsubscribe(),
        });
        // this.companyService.deleteData('FitterAssignedShop', this.assignShopList[i].ID).subscribe(data => {
        //   this.assignShopList.splice(i, 1);
        //   this.showNotification(
        //     'bg-green',
        //     'Data Deleted Successfully',
        //     'top',
        //     'right'
        //   );
        // }, (err) => {
        //   this.showNotification(
        //     'bg-red',
        //     'Could Not Delete Data.',
        //     'top',
        //     'right'
        //   );
        // });
        // Swal.fire(
        //   'Deleted!',
        //   'Your file has been deleted.',
        //   'success'
        // )
      }
    })
  }




  showNotification(colorName, text, placementFrom, placementAlign) {

    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'

    });
  }

}
