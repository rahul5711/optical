
import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { ThemePalette } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import * as qz from 'qz-tray';
import { sha256 } from 'js-sha256';
import { KJUR, KEYUTIL, stob64, hextorstr } from 'jsrsasign';
import 'rxjs/add/observable/fromPromise';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';

@Component({
  selector: 'app-fitter-details',
  templateUrl: './fitter-details.component.html'
})
export class FitterDetailsComponent implements OnInit {

  @ViewChild('myDiv') myDiv: ElementRef;
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  duplicateAlert = false;
  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  specList: any = [];
  fitterList: any[];
  shopList = [];
  item: any;
  category = 'Product';
  disableAddButtons = true;
  barcodeList: any;
  selectedItemPrint: any = { BarCode: null, ProductTypeName: null };
  tempItem = { Item: null, Spec: null };
  itemList = [];
  data = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  selectedPurchaseMaster: any = {
    ID: null, FitterID: null, FitterName: null, CompanyID: null, GSTNo: null, ShopID: 'All', ShopName: null, PaymentStatus: null, PurchaseDate: null,
    InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, TotalAmount: 0
  };

  filterList: any[];


  constructor(private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private changeDectectorRef: ChangeDetectorRef

    // private toastrService: ToastrService,
  ) {
    qz.api.setSha256Type(data => sha256(data));
    qz.api.setPromiseType(resolver => new Promise(resolver));
  }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  ngOnInit() {
    this.onPageLoad();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }

  onPageLoad() {
    this.spinner.show();
    this.selectedPurchaseMaster.PurchaseDate = new Date();
    this.getFitterList();
    this.showNotification(
      'bg-green',
      'Data Loaded successfully',
      'top',
      'right'
    );
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getFitterList() {
    this.companyService.getShortListByCompany('Fitter', 1).subscribe(data => {
      this.fitterList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  calculateFields(fieldName, mode, item) {
    switch (mode) {
      case 'subTotal':
        item.Total = +item.Qty * +item.UnitPrice;
        break;
    }
  }


  getShopList() {
    this.spinner.show();
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getShopListByID() {
    this.spinner.show();
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.selectedPurchaseMaster.ShopID = this.shopList[0].ID
      }
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  calculateGrandTotal() {
    this.selectedPurchaseMaster.Quantity = 0;
    this.selectedPurchaseMaster.TotalAmount = 0;

    this.itemList.forEach(element => {
      if (element.sel === 1) { 
        this.selectedPurchaseMaster.Quantity = +this.selectedPurchaseMaster.Quantity + +element.Qty;
        this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.Total;
      }
    });
  }

  getFitterDetails(event) {
    const index = this.fitterList.findIndex(element => element.Name === event.value);
    this.selectedPurchaseMaster.FitterID = this.fitterList[index].ID;
    this.selectedPurchaseMaster.FitterName = this.fitterList[index].Name;
    this.selectedPurchaseMaster.GSTNo = this.fitterList[index].GSTNo;
  }

  getPreorderPurchaseList() {
    this.spinner.show();

    this.companyService.getPreorderPurchaseList('Fitter', this.selectedPurchaseMaster.FitterID, this.selectedPurchaseMaster.ShopID).subscribe(data => {
    
      let tempArray = [];
      data.result.forEach(el => {
        el.AssignedOn = moment(el.AssignedOn).format(`${this.loggedInCompanySetting.DateFormat}`);
        tempArray.push(el);
      })
      this.itemList = tempArray;
      
      console.log( this.itemList)
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }


  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 17) {
      this.onSubmit();
    }
  }

  onSubmit() {
    let submit = false;
    this.filterList = this.itemList.filter(d => d.sel === 1);
    if (this.filterList.length > 0) {
      submit = true;
      this.filterList.forEach((ele) => {
        if (ele.Total === 0 || ele.Total === null) {
          submit = false
        }
      });
      if (!submit) {
         Swal.fire({
          icon: 'error',
          title: 'One of the selected Item does not have Total Amount field Filled.',
          text: ' Please Correct Before Submitting',
          footer: ''
        });
       }
    } else { submit = false;
       Swal.fire({
        icon: 'error',
        title: 'No Items were selected.',
        text: 'Please Select Atleast One Item To The List',
        footer: ''
      });
       }
    if (this.selectedPurchaseMaster.InvoiceNo === null || this.selectedPurchaseMaster.InvoiceNo === '') {
      submit = false;

      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Fitter Invoice No is required!',
       
      })
      
    }
    if (submit  && this.duplicateAlert === false) {
      this.calculateGrandTotal();
        this.spinner.show()
        this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
        this.data.PurchaseMaster = this.selectedPurchaseMaster;
        this.data.PurchaseDetail = JSON.stringify(this.filterList);
        this.companyService.updatePurchase('Fitter', this.data).subscribe(data1 => {
          this.router.navigate(['inventory/fitterinvoicelist/0']);
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Data submitted successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Data not submitted.',
            'top',
            'right'
          );
        });
      
    }else {
      alert("Duplicate InvoiceNo not Allowed");
    }
  }

  multicheck() {
    for (var i = 0; i < this.itemList.length; i++) {
      const index = this.itemList.findIndex((x => x === this.itemList[i]));
      if (this.itemList[index].sel == null || this.itemList[index].sel === 0) {
        this.itemList[index].sel = 1;
      } else {
        this.itemList[index].sel = 0;
      }
    }
  }

  validate(v, event) {
    if (v.sel === 0 || v.sel === null) {
      // event.target.parentNode.parentNode.style = 'background-color:none';
      v.sel = 1;
    } else {
      // event.target.parentNode.parentNode.style = 'background-color:green;color:white;';
      v.sel = 0;

    }
  }

  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }


  checkInvoicNo() {
    
    let Param = {FitterID: this.selectedPurchaseMaster.FitterID , ShopID: this.selectedPurchaseMaster.ShopID, InvoiceNo: this.selectedPurchaseMaster.InvoiceNo.trim()};
    this.companyService.getcheckInvoicNoFitter(JSON.stringify(Param)).subscribe(data1 => {
      this.duplicateAlert = false;

      if (data1.data.length !== 0) {
        
        Swal.fire({
          icon: 'error',
          title: 'Duplicate InvoiceNo not Allowed',
          text: '',
          footer: ''
        });
        this.selectedPurchaseMaster.InvoiceNo = null;
        this.duplicateAlert = true;
      }      
    }, (err) => {
      console.log(err);      
    });
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }
   
  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}

