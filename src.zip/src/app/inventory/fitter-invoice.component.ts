
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import 'rxjs/add/observable/fromPromise';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { DateAdapter } from '@angular/material/core';
import * as moment from 'moment';

@Component({
  selector: 'app-fitter-invoice',
  templateUrl: './fitter-invoice.component.html'
})
export class FitterInvoiceComponent implements OnInit {

  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  selectedProduct: any;
  specList: any = [];
  fitterList: any[];
  shopList: any[];
  item: any;
  category = 'Product';
  disableAddButtons = true;
  barcodeList: any;
  selectedItemPrint: any = { BarCode: null, ProductTypeName: null };
  tempItem = { Item: null, Spec: null };
  itemList = [];
  data = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  selectedPurchaseMaster: any = {
    ID: null, FitterID: null, FitterName: null, CompanyID: null, GSTNo: null, ShopID: null, ShopName: null, PaymentStatus: null, PurchaseDate: null,
    InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, TotalAmount: 0
  };

  filterList: any[];


  constructor(private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private changeDectectorRef: ChangeDetectorRef,
    private dateAdapter: DateAdapter<any>

    // private toastrService: ToastrService,
  ) {
  }

  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  ngOnInit() {
    this.dateAdapter.setLocale('hi-IN');
    if (this.id !== 0) {
      // this.spinner.show();
      this.companyService.getFitterInvoiceFullDataByID(this.id).subscribe(data => {
        this.selectedPurchaseMaster = data.result.FitterMaster;
        this.selectedPurchaseMaster.PurchaseDate = moment(this.selectedPurchaseMaster.PurchaseDate).format('YYYY-MM-DD');
        this.itemList = data.result.FitterDetail;
        // this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        // this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }

  }

  // onPageLoad() {
  //   this.spinner.show();
  //   // this.selectedPurchaseMaster.PurchaseDate = new Date();
  //   // this.getFitterList();
  //   // this.getShopList();
  //   // this.showNotification(
  //   //   'bg-green',
  //   //   'Data Loaded successfully',
  //   //   'top',
  //   //   'right'
  //   // );

  // }


  getFitterList() {
    this.companyService.getShortListByCompany('Fitter', 1).subscribe(data => {
      this.fitterList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  calculateFields(fieldName, mode, item) {
    switch (mode) {
      case 'subTotal':
        item.TotalAmount = +item.Quantity * +item.UnitPrice;
        break;
    }
  }


  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  calculateGrandTotal() {
    this.selectedPurchaseMaster.Quantity = 0;
    this.selectedPurchaseMaster.TotalAmount = 0;

    this.itemList.forEach(element => {
      if (element.sel === 1) { 
        this.selectedPurchaseMaster.Quantity = +this.selectedPurchaseMaster.Quantity + +element.Quantity;
        this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
    });
  }

  getFitterDetails(event) {
    const index = this.fitterList.findIndex(element => element.Name === event.value);
    this.selectedPurchaseMaster.FitterID = this.fitterList[index].ID;
    this.selectedPurchaseMaster.FitterName = this.fitterList[index].Name;
    this.selectedPurchaseMaster.GSTNo = this.fitterList[index].GSTNo;
  }

  getPreorderPurchaseList() {
    this.companyService.getPreorderPurchaseList('Fitter', this.selectedPurchaseMaster.FitterID, this.selectedPurchaseMaster.ShopID).subscribe(data => {
      this.itemList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }


  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 17) {
      this.onSubmit();
    }
  }

  onSubmit() {
    let submit = false;
    this.filterList = this.itemList.filter(d => d.sel === 1);
    if (this.filterList.length > 0) {
      submit = true;
      this.filterList.forEach((ele) => {
        if (ele.TotalAmount === 0 || ele.TotalAmount === null) {
          submit = false
        }
      });
      if (!submit) {
         Swal.fire({
          icon: 'error',
          title: 'One of the selected Item does not have Total Amount field Filled.',
          text: ' Please Correct Before Submitting',
          footer: ''
        });
       }
    } else { submit = false;
       Swal.fire({
        icon: 'error',
        title: 'No Items were selected.',
        text: 'Please Select Atleast One Item To The List',
        footer: ''
      });
       }
    if (this.selectedPurchaseMaster.InvoiceNo === null || this.selectedPurchaseMaster.InvoiceNo === '') {
      submit = false;
      alert("Fitter Invoice No is required")
    }
    if (submit) {
      this.calculateGrandTotal();
        this.spinner.show()
        this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
        this.data.PurchaseMaster = this.selectedPurchaseMaster;
        this.data.PurchaseDetail = this.filterList;
        this.companyService.updatePurchase('Fitter', this.data).subscribe(data1 => {
          this.router.navigate(['/inventory/fitterinvoicelist']);
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Data submitted successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Data not submitted.',
            'top',
            'right'
          );
        });
      
    }
  }

  multicheck() {
    for (var i = 0; i < this.itemList.length; i++) {
      const index = this.itemList.findIndex((x => x === this.itemList[i]));
      if (this.itemList[index].sel == null || this.itemList[index].sel === 0) {
        this.itemList[index].sel = 1;
      } else {
        this.itemList[index].sel = 0;
      }
    }
  }

  validate(v, event) {
    if (v.sel === 0 || v.sel === null) {
      // event.target.parentNode.parentNode.style = 'background-color:none';
      v.sel = 1;
    } else {
      // event.target.parentNode.parentNode.style = 'background-color:green;color:white;';
      v.sel = 0;

    }
  }

  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}

