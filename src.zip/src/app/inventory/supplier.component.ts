import { Component, OnInit } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { AdminService} from '../services/admin.service';
import * as moment from 'moment';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';
@Component({ selector: 'app-supplier', templateUrl: './supplier.component.html'
})

export class SupplierComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  viewSupplier = this.permission[this.permission.findIndex((element) => element.ModuleName = "Supplier")];
   
  deleteSupplierList = false;
  addSupplierList = false;
  editSupplierList = false;

  dispalyAllFields = true;
  supplierList: any;

data: any = { ID : null, Sno: 0, Name : null, MobileNo1 : null, MobileNo2 : null, PhoneNo : null, Address : null, Email : '', Website : null,
  GSTNo : null, CINNo : null, PhotoURL : null, Remark : null, ContactPerson : null, Fax : null, DOB: '', Anniversary: '',
  Status : 1, CreatedBy : null, CreatedOn : null, UpdatedBy : null, UpdatedOn : null
};



color: ThemePalette = 'primary';
  stringUrl: string;
  companyImage: any;

constructor(private companyService: CompanyService,
            private adminService: AdminService,
            private router: Router,
            private snackBar: MatSnackBar,
            private spinner: NgxSpinnerService,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
             private compressImage: CompressImageService
  ) {}

public id =  parseInt(this.route.snapshot.paramMap.get('id'), 10);
public id2 = parseInt(this.route.snapshot.paramMap.get('id2'), 10);
// public id3 = parseInt(this.route.snapshot.paramMap.get('queryParamsHandling'), 10);


purchasVariable: any = 0;

ngOnInit(){
  this.route
  .queryParams
  .subscribe(params => {
  this.purchasVariable = +params['check'] || 0;
  console.log(this.purchasVariable , 'purchasVariable');


  });

      this.permission.forEach(element => {    
      if (element.ModuleName === 'SupplierList') {
             this.editSupplierList = element.Edit;
             this.addSupplierList = element.Add;
             this.deleteSupplierList = element.Delete;
           }
         });

         if (this.id === 0) { 
          this.getListData();
          
         }
  if (this.id !== 0) {
    this.spinner.show();
    this.companyService.getDataByID(this.id, 'getSupplierByID', 'Supplier' ).subscribe(data => {
      this.data = data.result;
      if (data.result.DOB === '0000-00-00') {
        this.data.DOB = null;
      }
      if (data.result.Anniversary === '0000-00-00') {
        this.data.Anniversary = null;
      }
      this.companyImage = this.sanitize(this.data.PhotoURL);
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'bottom',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'bottom',
                    'right'
                  );
    });
  }



}

sanitize(imgName: string) {
  if (imgName !== null || imgName !== '') {
    this.stringUrl = this.env.apiUrl + imgName;
    return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
}

// uploadImage(e, mode){
//   const frmData = new FormData();
 
//     frmData.append('file', e.target.files[0]);


//   this.adminService.uploadFile(frmData).subscribe(data => {
//   this.data.PhotoURL = data.fileName;
//   this.spinner.hide();
//   this.companyImage = this.sanitize(this.data.PhotoURL);
//   this.spinner.hide();
// })
// }

uploadImage(e,mode) {
  let image: File = e.target.files[0]
  console.log(`Image size before compressed: ${image.size} bytes.`)
  this.compressImage.compress(image)
    .pipe(take(1)).subscribe(compressedImage => {
      console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
      const frmData = new FormData();
      frmData.append('file', compressedImage);
      this.adminService.uploadFile(frmData).subscribe(data => {
        this.data.PhotoURL = data.fileName;
        this.spinner.hide();
        this.companyImage = this.sanitize(this.data.PhotoURL);
        this.spinner.hide();
      })
    })
}

onChange(event) {
  if (this.loggedInCompanySetting.DataFormat === '1') {
    event = event.toUpperCase()
  } else if (this.loggedInCompanySetting.DataFormat == '2') {
    event = event.toTitleCase()
  }
  return event;
}

getListData() {
  this.companyService.getExtendedListByCompany1('SupplierfullListAll', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
    this.supplierList = res.result;
    if(res.result.length === 0) {
      this.data.Sno = Number(this.data.Sno) + 1;

    }else {
      if(this.supplierList[0].Sno !== 'null') {
        this.data.Sno = Number(this.supplierList[0].Sno) + 1;
      } else {
        this.data.Sno = 1
      }
    }
          console.log(this.data.Sno , 'this.data.Sno');
    this.showNotification(
      'bg-green',
      'Data Loaded successfully',
      'top',
      'right'
    );
  }, (err) => {
    this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Data Not Loaded.',
      'top',
      'right'
    );
  });
}


onSubmit() {
  this.spinner.show();
  this.companyService.saveData('Supplier', this.data).subscribe(data => {
    this.spinner.hide();
    if(this.purchasVariable === 1) {
      this.router.navigate(['/inventory/purchase/0']);
    } else {
      this.router.navigate(['/inventory/supplierlist']);
    }
    this.showNotification(
      'bg-green',
      'Data Saved successfully',
      'top',
      'right'
    );
  }, (err) => { console.log(err);
                this.spinner.hide();
                this.showNotification(
                  'bg-red',
                  'Data Not Saved.',
                  'top',
                  'right'
                );
  });
}


 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
