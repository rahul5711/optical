import { Component, OnInit } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { AdminService} from '../services/admin.service';

import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));

  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
 loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
 permission= JSON.parse(localStorage.getItem('Permission'));

 
  viewSupplier = this.permission[this.permission.findIndex((element) => element.ModuleName = "Supplier")];
locationObj = {
  PurchaseDetailID : null, ProductName : '', Barcode:'', TotalQty:0, Located:0, UnLocated:0, Location :'',  Qty:''
}
  UpdateItem = false;
  specList: any;
  selectedProduct: any;
  summaryListall = [];
  LocationList: any;
  Locationlist: any;

  constructor(
    private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
  ) { }
  data = { ProductCategory : 0, ProductName:'', SupplierID: 0, ShopID: 0, PurchaseID: 0, Barcode: "", CurrentStatus : "Available",BrandType:'All'
};
searchValue: any;
summaryList = [];
supplierList: any[];
shopList = [];
prodList: any[];
  ngOnInit() {
    this.spinner.show();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.data.ShopID = this.loggedInShop.ShopID;
     
      this.getShopListByID();
    } else {
      
      this.getShopList();

    }
    this.getProductList();
    this.getSupplierList();
    this.getLocationList();
  }

  filter() {
    let productName = '';
    this.specList.forEach(element => {
      if (productName === '') {
        productName = element.SelectedValue;
      } else if (element.SelectedValue !== '') {
        productName += '/' + element.SelectedValue;
      }
    });
    this.data.ProductName = productName;
  }

 

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product', 1).subscribe(data => {
      this.prodList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 0).subscribe(data => {
      this.supplierList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.data.ShopID = this.shopList[0].ID
      }
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  getfieldList() {
    if(this.data.ProductCategory !== 0){
    this.prodList.forEach(element => {
      if (element.ID === this.data.ProductCategory) {
        this.selectedProduct = element.Name;
      }
    })
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }else {
    this.specList = [];
    this.data.ProductName = '';
    this.data.ProductCategory = 0;
  }
}

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  getInventoryData(){
this.spinner.show();
    let whereList = '';
    if (this.data.ProductCategory !== 0){
    whereList = whereList + ' and PurchaseDetail.ProductTypeID = ' +  this.data.ProductCategory;
    this.filter();
  }
    if (this.data.ProductName !== '') {
      whereList = whereList + ' and PurchaseDetail.ProductName Like ' + '"' + this.data.ProductName + '%"';
    }
    if (this.data.ShopID !== 0){
      whereList = whereList + ' and BarcodeMaster.ShopID = ' +  this.data.ShopID; }
    if (this.data.SupplierID !== 0){
      whereList = whereList + ' and PurchaseMaster.SupplierID = ' +  this.data.SupplierID ; }
    if (this.data.Barcode !== ''){
      whereList = whereList + ' and BarcodeMaster.Barcode Like ' + '"' + this.data.Barcode + '%"' ; }
    if (this.data.CurrentStatus !== ''){
      whereList = whereList + ' and BarcodeMaster.CurrentStatus = ' + '"' + this.data.CurrentStatus + '"'; }
      if (this.data.BrandType !== ''  && this.data.BrandType !== 'All'){
        whereList = whereList + ' and PurchaseDetail.BrandType = ' + '"' + this.data.BrandType + '"'; }
    this.companyService.getGenericListByParem('ProductInventory', whereList).subscribe(data => {
      this.summaryList = data.result;
      let q = 0;

      this.summaryList.forEach(element => {
        let Param = `PurchaseDetailID = '${element.PurchaseDetailID}'`
        q = q+element.Count;
        console.log(q,"totalqty");
  //   this.adminService.getForgetPassword('LocationMaster', Param ).subscribe(data => {
  //   let Located = 0;
  //   let UnLocated = 0;
  //   data.result.forEach(el => {
  //     Located += Number(el.Qty);
  //     element.Located = Located;
  //   })
  //   UnLocated += Number(element.Count) - Number(Located);
  //   element.Located = Located;
  //   element.UnLocated = UnLocated;
    
  // }, (err) => { console.log(err);        
  //   });
      })
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

  updateProduct(data) {
    this.spinner.show();
    const filter = {BrandType: data.BrandType};
    this.companyService.saveSmallData('PurchaseDetail', data.PurchaseDetailID, filter).subscribe(data => {
    this.spinner.hide();

      this.showNotification(
        'bg-green',
        'Bar Code SuccessFully Update',
        'top',
        'right'
      );
      
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  changeDetection(i) {
    let obj;
    obj = this.summaryList[i];
    obj.changeDetection = 1;
    this.summaryListall.push(obj);
  }

  updateAllProduct() {
    this.summaryListall.forEach(ele => {
      this.spinner.show();
      const filter = {BrandType: ele.BrandType};
      this.companyService.saveSmallData('PurchaseDetail', ele.PurchaseDetailID, filter).subscribe(data => {
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Bar Code SuccessFully Update',
          'top',
          'right'
        );

        }, (err) => {
          console.log(err);

        });
    })
  }

  getLocationList() {
    this.companyService.getSupportMasterList('LocationMaster').subscribe(data => { 
      this.LocationList = data.result;
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  setLocation(data){
    this.locationObj.Located = 0;
    this.locationObj.UnLocated = 0;
    this.locationObj.Barcode = data.Barcode;
    this.locationObj.ProductName = data.ProductTypeName + '/'+ data.ProductName;
    this.locationObj.TotalQty = data.Count;
    this.locationObj.UnLocated = data.Count;
    this.locationObj.PurchaseDetailID = data.PurchaseDetailID;
  }
  
  checkQty(checkQty){
if(Number(checkQty) <= this.locationObj.UnLocated){

}else{
  alert("Qty is greater than available Qty");
}
  }

  saveLocation(){
    if(Number(this.locationObj.Qty) <= this.locationObj.UnLocated){
      this.companyService.saveData('LocationMaster', this.locationObj).subscribe(data => {
        this.locationObj.Location = '';
        this.locationObj.Qty = '';

        this.getLocationLists(this.locationObj.PurchaseDetailID);
        this.showNotification(
          'bg-green',
          'Data Saved successfully',
          'top',
          'right'
        );
      }, (err) => { console.log(err);
      });
    }else{
      alert("Qty is greater than available Qty");
      this.locationObj.Location = '';
      this.locationObj.Qty = '';
    }
  }

  getLocationLists(ID){
  

    let Param = `PurchaseDetailID = '${ID}'`
    
    this.adminService.getForgetPassword('LocationMaster', Param ).subscribe(data => {
    this.Locationlist = data.result;
    this.locationObj.Located = 0;
    this.locationObj.UnLocated = 0;
    this.Locationlist.forEach(ele => {
      this.locationObj.Located += Number(ele.Qty);

    })
    this.locationObj.UnLocated += Number(this.locationObj.TotalQty) - Number(this.locationObj.Located)  ;
  }, (err) => { console.log(err);        
    });
  }


  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('LocationMaster', this.Locationlist[i].ID).subscribe(data => {
          this.locationObj.Located -= Number(this.Locationlist[i].Qty);
          this.locationObj.UnLocated += Number(this.Locationlist[i].Qty);
          this.Locationlist.splice(i, 1);
         

          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

}
