import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ToastrService } from 'ngx-toastr';
import { ThemePalette } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import * as moment from 'moment';
import { NgxSpinnerService } from "ngx-spinner";
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-product-transfer',
  templateUrl: './product-transfer.component.html',
  styleUrls: ['./product-transfer.component.css']
})
export class ProductTransferComponent implements OnInit {
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  searchBarCode: any;
  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  secretCode: any;
  
  Remark: any;
  selectedBarCode: any;
  selectedRowID = -1;
  specList: any = [];
  prodList: any[];
  supplierList: any[];
  shopList: any[];
  item: any;
  service: any;
  category = 'Product';
  shopMode = 'false';
  disableAddButtons = true;
  tempItem = { Item: null, Spec: null };
  itemList = [];
  serviceList = [];
  temparray = [];
  data = { billMaster: null, Product: null, billDetail: null, service: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  currency = { Symbol: 'INR', Format: '1.2-2' };

  selectedBillMaster: any = {
    ID: null, CustomerID: null, CustomerName: null, CompanyID: null, OrderNo: null, PurchaseDate: null, GSTNo: null, ShopID: null,
    ShopName: null, BillDate: null, PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0,
    DiscountAmount: 0, GSTAmount: 0, TotalAmount: 0.00, AddlDiscount: 0.00
  };

  sampleXferItem: any = {
    ID: null, ProductName: null, BarCode: null, BarCodeCount: null, TransferCount: null,
    TransferToShop: null, TransferFromShop: null, AcceptanceCode: null, DateStarted: null, DateCompleted: null, TransferStatus: null,
    CreatedBy: null, UpdatedBy: null, CreatedOn: null, UpdatedOn: null, Remark : ''
  };


  sampleitem: any = {
    ID: null, ProductName: null, ProductTypeName: null, ProductTypeID: null, UnitPrice: 0.00,
    Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
    DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: 'IGST', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
    WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, Manual: false, PreOrder: false
  };
  xferItem: any;

  barCodeList: any;
  xferList: any;

  constructor(private companyService: CompanyService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private spinner: NgxSpinnerService,
              private route: ActivatedRoute,
    // private toastrService: ToastrService,
  ) { }

  ngOnInit() {
    this.spinner.show();
    this.getProductList();
    // this.getSupplierList();
    this.getShopList();
    this.item = this.sampleitem;
    this.xferItem = JSON.parse(JSON.stringify(this.sampleXferItem));
    this.loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
    this.companyService.getExtendedListByID('TransferMaster', this.loggedInShop.ShopID).subscribe(data => {
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.DateStarted = moment(el.DateStarted).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      this.xferList = data.result;
      
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      this.spinner.hide();

      this.showFailure(err, 'Error Loading Data.');
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product', 1).subscribe(data => {
      this.prodList = data.result;
    }, (err) => {
      console.log(err);
      this.showFailure(err, 'Error Loading Data.');
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
    }, (err) => {
      console.log(err);
      this.showFailure(err, 'Error Loading Data.');
    });
  }

  getfieldList() {
    if (this.selectedProduct !== null || this.selectedProduct !== '') {
      this.prodList.forEach(element => {
        if (element.Name === this.selectedProduct) { this.item.ProductTypeID = element.ID; }
      });
      this.item.ProductTypeName = this.selectedProduct;
      this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
        this.specList = data.result;
        this.getSptTableData();
      }, (err) => {
        console.log(err);
        this.showFailure(err, 'Error Loading Data.');
      });
    }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showFailure(err, 'Error Loading Data.');
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showFailure(err, 'Error Loading Data.');
        });
      }
    });

  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }


  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  cancelTransfer(i) {
    this.spinner.show();
    this.companyService.cancelTransfer(this.xferList[i]).subscribe(data => {
      
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.DateStarted = moment(el.DateStarted).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      // this.xferList = tempArray;
      // this.spinner.hide();
      this.companyService.getExtendedListByID('TransferMaster', this.loggedInShop.ShopID).subscribe(data => {
        let tempArray = [];
        data.result.forEach(el => {
          el.DateStarted = moment(el.DateStarted).format(`${this.loggedInCompanySetting.DateFormat}`);
          tempArray.push(el);
        })
        this.xferList = tempArray;
        
        this.spinner.hide();
      }, (err) => {
        console.log(err);
        this.spinner.hide();
  
        this.showFailure(err, 'Error Loading Data.');
      });
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showFailure(err, 'Error Loading Data.');
    });

  }

  acceptTransfer() {
    const n = this.selectedRowID;
    if (this.secretCode === this.xferList[n].AcceptanceCode) {
      this.xferList[n].Remark = this.xferList[n].Remark+ "    " +this.Remark;
      this.spinner.show();
      this.companyService.acceptTransfer(this.xferList[n]).subscribe(data => {
        // let tempArray = [];
        // data.result.forEach(el => {
        //   el.DateStarted = moment(el.DateStarted).format(`${this.loggedInCompanySetting.DateFormat}`);
        //   tempArray.push(el);
        // })
        // this.xferList = tempArray;
        // this.spinner.hide();
        this.companyService.getExtendedListByID('TransferMaster', this.loggedInShop.ShopID).subscribe(data => {
          let tempArray = [];
          data.result.forEach(el => {
            el.DateStarted = moment(el.DateStarted).format(`${this.loggedInCompanySetting.DateFormat}`);
            tempArray.push(el);
          })
          this.xferList = tempArray;
          this.secretCode = "";
          this.Remark = "";
          this.spinner.hide();
        }, (err) => {
          console.log(err);
          this.spinner.hide();
    
          this.showFailure(err, 'Error Loading Data.');
        });
      }, (err) => {
        console.log(err);
        this.spinner.hide();
        this.showFailure(err, 'Error Loading Data.');
      });
    } else {
      const message = "Please check with the Sender: " + this.xferList[n].CreatedByUser
        + " from Shop " + this.xferList[n].FromShop + " for Product: " + this.xferList[n].ProductName;
      Swal.fire({
        icon: 'error',
        title: 'Secret Code Does Not Match!!!!',
        text: `${message}`,
        footer: ''
      });
    }
  }



  printChallan(data){
    this.companyService.printChallan('TransferMaster', data , 'single').subscribe(data1 => {
      // data.CompanySettings = this.loggedInCompanySetting;
     
      const url = this.env.apiUrl + data1;
      console.log(data1);
      window.open(url, "_blank");
    }, (err) => {
      console.log(err);
     
    });
    
  }

  onSubmit() {
    if (this.xferItem.TransferCount > this.xferItem.BarCodeCount && this.xferItem.TransferCount < 1) {
      // alert("Products for Transfer should be between 1 and " + this.xferItem.BarCodeCount);
      const message = "Products for Transfer should be between 1 and " + this.xferItem.BarCodeCount;
      Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: `${message}` ,
        footer: ''
      });
    } else if ( this.xferItem.TransferCount == 0) {
      Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: `Must be transfer atleast one product` ,
        footer: ''
      });
    } else {
      this.spinner.show();
      this.xferItem.TransferStatus = "Transfer Initiated";
      this.companyService.transferProduct(this.xferItem).subscribe(data => {
        let tempArray = [];
        data.result.forEach(el => {
          el.DateStarted = moment(el.DateStarted).format(`${this.loggedInCompanySetting.DateFormat}`);
          tempArray.push(el);
        })
        this.xferList = tempArray;
        this.xferItem.ToShopID = "";
         // this.xferItem.TransferCount = 0;
        // this.xferItem.BarCodeCount = 0;
        // if(this.item.Barcode === null) {
        //   this.searchBarCode = "";
        //   this.xferItem.AcceptanceCode = "";
        // }
        if(this.xferItem.BarCodeCount - this.xferItem.TransferCount > 0) {
        this.getProductDataByBarCodeNo1();
        } else {
          this.xferItem.TransferCount = 0;
        this.xferItem.BarCodeCount = 0;
                  this.xferItem.AcceptanceCode = "";

        }
        this.spinner.hide();
        // this.barCodeList = [];
      }, (err) => {
        console.log(err);
        this.spinner.hide();
        this.showFailure(err, 'Error Loading Data.');
      });
    }
  }


  getProductDataByBarCodeNo() {
    this.loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
    if (this.loggedInShop && this.loggedInShop.ShopID !== null) {
      this.companyService.getProductDataByBarCodeNo(this.searchBarCode, false, false).subscribe(data1 => {
        this.item = data1.result;
        console.log(this.item,"kkk")
        

        if (this.item.Barcode === null) {
          // alert("Product Not Available in this Shop for Selected Barcode for Transfer.\n Please Check the Barcode.");
          Swal.fire({
            icon: 'error',
            title: 'Product Not Available in this Shop for Selected Barcode for Transfer.',
            text: ' Please Check the Barcode. ',
            footer: ''
          });
        }

        this.xferItem.ProductName = "";
        this.barCodeList.forEach(element => {
          if(element.Barcode === this.searchBarCode) {
            this.xferItem.ProductName = element.ProductName;
          }
          // this.xferItem.ProductName = this.xferItem.ProductName + "/" + element.SelectedValue;
        });
        this.xferItem.ProductName = this.selectedProduct + '/' +  this.xferItem.ProductName.toUpperCase();
       
        // this.xferItem.ProductName = this.item.ProductName;
        this.xferItem.BarCode = this.item.Barcode;
        this.xferItem.BarCodeCount = this.item.BarCodeCount;
        this.xferItem.TransferCount = 0;
        this.xferItem.TransferToShop = null;
        this.xferItem.TransferFromShop = this.loggedInShop.ShopID;
        this.xferItem.TransferStatus = "";
      }, (err) => {
        console.log(err);
        this.showFailure(err, 'Error Loading Data.');
      });
    }
    else {
      // alert("Please Select the Shop from Which To Tranfer Products.");
      Swal.fire({
        icon: 'error',
        title: 'Please Select the Shop from Which To Tranfer Products.',
        text: ' ',
        footer: ''
      });
    }
  }

  getProductDataByBarCodeNo1() {
    this.loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
    if (this.loggedInShop && this.loggedInShop.ShopID !== null) {
      this.spinner.show();
      this.companyService.getProductDataByBarCodeNo(this.searchBarCode, false, false).subscribe(data1 => {
        this.item = data1.result;
       
        if (this.item.Barcode === null) {
          this.spinner.hide();

          // alert("Product Not Available in this Shop for Selected Barcode for Transfer.\n Please Check the Barcode.");
          Swal.fire({
            icon: 'error',
            title: 'Product Not Available in this Shop for Selected Barcode for Transfer.',
            text: ' Please Check the Barcode. ',
            footer: ''
          });
        }

        this.xferItem.ProductName = "";
        this.xferItem.ProductName = this.item.ProductName.toUpperCase();
       
        // this.xferItem.ProductName = this.item.ProductName;
        this.xferItem.BarCode = this.item.Barcode;
        
        this.xferItem.BarCodeCount = this.item.BarCodeCount;
        this.xferItem.TransferCount = 0;
        this.xferItem.TransferToShop = null;
        this.xferItem.TransferFromShop = this.loggedInShop.ShopID;
        this.xferItem.TransferStatus = "";
        
        this.spinner.hide();

      }, (err) => {
        this.spinner.hide();

        console.log(err);
        this.showFailure(err, 'Error Loading Data.');
      });
    }
    else {
      // alert("Please Select the Shop from Which To Tranfer Products.");
      Swal.fire({
        icon: 'error',
        title: 'Please Select the Shop from Which To Tranfer Products.',
        text: ' ',
        footer: ''
      });
    }
  }

  getBarCodeList(index) {
    this.spinner.show();
    let searchString = "";

    this.specList.forEach((element, i) => {
      if (i <= index) {
        searchString = searchString + "/" + element.SelectedValue;
      }
    });

    // searchString = searchString.splice(1);

    this.companyService.getBarCodeList1(searchString.substring(1), this.selectedProduct, this.shopMode, this.loggedInShop.ID).subscribe(data => {
      this.barCodeList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      this.showFailure(err, 'Error Loading Data.');
    });
  }

  checkLimit(){
  if ( this.xferItem.TransferCount > this.xferItem.BarCodeCount ){
    // alert('Transfer Count can not be more than Available Count');
    Swal.fire({
      icon: 'error',
      title: 'Transfer Count can not be more than Available Count',
      text: ' ',
      footer: ''
    });
    this.xferItem.TransferCount = 0;
  }
}

  generateCode() {
    this.xferItem.AcceptanceCode = Math.floor(Math.random() * 100000000);
  }
  // setSelectedProductName(i) {
  //     this.selectedProduct = this.barCodeList[i].ProductName;
  //   }

  showSuccess(display, Message) {
    Swal.fire({
      icon: 'success',
      title: display,
      text: Message,
      footer: ''
    });
  }

  showFailure(error, Message) {
    Swal.fire({
      icon: 'error',
      title: error,
      text: Message,
      footer: ''
    });
  }

  FilterData(id){
   
    if(id !== '0'){
      this.temparray = [];
      this.companyService.getExtendedListByID('TransferMaster', this.loggedInShop.ShopID).subscribe(data => {
        this.xferList = data.result;
        this.xferList.forEach(element => {
          if(element.TransferToShop === id){
            this.temparray.push(element);
          }
        });
        this.xferList = this.temparray;
      }, (err) => {
        console.log(err);
  
      });
   
 
  }else{
    this.temparray = [];
    this.companyService.getExtendedListByID('TransferMaster', this.loggedInShop.ShopID).subscribe(data => {
      this.xferList = data.result;
    }, (err) => {
      console.log(err);

    });
  }
  }

  formreset() {
    this.specList = [];
    this.barCodeList = [];
    this.xferItem.ProductName = "";
       
        this.xferItem.BarCode = "";
        this.xferItem.BarCodeCount = 0;
        this.xferItem.TransferCount = 0;
        this.xferItem.TransferToShop = null;
        this.xferItem.TransferFromShop = this.loggedInShop.ShopID;
        this.xferItem.TransferStatus = "";
        this.xferItem.ToShopID = "";
        this.searchBarCode = "";
  }
  printChallan1(){
    this.companyService.printChallan('TransferMaster', this.xferList , 'multi').subscribe(data1 => {
      // data.CompanySettings = this.loggedInCompanySetting;
     
      const url = this.env.apiUrl + data1;
      console.log(data1);
      window.open(url, "_blank");
    }, (err) => {
      console.log(err);
     
    });
    
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }
}
