import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService} from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';


@Component({
  selector: 'app-preorder-list',
  templateUrl: './preorder-list.component.html',
  styleUrls: ['./preorder-list.component.css']

})
export class PreorderListComponent implements OnInit {
  term:any;
  dataList: any;
  gridview = true;
  stringUrl: string;
  env = environment;
  checked = false;
  dataListt = []

  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));

  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  deleteSupplierList = false;
  addSupplierList = false;
  editSupplierList = false;
  specList: any;
  selectedProduct: any;
  prodList: any;
  searchValue : any;

  constructor( private companyService: CompanyService, private spinner: NgxSpinnerService, private sanitizer: DomSanitizer,
               private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute) { }

  filter: any =  { ProductCategory:'All', ProductName: '' , ProductTypeName: '',};

  ngOnInit() {
    this.getListData();
    this.getProductList();
  }

  searchData() {
    let whereList = '';
 
    if (this.filter.ProductCategory !== 0 && this.filter.ProductCategory !== 'All') {
      whereList = whereList + ' PurchaseDetail.ProductTypeID = ' + this.filter.ProductCategory;
      this.filters();
    }
    if (this.filter.ProductCategory === 'All'){
      this.getListData();
    }
    if (this.filter.ProductName !== '') {
      whereList = whereList + ' and PurchaseDetail.ProductName Like ' + '"' + this.filter.ProductName + '%"';
    }
    this.companyService.getGenericListByParem('PreorderfullList', whereList ).subscribe(data => {
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.CreatedOn = moment(el.CreatedOn).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      this.dataList = data.result;
      console.log(this.dataList,"HHH")
     
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product',1).subscribe(data => {
      this.prodList = data.result;
  
      
    this.spinner.hide();
     
    }, (err) => {
       this.spinner.hide();
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
     
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getListData() {
    this.spinner.show();
    this.companyService.getExtendedListByCompany1('PreorderfullList', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
      let tempArray = [];
      res.result.forEach(el => {
        el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
        tempArray.push(el);
      })
      this.dataList = tempArray;
      this.spinner.hide();

      console.log(this.dataList ,'this.dataList')
  
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getfieldList() {
    if(this.filter.ProductCategory !== 'All'){

   
    this.prodList.forEach(element => {
      if (element.ID === this.filter.ProductCategory) {
        this.selectedProduct = element.Name;
      }
    })
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }else{
    this.specList = [];
  }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  filters() {
    let productName = '';
    let productcat = '';
    this.specList.forEach(element => {
      if (productName === '') {
        productName =  element.SelectedValue;
      } else if (element.SelectedValue !== '') {
        productName += '/' + element.SelectedValue;
      }
    });
    this.filter.ProductName =  productName;
  }


 

  deletePreOrder(data , i){
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      this.companyService.deletePreOrder('deletePreOrder', data.ID).subscribe(data => {
        this.dataList.splice(i, 1);
        
        }, (err) => {
        this.showNotification(
        'bg-red',
        'Could Not Delete Data.',
        'top',
        'right'
        );
        });
      Swal.fire(
        'Deleted!',
        'Your file has been deleted.',
        'success'
      )
    }
  })
}


selectPreorder(type) {
  if(type === 'all') {
    if(this.checked === true) {
      this.checked = false;
    } else {
     this.checked = true;
 
    }
    this.dataListt = [];
 
    this.spinner.show();
    this.dataList.forEach((ele, i) => {
      if(this.checked === true) {
       ele.Checked = 1;
       ele.index = i;

       this.dataListt.push(ele);
      } else {
       ele.Checked = 0;
       this.dataListt = [];
 
      }
    })
    console.log(this.dataListt , 'this.dataListtthis.dataListt');
    this.spinner.hide();
 
  }
   }


   singleSelectPreOrder(i) {
    if(this.dataList[i].Checked === false || this.dataList[i].Checked === 0 ) {
      this.dataList[i].index = i;

      this.dataListt.push(this.dataList[i]);

    } else if(this.dataList[i].Checked === true || this.dataList[i].Checked === 1 ) {
      // this.dataListt.forEach(el => {
      //   if(this.dataList[i].ID === el.ID) {
      //     this.dataListt.splice(el, 1);
      //   }
      // })

      this.dataListt.forEach((el, iind)=> {
        if(this.dataListt[iind].index === i) {

        this.dataListt.splice(iind, 1);
        }
    })


    }
    console.log(this.dataListt);
   }

   deleteall() {
     if(this.dataListt.length === 0) {
      alert("please select product")
     } else {
       this.spinner.show();
       for(var i = 0; i < this.dataListt.length; i++) {
        this.companyService.deletePreOrder('deletePreOrder', this.dataListt[i].ID).subscribe(data => {
          this.getListData();
          this.spinner.hide();

          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
       }
     }
   }

   convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

showNotification(colorName, text, placementFrom, placementAlign) {
  
  this.snackBar.open(text, '', {
    duration: 2000,
    // verticalPosition: placementFrom,
    horizontalPosition: 'left',
    panelClass: colorName,
    verticalPosition: 'bottom'
    
  });
}


}
