import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService} from '../services/company.service';
import {DomSanitizer} from '@angular/platform-browser';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from '../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import { PaginationService } from '../services/pagination.service';
import { map, filter, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { fromEvent, Subscription } from 'rxjs';

@Component({
  selector: 'app-purchase-list',
  templateUrl: './purchase-list.component.html'
})
export class PurchaseListComponent implements OnInit, AfterViewInit {
  @ViewChild('searching') searching: ElementRef | any;

  term = "";
  env = environment;
  UpdatePaymentMode = false;
  isImportant = false ;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  editPurchaseList = false;
  addPurchaseList = false;
  deletePurchaseList = false;
  stringUrl: string;
  dataList: any[];
  historyList = [];
  currency = {Symbol: 'INR', Format: '1.2-2' };
  PaymentModesList: any;
  page = 4;

  currentPage = 1;
  itemsPerPage = 10;
  pageSize: number;
  collectionSize = 0
 
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private pagination: PaginationService
  ) { }
  public id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  
  header: any;

  ngOnInit() {
  //  this.getList()
    
    this.getPaymentModesList();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'PurchaseList') {
             this.editPurchaseList = element.Edit;
             this.addPurchaseList = element.Add;
             this.deletePurchaseList = element.Delete;
           }
         });
    if (this.id === 0) {
      this.spinner.show();
      const dtm = {
        currentPage: this.currentPage,
        itemsPerPage: this.itemsPerPage 
      }
      this.pagination.getList('PurchaseMaster', dtm).subscribe(data => {
        this.spinner.hide();
        
        // let tempArray = [];
        // data.result.forEach(el => {
        //   el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
        //   tempArray.push(el);
        // })
           
        this.collectionSize = data.count;
        this.dataList = data.result;
        
 
        console.log(this.dataList,'kkk')
        this.header = "Purchase List"; 

        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => { console.log(err);
                    this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    } else {
      this.spinner.show();
      const dtm = {
        currentPage: this.currentPage,
        itemsPerPage: this.itemsPerPage,
        SupplierID : this.id
      }
      this.pagination.getList('PurchaseMasterSupplier', dtm).subscribe(data => {
        let tempArray = [];
        data.result.forEach(el => {
          el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
          tempArray.push(el);
        })
        
        this.dataList = tempArray;
        console.log(this.dataList);
        this.collectionSize = data.count;
       
        this.header = "Purchase List for " + this.dataList[0].SupplierName;   

        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => { console.log(err);
                    // this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    }
    
  }

  onPageChange(pageNum: number): void {
    this.pageSize = this.itemsPerPage*(pageNum - 1);
    }

    changePagesize(num: number): void {
      this.itemsPerPage = this.pageSize + num;
      }

      getList(){
        this.spinner.show()
        const dtm = {
          currentPage: this.currentPage,
          itemsPerPage: this.itemsPerPage 
        }
        this.pagination.getList('PurchaseMaster', dtm).subscribe(res => {
          
          this.collectionSize = res.count;
          this.dataList = res.result;
       
          this.spinner.hide()
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          this.spinner.hide()
          this.showNotification(
            'bg-red',
            'Data Not Loaded.',
            'top',
            'right'
          );
        });
      }

  updatePaymentMode(data) {
    this.spinner.show();
    this.companyService.saveData('updatePaymentHistory' , data).subscribe(data => {
      this.UpdatePaymentMode = false;

      this.spinner.hide();
    this.showNotification(
        'bg-green',
        'Data Update successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                
    });
  }

  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => { 
      this.PaymentModesList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  
  paymentHistory(ID){
    this.spinner.show();
    this.companyService.geListByOtherID('PaymentHistory' , ID).subscribe(data => {
      this.historyList = data.result;
      this.spinner.hide();
    
    }, (err) => { console.log(err);
                  this.spinner.hide();
                
    });
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        if(this.dataList[i].Quantity == 0) {
        this.companyService.deleteData('PurchaseMaster', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
          Swal.fire(
            'Deleted!',
            'Your file has been deleted.',
            'success'
          )
        } else {
          Swal.fire({
            title: 'Alert',
            text: "you can not delete this invoice, please delete product first!",
            icon: 'warning',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK!'
          })
        }
       
      }
    })
  }

  // deleteItem(i){
  //   let yes = confirm("Are you sure want to delete");
  //   if (yes) {
  //   this.companyService.deleteData('PurchaseMaster', this.dataList[i].ID).subscribe(data => {
  //   this.dataList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  // }
  //   }

  convertDate(date){
  
   return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

  ngAfterViewInit() {
    
    // server-side search
    fromEvent(this.searching.nativeElement, 'keyup').pipe(

      // get value
      map((event: any) => {
        return event.target.value;
      }),

      // if character length greater then 2
      // filter(res => res.length > 2),

      // Time in milliseconds between key events
      debounceTime(1000),

      // If previous query is different from current
      distinctUntilChanged(),
      // tap((event: KeyboardEvent) => {
      //     console.log(event)
      //     console.log(this.input.nativeElement.value)
      //   })
      // subscription for response
    ).subscribe((text: string) => {
  //  const name = e.target.value;
    let data = {
      searchQuery: text.trim(),

    }

    if (data.searchQuery !== "" && this.id === 0) {
      let dtm = {
        currentPage: 1,
        itemsPerPage: 50000,
        searchQuery: data.searchQuery 
      }
      
      this.pagination.getsearchList('PurchaseMaster', dtm).subscribe(data => {
        let tempArray = [];
        data.result.forEach(el => {
          el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
          tempArray.push(el);
        })

        this.dataList = tempArray;
        this.collectionSize = data.count;
       

        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => { console.log(err);
                    // this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    } else if (data.searchQuery !== "" && this.id !== 0) {
      let dtm = {
        currentPage: 1,
        itemsPerPage: 50000,
        searchQuery: data.searchQuery ,
        SupplierID : this.id

      }
      
      this.pagination.getsearchList('PurchaseMasterSupplier', dtm).subscribe(data => {
        let tempArray = [];
        data.result.forEach(el => {
          el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
          tempArray.push(el);
        })

        this.dataList = tempArray;
        this.collectionSize = data.count;
       

        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => { console.log(err);
                    // this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    } else if(this.id !== 0 && data.searchQuery == ""  ) {
      let dtm = {
        currentPage: 1,
        itemsPerPage: 50000,
        searchQuery: data.searchQuery ,
        SupplierID : this.id

      }
      
      this.pagination.getsearchList('PurchaseMasterSupplier', dtm).subscribe(data => {
        let tempArray = [];
        data.result.forEach(el => {
          el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
          tempArray.push(el);
        })

        this.dataList = tempArray;
        this.collectionSize = data.count;
       

        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => { console.log(err);
                    // this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    }else if(this.id === 0 && data.searchQuery == ""  ) {
      this.getList()
    } 

    
    

    });

    

  }

}
