import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { ThemePalette } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import * as qz from 'qz-tray';
import { sha256 } from 'js-sha256';
import { KJUR, KEYUTIL, stob64, hextorstr } from 'jsrsasign';
import 'rxjs/add/observable/fromPromise';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-preorderpurchase',
  templateUrl: './preorder-purchase.component.html',
  styleUrls: ['./preorder-purchase.component.css']
})
export class PreOrderPurchaseComponent implements OnInit {
  @ViewChild('myDiv') myDiv: ElementRef;
  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  
  searchValue: any;
  showAdd = false;
  selectedProduct: any;
  specList: any = [];
  prodList: any[];
  supplierList: any[];
  shopList: any[];
  item: any;
  charge: any;
  category = 'Product';
  disableAddButtons = true;
  barcodeList:any;
  selectedItemPrint: any = {BarCode : null, ProductTypeName: null };
  tempItem = { Item: null, Spec: null };
  itemList = [];
  chargeList = [];
  data = { PurchaseMaster: null, Product: null, PurchaseDetail: null, Charge: null };

  fieldType: any[] = [{ ID: 1, Name: "DropDown" }, { ID: 2, Name: "Text" }, { ID: 3, Name: "boolean" }];

  selectedPurchaseMaster: any = {
    ID: null, SupplierID: null, SupplierName: null, CompanyID: null, GSTNo: null, ShopID: null, ShopName: null, PurchaseDate: null,
    PaymentStatus: null, InvoiceNo: null, Status: 1, CreatedBy: null, Quantity: 0, SubTotal: 0, DiscountAmount: 0,
    GSTAmount: 0, TotalAmount: 0
  };


  sampleitem: any = {
    ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
    Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
    DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: '', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
    WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, Status: 1
  };


  samplecharge: any = {
    ID: null, PurchaseID: null, ChargeType: null, CompanyID: null, Description: '', Amount: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
    GSTType: '', TotalAmount: 0.00 , Status: 1 };


  constructor(private companyService: CompanyService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private spinner: NgxSpinnerService,
              private snackBar: MatSnackBar,
              private route: ActivatedRoute,
              private changeDectectorRef: ChangeDetectorRef

    // private toastrService: ToastrService,
  ) {
  }


  ngOnInit() {
    this.selectedPurchaseMaster.PurchaseDate = new Date();

    this.getSupplierList();
    this.getShopList();
  }


  deleteItem(category, i){
    if (category === "Product"){
      if(this.itemList[i].ID === null){
        this.itemList.splice(i, 1);
      } else {
        this.itemList[i].Status = 0;
      }

    } else if (category === "Charge"){
      if(this.chargeList[i].ID === null){
        this.chargeList.splice(i, 1);
      } else {
        this.chargeList[i].Status = 0;
      }
    }
    this.calculateGrandTotal();
  }

  selectItem(i){
    this.item= this.itemList[i];
    this.category = 'Product';
    this.selectedProduct = this.item.ProductTypeName
  }

  selectCharge(i){
    this.charge= this.chargeList[i];
  }
  
  getProductList() {
    this.companyService.getShortListByCompany('Product', 1).subscribe(data => {
      this.prodList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 1).subscribe(data => {
      this.supplierList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  calculateFields(fieldName, mode) {
    switch (mode) {
      case 'subTotal':
        this.item.SubTotal = +this.item.Quantity * +this.item.UnitPrice - this.item.DiscountAmount;
        break;
      case 'discount':
        if (fieldName === 'DiscountPercentage') { this.item.DiscountAmount = +this.item.SubTotal * +this.item.DiscountPercentage / 100; }
        if (fieldName === 'DiscountAmount') { this.item.DiscountPercentage = 100 * +this.item.DiscountAmount / +this.item.SubTotal; }
        break;
      case 'gst':
        if (fieldName === 'GSTPercentage') {
          this.item.GSTAmount =
            (+this.item.SubTotal - this.item.DiscountAmount) * +this.item.GSTPercentage / 100;
        }
        if (fieldName === 'GSTAmount') {
          this.item.GSTPercentage =
            100 * +this.item.GSTAmount / (+this.item.SubTotal - this.item.DiscountAmount);
        }
        break;
        case 'chgst':
          if (fieldName === 'GSTPercentage') {
            this.charge.GSTAmount =
              +this.charge.Amount * +this.charge.GSTPercentage / 100;
          }
          if (fieldName === 'GSTAmount') {
            this.charge.GSTPercentage =
              100 * +this.charge.GSTAmount / (+this.charge.Amount);
          }
          break;
      case 'total':
        this.item.TotalAmount = +this.item.SubTotal + +this.item.GSTAmount - +this.item.DiscountAmount;
        break;
        case 'chtotal':
          this.charge.TotalAmount = +this.charge.GSTAmount + +this.charge.Amount;
          break;
    }
  }


  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  addItem() {
    // this.tempItem.Item = this.item;
    // this.tempItem.Spec = this.specList;
    if (this.category === 'Product'){
      if (this.selectedPurchaseMaster.ID !== null){this.item.Status = 2}
    this.item.ProductName = "";
    this.specList.forEach(element => {

        this.item.ProductName = this.item.ProductName  + element.SelectedValue + "/";

    });
    this.item.ProductName = this.item.ProductName.substring(0, this.item.ProductName.length - 1);
    this.item.Spec = this.specList;
    this.itemList.push(this.item);
    this.tempItem = { Item: null, Spec: null };
    this.item = {
      ID: null, PurchaseID: null, CompanyID: null, ProductName: '', ProductTypeName: '', ProductTypeID: null, UnitPrice: 0.00,
    Quantity: 0, SubTotal: 0.00, DiscountPercentage: 0,
    DiscountAmount: 0.00, GSTPercentage: 0, GSTAmount: 0.00, GSTType: '', TotalAmount: 0.00, Multiple: false, RetailPrice: 0.00,
    WholeSalePrice: 0.00, Ledger: true, WholeSale: false, BaseBarCode: null, Status: 1
    };

    this.selectedProduct = "";
    this.specList = [];

  }

    if (this.category === 'Charges'){
      if (this.selectedPurchaseMaster.ID !== null){this.charge.Status = 2}
    this.chargeList.push(this.charge);
    this.charge = {
      ID: null, ChargeType: null, CompanyID: null, Description: '', Amount: 0.00, GSTPercentage: 0, GSTAmount: 0.00,
      GSTType: '', TotalAmount: 0.00, Status: 1 };
  }

  this.calculateGrandTotal();
  }

  calculateGrandTotal(){
    this.selectedPurchaseMaster.Quantity = 0;
    this.selectedPurchaseMaster.SubTotal = 0;
    this.selectedPurchaseMaster.DiscountAmount = 0;
    this.selectedPurchaseMaster.GSTAmount = 0;
    this.selectedPurchaseMaster.TotalAmount = 0;

    this.itemList.forEach(element => {
      if(element.Status !== 0){
      this.selectedPurchaseMaster.Quantity = +this.selectedPurchaseMaster.Quantity + +element.Quantity;
      this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.SubTotal;
      this.selectedPurchaseMaster.DiscountAmount = +this.selectedPurchaseMaster.DiscountAmount + +element.DiscountAmount;
      this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
      this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
    });

    this.chargeList.forEach(element => {
      if(element.Status !== 0){
      this.selectedPurchaseMaster.SubTotal = +this.selectedPurchaseMaster.SubTotal + +element.Amount;
      this.selectedPurchaseMaster.GSTAmount = +this.selectedPurchaseMaster.GSTAmount + +element.GSTAmount;
      this.selectedPurchaseMaster.TotalAmount = +this.selectedPurchaseMaster.TotalAmount + +element.TotalAmount;
      }
    });
  }


  getSupplierDetails(event) {
    const index = this.supplierList.findIndex(element => element.Name === event.value);
    this.selectedPurchaseMaster.SupplierID = this.supplierList[index].ID;
    this.selectedPurchaseMaster.SupplierName = this.supplierList[index].Name;
    this.selectedPurchaseMaster.GSTNo = this.supplierList[index].GSTNo;
  }

  getfieldList() {
    if (this.selectedProduct !== null || this.selectedProduct !== '') {
    this.prodList.forEach(element => {
        if (element.Name === this.selectedProduct){ this.item.ProductTypeID = element.ID; }
      });
    this.spinner.show();
    this.item.ProductTypeName = this.selectedProduct;
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
        this.specList = data.result;
        this.spinner.hide();
        this.getSptTableData();
        this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
      }, (err) => {
        console.log(err);
        // this.showFailure(err, 'Error Loading Data.');
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.spinner.show();
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.spinner.hide();
          this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.spinner.show();
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  displayAddField(i) {
    this.specList[i].DisplayAdd = 1;
  }

  saveFieldData(i) {
    this.specList[i].DisplayAdd = 0;
    let count = 0;
    this.specList[i].SptTableData.forEach(element => {
      if (element.TableValue.toLowerCase() === this.specList[i].SelectedValue.toLowerCase()) { count = count + 1; }

    });
    if (count !== 0 || this.specList[i].SelectedValue === '') {
      //  alert("Duplicate or Empty Values are not allowed");
       Swal.fire({
        icon: 'error',
        title: 'One of the selected Item does not have Total Amount field Filled.',
        text: ' Please correct before Submitting',
        footer: ''
      });
       } else {
      const Ref = this.specList[i].Ref;
      let RefValue = 0;
      if (Ref !== 0) {
        this.specList.forEach((element, j) => {
          if (element.FieldName === Ref) { RefValue = element.SelectedValue; }
        });
      }

      this.spinner.show();
      this.companyService.saveProductSupportData(this.specList[i].SelectedValue, RefValue, this.specList[i].SptTableName)
        .subscribe(data => {
          this.companyService.getProductSupportData(this.specList[i].SptTableName, RefValue).subscribe(data1 => {
            this.specList[i].SptTableData = data1.result;
            this.specList[i].SptFilterData = data1.result;
            this.spinner.hide();
            this.showNotification(
              'bg-green',
              'Data Saved successfully',
              'top',
              'right'
            );
          }, (err) => {
            console.log(err);
            // this.showFailure(err, 'Error Loading Data.');
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Error not saved Data.',
              'top',
              'right'
            );
          });
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Data not saved.',
            'top',
            'right'
          );
        });
    }

  }

  filterMyOptions(event, i) {
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  enterSubmit(event) {
    if (event.keyCode === 14) {
      this.addItem();
    }
    if (event.keyCode === 17) {
      this.onSubmit();
    }
  }

  onSubmit() {
    this.spinner.show()
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.PurchaseDetail = this.itemList;
    this.data.Charge = this.chargeList;
    this.companyService.savePurchase('Purchase', this.data).subscribe(data1 => {
      this.router.navigate(['/inventory/purchaselist']);
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    });
  }

  updatedPurchase(){
    this.spinner.show()
    this.selectedPurchaseMaster.ShopID = this.loggedInShop.ShopID;
    this.data.PurchaseMaster = this.selectedPurchaseMaster;
    this.data.PurchaseDetail = this.itemList;
    this.data.Charge = this.chargeList;
    this.companyService.updatePurchase('Purchase', this.data).subscribe(data1 => {
      // this.router.navigate(['/inventory/purchaselist']);
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data submitted successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Data not submitted.',
        'top',
        'right'
      );
    });

  }

   //  printer

   initQZ() {

    qz.security.setCertificatePromise(function(resolve, reject) {
      resolve('-----BEGIN CERTIFICATE-----\n' +
      'MIID2jCCAsKgAwIBAgIJAO4MCWl5uZYwMA0GCSqGSIb3DQEBCwUAMIGAMQswCQYD\n' +
      'VQQGEwJJTjELMAkGA1UECAwCTVAxDzANBgNVBAcMBkluZG9yZTEMMAoGA1UECgwD\n' +
      'QUNTMQswCQYDVQQLDAJJVDESMBAGA1UEAwwJbG9jYWxob3N0MSQwIgYJKoZIhvcN\n' +
      'AQkBFhVuZ3VyamFyMTk5MUBnbWFpbC5jb20wIBcNMTkwMTIzMTAxMDA4WhgPMjA1\n' +
      'MDA3MTgxMDEwMDhaMIGAMQswCQYDVQQGEwJJTjELMAkGA1UECAwCTVAxDzANBgNV\n' +
      'BAcMBkluZG9yZTEMMAoGA1UECgwDQUNTMQswCQYDVQQLDAJJVDESMBAGA1UEAwwJ\n' +
      'bG9jYWxob3N0MSQwIgYJKoZIhvcNAQkBFhVuZ3VyamFyMTk5MUBnbWFpbC5jb20w\n' +
      'ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCW/KdcXmH3J0SPg8MB3lvm\n' +
      'm6F7dspxYTykOK9UV9vdd+APiX6nTE+M/beoo4zI1brGbo7L3LVshGffPiCI5IQ4\n' +
      '8MmHVI+32+zDVgyOu465VOSu5MJLXr1bMhuf7wwHnbJcCOYfkQibO4KckQk2rSd7\n' +
      'DF/RDAEsIHFfoHCvAfaw7i0HazIvohhXvv/VEvsTtkL9ZCfNhYVKnmCkjEP+gkwx\n' +
      '70LEzSdNZ2HVTf3H4RzOp7vRceSyg9Wp99HnOoBrJi7BLLf1P0480eDLeIV0wIU3\n' +
      '3d6n05NieVGH4ge7KdSkH3bawlEWQ5R5LygSQX2JeA1OjpRQ8U/tIva88xo79HIj\n' +
      'AgMBAAGjUzBRMB0GA1UdDgQWBBT1rFtIE/FhX5xrqxF3z8WqksZQETAfBgNVHSME\n' +
      'GDAWgBT1rFtIE/FhX5xrqxF3z8WqksZQETAPBgNVHRMBAf8EBTADAQH/MA0GCSqG\n' +
      'SIb3DQEBCwUAA4IBAQBDEUdpzDgIXvmfWRie+YnhlEtgZxjPAhvi3BRbk8WZdulL\n' +
      'AB/cHjuahyhM7/S6pYSLCM7ByLvM5Ddox6axGTsAst3rdh2+1T1QLt8gJgOGcWBP\n' +
      'NWWVLg65+kmVlM7CbNbaty7WVxrhkHwO4p/7SgTZQek0WgDO2feOx0G1LEZuHphS\n' +
      'QY4ddyiMLpZLMb3zn00uWT8/ktXMXT0gfqa/h+8ccCUT6icwDk/hY5sRe19kS1ER\n' +
      'thD6mxrE4gh6q081ewZJqNAToKio5QRSHSSTbE7/xL07kX3HyeHKZzvlRQdzywHr\n' +
      '1kuUCW1JRvlclvtQS1jD6I3P+760tlol4QR2fUNG\n' +
      '-----END CERTIFICATE-----');
    });
  
  
    const Key = '-----BEGIN PRIVATE KEY-----\n' +
    'MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCW/KdcXmH3J0SP\n' +
    'g8MB3lvmm6F7dspxYTykOK9UV9vdd+APiX6nTE+M/beoo4zI1brGbo7L3LVshGff\n' +
    'PiCI5IQ48MmHVI+32+zDVgyOu465VOSu5MJLXr1bMhuf7wwHnbJcCOYfkQibO4Kc\n' +
    'kQk2rSd7DF/RDAEsIHFfoHCvAfaw7i0HazIvohhXvv/VEvsTtkL9ZCfNhYVKnmCk\n' +
    'jEP+gkwx70LEzSdNZ2HVTf3H4RzOp7vRceSyg9Wp99HnOoBrJi7BLLf1P0480eDL\n' +
    'eIV0wIU33d6n05NieVGH4ge7KdSkH3bawlEWQ5R5LygSQX2JeA1OjpRQ8U/tIva8\n' +
    '8xo79HIjAgMBAAECggEAXimjlo+mOSVcNMTP0VKDrgZRZ1ZmWt9xmllfvxIsJKqm\n' +
    'Kgpt2phU5HE3IQ0euAHTQf2hQLKc0tigjzGHyNf7PietB6FNIDUgK5J2sm12TU8M\n' +
    'b6ZrJeYn4cAWSmAi+Hz4xz0lh3pEC8vJYStyu46xmKPW/eCmuoZhLmo43Gw1FZH/\n' +
    'ePwifrP4tjFav0BqyyevjWHFV7BOcgQPOeOLDSFMOUIjneJr2slw+GRS02GF3KCs\n' +
    '+52Q6M6spTKuPeAiKq9Uv8Yy1cAItP7rf45h8ftaBIWAG4AqnE7AFH2ylNsVXp3l\n' +
    's+rDWklVeqDd92a90twBYlf1dUjfx2WrbnmeCbjXwQKBgQDFWR8QTR/nNX91ARFk\n' +
    'OFePZW3e93TTOvLiNbIK6tAgArgTt9zbPY596MpHNWd1mzvLDqh1tW/n9B6VBLU3\n' +
    'NXGLPzMfUCoeoqiadXe1UZ+l8wxe8V6S+cv7SroqoyUw+H/5NMRhI0DcV973JZCh\n' +
    'qr192P5FbYrn33PySd9Y5b0qBQKBgQDD3Dk4ULR0HTl5L7vGyZ3FJk9CNnywcXbf\n' +
    'gR/Xdof5NX1A/SrDCPMF4qkF8c2GitGMd/XM81wMpxIwTelZxxvQXBM8K+eMK2z3\n' +
    'k4YKNa9nQwR6vuxrgtMkAr5+OVq12Uz8j0pOUgkVmy93kx52MQtOri1L8v5zk5ZY\n' +
    'wTam6LzcBwKBgCvKILhvRJr7JfMCb6d7UQKCkSSeaA/OzsIfBAikHdZchBfr/lev\n' +
    'iwSpOOkgEnroHRZrhDnKLrCbXIXYa5V6iF1Lgr55/T6a/Sp40j0rhW8/RQl0KXYX\n' +
    'c4mpBTIczU3Wdh8H9GNRfTznSpQwg607w5w/H/yr19ynmoSym5qQL685AoGAcYgl\n' +
    'bvxxLeGG4DWILnnOR2qmhOYarxiGZJZvw7DErvOPkG1wLS/x11aEzZpVnYi4YSlk\n' +
    'RRJIKFlsFK4E9vKQr92/lKCKjtjZSEWubBqke0IAxboIR2XFSFmC3J4Yc9LrancR\n' +
    'BodNFsYm5LRV8wMI3+nc/ep0DsDdZMNTD7tXRl8CgYAL3P2sTdbg9+ipe507IniI\n' +
    '/aFVtKjhescb6sEjUBaVrIxpHpEGpIvxD2tB3LeU2oBoG1tjCI4Ln593WrYlGDdm\n' +
    'NieTIH3AS38mLYHz1RyusOMbq8TL+p/H/6s/65XXU0g7st1ESY5JgHWevRg4QtUp\n' +
    'ionZ//np79MDwXXJidBxaA==\n' +
    '-----END PRIVATE KEY-----';
    qz.security.setSignaturePromise(hash => {
      return (resolve, reject) => {
  
      const pk = KEYUTIL.getKey(Key);
      const sig = new KJUR.crypto.Signature({'alg': 'SHA1withRSA'});
      sig.init(pk);
      sig.updateString(hash);
      const hex = sig.sign();
      // console.log("DEBUG: \n\n" + stob64(hextorstr(hex)));
      resolve(stob64(hextorstr(hex)));
      };
    });
  
    // if (!qz.websocket.isActive()) {
      let qzVersion = 0;
      qz.websocket.connect().then(function() {
        qz.api.getVersion().then(function(data) {
            qzVersion = data;
            console.log(qzVersion);
        }).catch();
  
      }).catch();
    // } else {
  
    // }
  
  }
  
  
  
  PrintData() {
  
  // tslint:disable-next-line:max-line-length
  const dataToPrint = '<html>' + this.myDiv.nativeElement.innerHTML + '</html>';
  
    // const code = '12345';
  
    // convenience method
    // const chr = function(n) { return String.fromCharCode(n); };
  
    // const barcode = '\x1D' + 'h' + chr(80) +   //barcode height
    //     '\x1D' + 'f' + chr(0) +              //font for printed number
    //     '\x1D' + 'k' + chr(69) + chr(code.length) + code + chr(0); //code39
  
    const data = [{
      type: 'pixel',
      format: 'html',
       flavor: 'plain', // or 'file' if using a URL
      data: dataToPrint,
      // options: { length: 'ESCPOS', dotDensity: 'double' }
    }];

  
    if (qz.websocket.isActive()) {
  
      qz.print(qz.configs.create('BARCODEPRINTER'), data)
      .then(dta => {
  
      })
      .catch(function(e) { console.error(e); });
    } else {
      qz.websocket.connect().then(() =>
      qz.print(qz.configs.create('BARCODEPRINTER'), data))
      .then(dta => {
  
      })
      .catch(err => console.error(err));
    }
  }


  ngAfterViewInit() {
    // this.dtTrigger.next();
    // console.log(this.myDiv.nativeElement.innerHTML);
  }
  
  getPrinters(): Observable<any[]> {
    return Observable
    .fromPromise(qz.websocket.connect().then(() => qz.printers.find()))
    .map((printers: string[]) => printers);
    }
    
    getPrinter(printerName: string): Observable<string> {
    return Observable
    .fromPromise(qz.websocket.connect().then(() => qz.printers.find(printerName)))
    .map((printer: string) => printer);
    }


  //get getBarcodelist
  getBarcodelist(data){
    this.companyService.getSearchBarCodeFilter(data.ID, false, '').subscribe(data => {
      this.barcodeList = data.data;
      this.barcodeList.forEach(element => {
        this.getPrintBySelectedItem(element);
      });
    }, (err) => {
      console.log(err);
    });
  
  }

  getPrintBySelectedItem(data) {
    this.selectedItemPrint.BarCode = data.Barcode;
    this.selectedItemPrint.ProductTypeName = data.ProductTypeName;
    this.changeDectectorRef.detectChanges();
  console.log('THISISMYDATA', this.myDiv.nativeElement.innerHTML);
  this.PrintData();
  }

  showSuccess(display, Message) {
    // this.toastrService.success(display, Message);
  }

  showFailure(error, Message) {
    // this.toastrService.error(error, Message);
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}
