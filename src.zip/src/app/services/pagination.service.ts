import { Injectable, ErrorHandler } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PaginationService {
  env = environment;
  loggedInUser = localStorage.getItem('LoggedINUser');
  loggedInCompany = localStorage.getItem('LoggedINCompany');
  loggedInShop = localStorage.getItem('LoggedINShop');
  loggedInCompanySetting = localStorage.getItem('LoggedINCompanySetting');
  private url = this.env.apiUrl + 'pageApi';

  constructor(private httpClient: HttpClient) { 
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
  }


  getList(TableName, Body): Observable<any> {
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', JSON.parse(this.loggedInUser).ID).set('TableName', TableName).set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ShopID', JSON.parse(this.loggedInShop).ID);
    return this.httpClient.post<any>(this.url + '/getList', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }
  getsearchList(TableName, Body): Observable<any> {
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', JSON.parse(this.loggedInUser).ID).set('TableName', TableName).set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ShopID', JSON.parse(this.loggedInShop).ID);
    return this.httpClient.post<any>(this.url + '/getsearchList', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  getPreOrderStatus(mode, dtm): Observable<any> {
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode).set('dtm', JSON.stringify(dtm))
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ShopID', JSON.parse(this.loggedInShop).ShopID);
    return this.httpClient.get<any>(this.url + '/preOrderStatus', { headers, params })
      .pipe(catchError(this.handleError));
  }



  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', errorResponse.error.message);
    } else {
      console.error('Server Side Error: ', errorResponse);
    }
    return throwError(errorResponse);
  }


}
