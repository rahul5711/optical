import { Injectable, ErrorHandler } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PoService {
  env = environment;
  loggedInUser = localStorage.getItem('LoggedINUser');
  loggedInCompany = localStorage.getItem('LoggedINCompany');
  loggedInShop = localStorage.getItem('LoggedINShop');
  loggedInCompanySetting = localStorage.getItem('LoggedINCompanySetting');
  private url = this.env.apiUrl + 'poApi';

  constructor(private httpClient: HttpClient) { 
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
  }

  getPurchaseFullDataByID(ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID);
    return this.httpClient.get<any>(this.url + '/purchaseFullDataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  savePurchase(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/savePurchase', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  updatePurchase(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/updatePurchase', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', errorResponse.error.message);
    } else {
      console.error('Server Side Error: ', errorResponse);
    }
    return throwError(errorResponse);
  }
}
