import { Injectable, ErrorHandler } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  env = environment;
  loggedInUser = localStorage.getItem('LoggedINUser');
  loggedInCompany = localStorage.getItem('LoggedINCompany');
  loggedInShop = localStorage.getItem('LoggedINShop');
  loggedInCompanySetting = localStorage.getItem('LoggedINCompanySetting');
  private url = this.env.apiUrl + 'company';
  private _url1 = this.env.apiUrl + 'uploads';

  constructor(private httpClient: HttpClient) {
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
  }

  uploadFile(image, fileName, module) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('loggedOnUser', this.loggedInUser).set('mode', module).set('ID', fileName);
    return this.httpClient.post<any>(this._url1, image, {headers: headers, params: params } )
    .pipe(catchError(this.handleError));
  }

  transferProduct(Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/transferProduct', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  cancelTransfer(Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/cancelTransfer', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  filterDataByParam(Body, TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID)
    .set('TableName', TableName);
    return this.httpClient.post<any>(this.url + '/filterDataByParam', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  acceptTransfer(Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/acceptTransfer', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  getPreOrderStatus(mode): Observable<any> {
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ShopID', JSON.parse(this.loggedInShop).ShopID);
    return this.httpClient.get<any>(this.url + '/preOrderStatus', { headers, params })
      .pipe(catchError(this.handleError));
  }

  setPreOrderStatus(Body, mode): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/setPreOrderStatus', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  setPreOrderStatusPo(Body, mode): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/setPreOrderStatusPo', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  getProductDataByBarCodeNo(SearchBarCode, PreOrder, ShopMode): Observable<any> {
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('SearchBarCode', SearchBarCode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ShopID', JSON.parse(this.loggedInShop).ShopID)
      .set('ShopMode', ShopMode).set('PreOrder', PreOrder);
    return this.httpClient.get<any>(this.url + '/productDataByBarCodeNo', { headers, params })
      .pipe(catchError(this.handleError));
  }

  // getSmsReport(MobileNo, MsgText, TemplateID): Observable<any> {
  //   this.loggedInShop = localStorage.getItem('LoggedINShop');
  //   const headers = new HttpHeaders().set('Content-Type', 'application/json');
  //   const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('MobileNo', MobileNo)
  //     .set('MsgText', MsgText).set('TemplateID', TemplateID);
  //   return this.httpClient.get<any>(this.url + '/getSmsReport', { headers, params })
  //     .pipe(catchError(this.handleError));
  // }

  getBarCodeList(SearchString, ProductName, ShopMode): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('SearchString', SearchString)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ProductName', ProductName)
      .set('ShopID', JSON.parse(this.loggedInShop).ShopID).set('ShopMode', ShopMode);
    return this.httpClient.get<any>(this.url + '/barCodeListBySearchString', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getBarCodeList1(SearchString, ProductName, ShopMode, ShopID): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('SearchString', SearchString)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ProductName', ProductName)
      .set('ShopID', ShopID).set('ShopMode', ShopMode);
    return this.httpClient.get<any>(this.url + '/barCodeListBySearchString', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getPreOrderBarCodeList(SearchString, ProductName): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('SearchString', SearchString)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ProductName', ProductName)
      .set('ShopID', JSON.parse(this.loggedInShop).ShopID);
    return this.httpClient.get<any>(this.url + '/barPreOrderCodeListBySearchString', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getAggregateListByParem(TableName1, TableName2, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName1', TableName1).set('TableName2', TableName2)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/agreegateListByParem', { headers, params })
      .pipe(catchError(this.handleError));
  }


  generateBill(mode, Body): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/generateBill', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  purchaseReturn(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/purchaseReturn', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }



  generateOrderForm(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/generateOrderForm', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  customerNote(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Company', this.loggedInCompanySetting)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/customerNote', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  billPayment(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Company', this.loggedInCompanySetting)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/billPayment', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  billSubPayment(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Company', this.loggedInCompanySetting)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/billSubPayment', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  BarcodePrint(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Company', this.loggedInCompanySetting)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/BarcodePrint', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  BarcodePrintAll(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Company', this.loggedInCompanySetting)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/BarcodePrintAll', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }
  BarcodePrintAlls(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Company', this.loggedInCompanySetting)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Mode', mode);
    return this.httpClient.post<any>(this.url + '/BarcodePrintAlls', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }






  getExtendedListByCompany(TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
    .set('CompanyID', this.loggedInCompany).set('ShopID', this.loggedInShop);
    return this.httpClient.get<any>(this.url + '/extendedListByCompany', { headers, params })
      .pipe(catchError(this.handleError));
  }



getExtendedListByCompany1(TableName, CompanyID, ShopID): Observable<any> {
  const headers = new HttpHeaders().set('Content-Type', 'application/json');
  const params = new HttpParams()
  .set('LoggedOnUser', this.loggedInUser)
  .set('TableName', TableName)
  .set('CompanyID', CompanyID)
  .set('ShopID', ShopID);
  return this.httpClient.get<any>(this.url + '/extendedListByCompany1', { headers, params })
  .pipe(catchError(this.handleError));
}

customeridd(TableName, CompanyID, ShopID): Observable<any> {
  const headers = new HttpHeaders().set('Content-Type', 'application/json');
  const params = new HttpParams()
  .set('LoggedOnUser', this.loggedInUser)
  .set('TableName', TableName)
  .set('CompanyID', CompanyID)
  .set('ShopID', ShopID);
  return this.httpClient.get<any>(this.url + '/customeridd', { headers, params })
  .pipe(catchError(this.handleError));
}

getExtendedCustomerListBy(TableName, CompanyID, ShopID): Observable<any> {
  const headers = new HttpHeaders().set('Content-Type', 'application/json');
  const params = new HttpParams()
  .set('LoggedOnUser', this.loggedInUser)
  .set('TableName', TableName)
  .set('CompanyID', CompanyID)
  .set('ShopID', ShopID);
  return this.httpClient.get<any>(this.url + '/extendedCustomerListBy', { headers, params })
  .pipe(catchError(this.handleError));
}

getExtendedCustomerListBy2(TableName, CompanyID, ShopID,Page): Observable<any> {
  const headers = new HttpHeaders().set('Content-Type', 'application/json');
  const params = new HttpParams()
  .set('LoggedOnUser', this.loggedInUser)
  .set('TableName', TableName)
  .set('CompanyID', CompanyID)
  .set('ShopID', ShopID);
  return this.httpClient.get<any>(this.url + '/extendedCustomerListBy2'  + Page , { headers, params })
  .pipe(catchError(this.handleError));
}



  getDashboardData(dt1, dt2, shopID): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Date1', dt1).set('Date2', dt2).set('ShopID', shopID)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/getDashboardData', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getShortListByCompany(TableName, DelMode): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('DelMode', DelMode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/shortListByCompany', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getShortListByCompanyOrderBy(TableName, DelMode): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('DelMode', DelMode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/getShortListByCompanyOrderBy', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getcheckInvoicNo(Param): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Param', Param)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/getcheckInvoicNo', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getcheckInvoicNoComm(Param): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Param', Param)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/getcheckInvoicNoComm', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getcheckInvoicNoFitter(Param): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Param', Param)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/getcheckInvoicNoFitter', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getBillData(ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('ID', ID)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/getBillData', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getSearchBarCodeList(): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/getSearchBarCodeList', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getSearchBarCodeFilter(PurchaseDetailID, ShopMode, mode): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('PurchaseDetailID', PurchaseDetailID)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ShopID', JSON.parse(this.loggedInShop).ShopID)
      .set('ShopMode', ShopMode).set('mode', mode);
    return this.httpClient.get<any>(this.url + '/getSearchBarCodeFilter', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getExtendedDataByID(TableName, ID): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID);
    return this.httpClient.get<any>(this.url + '/extendedDataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getExtendedListByID(TableName, ID): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID);
    return this.httpClient.get<any>(this.url + '/extendedListByID', { headers, params })
      .pipe(catchError(this.handleError));
  }


  printChallan(Mode, Body, Type): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Company', this.loggedInCompany).set('Mode', Mode).set('Type', Type);
    return this.httpClient.post<any>(this.url + '/printChallan', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  getShortDataByID(TableName, ID): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID);
    return this.httpClient.get<any>(this.url + '/shortDataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getCredit(ID, Mode): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID).set('CreditEntity', Mode);
    return this.httpClient.get<any>(this.url + '/getCredit', { headers, params })
      .pipe(catchError(this.handleError));
  }
  getShortListByParam(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', JSON.stringify(Parem));
    return this.httpClient.get<any>(this.url + '/shortListByParem', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getShortListByParamNew(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', JSON.stringify(Parem));
    return this.httpClient.get<any>(this.url + '/shortListByParemNew', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getShortListByParamNewBill(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', JSON.stringify(Parem));
    return this.httpClient.get<any>(this.url + '/shortListByParemNewBill', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getExtendedListByParamNew(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', JSON.stringify(Parem));
    return this.httpClient.get<any>(this.url + '/extendedListByParemNew', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getGenericListByParem(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/genericListByParem', { headers, params })
      .pipe(catchError(this.handleError));
  }

  newpurchasereports(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/newpurchasereports', { headers, params })
      .pipe(catchError(this.handleError));
  }
  getGenericListByParemSalePayment(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/getGenericListByParemSalePayment', { headers, params })
      .pipe(catchError(this.handleError));
  }
  getGenericListByParemSaleReport(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/getGenericListByParemSaleReport', { headers, params })
      .pipe(catchError(this.handleError));
  }




  getLaserReportpdf(CustomerID, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CustomerID', CustomerID)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/laserReportpdf', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getLaserReportSuppdf(SupplierID, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('SupplierID', SupplierID)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/laserReportSubpdf', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getLaserReportemppdf(EmployeeID, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('EmployeeID', EmployeeID)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/laserReportemppdf', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getCommissionList(Parem, UserType): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('UserType', UserType)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', Parem);
    return this.httpClient.get<any>(this.url + '/getCommissionList', { headers, params })
      .pipe(catchError(this.handleError));
  }




  getExtendedListByParam(TableName, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', JSON.stringify(Parem));
    return this.httpClient.get<any>(this.url + '/extendedListByParem', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getPaymentListByPaymentType(PaymentType, Parem): Observable<any> {

    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('PaymentType', PaymentType)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Parem', JSON.stringify(Parem));
    return this.httpClient.get<any>(this.url + '/getPaymentListByPaymentType', { headers, params })
      .pipe(catchError(this.handleError));
  }

  // Function to get Purchase Data along with details ansd Specs
  getPurchaseFullDataByID(ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID);
    return this.httpClient.get<any>(this.url + '/purchaseFullDataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getFitterInvoiceFullDataByID(ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID);
    return this.httpClient.get<any>(this.url + '/fitterInvoiceFullDataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getCommissionInvoiceFullDataByID(ID,UserType): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID).set('UserType', UserType);
    return this.httpClient.get<any>(this.url + '/commissionInvoiceFullDataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  // ??
  getList(TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url, { headers, params })
      .pipe(catchError(this.handleError));
  }

  getdeletedata(TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('loggedInShop', this.loggedInShop);
    return this.httpClient.get<any>(this.url+ '/getdeletedata', { headers, params })
      .pipe(catchError(this.handleError));
  }

  deletePermanent(TableName, ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID);
    return this.httpClient.delete<any>(this.url + '/deletePermanent', { headers, params })
      .pipe(catchError(this.handleError));
  }

  Retrive(TableName, ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID);
    return this.httpClient.delete<any>(this.url + '/Retrive', { headers, params })
      .pipe(catchError(this.handleError));
  }

  // ??
  geListByOtherID(TableName, ID): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID)
      .set('TableName', TableName).set('ID', ID).set('Shop', JSON.parse(this.loggedInShop));
    return this.httpClient.get<any>(this.url + '/listByOtherID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  geListByOtherID1(TableName, ID, Shop): Observable<any> {
    // this.loggedInUser = localStorage.getItem('LoggedINUser');
    // this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    // this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID)
      .set('TableName', TableName).set('ID', ID).set('Shop', Shop);
    return this.httpClient.get<any>(this.url + '/listByOtherID1', { headers, params })
      .pipe(catchError(this.handleError));
  }

  


  getPreorderPurchaseList(Mode, ID, ShopID): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID)
    .set('Mode', Mode).set('ID', ID).set('ShopID', ShopID);
    return this.httpClient.get<any>(this.url + '/getPreorderPurchaseList', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getListByPage(Mode, ID, ShopID, pageLimit): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID)
    .set('Mode', Mode).set('ID', ID).set('ShopID', ShopID).set('pageLimit', pageLimit);
    return this.httpClient.get<any>(this.url + '/getListByPage', { headers, params })
      .pipe(catchError(this.handleError));
  }

  checkforDuplicate(TableName, LoginName): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('TableName', TableName).set('LoginName', LoginName);
    return this.httpClient.get<any>(this.url + '/checkforDuplicate', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getSearchDataByFilter(TableName, filter): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID)
      .set('TableName', TableName).set('filter', JSON.stringify(filter));
    return this.httpClient.get<any>(this.url + '/searchDataByFilter', { headers, params })
      .pipe(catchError(this.handleError));
  }
  getSearchDataByFilterForCashRegister(TableName, filter): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    this.loggedInCompany = localStorage.getItem('LoggedINCompany');
    this.loggedInShop = localStorage.getItem('LoggedINShop');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('CompanyID', JSON.parse(this.loggedInCompany).ID)
      .set('TableName', TableName).set('filter', JSON.stringify(filter));
    return this.httpClient.get<any>(this.url + '/getSearchDataByFilterForCashRegister', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getPermissionByRole(ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('ID', ID)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/permissionByRole', { headers, params })
      .pipe(catchError(this.handleError));
  }

  // YY
  getProdFieldList(ProductTypeName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('ProductTypeName', ProductTypeName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/fieldList', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getDataByID(ID, Mode, TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('loggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('ID', ID).set('Mode', Mode).set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/dataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getDataByName(TableName, Name): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('Name', Name).set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/dataByName', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getProductSupportData(TableName, Ref): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('Ref', Ref)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/productSupportData', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getSupportMasterList(TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('TableName', TableName)
    .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.get<any>(this.url + '/supportMasterList', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getCashRegisterData(): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ShopID', JSON.parse(this.loggedInShop).ID);
    return this.httpClient.get<any>(this.url + '/cashRegisterData', { headers, params })
      .pipe(catchError(this.handleError));
  }

  saveProductSupportData(SelectedValue, Ref, TableName): Observable<any> {
    let val = {"SelectedValue" : SelectedValue};
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('Ref', Ref)
      .set('SelectedValue', SelectedValue).set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/saveProductSupportData', val ,{ headers, params })
      .pipe(catchError(this.handleError));
  }

  saveData(TableName, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName) .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/save', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  saveSmallData(TableName, ID,  Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('ID', ID);
    return this.httpClient.post<any>(this.url + '/saveSmallData', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  savePurchase(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/savePurchase', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  updatePurchase(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/updatePurchase', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  getExistingProduct(data): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/getExistingProduct', data, { headers, params })
      .pipe(catchError(this.handleError));
  }

  saveBill(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/saveBill', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  updateBill(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Company', this.loggedInCompanySetting);
    return this.httpClient.post<any>(this.url + '/updateBill', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }
  updateCurrection(mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Company', this.loggedInCompanySetting);
    return this.httpClient.post<any>(this.url + '/updateCurrection', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  updateProductStatus(id, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('id', id)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID);
    return this.httpClient.post<any>(this.url + '/updateProductStatus', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  applyPayment(mode, userMode, Body): Observable<any> {
    this.loggedInCompanySetting = localStorage.getItem('LoggedINCompanySetting');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Mode', mode).set('UserMode', userMode)
      .set('CompanyID', JSON.parse(this.loggedInCompany).ID).set('Company', this.loggedInCompanySetting);
    return this.httpClient.post<any>(this.url + '/applyPayment', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  deleteData(TableName, ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID);
    return this.httpClient.delete<any>(this.url + '/delete', { headers, params })
      .pipe(catchError(this.handleError));
  }

  deleteDataOtherID(TableName, ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID);
    return this.httpClient.delete<any>(this.url + '/deleteOtherID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  deletePreOrder(TableName, ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID);
    return this.httpClient.delete<any>(this.url + '/deletePreOrder', { headers, params })
      .pipe(catchError(this.handleError));
  }

  printLens(Mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('shop', this.loggedInShop).set('Company', this.loggedInCompany).set('Mode', Mode);
    return this.httpClient.post<any>(this.url + '/printLens', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  AssignFitterPDF(Mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Shop', this.loggedInShop).set('Mode', Mode);
    return this.httpClient.post<any>(this.url + '/AssignFitterPDF', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  AssignSupplierPDF(Mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Shop', this.loggedInShop).set('Mode', Mode);
    return this.httpClient.post<any>(this.url + '/AssignSupplierPDF', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  PurchasePDF(Mode, Body): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('Shop', this.loggedInShop).set('Mode', Mode);
    return this.httpClient.post<any>(this.url + '/PurchasePDF', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  sendSms(MobileNo, MsgText, TemplateID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('MsgText', MsgText).set('MobileNo', MobileNo)
      .set('TemplateID', TemplateID);
    return this.httpClient.get<any>(this.url + '/sendsms' , { headers, params })
      .pipe(catchError(this.handleError));
  }

  sendSms1(MobileNo, MsgText, TemplateID, SenderID , MsgAPIKey): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('MsgText', MsgText).set('MobileNo', MobileNo)
      .set('TemplateID', TemplateID).set('SenderID', SenderID).set('MsgAPIKey', MsgAPIKey);
    return this.httpClient.get<any>(this.url + '/sendsms' , { headers, params })
      .pipe(catchError(this.handleError));
  }
  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', errorResponse.error.message);
    } else {
      console.error('Server Side Error: ', errorResponse);
    }
    return throwError(errorResponse);
  }
}
