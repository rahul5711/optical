import { Injectable, ErrorHandler } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  env = environment;
  loggedInUser = localStorage.getItem('LoggedINUser');
  loggedInCompany = localStorage.getItem('LoggedInCompany');

  private url = this.env.apiUrl + 'admin';
  private url1 = this.env.apiUrl + 'upload';
  private url2 = this.env.apiUrl;

  constructor(private httpClient: HttpClient) { }

  gettList(TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('loggedOnUser', this.loggedInUser).set('TableName', TableName).set('Mode', 'getAllData');
    return this.httpClient.get<any>(this.url + '/', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getSupportList(TableName, parem): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('TableName', TableName).set('parem', parem).set('Mode', 'getSupportData');
    return this.httpClient.get<any>(this.url + '/', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getForgetPassword(TableName, parem): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('TableName', TableName).set('parem', parem).set('Mode', 'getAllDataByParem');
    return this.httpClient.get<any>(this.url + '/', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getfilterList(TableName, parem): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('TableName', TableName).set('parem', parem).set('Mode', TableName);
    return this.httpClient.get<any>(this.url + '/', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getSupportMasterList(TableName): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('TableName', TableName).set('loggedOnUser', this.loggedInUser);
    return this.httpClient.get<any>(this.url + '/supportMasterList', { headers, params })
      .pipe(catchError(this.handleError));
  }
  getProductAssignList(TableName): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('TableName', TableName).set('loggedOnUser', this.loggedInUser);
    return this.httpClient.get<any>(this.url + '/getProductAssignList', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getCompanyList(TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('TableName', TableName);
    return this.httpClient.get<any>(this.url + '/companylist', { headers, params })
      .pipe(catchError(this.handleError));
  }

  getDataByID(ID , Mode, TableName): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('loggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID).set('Mode', Mode);
    return this.httpClient.get<any>(this.url + '/dataByID', { headers, params })
      .pipe(catchError(this.handleError));
  }

  // getOwnerDataByID(ID, TableName, Mode): Observable<any[]> {
  //   const headers = new HttpHeaders().set('Content-Type', 'application/json');
  //   const params = new HttpParams().set('loggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID).set('Mode', Mode);;
  //   return this.httpClient.get<any[]>(this.url + '/ownerDataByID', { headers, params })
  //     .pipe(catchError(this.handleError));
  // }
  getShortListByCompany(TableName, DelMode): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('DelMode', DelMode)
    ;
    return this.httpClient.get<any>(this.url + '/shortListByCompany', { headers, params })
      .pipe(catchError(this.handleError));
  }





  getDataByName(TableName, Name): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName)
      .set('Name', Name);
    return this.httpClient.get<any>(this.url + '/dataByName', { headers, params })
      .pipe(catchError(this.handleError));
  }



  saveData(TableName, Body): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('loggedOnUser', this.loggedInUser).set('TableName', TableName);
    return this.httpClient.post<any>(this.url + '/save', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }


  assignProduct(Body): Observable<any> {
    this.loggedInUser = localStorage.getItem('LoggedINUser');
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('loggedOnUser', this.loggedInUser);
    return this.httpClient.post<any>(this.url + '/assignProduct', Body, { headers, params })
      .pipe(catchError(this.handleError));
  }

  sendEmail(Body, Mode): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('Mode', Mode);
    return this.httpClient.post<any>(this.url2 + 'email', Body, { headers, params})
      .pipe(catchError(this.handleError));
  }

  deleteData(id , TableName): Observable<any[]> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('loggedOnUser', this.loggedInUser).set('TableName', TableName).set('id', id);
    return this.httpClient.delete<any[]>(this.url + '/delete' , { headers, params })
      .pipe(catchError(this.handleError));
  }

  deleteData1(TableName, ID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('LoggedOnUser', this.loggedInUser).set('TableName', TableName).set('ID', ID);
    return this.httpClient.delete<any>(this.url + '/delete1', { headers, params })
      .pipe(catchError(this.handleError));
  }

  uploadFile(data: any): Observable<any> {
    // const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams();
    return this.httpClient.post<any>(this.url1, data, { params })
      .pipe(catchError(this.handleError));
  }

  sendSms(MobileNo, MsgText, TemplateID): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json');
    const params = new HttpParams().set('MsgText', MsgText).set('MobileNo', MobileNo)
      .set('TemplateID', TemplateID);
    return this.httpClient.get<any>(this.url + '/sendsms' , { headers, params })
      .pipe(catchError(this.handleError));
  }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', errorResponse.error.message);
    } else {
      console.error('Server Side Error: ', errorResponse);
    }
    return throwError(errorResponse);
  }
}
