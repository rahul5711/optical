import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductManagementComponent } from './product-management.component';
import { ProductManageComponent } from './product-manage.component';
import { ServiceManagementComponent } from './service-management.component';
import { ChargerManagementComponent } from './charger-management.component';
import { AddTypesComponent } from './add-types.component';



const routes: Routes = [
  { path: '',
  children: [
    { path: '', component: ProductManagementComponent },
    { path: 'productManage', component: ProductManageComponent },
    { path: 'productManagement', component: ProductManagementComponent },
    { path: 'serviceManagement', component: ServiceManagementComponent },
    { path: 'chargerManagement', component: ChargerManagementComponent },
    { path: 'addTypes', component: AddTypesComponent },


  ]}
  ];



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProdserviceRoutingModule { }
