import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProdserviceRoutingModule } from './prodservice-routing.module';
import { ProductManagementComponent } from './product-management.component';
import { ProductManageComponent } from './product-manage.component';
import { ServiceManagementComponent } from './service-management.component';
import { ChargerManagementComponent } from './charger-management.component';
import { AddTypesComponent } from './add-types.component';




import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { ProditemFilter} from './../filter/proditemfilter';
import { ProdItemFilterSep} from './../filter/ProdItemFilterSep';
import { AddNameFilter} from './../filter/addNameFilter';
import { AutoFoucsDirectivesDirective } from './auto-foucs-directives.directive';






@NgModule({
  declarations: [ProductManagementComponent, ProductManageComponent, AddTypesComponent, ServiceManagementComponent, ProditemFilter,ProdItemFilterSep,ChargerManagementComponent,AddNameFilter,AutoFoucsDirectivesDirective],
  imports: [
    CommonModule,
    ProdserviceRoutingModule,
    CommonModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSortModule,
    MatToolbarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatTabsModule,
    MaterialFileInputModule,
    NgxSpinnerModule,
    PerfectScrollbarModule,
    NgxMatSelectSearchModule,
  ]
})
export class ProdserviceModule { }
