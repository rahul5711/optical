import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-service-management',
  templateUrl: './service-management.component.html'
})
export class ServiceManagementComponent implements OnInit {
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  editServiceManagement = false;
  addServiceManagement = false;
  deleteServiceManagement = false;
  dataList: any[];
  selectedRow: any = {ID: null, CompanyID: null, Name: null, Cost: 0, Price: 0, GSTPercentage: 0, GSTAmount: 0, GSTType: 'None' };
  showAdd = false;
  gstList: any;
  searchValue : any;
  constructor(private companyService: CompanyService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private route: ActivatedRoute,
              private spinner: NgxSpinnerService,
              private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    this.spinner.show();
    this.getList();
    this.getGstList();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ServiceManagement') {
             this.editServiceManagement = element.Edit;
             this.addServiceManagement = element.Add;
             this.deleteServiceManagement = element.Delete;
           }
         });
  }

  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => { 
      this.gstList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  onKeydown(event) {
    console.log(event);
  }
  getList() {
    this.companyService.getShortListByCompany('ServiceMaster', 1).subscribe(data => {
      this.dataList = data.result;
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();

      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  setValues() {

    this.dataList.forEach(element => {
      if (element.ID === this.selectedRow.ID) {
        this.selectedRow.Price = element.Price;
        this.selectedRow.Cost = element.Cost;
        this.selectedRow.Description = element.Description;
        this.selectedRow.GSTAmount = element.GSTAmount;
        this.selectedRow.GSTPercentage = element.GSTPercentage;
        this.selectedRow.GSTType = element.GSTType;
        this.selectedRow.TotalAmount = element.TotalAmount;
}
    });
  }

calculate(fieldName, mode){

  switch (mode) {
    case 'chgst':
      if (fieldName === 'GSTPercentage') {
        this.selectedRow.GSTAmount =
          +this.selectedRow.Price * +this.selectedRow.GSTPercentage / 100;
      }
      if (fieldName === 'GSTAmount') {
        this.selectedRow.GSTPercentage =
          100 * +this.selectedRow.GSTAmount / (+this.selectedRow.Price);
      }
      break;

      case 'chtotal':
        this.selectedRow.TotalAmount = +this.selectedRow.GSTAmount + +this.selectedRow.Price;
        break;

        case 'chgst1':
        this.selectedRow.TotalAmount = +this.selectedRow.GSTAmount + +this.selectedRow.Price;
        break;
  }

}


  resetData(){
    this.selectedRow = {ID: null, CompanyID: null, Name: null, Cost: 0, Price: 0, GSTPercentage: 0, GSTAmount: 0, GSTType: "None" };
  }

  saveData() {
    let count = 0;
    if (this.selectedRow.Name !== null && this.selectedRow.Name !== undefined){
    this.dataList.forEach(element => {
      if (element.Name.toLowerCase() === this.selectedRow.Name.toLowerCase() ){count = count + 1; }

    });
  }
    if (count !== 0 || this.selectedRow.Name === '' || this.selectedRow.Name === null){
      // alert ("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
     }
    else {
      this.companyService.saveData('ServiceMaster', this.selectedRow).subscribe(data => {
        this.getList();
        this.showNotification(
          'bg-green',
          'Data Loaded successfully',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }
  }

  deleteData() {
    this.companyService.deleteData('ServiceMaster',this.selectedRow.ID).subscribe(data => {
      this.selectedRow = {ID: null, CompanyID: null, Name: null, Cost: 0, Price: 0, GSTPercentage: 0, GSTAmount: 0, GSTType: "None" };
      this.getList();
      this.showNotification(
        'bg-red',
        'Data Deleted',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}


