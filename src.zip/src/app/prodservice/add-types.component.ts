import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSelect } from '@angular/material/select';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-add-types',
  templateUrl: './add-types.component.html'
})
export class AddTypesComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

specList: any = [
{ SpecID : 33, ProductName : "Frame", CompanyID : 1, FieldName : "Company", Seq : "1", FieldType : "DropDown", Ref : "0", SptTableName : "Company1707741"},
{ SpecID : 34, ProductName : "Frame", CompanyID : 1, FieldName : "Model", Seq : "2", FieldType : "DropDown", Ref : "Company", SptTableName : "Model5984511"},
];

@ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;


  
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));

selectedProduct: any;
searchValue:any;
prodList: any[];
showAdd = false;
showFeild = false;
newProduct = {Name: "", HSNCode: ""};
fieldType: any[] = [{ID: 1, Name: "DropDown"}, {ID: 2, Name: "Text"}, {ID: 3, Name: "boolean"}];
data1: any = { ID : null, CompanyID : null,  Name:'', Category : null,
 Status : 1, CreatedBy: null, UpdatedBy: null,
};
  newDepartment = {ID: null, CompanyID: null, Name: "", TableName:null,   Status: 1};

  depList: any;
  selectedDepartmentHead: any;
  selectedDepartment: any;
  
productType = [
  {Name: 'Fitting Type',value:'LensType'},
  {Name: 'Reference By',value:'ReferenceBy'},
  {Name: 'Doctor Type',value:'DoctorType'},
  {Name: 'PaymentMode Type',value:'PaymentModeType'},
  {Name: 'Tax Type',value:'TaxType'},
  {Name: 'Tray No',value:'TrayNo'},
  {Name: 'Gender',value:'Gender'},
  {Name: 'Customer Category',value:'CustomerCategory'},
  {Name: 'Location Master',value:'LocationMaster'},
  {Name: 'Other',value:'Other'},




]

constructor(private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
            private spinner: NgxSpinnerService,
            private snackBar: MatSnackBar,
) {}

  ngOnInit() {
  
  }







  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  displayAddField(i){
    this.specList[i].DisplayAdd = 1;
    this.specList[i].SelectedValue = '';
  }
  keyFunc(){
    alert('hiiiii');
  }

  saveFieldData(i){
    this.specList[i].DisplayAdd = 0;
    let count = 0;
    this.specList[i].SptTableData.forEach(element => {
      if (element.TableValue.toLowerCase() === this.specList[i].SelectedValue.toLowerCase() ){count = count + 1; }

    });
    if (count !== 0 || this.specList[i].SelectedValue === ''){
      //  alert ("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
       } else {
    const Ref = this.specList[i].Ref;
    let RefValue = 0;
    if (Ref !== 0){
      this.specList.forEach((element, j)  => {
        if (element.FieldName === Ref){ RefValue = element.SelectedValue; }
      });
    }

    this.companyService.saveProductSupportData( this.specList[i].SelectedValue, RefValue, this.specList[i].SptTableName )
    .subscribe(data => {
      this.companyService.getProductSupportData(this.specList[i].SptTableName, RefValue).subscribe(data1 => {
        this.specList[i].SptTableData = data1.result;
        this.specList[i].SptFilterData = data1.result;
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  }

  

  filterMyOptions(event, i){
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  

  showNotification(colorName, text, placementFrom, placementAlign) {
    this.snackBar.open(text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName
    });
  }
  getfieldList(){
    this.spinner.show();
    if (this.selectedProduct !== null || this.selectedProduct !== '' ){

      this.showFeild = true;
    this.companyService.getSupportMasterList(this.selectedProduct).subscribe(data => {
      this.depList = data.result;
     
      this.spinner.hide();

   
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    }
  }


  showData(){
    this.depList.forEach(element => {
      if (element.Name === this.selectedDepartment) {this.selectedDepartmentHead = element.DepartmentHead; this.selectedDepartment = element.ID; }
    });
  }

  getDepartmentList(){
    this.companyService.getShortListByCompany('SupportMaster', 1).subscribe(data => {
        this.depList = data.result;
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }

  delSupport() {
    if (this.data1.Category === null) {
      alert("please select value");
    } else {
       this.depList.forEach(element => {
        if (element.Name === this.data1.Category) {
          this.companyService.deleteData('SupportMaster', element.ID).subscribe(data1 => {
            this.showNotification(
              'bg-red',
              'Data Deleted',
              'top',
              'right'
            );
            this.getfieldList();
            
          }, (err) => { console.log(err);
                        this.spinner.hide();
                        this.showNotification(
                          'bg-red',
                          'Data Not Saved.',
                          'top',
                          'right'
                        );
          });
        }
      });

    }
    console.log(this.data1.Category, this.selectedProduct);
  }

  saveDepartment(){
    let count = 0;
    this.depList.forEach(element => {
      if (element.Name.toLowerCase() === this.newDepartment.Name.toLowerCase() ){count = count + 1; }

    });
    if (count === 0 && this.newDepartment.Name !== ''){
      this.data1.CompanyID = this.loggedInCompany.ID;
      this.newDepartment.TableName = this.selectedProduct;
      this.companyService.saveData('SupportMaster', this.newDepartment).subscribe(data => {
        this.newDepartment.Name = "";
        // this.getfieldList();
        this.companyService.getSupportMasterList(this.selectedProduct).subscribe(data => {
          this.depList = data.result;
       this.data1.Category = this.depList[0].Name;
          }, (err) => { console.log(err);   });
        }, (err) => { console.log(err);
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
    }else { 
      // alert ("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
    this.newDepartment.Name = ""; }
  }

  
  onSubmit() {
      this.spinner.show();
      this.data1.CompanyID = this.loggedInCompany.ID;
      this.data1.TableName = this.selectedProduct;
      this.companyService.saveData('SupportMaster', this.data1).subscribe(data1 => {
        this.data1.ID = data1.result.insertId;
      }, (err) => { console.log(err);
                    this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Data Not Saved.',
                      'top',
                      'right'
                    );
      });
  }
}

