import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSelect } from '@angular/material/select';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-product-manage',
  templateUrl: './product-manage.component.html'
})
export class ProductManageComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

specList: any = [
{ SpecID : 33, ProductName : "Frame", CompanyID : 1, FieldName : "Company", Seq : "1", FieldType : "DropDown", Ref : "0", SptTableName : "Company1707741"},
{ SpecID : 34, ProductName : "Frame", CompanyID : 1, FieldName : "Model", Seq : "2", FieldType : "DropDown", Ref : "Company", SptTableName : "Model5984511"},
];

@ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
selectedProduct: any;
EnteredValue:any;
searchValue:any;
prodList: any[];
showAdd = false;
newProduct = {Name: "", HSNCode: ""};
fieldType: any[] = [{ID: 1, Name: "DropDown"}, {ID: 2, Name: "Text"}, {ID: 3, Name: "boolean"}];

constructor(private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
            private spinner: NgxSpinnerService,
            private snackBar: MatSnackBar,
) {}

  ngOnInit() {
    this.spinner.show();
    this.getProductList();
  }


  getProductList(){
    this.companyService.getShortListByCompanyOrderBy('Product', 1).subscribe(data => {
        this.prodList = data.result;
        this.spinner.hide();

      }, (err) => { console.log(err);
                   this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }


  getfieldList(){
    if (this.selectedProduct !== null || this.selectedProduct !== '' ){
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString() ) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
         
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });
   
  }

  displayAddField(i){
    this.specList[i].DisplayAdd = 1;
    this.specList[i].SelectedValue = '';
  }
  keyFunc(){
    alert('hiiiii');
  }

  saveFieldData(i){
   
    this.specList[i].DisplayAdd = 0;
    let count = 0;
    this.specList[i].SptTableData.forEach(element => {
      if (element.TableValue.toLowerCase() === this.specList[i].SelectedValue.toLowerCase() ){count = count + 1; }
    });
    if (count !== 0 || this.specList[i].SelectedValue === ''){
      //  alert ("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
       } else {
    const Ref = this.specList[i].Ref;
    let RefValue = 0;
    if (Ref !== 0){
      this.specList.forEach((element, j)  => {
        if (element.FieldName === Ref){ RefValue = element.SelectedValue; }
      });
    }

    this.companyService.saveProductSupportData( this.specList[i].SelectedValue, RefValue, this.specList[i].SptTableName )
    .subscribe(data => {
      
      this.companyService.getProductSupportData(this.specList[i].SptTableName, RefValue).subscribe(data1 => {
        this.specList[i].SptTableData = data1.result;
        this.specList[i].SptFilterData = data1.result;
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }
 
  }

  

  filterMyOptions(event, i){
    if (!this.specList[i].SptTableData) {
      return;
    }
    // get the search keyword
    let search = event.target.value;

    search = search.toLowerCase();

    this.specList[i].sptFilterData = this.specList[i].SptTableData.filter(
      element => element.TableValue.toLowerCase().includes(search));
  }

  onSubmit(){}

  showNotification(colorName, text, placementFrom, placementAlign) {
    this.snackBar.open(text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  deleteSpecValue(value, selectedValue, i) {
    if (selectedValue === "") {
      Swal.fire({
        icon: 'error',
        title: 'please select value',
        text: '',
        footer: ''
      });
    } else {
      value.SptFilterData.forEach(element => {
        if (element.TableValue === selectedValue) {
          console.log(element, 'element');
          this.companyService.deleteData('SpecSptTable', element.ID).subscribe(data1 => {
            this.showNotification(
              'bg-red',
              'deleted',
              'top',
              'right'
            ); 
            this.companyService.getProductSupportData(this.specList[i].SptTableName, value.Ref).subscribe(data1 => {
              this.specList[i].SptTableData = data1.result;
              this.specList[i].SptFilterData = data1.result;
            }, (err) => {
              console.log(err);
              this.showNotification(
                'bg-red',
                'Error Loading Data.',
                'top',
                'right'
              );
            });
          }, (err) => {
            console.log(err);
            this.showNotification(
              'bg-red',
              'Error Loading Data.',
              'top',
              'right'
            );
          });
        }
        
      });
    }
  }

}
