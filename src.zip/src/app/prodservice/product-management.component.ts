import { Component, OnInit } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html'
})
export class ProductManagementComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  editManageProduct = false;
  addManageProduct = false;
  deleteManageProduct = false;

productList: any[];
specList: any;
gstList: any;

newSpec: any = {ID : null, ProductName: '', Name : '', Seq: null,  Type: '', Ref: 0, SptTableName: '', Required: false  };
selectedProduct: any = '';
selectedHSNCode: any = '';
selectedGSTPercentage: any = 0;
selectedGSTType: any = '';
prodList: any[];
showAdd = false;
newProduct = {Name: "", HSNCode: "", GSTPercentage: 0, GSTType: "None"};
fieldType: any[] = [{ID: 1, Name: "DropDown"}, {ID: 2, Name: "Text"}, {ID: 3, Name: "boolean"} , {ID: 4, Name: "Date"}];
  selectedProductID: any;
  searchValue:any;

constructor(private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
            private spinner: NgxSpinnerService,
            private snackBar: MatSnackBar
) {}

  ngOnInit() {
    this.spinner.show();
    this.getGstList();
    this.getProductList();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ManageProduct') {
             this.editManageProduct = element.Edit;
             this.addManageProduct = element.Add;
             this.deleteManageProduct = element.Delete;
           }
         });
  }

  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => { 
      this.gstList = data.result;
    }, (err) => {
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getProductList(){
    this.companyService.getShortListByCompany('Product',1).subscribe(data => {
        this.prodList = data.result;
        this.spinner.hide();

      }, (err) => { console.log(err);
        this.spinner.hide();

                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }


  getfieldList(){

    this.prodList.forEach(element => {
      if (element.Name === this.selectedProduct) {
        this.selectedHSNCode = element.HSNCode; 
        this.selectedGSTPercentage = element.GSTPercentage; 
        this.selectedGSTType = element.GSTType; 
        this.selectedProductID = element.ID; 
      }
    });

    if (this.selectedProduct !== null || this.selectedProduct !== '' ){
    this.companyService.getDataByName('ProductSpec', this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    }
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  saveSpec(){
    this.spinner.show();

    let count = 0;
    this.specList.forEach(element => {
      if (element.Name.toLowerCase() === this.newSpec.Name.toLowerCase() ){
        count = count + 1; 
      }

    });

    if (count === 0 && this.newSpec.Name !== '' && this.newSpec.Type !== ''){
    this.newSpec.ProductName = this.selectedProduct;
    if (this.newSpec.Type === 'DropDown' && this.newSpec.SptTableName === ''){
        this.newSpec.SptTableName = this.newSpec.Name + Math.floor(Math.random() * 999999) + 1 ;
    }

    let specData = this.newSpec;
    this.newSpec = {ID : null, ProductName: '', Name : '', Seq: null,  Type: '', Ref: 0, SptTableName: '', Required: false  };

    this.companyService.saveData('ProductSpec', specData).subscribe(data => {

      this.getfieldList();
    

      this.spinner.hide();

      }, (err) => { console.log(err);
        this.spinner.hide();

                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    } else {
      this.spinner.hide();

      // alert('Can not Save. Missing required fields');
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: ' Fill all Required Fields ',
        footer: ''
      });
     }

  }

  checkDuplicateProduct() {
    this.prodList.forEach(element => {
      if (element.Name.toLowerCase() === this.newProduct.Name.toLowerCase() ){
        Swal.fire({
          icon: 'error',
          title: 'Duplicate or Empty Values are not allowed',
          text: '',
          footer: ''
        });
      }

    });
  }

  saveProduct(){
    let count = 0;
    this.prodList.forEach(element => {
      if (element.Name.toLowerCase() === this.newProduct.Name.toLowerCase().trim()){count = count + 1; }
    });
    if (count === 0 && this.newProduct.Name !== ''){
      this.companyService.saveData('Product', this.newProduct).subscribe(data => {
        this.companyService.getShortListByCompany('Product',1).subscribe(data => {
          this.prodList = data.result;
          this.selectedProduct = this.prodList[0].Name;
          this.selectedHSNCode = this.prodList[0].HSNCode;  
          this.selectedGSTPercentage = this.prodList[0].GSTPercentage;  
          this.selectedGSTType = this.prodList[0].GSTType;  
          if (this.selectedProduct !== null || this.selectedProduct !== '' ){
            this.companyService.getDataByName('ProductSpec', this.selectedProduct).subscribe(data => {
              this.specList = data.result;
              }, (err) => { console.log(err);
                            this.showNotification(
                              'bg-red',
                              'Error Loading Data.',
                              'top',
                              'right'
                            );
              });
            }
        }, (err) => { console.log(err);});
        this.newProduct.Name = "";
        this.newProduct.HSNCode = "";
        this.newProduct.GSTPercentage = 0;
        this.newProduct.GSTType = "None";
        
        }, (err) => { console.log(err);
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
  this.newProduct.Name = ""; }
  }

  deleteProductType(){
    if (this.specList.length === 0 ) {
      this.companyService.deleteData('Product', this.selectedProductID).subscribe(data => {
        this.newProduct.HSNCode = "";
        this.selectedHSNCode = "";
        this.selectedGSTPercentage = 0;
        this.selectedGSTType = "None";
        this.getProductList();
        }, (err) => { console.log(err);
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'ERROR',
        text: 'First delete related Feild',
        footer: ''
      }); 
    }

   
  }

 

  generateTableName(){
    if (this.newSpec.Type === 'DropDown'){
    if (this.newSpec.SptTableName !== '' || this.newSpec.SptTableName !== null) {
      this.newSpec.SptTableName = this.newSpec.Name + Math.floor(Math.random() * 1000) + 1 ;
    }
  }
  }

  onSubmit() {
    // this.adminService.saveData('Company', this.data).subscribe(data => {
    //   if (this.id === 0){
    //     this.data1.CompanyID = data.insertId; }
    //   this.data1.UserGroup = 'CompanyAdmin';
    //   this.adminService.saveData('User', this.data1).subscribe(data1 => {
    //   }, (err) => { console.log(err);
    //                 this.showFailure(err, 'Error Loading Data.');
    //   });
    // }, (err) => { console.log(err);
    //               this.showFailure(err, 'Error Loading Data.');
    // });
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('ProductSpec', this.specList[i].ID).subscribe(data => {
          this.specList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  // deleteItem(i){
  //   this.companyService.deleteData('ProductSpec', this.specList[i].ID).subscribe(data => {
  //   this.specList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  //   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
