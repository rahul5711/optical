import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../services/login.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CompanyService } from '../services/company.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-doctor-login',
  templateUrl: './doctor-login.component.html'
})
export class DoctorLoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  returnUrl: string;
  hide = true;
  constructor(private router: Router,
              private snackBar: MatSnackBar,
              private formBuilder: FormBuilder,
              private route: ActivatedRoute,
              private spinner: NgxSpinnerService,
              private companyService: CompanyService,
              private loginService: LoginService) { }

  loginUser: any = { userEmail: '', userPassword: '' };
  loggedInUser: any;
  shopList: any;
  selectedShop: any;


  ngOnInit() {
    localStorage.removeItem('LoggedINUser');
    this.loginForm = this.formBuilder.group({
      username: [''],
      password: ['']
    });
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
  }
  get f() {
    return this.loginForm.controls;
  }

  validateDoctor() {
    this.spinner.show();

    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      this.spinner.hide();
      return;
    } else {

      this.loginService.validateDoctor(this.loginUser)
        .subscribe((data: any) => {
          console.log(data);
          if (data.loginUser) {
            this.spinner.hide();
            localStorage.setItem('LoggedINUser', JSON.stringify(data.loginUser));
            localStorage.setItem('LoggedINCompany', JSON.stringify(data.userCompany));
            window.localStorage.setItem('isLoggedIn', 'true');
            this.router.navigate(['/admin/adminDashboard']);
            this.showNotification(
              'bg-green',
              data.loginUser.Name,
              'Log in successfully',
              'top',
              'right'
            );
          } else {
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Login failed !',
              'Username or Password mismatch.',
              'top',
              'right'
            );

          }
        },
          (err) => {
            // console.log(err);
            this.router.navigate(['/']);
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Login failed !',
              'Please contact Administrator',
              'top',
              'right'
            );
          });
    }
  }

  getShopList() {
    this.companyService.geListByOtherID('UserShop', JSON.parse(localStorage.getItem('LoggedINUser')).ID).subscribe(res => {
      this.shopList = res.result;
    }, (err) => {
      console.log(err);
    });
  }

  saveSelectedShop() {
    this.shopList.forEach(element => {
      if (element.ID === this.selectedShop) {
        localStorage.setItem('LoggedINShop', JSON.stringify(element));
        this.router.navigate(['/admin/companyDashboard']);
      }
    });
  }
  showNotification(colorName, Username, text, placementFrom, placementAlign) {
    this.snackBar.open(Username + ' ' + text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName
    });
  }

}
