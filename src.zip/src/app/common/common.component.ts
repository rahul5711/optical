import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { CompanyService } from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { DataStorageService } from '../services/data-storage.service';
const document: any = window.document;


@Component({
  selector: 'app-common',
  templateUrl: './common.component.html',
  styleUrls: ['./common.component.css']
})

export class CommonComponent implements OnInit {
  items: any[];
 
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = localStorage.getItem('LoggedINCompany');
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  // permission = this.dataStorageService.permission;
  permission = JSON.parse(localStorage.getItem('Permission'));


  viewCompanyInfo = true; viewEmployee = true; viewEmployeeList = true; viewNewShop = true; viewShopList = true; viewRolePermission = true; viewCompanySetting: any = true;
  viewProductType = true; viewManageProducts = true; viewServiceManagement = true; viewSupplier = true; viewSupplierList = true; viewPurchaseList = true;
  viewPurchase = true; viewTransferProduct = true; viewPreOrderProduct = true; viewPreOrderHistory = true;
  viewCustomerList = true; viewNewCustomer = true; viewDoctorManagement = true; viewDoctorList = true; viewBillingList = true;
  viewBilling = true; viewPaymentList = true; viewPayment = true; viewReceivableList = true; viewReceive = true;
  viewInventory = true; viewSale = true; viewAccounting = true; viewCustomer = true;
  viewFitterList = true; viewFitter = true; viewDepartmentManagement = true; viewLoginHistory = true;
  viewChargeManagement = true; viewAddManagement = true;viewPurchaseReturn = true; viewPurchaseConvert = true;
  viewProductInventory = true; viewSearchBarcode = true;viewFitterInvoice = true; viewFitterInvoiceList = true;
  viewCashRegister = true; viewPayrollList = true; viewPayroll = true; viewExpenseList = true; viewExpense = true;
  viewCashCollectionReport = true; viewSaleDetails= true; viewSalePaymentReport= true; viewSaleProfitReport= true; viewPurchaseReport=true;viewEyeReport=true;viewTransferReport=true;viewExpiryReport =true;viewServiceReport=true;viewReminderReport=true;viewProductSummaryReport=true;viewLaserReport=true; viewExpenseReport=true;viewPettyCashReport=true;viewCashCounterReport=true;


 
  constructor(private router: Router, private dataStorageService: DataStorageService,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute, private companyService: CompanyService) {
  }


  shopList: any;
  selectedShop: any;
  dispaly= false;

  ngOnInit() {
    console.log('commonnnn');
    if (localStorage.getItem("LoggedINShop") !== null && this.loggedInUser.UserGroup === 'Employee') {
      this.loggedInShop = JSON.parse(localStorage.getItem("LoggedINShop"));

    }
    // this.callFullscreen();
    if (this.loggedInUser.UserGroup === 'CompanyAdmin') {
      this.getShopList();
    } else if (this.loggedInUser.UserGroup === 'Employee') {
      this.permission.forEach(element => {
        if (element.ModuleName === 'Supplier') {
          this.viewSupplier = element.MView;
        } else if (element.ModuleName === 'SupplierList') {
          this.viewSupplierList = element.MView;
        } else if (element.ModuleName === 'Purchase') {
          this.viewPurchase = element.MView;
        } else if (element.ModuleName === 'PurchaseList') {
          this.viewPurchaseList = element.MView;
        } else if (element.ModuleName === 'PurchaseReturn') {
          this.viewPurchaseReturn= element.MView;
        } else if (element.ModuleName === 'PurchaseConvert') {
          this.viewPurchaseConvert = element.MView;
        } else if (element.ModuleName === 'TransferProduct') {
          this.viewTransferProduct = element.MView;
        } else if (element.ModuleName === 'PreOrderProduct') {
          this.viewPreOrderProduct = element.MView;
        } else if (element.ModuleName === 'ProductInventory') {
          this.viewProductInventory = element.MView;
        } else if (element.ModuleName === 'PreOrderHistory') {
          this.viewPreOrderHistory = element.MView;
        } else if (element.ModuleName === 'SearchBarcode') {
          this.viewSearchBarcode = element.MView;
        } else if (element.ModuleName === 'Fitter') {
          this.viewFitter = element.MView;
        } else if (element.ModuleName === 'FitterList') {
          this.viewFitterList = element.MView;
        } else if (element.ModuleName === 'FitterInvoice') {
          this.viewFitterInvoice = element.MView;
        } else if (element.ModuleName === 'FitterInvoiceList') {
          this.viewFitterInvoiceList = element.MView;
        } else if (element.ModuleName === 'CompanyInfo') {
          this.viewCompanyInfo = element.MView;
        } else if (element.ModuleName === 'Employee') {
          this.viewEmployee = element.MView;
        } else if (element.ModuleName === 'EmployeeList') {
          this.viewEmployeeList = element.MView;
        } else if (element.ModuleName === 'Shop') {
          this.viewNewShop = element.MView;
        } else if (element.ModuleName === 'ShopList') {
          this.viewShopList = element.MView;
        } else if (element.ModuleName === 'RolePermission') {
          this.viewRolePermission = element.MView;
        } else if (element.ModuleName === "CompanySetting") {
          this.viewCompanySetting = element.MView;
        }else if (element.ModuleName === "DepartmentManagement") {
          this.viewDepartmentManagement = element.MView;
        } else if (element.ModuleName === "LoginHistory") {
          this.viewLoginHistory = element.MView;
        } else if (element.ModuleName === 'ProductType') {
          this.viewProductType = element.MView;
        } else if (element.ModuleName === 'ManageProduct') {
          this.viewManageProducts = element.MView;
        } else if (element.ModuleName === 'ServiceManagement') {
          this.viewServiceManagement = element.MView;
        } else if (element.ModuleName === 'ChargeManagement') {
          this.viewChargeManagement = element.MView;
        } else if (element.ModuleName === 'AddManagement') {
          this.viewAddManagement = element.MView;
        } else if (element.ModuleName === 'CustomerList') {
          this.viewCustomerList = element.MView;
        } else if (element.ModuleName === 'NewCustomer') {
          this.viewNewCustomer = element.MView;
        } else if (element.ModuleName === 'DoctorManagement') {
          this.viewDoctorManagement = element.MView;
        } else if (element.ModuleName === 'DoctorList') {
          this.viewDoctorList = element.MView;
        } else if (element.ModuleName === 'BillingList') {
          this.viewBillingList = element.MView;
        } else if (element.ModuleName === 'Billing') {
          this.viewBilling = element.MView;
        } else if (element.ModuleName === 'CashRegister') {
          this.viewCashRegister = element.MView;
        } else if (element.ModuleName === 'PaymentList') {
          this.viewPaymentList = element.MView;
        } else if (element.ModuleName === 'Payment') {
          this.viewPayment = element.MView;
        } else if (element.ModuleName === 'ReceivableList') {
          this.viewReceivableList = element.MView;
        } else if (element.ModuleName === 'Receive') {
          this.viewReceive = element.MView;
        }  else if (element.ModuleName === 'PayrollList') {
          this.viewPayrollList = element.MView;
        } else if (element.ModuleName === 'Payroll') {
          this.viewPayroll = element.MView;
        } else if (element.ModuleName === 'ExpenseList') {
          this.viewExpenseList = element.MView;
        } else if (element.ModuleName === 'Expense') {
          this.viewExpense = element.MView;
        } else if (element.ModuleName === 'InventoryReport') {
          this.viewInventory = element.MView;
        } else if (element.ModuleName === 'SaleReport') {
          this.viewSale = element.MView;
        } else if (element.ModuleName === 'SalePaymentReport') {
          this.viewSalePaymentReport = element.MView;
        } else if (element.ModuleName === 'SaleProfitReport') {
          this.viewSaleProfitReport = element.MView;
        } else if (element.ModuleName === 'SaleDetailsReport') {
          this.viewSaleDetails = element.MView;
        } else if (element.ModuleName === 'PurchaseReport') {
          this.viewPurchaseReport = element.MView;
        } else if (element.ModuleName === 'EyeReport') {
          this.viewEyeReport = element.MView;
        } else if (element.ModuleName === 'TransferReport') {
          this.viewTransferReport = element.MView;
        }else if (element.ModuleName === 'ExpiryReport') {
          this.viewExpiryReport = element.MView;
        }else if (element.ModuleName === 'ServiceReport') {
          this.viewServiceReport = element.MView;
        }else if (element.ModuleName === 'ReminderReport') {
          this.viewReminderReport = element.MView;
        }else if (element.ModuleName === 'LaserRrport') {
          this.viewLaserReport = element.MView;
        }
        else if (element.ModuleName === 'ProductSummaryReport') {
          this.viewProductSummaryReport = element.MView;
        }else if (element.ModuleName === 'AccountingReport') {
          this.viewAccounting = element.MView;
        } else if (element.ModuleName === 'CustomerReport') {
          this.viewCustomer = element.MView;
        } else if (element.ModuleName === 'CashCollectionReport') {
          this.viewCashCollectionReport = element.MView;
        } else if (element.ModuleName === 'ExpenseReport') {
          this.viewExpenseReport = element.MView;
        } else if (element.ModuleName === 'PettyCashReport') {
          this.viewPettyCashReport = element.MView;
        } else if (element.ModuleName === 'CashCounterReport') {
          this.viewCashCounterReport = element.MView;
        }
      });
    }

  }



  newShop() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      const shopList = data.result;
      if (shopList.length >= JSON.parse(this.loggedInCompany).NoOfShops) {
        alert("New Shop Can not be added as your plan does not allow");
      } else {
        this.router.navigate(['/admin/shop/0']);
      }
    }, (err) => {
      console.log(err);
    });
  }

  getShopList() {
    this.companyService.geListByOtherID('UserShop', 0).subscribe(res => {
      this.shopList = res.result;
    
      if (this.shopList.length !== 0) {
        this.spinner.show();
        // localStorage.setItem('LoggedINShop', JSON.stringify(this.shopList[0]));
        // this.loggedInShop = this.shopList[0];
        this.selectedShop = JSON.parse(localStorage.getItem("LoggedINShop"));
        if(this.selectedShop === null ) {
          this.selectedShop = this.shopList[0].ShopID;
          localStorage.setItem('LoggedINShop', JSON.stringify(this.shopList[0]));
          this.spinner.hide();
        } else {
          this.spinner.show();
          this.selectedShop = JSON.parse(localStorage.getItem("LoggedINShop")).ShopID;
          this.spinner.hide();
        }
      } 
      

    }, (err) => {
      console.log(err);
      this.spinner.hide();

    });
  }

  saveSelectedShop() {
    localStorage.removeItem('LoggedINShop');
    this.shopList.forEach(element => {
      if (element.ID === this.selectedShop) {
        localStorage.setItem('LoggedINShop', JSON.stringify(element));
        this.loggedInShop = element;
        this.selectedShop = JSON.parse(localStorage.getItem("LoggedINShop")).ShopID;
        this.router.navigate(['/admin/companyDashboard']);
      }
    });
  }

  myFunction() {
    const x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }

  callFullscreen() {
    if (
      !document.fullscreenElement &&
      !document.mozFullScreenElement &&
      !document.webkitFullscreenElement &&
      !document.msFullscreenElement
    ) {
      if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
      } else if (document.documentElement.msRequestFullscreen) {
        document.documentElement.msRequestFullscreen();
      } else if (document.documentElement.mozRequestFullScreen) {
        document.documentElement.mozRequestFullScreen();
      } else if (document.documentElement.webkitRequestFullscreen) {
        document.documentElement.webkitRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      }
    }
  }

  logout() {
    localStorage.removeItem('LoggedINUser');
    localStorage.removeItem('LoggedINCompany');
    localStorage.removeItem('LoggedINShop');
    window.localStorage.setItem('isLoggedIn', 'false');
    localStorage.clear();
    this.router.navigate(['/login']).then(() => {
      window.location.reload();
    });
    // window.location.reload();
    // location.href = '/';

  }

  userd(){
    this.dispaly = !this.dispaly
  }

  onOpen(event) {
    alert(event);
  }

}
