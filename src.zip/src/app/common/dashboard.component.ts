import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  loggedInUser = localStorage.getItem('LoggedINUser');
  loggedInCompany = localStorage.getItem('LoggedINCompany');
  loggedInShop = localStorage.getItem('LoggedINShop');
  constructor() { }

  ngOnInit() {

    
  }

}
