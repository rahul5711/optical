import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../services/login.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CompanyService } from '../services/company.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import {DataStorageService} from "../services/data-storage.service"


@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  loggedInUser = localStorage.getItem('LoggedINUser');
  loggedInCompany = localStorage.getItem('LoggedINCompany');
  loggedInShop = localStorage.getItem('LoggedINShop');
  constructor(private router: Router,
    private snackBar: MatSnackBar,
    private formBuilder: FormBuilder,
    private dataStorageService: DataStorageService,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private companyService: CompanyService,
    private loginService: LoginService){ }

  ngOnInit() {

  
  }

}
