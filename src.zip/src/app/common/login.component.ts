import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../services/login.service';
import { AdminService} from '../services/admin.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CompanyService } from '../services/company.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import {DataStorageService} from "../services/data-storage.service";
import { environment } from '../../environments/environment';
import {DomSanitizer} from '@angular/platform-browser';
import * as moment from 'moment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  returnUrl: string;
  hide = true;
  stringUrl: string;
  env = environment;
  firstImage: any;
  secondImage: any;
  thirdImage: any;
  forthImage: any;
  newsList: any;
  Facebook: any;
  Facebook1: any;
  Instagram: any;
  linkedin: any;
  Google: any;
  dataList: any;
  fData: any;
  todayDate: any;
  label = "password"
  constructor(private router: Router,
              private snackBar: MatSnackBar,
              private sanitizer: DomSanitizer,
              private formBuilder: FormBuilder,
              private dataStorageService: DataStorageService,
              private route: ActivatedRoute,
              private spinner: NgxSpinnerService,
              private companyService: CompanyService,
              private adminService: AdminService,
              private loginService: LoginService) { }

  loginUser: any = { userEmail: '', userPassword: '', ipAddress: '' };
  forgetPassword = '';
  loggedInUser: any;
  shopList: any;
  selectedShop: any;
  roleList = [];
  moduleList: any = [
    {ModuleName: 'CompanyInfo', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Employee', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'EmployeeList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Shop', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ShopList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'RolePermission', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CompanySetting', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'DepartmentManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'LoginHistory', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ProductType', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ManageProduct', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ServiceManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ChargeManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'AddManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Supplier', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SupplierList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Purchase', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseReturn', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseConvert', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'TransferProduct', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'AcceptTranfer', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PreOrderProduct', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PreOrderHistory', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ProductInventory', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SearchBarcode', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Fitter', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'FitterList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'FitterInvoice', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'FitterInvoiceList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'PaymentList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'Payment', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'ReceivableList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'Receivable', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'NewCustomer', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CustomerList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Billing', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'BillingList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'DoctorManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'DoctorList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CashRegister', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Payment', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PaymentList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Payroll', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PayrollList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Expense', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ExpenseList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'InventoryReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SaleReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SalePaymentReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SaleProfitReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'AccountingReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CustomerReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CashCollectionReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'LaserReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ReminderReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ServiceReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ExpiryReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'TransferReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'EyeReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SaleDetailsReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ProductSummaryReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ExpenseReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PettyCashReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CashCounterReport', MView: true, Edit: true, Add: true, View: true, Delete: true},



  ];

  ngOnInit() {
    this.spinner.show();
    localStorage.removeItem('LoggedINUser');
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
      
    });
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
    this.getNews();
 

    this.getImageList();
    

    this.getSocialLink();
    this.spinner.hide();
  }
  get f() {
    return this.loginForm.controls;
  }

  showPassword() {
    if (this.label === "password") {
      this.label = "text"
    } else {
      this.label = "password"
      
    }
  }

  validateUser() {
    this.spinner.show();
    this.forgetPassword = '';
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      this.spinner.hide();
      return;
    } else {
      // this.loginService.getIPAddress().subscribe((res:any)=>{  
        this.loginUser.ipAddress = '**********'; 
        this.loginService.validateUser(this.loginUser)
        .subscribe((data: any) => {
          if (data.loginUser && data.loginCode === 1) {
            this.spinner.hide();
            localStorage.setItem('LoggedINUser', JSON.stringify(data.loginUser));
           
            window.localStorage.setItem('isLoggedIn', 'true');
            this.showNotification(
              'bg-green',
              data.loginUser.Name,
              'Log in successfully',
              'bottom',
              'right'
            );
            if (data.loginUser.UserGroup === 'SuperAdmin') {
              this.router.navigate(['/admin/adminDashboard']);
            } else if (data.loginUser.UserGroup === 'CompanyAdmin') {
              let d = Number(moment(new Date()).diff(data.userCompany.CancellationDate, 'days').toString().substring(1));
                if(new Date() > new Date(data.userCompany.EffectiveDate) && new Date() <= new Date(data.userCompany.CancellationDate) && d >= 1) {
                  localStorage.setItem('LoggedINCompany', JSON.stringify(data.userCompany));
                  localStorage.setItem('LoggedINCompanySetting', JSON.stringify(data.companySetting));
                  localStorage.setItem('Permission', JSON.stringify(this.moduleList));
                  this.dataStorageService.permission = this.moduleList;
                  if( d <= 10 || d <= 1) {
                    alert("Your key will expire in next " + d + " days");
                    this.router.navigate(['/admin/companyDashboard']);
                  }else if(d >= 1) {
                    this.router.navigate(['/admin/companyDashboard']);
  
                  } 
                }  else {
                  alert("Your plan expired, Please contact us");
                }
               

              } else if (data.loginUser.UserGroup === 'Employee') {
                let d = Number(moment(new Date()).diff(data.userCompany.CancellationDate, 'days').toString().substring(1));
                let  per = false;
                if(new Date() > new Date(data.userCompany.EffectiveDate) && new Date() <= new Date(data.userCompany.CancellationDate) && d >= 1) {
                  
                  if( d <= 10 || d <= 1) {
                    per = true;
                    alert("Your key will expire in next " + d + " days");
                  }else if(d >= 1) {
                    per = true;
                  } 
                }  else {
                  per = false;
                  alert("Your plan expired, Please contact us");
                }
                if(per === true) {
                  localStorage.setItem('LoggedINCompany', JSON.stringify(data.userCompany));
                  localStorage.setItem('LoggedINCompanySetting', JSON.stringify(data.companySetting));
                  this.hide = false;
                  this.getShopList();
                  this.getRoleList();
                }

                }

          } else if (data.loginCode === 0) {
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Login failed !',
              'User not Valid login time',
              'top',
              'right'
            );
            this.router.navigate(['']);
          } else {
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Login failed !',
              'Username or Password mismatch.',
              'top',
              'right'
            );

          }
        },
          (err) => {
            // console.log(err);
            this.router.navigate(['/']);
            this.spinner.hide();
            this.showNotification(
              'bg-red',
              'Login failed !',
              'Please contact Administrator',
              'top',
              'right'
            );
          }); 
      // });  
    }
  }
 

  getShopList() {
    this.companyService.geListByOtherID('UserShop', JSON.parse(localStorage.getItem('LoggedINUser')).ID).subscribe(res => {
      this.shopList = res.result;
    }, (err) => {
      console.log(err);
    });
  }

  getRoleList() {
    this.companyService.getShortListByCompany('Role',1).subscribe(data => {
      this.roleList = data.result;
      this.spinner.hide();
      console.log(data.result, 'rolelist');
    }, (err) => {
      console.log(err);
    });
  }

  saveSelectedShop() {
    this.shopList.forEach(element => {
      if (element.ID === this.selectedShop) {
        localStorage.setItem('LoggedINShop', JSON.stringify(element));
        // localStorage.setItem('Permission', element.Permission);
        // this.dataStorageService.permission = JSON.parse(element.Permission);
        this.setPermission(element.RoleID);
        this.router.navigate(['/admin/companyDashboard']);
      }
    });
  }

  setPermission(RoleID) {
    this.roleList.forEach(element => {
      if (element.ID === RoleID) {
       localStorage.setItem('Permission', element.Permission);
        this.dataStorageService.permission = JSON.parse(element.Permission);
      }
    });
  }

  getNews() {
    this.adminService.getSupportList('SupportMaster','News').subscribe(data => {
      this.newsList = data.result[0];
       }, (err) => { console.log(err);   });
  }

  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
  }

  getImageList() {
    
    this.adminService.getSupportList('SupportMaster','Images').subscribe(data => {
      let images = data.result[0];
      let imageParse = JSON.parse(images.Name);
      this.firstImage = this.sanitize(imageParse.FirstImage);
      this.secondImage = this.sanitize(imageParse.SecondImage);
      this.thirdImage = this.sanitize(imageParse.ThirdImage);
      this.forthImage = this.sanitize(imageParse.ForthImage);
    
      

       }, (err) => { console.log(err);   });
  }

  getSocialLink() {
    this.adminService.getSupportList('SupportMaster','SocialLinks').subscribe(data => {
      let socialLinkList = data.result[0];
      let socialParse = JSON.parse(socialLinkList.Name);
      this.Facebook = socialParse.Facebook;
      this.Facebook1 = socialParse.Facebook1;
      this.Instagram = socialParse.Instagram;
      this.linkedin = socialParse.linkedin;
      this.Google = socialParse.Google;


      // console.log(this.sociaLink , 'tsociaLink');

       }, (err) => { console.log(err);   });
  }

  linkedinLink() {
    window.open(this.linkedin, "_blank");
  }
  facebookLink() {
    window.open(this.Facebook, "_blank");
  }facebook1Link() {
    window.open(this.Facebook1, "_blank");
  }instagramLink() {
    window.open(this.Instagram, "_blank");
  }GoogleLink() {
    window.open(this.Google, "_blank");
  }

  getforgetPassword() {
    let Param = `LoginName = '${this.forgetPassword}'`
    this.adminService.getForgetPassword('User', Param).subscribe(data => {
      this.fData = data.result;
      this.forgetPassword = '';
    if(data.result.length === 0) {
      // this.showNotification(
      //   'bg-red',
      //   'failed !',
      //   'Your email does not exist please contact administrator',
      //   'top',
      //   'right'
      // );
      alert("Your UserName does not exist please contact administrator");
    } else {
      this.adminService.sendEmail(this.fData[0], 'forgetPassword').subscribe(data2 => {
        this.showNotification(
        'bg-green',
        'Success',
        'Password has been sent on your email',
        'top',
        'right'
      );
      }, (err) => { console.log(err);
                    
      });
     
    }

       }, (err) => { console.log(err);   });
  }

  showNotification(colorName, Username, text, placementFrom, placementAlign) {
    this.snackBar.open(Username + ' ' + text, '', {
      duration: 2000,
      verticalPosition: placementFrom,
      horizontalPosition: placementAlign,
      panelClass: colorName
    });
  }
}


