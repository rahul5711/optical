export class Shop {
 
  ID: number;
  CompanyID: number;
  Name: string;
  MobileNo1?: string;
  MobileNo2?: string;
  PhoneNo?: string;
  Address?: string;
  Email?: string;
  Website?: string;
  GSTNo?: string;
  CINNo?: string;
  LogoURL?: any;
  ShopTiming?: string;
  WelcomeNote: string;
  Status: number;
  CreatedBy?: number;
  CreatedOn?: any;
  UpdatedBy?: number;
  UpdatedOn?: any;
}
