import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../../services/company.service';
import * as moment from 'moment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-accounting-report',
  templateUrl: './accounting-report.component.html'
})
export class AccountingReportComponent implements OnInit {
  dtTrigger: Subject<AccountingReportComponent> = new Subject();
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  fileName= 'AccountingExcel.xlsx';

  dtOptions: any = {};
  shopList = [];
  AccountingReportRag: any;
  constructor(private companyService: CompanyService, 
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,) { }

  filter: any =  {date1: moment().startOf('month').format('YYYY-MM-DD'), date2: moment().format('YYYY-MM-DD'), reportType: 0 , shopID: 0};

  dataList =[];
  totalAmount = 0;
  ngOnInit(): void {
    this.permission.forEach(element => {    
      if (element.ModuleName === 'AccountingReport') {
             this.AccountingReportRag = element.Edit;
           }
         });
    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      // pagingType: 'full_numbers',
      pageLength: 200000,
      // colReorder: true,
      dom: 'Bfrtip',
      scrollY:'50vh',
      scrollCollapse: false,
      scrollX: true,
      // Configure the buttons
      buttons: [
        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          messageTop:  'Accounting Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Accounting Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // {
        //   extend: 'excel',
        //   messageTop: 'Accounting Report Generated On ' + moment().format('LLLL') ,
        //   exportOptions: {
        //     columns: ':visible'
        //   },
        //   title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdfHtml5',
          messageTop: 'Accounting Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            columns: ':visible',
            modifier: {
              page: 'visible'
            }
          },
          header: true,
          title: 'Accounting Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        }
      ],
      retrieve: true
    };
    this.spinner.show();

    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }

  searchData() {
    this.spinner.show();

    this.totalAmount = 0;
    if (this.filter.date1 !== null && this.filter.date2 !== null 
       && this.filter.reportType !== '' && this.filter.reportType !== 0 && this.filter.shopID !== ''  && this.filter.shopID !== 0) {
      this.companyService.getGenericListByParem('AccountingReport', JSON.stringify(this.filter)).subscribe(data => {
      
        // let tempArray = [];
        // data.result.forEach(el => {
        //   el.PaymentDate = moment(el.PaymentDate).format(`${this.loggedInCompanySetting.DateFormat}`);
        //   tempArray.push(el);
        // })
        this.dataList = data.result;
        console.log(this.dataList,'vvv')
        this.totalCalculation(this.dataList);
        this.dtTrigger.next();
    this.spinner.hide();

      }, (err) => {
        console.log(err);
    this.spinner.hide();

        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    }
  }

  totalCalculation(data) {
    for (var i = 0; i < data.length; i++) {
      this.totalAmount = this.totalAmount + parseInt(data[i].Amount);
    }
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.filter.shopID = this.shopList[0].ID
      }
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportSup');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
  
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
