import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../../services/company.service';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";
import { NgSwitchCase } from '@angular/common';
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-product-expiry-report',
  templateUrl: './product-expiry-report.component.html',
  styleUrls: ['./product-expiry-report.component.sass']
})
export class ProductExpiryReportComponent implements OnInit {

  dtTrigger: Subject<ProductExpiryReportComponent> = new Subject();
  fileName= 'ProductExpiryReportExcel.xlsx';

  dtOptions: any = {};
  specList: any = [];
  gstdividelist = [];
  sgst = 0;
  cgst = 0;
  searchValue:any;
  EnteredValue:any;

  range: any;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  dataLists = [];
  gstList: any;
  itemList1 = [];
  todaydate: any;
  ExpiryRrportRag: any;
  constructor(private companyService: CompanyService,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,) { }

  filter: any =  {PaymentStatus: 0, ProductCategory:0, date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().format('YYYY-MM-DD'),  ShopID: 0, SupplierID: 0, ProductTypeName: 0, productName:'', GroupBy: '',GSTPercentage:'All',GSTType:'All'};
  filter2: any =  {PaymentStatus: 'All',ProductStatus:'All', date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'),customerID: 'All', ShopID: 0, ProductTypeName: '',  GSTType:'All',FilterTypes:'ProductExpDate',GSTPercentage:'All', ProductCategory: 0, productName:'',};

  disableDates: boolean = true;
  customerList: any;
  shopList = [];
  dataList=[];
  prodList: any[];
  selectedProduct: any[];
  supplierList = [];
  totalQty = 0;
  totalAmount = 0;
  totalDiscount = 0;
  totalGstAmount = 0;
  totalUnitPrice = 0;
  ngOnInit(): void {
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ExpiryReport') {
         this.ExpiryRrportRag = element.Edit;
       }
     });
    this.range = 'Today';
    this.getDateRange();
    this.getGstList();
    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      pageLength: 200000,
      colReorder: true,
      dom: 'Bfrtip',
      scrollY:'50vh',
      scrollCollapse: false,
      scrollX: true,
      // Configure the buttons
      buttons: [
        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          footer: true ,
          messageTop:  'Purchase Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Purchase Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10 ;
            doc.styles.tableFooter.fontSize = 8 ;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // {
        //   extend: 'excel',
        //   messageTop: 'Purchase Report Generated On ' + moment().format('LLLL') ,
        //   exportOptions: {
        //     columns: ':visible'
        //   },
        //   title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdfHtml5',
          footer: true ,

          messageTop: 'Purchase Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            columns: ':visible',
            modifier: {
              page: 'current'
            }
          },
          header: true,
          title: 'Purchase Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10 ;
            doc.styles.tableFooter.fontSize = 8 ;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; 
            //<-- set fontsize to 16 instead of 10 
          }
        }
      ],
      retrieve: true
    };
    this.spinner.show();

    this.getProductList();
    this.getCustomerList();
   
    this.getSupplierList();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }

  getDateRange(){
let d1 = moment().startOf('month').format('YYYY-MM-DD');
let d2 = moment().format('YYYY-MM-DD'); 
if(this.range === 'Custom Range'){ this.disableDates = true} else { this.disableDates = false}
    switch (this.range) {
      case "Today":
        d1 = moment().format('YYYY-MM-DD');
        d2 = moment().format('YYYY-MM-DD');
        break;
      case "Yesterday":
        d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
        d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
        break;
      case "This Week":
        d1 = moment().startOf('week').format('YYYY-MM-DD'); 
        d2 = moment().format('YYYY-MM-DD');
        break;
      case "Last Week":
        d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
        d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
        break;
      case "This Month":
        d1 = moment().startOf('month').format('YYYY-MM-DD'); 
        d2 = moment().format('YYYY-MM-DD');
      break;
      case "Last Month":
        d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
        d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
        break;
      case "This Quarter":
        d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
        d2 = d2 = moment().format('YYYY-MM-DD');
        break;
      case "Last Quarter":
        d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
        d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
        break;
      case "This Year":
        d1 = moment().startOf('year').format('YYYY-MM-DD'); 
        d2 = d2 = moment().format('YYYY-MM-DD');
        break;
      case "Last Year":
        d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
        d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
        break;
              
      default:
        
        break;
    }
    this.filter.date1 = d1;
    this.filter.date2 = d2;
    this.filter2.date1 = d1;
    this.filter2.date2 = d2;
  }




  searchData() {
    this.spinner.show();
    this.filterS();
    let whereList = '';
    this.totalQty = 0;
    this.totalAmount = 0;
    this.totalDiscount = 0;
    this.totalGstAmount = 0;
    this.totalUnitPrice = 0;
    this.sgst = 0;
    this.cgst = 0;
    this.todaydate = moment(new Date()).format('YYYY-MM-DD');
    if (this.filter.date1 !== '' && this.filter.date1 !== null){
      let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and PurchaseDetail.ProductExpDate between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + ' and' +  `'${date2}'`; }
    if (this.filter.ShopID !== 0 && this.filter.ShopID !== null &&  this.filter.ShopID !== 'All'){
      whereList = whereList + ' and PurchaseMaster.ShopID = ' +  this.filter.ShopID; }
      if (this.filter.SupplierID !== 0 && this.filter.SupplierID !== null &&  this.filter.SupplierID !== 'All'){
        whereList = whereList + ' and PurchaseMaster.SupplierID = ' +  this.filter.SupplierID ; }
    if (this.filter.ProductTypeName !== 0 && this.filter.ProductTypeName !== null &&  this.filter.ProductTypeName !== 'All'){
      whereList = whereList + ' and PurchaseDetail.ProductTypeName = '  + `'${this.filter.ProductTypeName}'` ; }
    if (this.filter.PaymentStatus !== 0 && this.filter.PaymentStatus !== null &&  this.filter.PaymentStatus !== 'All'){
      whereList = whereList + ' and PurchaseMaster.PaymentStatus = '  + `'${this.filter.PaymentStatus}'`; }
      if (this.filter.ProductCategory !== 0) {
        whereList = whereList + ' and PurchaseDetail.ProductTypeID = ' + this.filter.ProductCategory;
      }
      if (this.filter.ProductName !== '') {
        whereList = whereList + ' and PurchaseDetail.ProductName Like ' + '"' + this.filter.ProductName + '%"';
      }
      if (this.filter.GSTPercentage !== 0 && this.filter.GSTPercentage !== null &&  this.filter.GSTPercentage !== 'All'){
        whereList = whereList + ' and PurchaseDetail.GSTPercentage = '  + `'${this.filter.GSTPercentage}'` ; }
        if (this.filter.GSTType !== 0 && this.filter.GSTType !== null &&  this.filter.GSTType !== 'All'){
          whereList = whereList + ' and PurchaseDetail.GSTType = '  + `'${this.filter.GSTType}'` ; }
    // if (this.filter.GroupBy !== '' && this.filter.GroupBy !== null){
    //   whereList = whereList + ' Group By PurchaseMaster. '  + `${this.filter.GroupBy}`; }
    this.companyService.getGenericListByParem('PurchaseReportExp', whereList ).subscribe(data => {
      this.dataList = data.result;
      this.dataList.forEach(element => {
        if(element.ProductExpDate < this.todaydate) {
          element.Color = true;
        } else {
          element.Color = false;
 
        }
      });
      console.log(this.dataList)
      this.totalCalculation(this.dataList);
      this.dtTrigger.next();
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();

      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  searchData1() {
    this.spinner.show();
    let whereList = '';
    this.totalQty = 0;
    this.sgst = 0;
    this.cgst = 0;
    this.totalDiscount = 0;
    this.totalGstAmount = 0;
    this.todaydate = moment(new Date()).format('YYYY-MM-DD');

    if (this.filter2.date1 !== '' && this.filter2.date1 !== null && this.filter2.FilterTypes === 'ProductExpDate'){
      let date1 =  moment(this.filter2.date1).format('YYYY-MM-DD')
      whereList = whereList + ' and BillDetail.ProductExpDate between' +  `'${date1}'`; }
      if (this.filter2.date2 !== '' && this.filter2.date2 !== null  && this.filter2.FilterTypes === 'ProductExpDate'){
        let date2 =  moment(this.filter2.date2).format('YYYY-MM-DD')
        whereList = whereList + 'and' + `'${date2}'`; 
      }
  
      // if (this.filter2.date1 !== '' && this.filter2.date1 !== null && this.filter2.FilterTypes === 'DeliveryDate'){
      //   let date1 =  moment(this.filter2.date1).format('YYYY-MM-DD')
      //   whereList = whereList + ' and BillMaster.DeliveryDate between' +  `'${date1}'`; }
      //   if (this.filter2.date2 !== '' && this.filter2.date2 !== null  && this.filter2.FilterTypes === 'DeliveryDate'){
      //     let date2 =  moment(this.filter2.date2).format('YYYY-MM-DD')
      //     whereList = whereList + 'and' + `'${date2}'`; 
      //   }
  
    if (this.filter2.ShopID !== 0 && this.filter2.ShopID !== null){
      whereList = whereList + ' and BillMaster.ShopID = ' +  this.filter2.ShopID; }
      if (this.filter2.customerID !== 0 && this.filter2.customerID !== null && this.filter2.customerID !== 'All'){
        whereList = whereList + ' and BillMaster.CustomerID = ' +  this.filter2.customerID ; }

        // if (this.filter2.ProductCategory !== 0 && this.filter2.ProductCategory !== null) {
        //   whereList = whereList + ' and BillDetail.ProductTypeName = ' + this.filter2.ProductCategory;
        //   this.filterS() ;
        // }
        // if (this.filter2.ProductName !== '') {
        //   whereList = whereList + ' and BillDetail.ProductName Like ' + '"' + this.filter2.ProductName + '%"';
        // }

    if (this.filter2.ProductCategory !== 0 ){
      // whereList = whereList + ' and BillDetail.ProductTypeID = ' + this.filter2.ProductCategory;
      this.prodList.forEach(ele =>{
      if(ele.ID === this.filter2.ProductCategory){
        whereList = whereList + ' and BillDetail.ProductTypeName = ' + `'${ele.Name}'`;
      }

      })  
      this.filter1() ;

    }

    if (this.filter2.ProductName !== '' && this.filter2.ProductName !== undefined) {
        whereList = whereList + ' and BillDetail.ProductName Like ' + '"' + this.filter2.ProductName + '%"';

      }

    if (this.filter2.PaymentStatus !== '' && this.filter2.PaymentStatus !== null && this.filter2.PaymentStatus !== 'All'){
      whereList = whereList + ' and BillMaster.PaymentStatus = '  + `'${this.filter2.PaymentStatus}'`; }
      if (this.filter2.GSTType !== '' && this.filter2.GSTType !== null &&  this.filter2.GSTType !== 'All'){
        whereList = whereList + ' and BillDetail.GSTType = '  + `'${this.filter2.GSTType}'`; }
        if (this.filter2.GSTPercentage !== '' && this.filter2.GSTPercentage !== null && this.filter2.GSTPercentage !== 'All' ){
          whereList = whereList + ' and BillDetail.GSTPercentage = '  + `'${this.filter2.GSTPercentage}'`; }
          if (this.filter2.ProductStatus !== '' && this.filter2.ProductStatus !== null && this.filter2.ProductStatus !== 'All'){
            whereList = whereList + ' and BillDetail.ProductStatus = '  + `'${this.filter2.ProductStatus}'`; }
      
    this.companyService.getGenericListByParem('BillMasterExpProduct', whereList ).subscribe(data => {
      this.itemList1 = data.result;
      this.itemList1.forEach(element => {
        if(element.ProductExpDate < this.todaydate) {
          element.Color = true;
        } else {
          element.Color = false;
 
        }
      });
console.log(this.itemList1);
      this.totalCalculation(this.itemList1);
      this.dtTrigger.next();
    this.spinner.hide();
      
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }



  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => { 
      this.gstList = data.result;
      this.gstdividelist = [];
      data.result.forEach(ele => {
     
        if(ele.Name.toUpperCase() !== 'CGST-SGST'){
          let obj = {GstType: '', Amount: 0};
          obj.GstType = ele.Name;
          this.gstdividelist.push(obj);

        }
      })
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getfieldList() {
    if(this.filter.ProductCategory !== 0){
    this.prodList.forEach(element => {
      if (element.ID === this.filter.ProductCategory) {
        this.selectedProduct = element.Name;
      }
    })
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }else {
    this.specList = [];
    this.filter.ProductName = '';
    this.filter.ProductCategory = 0;

  }
}

  getfieldList1() {
    if(this.filter2.ProductCategory !== 0){
    this.prodList.forEach(element => {
      if (element.ID === this.filter2.ProductCategory) {
        this.selectedProduct = element.Name;
      }
    })
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }else {
    this.specList = [];
    this.filter2.ProductCategory = 0;
    this.filter2.ProductName = '';

  }
}

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  filterS() {
    let productName = '';
    this.specList.forEach((element: { SelectedValue: string; }) => {
      if (productName === '') {
        productName = element.SelectedValue;
      } else if (element.SelectedValue !== '') {
        productName += '/' + element.SelectedValue;
      }
    });
    this.filter.ProductName = productName;
  }

  filter1() {
    let productName = '';
    this.specList.forEach((element: { SelectedValue: string; }) => {
      if (productName === '') {
        productName = element.SelectedValue;
      }  else if (element.SelectedValue !== '') {
        productName += '/' + element.SelectedValue;
      }
    });
    this.filter2.ProductName = productName;
  }


  totalCalculation(data) {
    this.gstdividelist.forEach(ele => {
      ele.Amount = 0;
  })
    for (var i = 0; i < data.length; i++) {
      this.totalQty = this.totalQty + parseInt(data[i].Quantity);
      this.totalGstAmount = this.totalGstAmount + parseInt(data[i].GSTAmount);
      this.totalAmount = this.totalAmount + parseInt(data[i].TotalAmount);
      this.totalDiscount = this.totalDiscount + parseInt(data[i].DiscountAmount);
      this.totalUnitPrice = this.totalUnitPrice + parseInt(data[i].SubTotal);
      this.gstdividelist.forEach(ele => {
        if(data[i].GSTType === ele.GstType && data[i].Status !== 0 && data[i].GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(data[i].GSTAmount);
        }
      })

      if(data[i].Status !== 0 && data[i].GSTType.toUpperCase() === 'CGST-SGST') {
         this.sgst +=  Number(data[i].GSTAmount) / 2 ;
         this.cgst +=  Number(data[i].GSTAmount) / 2 ;

      }
    }
  }

  getCustomerList() {
    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerList = res.result;
    this.spinner.hide();

    }, (err) => {
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 0).subscribe(data => {
      this.supplierList = data.result;
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    this.spinner.hide();

    }, (err) => { console.log(err);
                   this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.filter.ShopID = this.shopList[0].ID
      }
    this.spinner.hide();

    }, (err) => {
      console.log(err);
       this.spinner.hide();
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product',1).subscribe(data => {
      this.prodList = data.result;
    this.spinner.hide();
     
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
    this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportSup');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
  
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }
  
  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
