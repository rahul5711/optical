import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../../services/company.service';
import { Subject } from 'rxjs';
import * as XLSX from 'xlsx';
import { DomSanitizer } from '@angular/platform-browser';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-customer-report',
  templateUrl: './customer-report.component.html'
})
export class CustomerReportComponent implements OnInit {
  dtTrigger: Subject<CustomerReportComponent> = new Subject();
  dtOptions: any = {};

  constructor(private snackBar: MatSnackBar,
              private companyService: CompanyService,
              private sanitizer: DomSanitizer,
              private spinner: NgxSpinnerService) { }



  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  customerList:any = [];
  gridview = true;
  filter: any =  {customerID: null, date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().format('YYYY-MM-DD')};
  // customerList: any;
  dataList: any;
  editCustomerList = false;
  addCustomerList = false;
  deleteCustomerList = false;
  spectacleList: any;
  ExcelArray = [];

  // fileName= 'ExcelSheet.xlsx';
  fileName1= 'CustomerListExcel.xlsx';
  fileName = 'Cust_Power_ListExcel.xlsx';
  term:any;
  ngOnInit(): void {
    this.spinner.show();

    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      pageLength: 25,
      colReorder: true,
      scrollY: 400,
      scrollX: true,
      dom: 'Bfrtip',
    lengthMenu: [ 25, 50, 75, 100 ],
     
      // Configure the buttons
      buttons: [
      'pageLength',

        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          messageTop:  'Eye Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Eye Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // {
        //   extend: 'excel',
        //   messageTop: 'Eye Report Generated On ' + moment().format('LLLL') ,
        //   exportOptions: {
        //     columns: ':visible'
        //   },
        //   title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdfHtml5',
          messageTop: 'Eye Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            columns: ':visible',
            modifier: {
              columns: ':visible'
            
              
            }
          },
          header: true,
          title: 'Eye Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        }
      ],
      retrieve: true
    };
    this.spinner.show();

    this.getCustomerList();
    this.companyService.getExtendedCustomerListBy('CustomerFullList', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(res => {
      this.customerList = res.result;
      this.dtTrigger.next();
 console.log( this.customerList ,' this.customerList')
       // this.modifyExcel();
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }



  getCustomerList1() {
    this.spinner.show();

    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerList = res.result;
    }, (err) => {
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
 

  
  modifyExcel() {
    this.spinner.show();
    this.ExcelArray = [];
    this.customerList.forEach(ele => {
      this.companyService.geListByOtherID('spectacle_rx', ele.ID).subscribe(res => {
            // this.spectacleList = res.result;
            // ele.LensType = 'spectacle';
            ele.spectacle_rx = [];
            ele.spectacle_rx.push(res.result[0]);
            this.ExcelArray.push(ele);
            this.companyService.geListByOtherID('contact_lens_rx', ele.ID).subscribe(res => {
                  // this.contactLensList = res.result;
                  ele.contact_lens_rx = [];
                  ele.contact_lens_rx.push(res.result[0]);
                  this.ExcelArray.push(ele);
                }, (err) => {
                  console.log(err);
                });
                this.spinner.hide();
            console.log(this.customerList , 'ExcelArray');
          }, (err) => {
            console.log(err);
          });
    })
  }

  getCustomerList() {
    this.spinner.show();
    this.companyService.getExtendedListByCompany('CustomerFullList').subscribe(res => {
      this.customerList = res.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }





  // deleteItem(i){
  //   Swal.fire({
  //     title: 'Are you sure?',
  //     text: "You won't be able to revert this!",
  //     icon: 'warning',
  //     showCancelButton: true,
  //     confirmButtonColor: '#3085d6',
  //     cancelButtonColor: '#d33',
  //     confirmButtonText: 'Delete it!'
  //   }).then((result) => {
  //     if (result.isConfirmed) {
  //       this.companyService.deleteData('Customer', this.customerList[i].ID).subscribe(data => {
  //         this.customerList.splice(i, 1);
  //         this.showNotification(
  //         'bg-green',
  //         'Data Deleted Successfully',
  //         'top',
  //         'right'
  //         );
  //         }, (err) => {
  //         this.showNotification(
  //         'bg-red',
  //         'Could Not Delete Data.',
  //         'top',
  //         'right'
  //         );
  //         });
  //       Swal.fire(
  //         'Deleted!',
  //         'Your file has been deleted.',
  //         'success'
  //       )
  //     }
  //   })
  // }
  
  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportsss');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
 
  }

  exportEx1(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportccc');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
    // ws['!cols'] = [];
    // ws['!cols'][0] = { hidden: true };
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
 
    /* save to file */  
    XLSX.writeFile(wb, this.fileName1);
 
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }
  

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}


