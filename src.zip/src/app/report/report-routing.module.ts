import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportComponent } from './report.component';
import { InventoryReportComponent } from './inventory-report/inventory-report.component';
import { Inventory2ReportComponent } from './inventory2-report/inventory2-report.component';
import { SaleReportComponent } from './sale-report/sale-report.component';
import { TransferReportComponent } from './Transfer-product-report/Transfer-report.component';
import { SaleReportDetailComponent } from './sale-report-detail/sale-report-detail.component';
import { ServiceReportComponent } from './service-report/service-report.component';
import { CashReportComponent } from './cash-report/cash-report.component';
import { ExpenseReportComponent } from './expense-report/expense-report.component';
import { PettyCaseReportComponent } from './pettyCase-report/pettyCase-report.component';
import { PurchaseReportComponent } from './purchase-report/purchase-report.component';
import { AccountingReportComponent } from './accounting-report/accounting-report.component';
import { CustomerReportComponent } from './customer-report/customer-report.component';
import { ProductExpiryReportComponent } from './product-expiry-report/product-expiry-report.component';
import { EyeReportComponent } from './eye-report/eye-report.component';
import { ReminderReportComponent } from './reminder-report/reminder-report.component';
import { LaserReportComponent } from './laser-report/laser-report.component';
import { ProductSummaryComponent} from './product-summary/product-summary.component';
import { CaseCounterReportComponent } from './CaseCounter-report/CaseCounter-report.component';
import { ProfitComponent } from './profit/profit.component';



const routes: Routes = [{ path: '', component: ReportComponent },
{ path: 'inventory-report', component: InventoryReportComponent },
{ path: 'inventory2-report', component: Inventory2ReportComponent },
{ path: 'sale-report', component: SaleReportComponent },
{ path: 'eye-report', component: EyeReportComponent },
{ path: 'transfer-report', component: TransferReportComponent },
{ path: 'sale-report-detail', component: SaleReportDetailComponent },
{ path: 'sale-report-detail', component: SaleReportDetailComponent },
{ path: 'service-report', component: ServiceReportComponent },
{ path: 'reminder-report', component: ReminderReportComponent },
{ path: 'laser-report', component: LaserReportComponent },
{path: 'product-summary', component: ProductSummaryComponent},
{ path: 'product-expiry-report', component: ProductExpiryReportComponent },
{ path: 'cash-report', component: CashReportComponent },
{ path: 'expense-report', component: ExpenseReportComponent },
{ path: 'pettyCase-report', component: PettyCaseReportComponent },
{ path: 'CashCounter-report', component: CaseCounterReportComponent },
{ path: 'purchase-report', component: PurchaseReportComponent },
{ path: 'accounting-report', component: AccountingReportComponent },
{ path: 'saleProfit-report', component: ProfitComponent },

{ path: 'customer-report', component: CustomerReportComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
