import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../../services/company.service';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";
import { AdminService } from '../../services/admin.service';


@Component({
  selector: 'app-reminder-report',
  templateUrl: './reminder-report.component.html',
  styleUrls: ['./reminder-report.component.css']
})
export class ReminderReportComponent implements OnInit {

  dtTrigger: Subject<ReminderReportComponent> = new Subject();
  searchValue: any;

  dtOptions: any = {};
  range: any;
  disableDates: boolean = true;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  bdayTbl: 'Supplier';
  anniTbl: string;
  ReminderRrportRag: any;
  constructor(private companyService: CompanyService,
              private adminService: AdminService,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,) { }

  filter: any =  {PaymentStatus: 'All', ProductStatus:'All' ,date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), customerID: 'All', ShopID: 0, ProductTypeName: '',FilterTypes:'Bday' , FilterType:'Customer'};

  customerList: any;
  shopList = [];
  dataList: any;
  prodList: any[];
  selectedProduct: any[];
  totalQty = 0;
  SubTotal = 0;

  totalInvoiceAmt = 0;
  totalDiscount = 0;
  totalGstAmount = 0;
  ngOnInit(): void {
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ReminderReport') {
         this.ReminderRrportRag = element.Edit;
       }
     });
    this.range = 'Today';
    this.getDateRange();
    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      pageLength: 200000,
      colReorder: true,
      dom: 'Bfrtip',
      scrollY:'50vh',
      scrollCollapse: false,
      scrollX: true,
      // Configure the buttons
      buttons: [
        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          messageTop:  'Reminder Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Reminder Report' + ' / ' + this.loggedInShop.Name,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        {
          extend: 'excel',
          messageTop: 'Reminder Report Generated On ' + moment().format('LLLL') ,
          exportOptions: {
            columns: ':visible'
          },
          title: 'Reminder Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
        },
        {
          extend: 'pdfHtml5',
          messageTop: 'Reminder Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            modifier: {
              page: 'current'
            }
          },
          header: true,
          title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        }
      ],
      retrieve: true
    };
    this.spinner.show();
 
    this.getProductList();
    this.getCustomerList();
   
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }

  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
      }

  searchData() {
    this.spinner.show();
    let tab = '';
    let whereList = '';
      let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')

if (this.filter.FilterTypes === 'Bday' ){
  if(this.filter.FilterType === 'Supplier'){
    tab = 'SupplierNotification';
    whereList = ' and Supplier.DOB between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
   }else if (this.filter.FilterType === 'Customer'){
    tab = 'CustomerNotification';
    whereList = ' and Customer.DOB between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
   }else if (this.filter.FilterType === 'Employee'){
    tab = 'EmployeeNotification';
    whereList = ' and User.DOB between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
  }else if (this.filter.FilterType === 'Fitter'){
    tab = 'FitterNotification';
    whereList = ' and Fitter.DOB between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
  }else if (this.filter.FilterType === 'Doctor'){
    tab = 'DoctorNotification';
    whereList = ' and Doctor.DOB between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
  }
}

if(this.filter.FilterTypes === 'Anniversary'){
  if(this.filter.FilterType === 'Supplier'){
    tab = 'SupplierNotification';
    whereList = ' and Supplier.Anniversary between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
   }else if (this.filter.FilterType === 'Customer'){
    tab = 'CustomerNotification';
    whereList = ' and Customer.Anniversary between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
   }else if (this.filter.FilterType === 'Employee'){
    tab = 'EmployeeNotification';
    whereList = ' and User.Anniversary between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
  }else if (this.filter.FilterType === 'Fitter'){
    tab = 'FitterNotification';
    whereList = ' and Fitter.Anniversary between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
  }else if (this.filter.FilterType === 'Doctor'){
    tab = 'DoctorNotification';
    whereList = ' and Doctor.Anniversary between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
  }
}

if(this.filter.FilterTypes === 'Comfort'){
    tab = 'EyeTestNotification';
    whereList = ' and DATE_FORMAT(spectacle_rx.CreatedOn, "%Y-%m-%d") between ' +  `'${date1}'`;
    whereList = whereList + ' and' +  `'${date2}'`;
} 

if(this.filter.FilterTypes === 'Service'){
  tab = 'ServiceNotification';
  whereList = ' and DATE_FORMAT(BillDetail.CreatedOn, "%Y-%m-%d") between ' +  `'${date1}'`;
  whereList = whereList + ' and' +  `'${date2}'`;
}


    this.companyService.getGenericListByParem(tab, whereList ).subscribe(data => {
      
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.CreatedOn = moment(el.CreatedOn).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      this.dataList = data.result;
      console.log(data.result,tab);

      this.dtTrigger.next();
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  totalCalculation(data) {
    for (var i = 0; i < data.length; i++) {
      this.totalQty = this.totalQty + parseInt(data[i].Quantity);
      this.SubTotal = this.SubTotal + parseInt(data[i].SubTotal);

      this.totalGstAmount = this.totalGstAmount + parseInt(data[i].GSTAmount);
      this.totalInvoiceAmt = this.totalInvoiceAmt + parseInt(data[i].TotalAmount);
      this.totalDiscount = this.totalDiscount + parseInt(data[i].DiscountAmount);
    }
  }

  getCustomerList() {
    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerList = res.result;
    this.spinner.hide();

    }, (err) => {
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  sendWhA(data,mode){
    if(mode === 'BirthdayWh'){
      var msg = `Hi ${data.Name},%0A`+
      `Wish You Happy Birthday Get Special Discount Today%0A`+
      `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
      var mob = "91" + data.MobileNo1;
     var url = `https://wa.me/${mob}?text=${msg}`;
     window.open(url, "_blank");
    }else if (mode === 'AnniversaryWh'){
      var msg = `Hi ${data.Name},%0A`+
      `Happy Anniversary. May you yo love bird stay happy and blessed always%0A`+
      `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
      var mob = "91" + data.MobileNo1;
     var url = `https://wa.me/${mob}?text=${msg}`;
     window.open(url, "_blank");
    }else if (mode === 'ComfortWh'){
      var msg = `Hi ${data.Name},%0A`+
      `We are curious to know about the comfort and quality of Spectacles that u bought from our store.%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
    }else if (mode === 'ServiceWh'){
      var msg = `Hi ${data.Name},%0A`+
    `Just a Gental reminder about your FREE service is coming up. Please contact.%0A`+
     `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
     var mob = "91" + data.MobileNo1;
    var url = `https://wa.me/${mob}?text=${msg}`;
    window.open(url, "_blank");
    }
  
  }

  sendEM(data,mode){
    if(mode === "BirthdayEm"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'CustomerBday').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "AnniversaryEm"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'Customer_Anni').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "ComfortEm"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'ComfortFeedback').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "ServiceEm"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'ServicenewMsg').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }
  }

 

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    this.spinner.hide();

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.filter.ShopID = this.shopList[0].ID
      }
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();

      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompany('Product',1).subscribe(data => {
      this.prodList = data.result;
    this.spinner.hide();
     
    }, (err) => {
       this.spinner.hide();
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
     
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  
  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }


  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
