import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../../services/company.service';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-laser-report',
  templateUrl: './laser-report.component.html',
  styleUrls: ['./laser-report.component.css']
})
export class LaserReportComponent implements OnInit {

  dtTrigger: Subject<LaserReportComponent> = new Subject();
  searchValue: any;

  dtOptions: any = {};
  range: any;
  disableDates: boolean = true;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  pdfLink: any;
  LaserRrporttRag: any;
  supplierList: any;
  employeeList: any;
  constructor(private companyService: CompanyService,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,) { }

  filter: any =  {PaymentStatus: 'All', ProductStatus:'All' ,date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), customerID: '', supplierID: '', employeelID :'', ShopID: this.loggedInShop.ID, };



  customerList: any;
  shopList = [];
  dataList: any;
  prodList: any[];
  selectedProduct: any[];
  totalQty = 0;
  SubTotal = 0;

  totalInvoiceAmt = 0;
  totalDiscount = 0;
  totalGstAmount = 0;
  ngOnInit(): void {
    this.permission.forEach(element => {    
      if (element.ModuleName === 'LaserReport') {
         this.LaserRrporttRag = element.Edit;
       }
     });
    this.range = 'Today';
    this.getDateRange(); 
    this.getCustomerList();
    this.getSupplierList();
   this.getEmployeeList();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }

  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
      }

  searchData() {
    this.spinner.show();
    
    let whereList = '';
    if (this.filter.date1 !== '' && this.filter.date1 !== null ){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(BillMaster.CreatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null ){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; 
    }
    if (this.filter.ShopID !== 0 && this.filter.ShopID !== null){
      whereList = whereList + ' and BillMaster.ShopID = ' +  this.filter.ShopID; }
      if (this.filter.customerID !== 0 && this.filter.customerID !== null && this.filter.customerID !== 'All'){
        whereList = whereList + ' and BillMaster.CustomerID = ' +  this.filter.customerID ; }
  
    if (this.filter.PaymentStatus !== '' && this.filter.PaymentStatus !== null  && this.filter.PaymentStatus !== 'All'){
      whereList = whereList + ' and BillMaster.PaymentStatus = '  + `'${this.filter.PaymentStatus}'`; }
    
    this.companyService.getLaserReportpdf(this.filter.customerID, whereList ).subscribe(data => {

      let data1 = {Shop: this.loggedInShop, paidList: data.data, InvoicedAmount:data.InvoicedAmount, BalanceDue:data.BalanceDue, AmountPaid:data.AmountPaid, From: this.filter.date1, To: this.filter.date2,
         Companysetting:this.loggedInCompanySetting , Company:this.loggedInCompany}
      this.companyService.billPayment('billPayment', data1).subscribe(data => {
        this.spinner.hide();
        const url =  data;
        this.pdfLink = url;
        console.log(data);
        window.open(url, "_blank");
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    
    
      console.log(data , 'data');

    }, (err) => {
      console.log(err);
   
    });
  }

  searchDataSupplier() {
    this.spinner.show();
    let whereList = '';
    if (this.filter.date1 !== '' && this.filter.date1 !== null ){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and PurchaseMaster.PurchaseDate between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null ){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; 
    }
    if (this.filter.ShopID !== 0 && this.filter.ShopID !== null){
      whereList = whereList + ' and PurchaseMaster.ShopID = ' +  this.filter.ShopID; }
      if (this.filter.supplierID !== 0 && this.filter.supplierID !== null && this.filter.supplierID !== 'All'){
        whereList = whereList + ' and PurchaseMaster.SupplierID = ' +  this.filter.supplierID ; }
   
    this.companyService.getLaserReportSuppdf(this.filter.supplierID, whereList ).subscribe(data => {

      let data1 = {Shop: this.loggedInShop, paidList: data.data, InvoicedAmount:data.InvoicedAmount, BalanceDue:data.BalanceDue, AmountPaid:data.AmountPaid, From: this.filter.date1, To: this.filter.date2,
         Companysetting:this.loggedInCompanySetting , Company:this.loggedInCompany}
      this.companyService.billSubPayment('billSubPayment', data1).subscribe(data => {
        this.spinner.hide();
        const url =  data;
        this.pdfLink = url;
        console.log(data);
        window.open(url, "_blank");
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    
    
      console.log(data , 'data');

    }, (err) => {
      console.log(err);
   
    });
  }


 
  searchDataEmpolyee() {
    this.spinner.show();
    let whereList = '';
    if (this.filter.date1 !== '' && this.filter.date1 !== null ){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(Payroll.CreatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null ){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; 
    }
 
      if (this.filter.employeelID !== 0 && this.filter.employeelID !== null && this.filter.employeelID !== 'All'){
        whereList = whereList + ' and Payroll.EmployeeID = ' +  this.filter.employeelID ; }
   
    this.companyService.getLaserReportemppdf(this.filter.employeelID, whereList ).subscribe(data => {
      console.log(data,'data');
      

      let data1 = {Shop: this.loggedInShop, paidList: data.data, InvoicedAmount:data.InvoicedAmount, BalanceDue:data.BalanceDue, AmountPaid:data.AmountPaid, From: this.filter.date1, To: this.filter.date2,
         Companysetting:this.loggedInCompanySetting , Company:this.loggedInCompany}
      this.companyService.billSubPayment('billSubPayment', data1).subscribe(data => {
        this.spinner.hide();
        const url =  data;
        this.pdfLink = url;
        console.log(data);
        window.open(url, "_blank");
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data',
          'top',
          'right'
        );
      });
    
    
      console.log(data , 'data');

    }, (err) => {
      console.log(err);
   
    });
  }
  getCustomerList() {
    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerList = res.result;
    this.spinner.hide();

    }, (err) => {
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }


  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier',1).subscribe(res => {
      this.supplierList = res.result;
    this.spinner.hide();

    }, (err) => {
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getEmployeeList() {
    this.companyService.getShortListByCompany('User', 1).subscribe(data => {
      this.employeeList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    this.spinner.hide();

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.filter.ShopID = this.shopList[0].ID
      }
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();

      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }


  onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === 1) {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == 2) {
      event = event.toTitleCase()
    }
    return event; 
  }
  
  
  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}
