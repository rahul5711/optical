import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Inventory2ReportComponent } from './inventory2-report.component';

describe('Inventory2ReportComponent', () => {
  let component: Inventory2ReportComponent;
  let fixture: ComponentFixture<Inventory2ReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Inventory2ReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Inventory2ReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
