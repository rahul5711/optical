import { Component, ModuleWithComponentFactories, OnInit } from '@angular/core';
import { CompanyService } from '../../services/company.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { Subject } from 'rxjs';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-inventory2-report',
  templateUrl: './inventory2-report.component.html',
  styleUrls: ['./inventory2-report.component.sass']
})
export class Inventory2ReportComponent implements OnInit {

  dtTrigger: Subject<Inventory2ReportComponent> = new Subject();
  fileName= 'InventoryReportExcel.xlsx';

  dtOptions: any = {};
  
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  viewSupplier = this.permission[this.permission.findIndex((element) => element.ModuleName = "Supplier")];
  dataList: any;
  gstList: any;
  editEmployeeList: any;
  InventoryReportRag: any;


  constructor(
    private companyService: CompanyService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
  ) { }
  data = {
    ProductCategory: 0, SupplierID: 0, ShopID: 0, Ledger: 'Both', GSTType:"All", Barcode: "", CurrentStatus: "Available", ProductName: '',GSTPercentage:'All',
    date1: moment().startOf('month').format('DD-MM-YYYY'),
  date2: moment().add( 2 , 'days').format('DD-MM-YYYY'),
  };

  range: any;
  disableDates: boolean = true;
  searchValue: any;
  EnteredValue: any;
  summaryList = [];
  supplierList: any[];
  shopList = [];
  prodList: any[];
  specList: any = [];
  gstdividelist = [];
  sgst = 0;
  cgst = 0;
  category = 'Product';
  spec = { SelectedValue: ''};
  selectedProduct = '';
  totalQty = 0;
  totalRetailPrice = 0;
  sub = 0;
  totalwholesaleprice = 0;
  totalGstAmount = 0;
  totalUnitPrice = 0;
  totalDiscountPrice = 0;
  totalAmount = 0;
  totalIGST = 0;
  totalCgstSgst = 0;
  
  ngOnInit(): void {
     this.permission.forEach(element => {    
     if (element.ModuleName === 'InventoryReport') {
        this.InventoryReportRag = element.Edit;
      }
    });
    this.range = 'Today';
    this.getDateRange();
    this.getGstList();

    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      
      pageLength: 2000000,
      colReorder: true,
      processing: true,
      dom: 'Bfrtip',
      scrollY:'50vh',
   
      scrollX: true,
      // Configure the buttons
      buttons: [
        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          messageTop:  'Inventory Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Inventory Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // // {
        // //   extend: 'excel',
        // //   messageTop: 'Inventory Report Generated On ' + moment().format('LLLL') ,
        // //   exportOptions: {
        // //     columns: ':visible'
            
        // //   },
        //   title: JSON.parse(this.loggedInCompany).Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdf',
          footer: true ,
          messageTop: 'Inventory Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            columns: ':visible',
            modifier: {
              page: 'current',
              
            }
          },
          header: true,
          title: 'Inventory Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10 ;
            doc.styles.tableFooter.fontSize = 8 ;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 7.5; //<-- set fontsize to 16 instead of 10 
          }
        }
      ],
      retrieve: true
    };
    this.spinner.show();
    this.getProductList();
    this.getSupplierList();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }

  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportSup');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
  
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getfieldList() {
    if(this.data.ProductCategory !== 0){
    this.prodList.forEach(element => {
      if (element.ID === this.data.ProductCategory) {
        this.selectedProduct = element.Name;
      }
    })
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }else{
this.specList = [];
  }
}

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });
  }
  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
            case "This Week":
              d1 = moment().startOf('week').format('YYYY-MM-DD'); 
              d2 = moment().format('YYYY-MM-DD');
              break;
            case "Last Week":
              d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
              d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
              break;
            case "This Month":
              d1 = moment().startOf('month').format('YYYY-MM-DD'); 
              d2 = moment().format('YYYY-MM-DD');
            break;
            case "Last Month":
              d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
              d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
              break;
            case "This Quarter":
              d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
              d2 = d2 = moment().format('YYYY-MM-DD');
              break;
            case "Last Quarter":
              d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
              d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
              break;
            case "This Year":
              d1 = moment().startOf('year').format('YYYY-MM-DD'); 
              d2 = d2 = moment().format('YYYY-MM-DD');
              break;
            case "Last Year":
              d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
              d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
              break;        
          default:
            
            break;
        }
        this.data.date1 = d1;
        this.data.date2 = d2;
      }

  filter() {
    let productName = '';
    this.specList.forEach(element => {
      if (productName === '') {
        productName = element.SelectedValue;
      } else if (element.SelectedValue !== '') {
        productName += '/' + element.SelectedValue;
      }
    });
    this.data.ProductName = productName;
  }

  getInventoryData() {
    this.spinner.show();
    let whereList = '';
    this.totalQty = 0;
    this.totalGstAmount = 0;
    this.totalRetailPrice = 0;
    this.totalwholesaleprice = 0;
    this.totalUnitPrice = 0;
    this.totalDiscountPrice = 0;
    this.totalAmount = 0;
    this.totalIGST = 0;
    this.totalCgstSgst = 0;
    this.sgst = 0;
    this.cgst = 0;
    this.sub = 0;
    if (this.data.date1 !== '' && this.data.date1 !== null){
      let date1 =  moment(this.data.date1).format('YYYY-MM-DD')
      whereList = whereList + ' and PurchaseMaster.PurchaseDate between ' +  `'${date1}'`; 
    }
      if (this.data.date2 !== '' && this.data.date2 !== null){
        let date2 =  moment(this.data.date2).format('YYYY-MM-DD')
        whereList = whereList + ' and ' + `'${date2}'`;
      } 
    if (this.data.ProductCategory !== 0) {
      whereList = whereList + ' and PurchaseDetail.ProductTypeID = ' + this.data.ProductCategory;
      this.filter();
    }
    if (this.data.ShopID !== 0) {
      whereList = whereList + ' and BarcodeMaster.ShopID = ' + this.data.ShopID;
    }
    if (this.data.Ledger !== 'Both')
    {
      if (this.data.Ledger === 'Ledger Only') {
        whereList = whereList + ' and PurchaseDetail.Ledger = 1 ';
      } else { whereList = whereList + ' and PurchaseDetail.Ledger = 0 '; }
    }
    if (this.data.SupplierID !== 0) {
      whereList = whereList + ' and PurchaseMaster.SupplierID = ' + this.data.SupplierID;
    }
    if (this.data.Barcode !== '') {
      whereList = whereList + ' and BarcodeMaster.Barcode Like ' + '"' + this.data.Barcode + '%"';
    }
    if (this.data.CurrentStatus !== '' && this.data.CurrentStatus !== 'All') {
      whereList = whereList + ' and BarcodeMaster.CurrentStatus = ' + '"' + this.data.CurrentStatus + '"';
    }
    if (this.data.CurrentStatus !== '' && this.data.CurrentStatus === 'All') {
      whereList = whereList;
    }
    if (this.data.ProductName !== '') {
      whereList = whereList + ' and PurchaseDetail.ProductName Like ' + '"' + this.data.ProductName + '%"';
    }
    if (this.data.GSTType !== '' && this.data.GSTType !== 'All') {
      whereList = whereList + ' and PurchaseDetail.GSTType Like ' + '"' + this.data.GSTType + '%"';
    }
    if (this.data.GSTType !== '' && this.data.GSTType === 'All') {
      whereList = whereList;
    }
    if (this.data.GSTPercentage !== '' && this.data.GSTPercentage !== 'All') {
      whereList = whereList + ' and PurchaseDetail.GSTPercentage = ' + '"' + this.data.GSTPercentage + '"';
    }

    this.companyService.getGenericListByParem('ProductInventory', whereList).subscribe(data => {
     
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.PurchaseDate = moment(el.PurchaseDate).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })

      this.summaryList = data.result;
      this.summaryList.forEach(ele =>{
        ele.SubTotal = ele.Count * ele.UnitPrice
        ele.GSTAmount = (ele.UnitPrice * ele.Count - ele.DiscountAmount) * ele.GSTPercentage / 100;
        ele.TotalAmount = ele.SubTotal + ele.GSTAmount
      })
      let ex = document.getElementById('exportSup');
      console.log(ex,'fff')
      console.log(this.summaryList,"kkkkkkkkkkk")
      this.totalCalculation(this.summaryList);
      this.dtTrigger.next();
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getGstList() {
    this.companyService.getSupportMasterList('TaxType').subscribe(data => { 
      this.gstList = data.result;
      this.gstdividelist = [];
      data.result.forEach(ele => {

        if(ele.Name.toUpperCase() !== 'CGST-SGST'){
          let obj = {GstType: '', Amount: 0};
          obj.GstType = ele.Name;
          this.gstdividelist.push(obj);

        }
      })
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  

  totalCalculation(data) {
    this.gstdividelist.forEach(ele => {
      ele.Amount = 0;
  })
  
    for (var i = 0; i < data.length; i++) {
      if(data[i].Status !== 0) {
      this.totalQty = this.totalQty + parseInt(data[i].Count);
      this.totalGstAmount = this.totalGstAmount + parseInt(data[i].GSTAmount);
      this.totalRetailPrice = this.totalRetailPrice + data[i].Count *  parseInt(data[i].RetailPrice);
      this.totalwholesaleprice = this.totalwholesaleprice + data[i].Count *  parseInt(data[i].WholeSalePrice);
      this.totalUnitPrice = this.totalUnitPrice + parseInt(data[i].SubTotal);
      this.totalDiscountPrice = this.totalDiscountPrice + parseInt(data[i].DiscountAmount);
      this.totalAmount = this.totalAmount + parseInt(data[i].TotalAmount);
      }
      this.gstdividelist.forEach(ele => {
        if(data[i].GSTType === ele.GstType && data[i].Status !== 0 && data[i].GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(data[i].GSTAmount);
        }
      })

      if(data[i].Status !== 0 && data[i].GSTType.toUpperCase() === 'CGST-SGST') {
         this.sgst +=  Number(data[i].GSTAmount) / 2 ;
         this.cgst +=  Number(data[i].GSTAmount) / 2 ;

      }
     }
     
  
    
  }

 
     



  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product', 1).subscribe(data => {
      this.prodList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 0).subscribe(data => {
      this.supplierList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result, 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.data.ShopID = this.shopList[0].ID
      }
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}
