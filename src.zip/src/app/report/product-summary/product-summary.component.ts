
import { Component, ModuleWithComponentFactories, OnInit } from '@angular/core';
import { CompanyService } from '../../services/company.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { Subject } from 'rxjs';
import * as XLSX from 'xlsx';
import jspdf from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-product-summary',
  templateUrl: './product-summary.component.html'
})
export class ProductSummaryComponent implements OnInit {

  dtTrigger: Subject<ProductSummaryComponent> = new Subject();
  dtOptions: any = {};

  fileName= 'ProductSummaryComponentExcel.xlsx';

  
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  viewSupplier = this.permission[this.permission.findIndex((element) => element.ModuleName = "Supplier")];
  dataList: any;
  gstList: any;
  ProductSummaryRrportRag: any;
  table: DataTables.Api;


  constructor(
    private companyService: CompanyService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
  ) { }
  data = {
     SupplierID: 0, ShopID: 0,date1: moment().startOf('month').format('YYYY-MM-DD'),date2: moment().add( 2 , 'days').format('YYYY-MM-DD'),
  };

  range: any;
  disableDates: boolean = true;
  searchValue: any;
  EnteredValue: any;
  summaryList = [];
  supplierList: any[];
  shopList = [];
  prodList: any[];
  specList: any = [];
  gstdividelist = [];
  sgst = 0;
  cgst = 0;
  category = 'Product';
  spec = { SelectedValue: ''};
  selectedProduct = '';
  totalQty = 0;
  Sold = 0;
  Available = 0;
  Damaged = 0;
  LostStolen = 0;
  TransferPending = 0;
  totalRetailPrice = 0;
  totalwholesaleprice = 0;
  totalGstAmount = 0;
  totalUnitPrice = 0;
  totalDiscountPrice = 0;
  totalAmount = 0;
  totalIGST = 0;
  totalCgstSgst = 0; 

 
  ngOnInit(): void {
  
   
    
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ProductSummaryReport') {
         this.ProductSummaryRrportRag = element.Edit;
       }
     });
    
    this.range = 'Today';
    this.getDateRange();
 
   
    this.spinner.show();
  
    this.getSupplierList();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }
  
  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportpro');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
  
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }



  getInventoryData() {
    this.dtOptions = {
     
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      pageLength: 25,
      destroy: true,
      // Declare the use of the extension in the dom parameter
   
      paging: true,
      colReorder: true,
      scrollY: 400,
      scrollX: true,
      dom: 'Bfrtip',
    lengthMenu: [ 25, 50, 75, 100 ],
     
      // Configure the buttons
      buttons: [
      'pageLength',
        'colvis',
        'copy',
        
        {
          extend: 'print',
          messageTop:  'ProductSummary Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title:  'ProductSummary Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8;
            doc.defaultStyle.getElementById('exportSup') //<-- set fontsize to 16 instead of 10 
          }
        },
        
        {
          extend: 'pdfHtml5',
          footer: true ,
         
          messageTop: 'ProductSummary Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            columns: ':visible',
            modifier: {
              
            }
          },
          header: true,
          title: 'ProductSummary Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10 ;
            doc.styles.tableFooter.fontSize = 8 ;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
       
        
      ],
      
      retrieve: true,
      
     
      
    };
    this.spinner.show();
    this.summaryList = [];
    let whereList = '';
  
    if (this.data.date1 !== '' && this.data.date1 !== null){
      let date1 =  moment(this.data.date1).format('YYYY-MM-DD')
      whereList = whereList + ' and DATE_FORMAT(BarcodeMaster.CreatedOn, "%Y-%m-%d") between' +  `'${date1}'`; }
      if (this.data.date2 !== '' && this.data.date2 !== null){
        let date2 =  moment(this.data.date2).format('YYYY-MM-DD')
        whereList = whereList + 'and ' + `'${date2}'`; }
    
    if ( this.data.ShopID !== 0 && this.data.ShopID !== null ) {
      whereList = whereList + ' and BarcodeMaster.ShopID = ' + this.data.ShopID;
    }
  
    if ( this.data.SupplierID !== 0  && this.data.SupplierID !== null   ) {
      whereList = whereList + ' and PurchaseMaster.SupplierID = ' + this.data.SupplierID;
    }
    this.companyService.getGenericListByParem('ProductSummaryReport', whereList).subscribe(data => {
     
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.CreatedOn = moment(el.CreatedOn).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      this.summaryList = data.result;
      
      
      

      console.log(this.summaryList,"summmaaa")
      this.totalCalculation(this.summaryList);
      this.dtTrigger.next();
      this.dtOptions = {
      
        // Declare the use of the extension in the dom parameter
        pagingType: 'full_numbers',
        pageLength: 200000,
        
  
        dom: 'Bfrtip',
        scrollY:'50vh',
        scrollCollapse: false,
        scrollX: true,
        current:true,
        // Configure the buttons
        buttons: [
          // 'columnsToggle',
          'colvis',
          'copy',
          {
            extend: 'print',
            messageTop:  'Inventory Report Generated On ' + moment().format('LLLL'),
            exportOptions: {
              columns: ':visible',
              orientation: 'landscape'
            },
            header: true,
            title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
            
            customize: function (doc) {
              doc.defaultStyle.fontSize = 8;
              doc.defaultStyle.getElementById('exportSup') //<-- set fontsize to 16 instead of 10 
            }
          },
          // // {
          // //   extend: 'excel',
          // //   messageTop: 'Inventory Report Generated On ' + moment().format('LLLL') ,
          // //   exportOptions: {
          // //     columns: ':visible'
              
          // //   },
          //   title: JSON.parse(this.loggedInCompany).Name + ' / ' + this.loggedInShop.Name,
          // },
          {
            extend: 'pdfHtml5',
           
            messageTop: 'Inventory Report Generated On ' + moment().format('LLLL'),
            orientation: 'landscape',
            pageSize: 'LEGAL',
            exportOptions: {
              columns: ':visible',
              modifier: {
                
                
                
              }
            },
            header: true,
            title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
            customize: function (doc) {
              doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
            }
          }
        ],
        
        retrieve: false
      };
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

 

  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.data.date1 = d1;
        this.data.date2 = d2;
      }

  totalCalculation(data) {
    this.gstdividelist.forEach(ele => {
      ele.Amount = 0;
  })
  
    for (var i = 0; i < data.length; i++) {
      this.Available = this.Available + parseInt(data[i].Available);
      this.Damaged = this.Damaged + parseInt(data[i].Damaged);
      this.LostStolen = this.LostStolen + parseInt(data[i].LostStolen);
      this.totalQty = this.totalQty + parseInt(data[i].totalQty);
      this.TransferPending = this.TransferPending + parseInt(data[i].TransferPending);


      this.Sold = this.Sold + parseInt(data[i].Sold);

      this.totalGstAmount = this.totalGstAmount + parseInt(data[i].GSTAmount);
      this.totalRetailPrice = this.totalRetailPrice + data[i].Count *  parseInt(data[i].RetailPrice);
      this.totalwholesaleprice = this.totalwholesaleprice + data[i].Count *  parseInt(data[i].WholeSalePrice);
      this.totalUnitPrice = this.totalUnitPrice + parseInt(data[i].SubTotal);
      this.totalDiscountPrice = this.totalDiscountPrice + parseInt(data[i].DiscountAmount);
      this.totalAmount = this.totalAmount + parseInt(data[i].TotalAmount);
      this.gstdividelist.forEach(ele => {
        if(data[i].GSTType === ele.GstType && data[i].Status !== 0 && data[i].GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(data[i].GSTAmount);
        }
      })

      if(data[i].Status !== 0 && data[i].GSTType.toUpperCase() === 'CGST-SGST') {
         this.sgst +=  Number(data[i].GSTAmount) / 2 ;
         this.cgst +=  Number(data[i].GSTAmount) / 2 ;

      }
     }
     
  
    
  }

 

  getSupplierList() {
    this.companyService.getShortListByCompany('Supplier', 0).subscribe(data => {
      this.supplierList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result, 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.data.ShopID = this.shopList[0].ID
      }
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  generatePDF() {
    var data = document.getElementById('exportSup');
    html2canvas(data).then(canvas => {
      var imgWidth = 208;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf('p', 'mm', 'a4');
      var position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      pdf.save('newPDF.pdf');
    });
  }
  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }


  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
