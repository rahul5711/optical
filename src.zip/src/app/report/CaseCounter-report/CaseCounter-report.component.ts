import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../../services/company.service';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";
import * as XLSX from 'xlsx';
import { style } from '@angular/animations';



@Component({
  selector: 'app-CaseCounter-report',
  templateUrl: './CaseCounter-report.component.html',
  
  
})
export class CaseCounterReportComponent implements OnInit {
  fileName= 'CaseCounterReportExcel.xlsx';
  fileName1= 'CaseCounterWithdrlReportExcel.xlsx';


  dtTrigger: Subject<CaseCounterReportComponent> = new Subject();
  dtTrigger1: Subject<CaseCounterReportComponent> = new Subject();


  dtOptions: any = {};
  dtOptions1: any = {};

  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  PaymentModesList: any;

  employeeList: any;
  CashCounterReportRag: any;
  dataList1: any;
  constructor(private companyService: CompanyService,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,) { }

  filter: any =  {PaymentStatus: '', date1: moment().format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'),  ShopID: 'All', EmployeeID:'All'};
  filter1: any =  {PaymentStatus: '', date1: moment().format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'),  ShopID: 'All', EmployeeID:'All'};

  customerList: any;
  shopList = [];
  dataList= [];
  prodList: any[];
  selectedProduct: any[];
  totalAmount = 0;
  cash = 0;
  g_pay = 0;
  card = 0;
  paytm = 0;
  cheque = 0;
  bhim = 0;
  customer_return = 0;
  Customer_Reward = 0;
  paymentDetailList = [];
  range: any;
  disableDates: boolean = true;
  ngOnInit(): void {
    this.permission.forEach(element => {    
      if (element.ModuleName === 'CashCounterReport') {
             this.CashCounterReportRag = element.Edit;
           }
         });
    this.range = 'Today';
    this.getDateRange();
    
    
    this.dtOptions1 = {
      
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      pageLength: 200000,
      colReorder: true,
      dom: 'Bfrtip',
      scrollY:'50vh',
      scrollCollapse: false,
      scrollX: true,
      // Configure the buttons
      buttons: [
        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          footer: true ,
          messageTop:  'Expense Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Expense Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10;
            doc.styles.tableFooter.fontSize = 5;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // {
        //   extend: 'excel',
        //   messageTop: 'Cash Report Generated On ' + moment().format('LLLL') ,
        //   exportOptions: {
        //     columns: ':visible'
        //   },
        //   title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdfHtml5',
           footer: true ,
          messageTop: 'Expense Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          
          exportOptions: {
           
            columns: ':visible',
            modifier: {
              page: 'current'
            }
          },
          header: true,
        
          title: 'Expense Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10 ;
            doc.styles.tableFooter.fontSize = 10 ;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
        
          }
        }
      ],
      retrieve: true
    };
    this.dtOptions = {
      
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      pageLength: 200000,
      colReorder: true,
      dom: 'Bfrtip',
      scrollY:'50vh',
      scrollCollapse: false,
      scrollX: true,
      // Configure the buttons
      buttons: [
        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          footer: true ,
          messageTop:  'Expense Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Expense Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10;
            doc.styles.tableFooter.fontSize = 5;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // {
        //   extend: 'excel',
        //   messageTop: 'Cash Report Generated On ' + moment().format('LLLL') ,
        //   exportOptions: {
        //     columns: ':visible'
        //   },
        //   title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdfHtml5',
           footer: true ,
          messageTop: 'Expense Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          
          exportOptions: {
           
            columns: ':visible',
            modifier: {
              page: 'current'
            }
          },
          header: true,
        
          title: 'Expense Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10 ;
            doc.styles.tableFooter.fontSize = 10 ;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
        
          }
        }
      ],
      retrieve: true
    };
    this.spinner.show();
this.getEmployeeList();
    this.getProductList();
    this.getCustomerList();
   this.getPaymentModesList();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
    this.paymentDetailList = [];
  
  }
  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
        this.filter1.date1 = d1;
        this.filter1.date2 = d2;
      }
      searchData1() {
        this.spinner.show();
        let whereList = '';
        this.totalAmount = 0;
        this.cash = 0;
        this.g_pay = 0;
        this.card = 0;
        this.paytm = 0;
        this.cheque = 0;
        this.bhim = 0;
        this.Customer_Reward = 0;
        this.customer_return = 0;
      
            if (this.filter1.date1 !== '' && this.filter1.date1 !== null){
              let date1 =  moment(this.filter1.date1).format('YYYY-MM-DD')
              whereList = whereList + ' and DATE_FORMAT(PettyCash.CreatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
              if (this.filter1.date2 !== '' && this.filter1.date2 !== null){
                let date2 =  moment(this.filter1.date2).format('YYYY-MM-DD')
                whereList = whereList + ' and ' + `'${date2}'`; }
    
                if (this.filter1.ShopID !== 0 && this.filter1.ShopID !== null &&  this.filter1.ShopID !== 'All'){
                  whereList = whereList + ' and PettyCash.ShopID = ' +  this.filter1.ShopID; }
    
                  if (this.filter1.EmployeeID !== 0 && this.filter1.EmployeeID !== null  &&  this.filter1.EmployeeID !== 'All'){
                    whereList = whereList + ' and PettyCash.EmployeeID = ' +  this.filter1.EmployeeID; }
               
    
        this.companyService.getGenericListByParem('CashCounterReportWithdrl', whereList ).subscribe(data => {
          // let tempArray = [];
          // data.result.forEach(el => {
          //   el.PaymentDate = moment(el.PaymentDate).format(`${this.loggedInCompanySetting.DateFormat}`);
          //   tempArray.push(el);
          // })
          this.dataList1 = data.result;
    console.log(this.dataList1);
    
          this.dtTrigger1.next();
          this.spinner.hide();
    
        }, (err) => {
          console.log(err);
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Error Loading Data',
            'top',
            'right'
          );
        });
      }
  searchData() {
    this.spinner.show();
    let whereList = '';
    this.totalAmount = 0;
    this.cash = 0;
    this.g_pay = 0;
    this.card = 0;
    this.paytm = 0;
    this.cheque = 0;
    this.bhim = 0;
    this.Customer_Reward = 0;
    this.customer_return = 0;
  
        if (this.filter.date1 !== '' && this.filter.date1 !== null){
          let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
          whereList = whereList + ' and DATE_FORMAT(CashRegister.CreatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
          if (this.filter.date2 !== '' && this.filter.date2 !== null){
            let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
            whereList = whereList + ' and ' + `'${date2}'`; }

            if (this.filter.ShopID !== 0 && this.filter.ShopID !== null &&  this.filter.ShopID !== 'All'){
              whereList = whereList + ' and CashRegister.ShopID = ' +  this.filter.ShopID; }

              if (this.filter.EmployeeID !== 0 && this.filter.EmployeeID !== null  &&  this.filter.EmployeeID !== 'All'){
                whereList = whereList + ' and CashRegister.CreatedBy = ' +  this.filter.EmployeeID; }
           

    this.companyService.getGenericListByParem('CashCounterReport', whereList ).subscribe(data => {
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.PaymentDate = moment(el.PaymentDate).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      this.dataList = data.result;
console.log(this.dataList);

      this.dtTrigger.next();
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  

  totalCalculation(data) {
    this.paymentDetailList = [];
    for (var i = 0; i < data.length; i++) {
      this.totalAmount = this.totalAmount + parseInt(data[i].Amount);
      // if (data[i].PaymentMode.toUpperCase() === 'CASH') {
      //   this.cash = this.cash + parseInt(data[i].Amount);

      // } else if (data[i].PaymentMode.toUpperCase() === 'PAYTM'){
      //   this.paytm = this.paytm + parseInt(data[i].Amount);

      // }else if (data[i].PaymentMode.toUpperCase() === 'BHIM'){
      // this.bhim = this.bhim  + parseInt(data[i].Amount);
        
      // }else if (data[i].PaymentMode.toUpperCase() === 'CHEQUE'){
      // this.cheque = this.cheque + parseInt(data[i].Amount);
        
      // }else if (data[i].PaymentMode.toUpperCase() === 'CARD'){
      // this.card = this.card + parseInt(data[i].Amount);
        
      // }else if (data[i].PaymentMode.toUpperCase() === 'GPAY'){
      // this.g_pay =  this.g_pay + parseInt(data[i].Amount);  
      // } else
      if (data[i].PaymentMode === 'Customer Reward'){
        this.Customer_Reward =  this.Customer_Reward + parseInt(data[i].Amount);  
        } 
       if (data[i].PaymentMode === 'Customer Return' ){
        var negative = parseInt(data[i].Amount).toString()[0]
       if (negative !== '-') {
        this.customer_return =  this.customer_return + parseInt(data[i].Amount); 
       } 
        } 
    }

    this.PaymentModesList.forEach(ele => {
      let obj = {Mode: '', Amount: 0};
      obj.Mode = ele.Name;
      data.forEach(el => {
        if(ele.Name === el.PaymentMode && el.PaymentMode !== 'Customer Reward' && el.PaymentMode !== 'Customer Return') {
          obj.Amount += Number(el.Amount);
        }
      })
      this.paymentDetailList.push(obj);
      console.log(this.paymentDetailList, 'this.paymentDetailList');

      obj = {Mode: '', Amount: 0};

    })
  }


  getEmployeeList() {
    this.companyService.getShortListByCompany('User', 1).subscribe(data => {
      this.employeeList = data.result;
      this.spinner.hide();
    }, (err) => {
      this.spinner.hide();
      this.showNotification('bg-red','Data Not Loaded.', 'top', 'right' );
    });
  }

  getCustomerList() {
    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerList = res.result;
      this.spinner.hide();

    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getPaymentModesList() {
    this.companyService.getSupportMasterList('PaymentModeType').subscribe(data => { 
      this.PaymentModesList = data.result;
     
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }

    , (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();

    }, (err) => { console.log(err);
                   this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.filter.ShopID = this.shopList[0].ID
      }
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product',1).subscribe(data => {
      this.prodList = data.result;
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.spinner.hide();
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }
  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportSup');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
  
  }

  exportEx1(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportSup1');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName1);
  
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

   
  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
