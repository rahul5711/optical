import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../../services/company.service';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-eye-report',
  templateUrl: './eye-report.component.html',
  styleUrls: ['./eye-report.component.css']
})
export class EyeReportComponent implements OnInit {

  dtTrigger: Subject<EyeReportComponent> = new Subject();
  searchValue: any;
  fileName= 'EyeReportExcel.xlsx';

  dtOptions: any = {};
  range: any;
  disableDates: boolean = true;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  EyeRrportRag: any;

  constructor(private companyService: CompanyService,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,) { }

  filter: any =  {PaymentStatus: 'All', ProductStatus:'All' ,date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), customerID: 'All', ShopID: 0, ProductTypeName: '',FilterTypes:'CreatedOn'};

  customerList: any;
  shopList = [];
  dataList= [];
  prodList: any[];
  selectedProduct: any[];
  totalQty = 0;
  SubTotal = 0;

  totalInvoiceAmt = 0;
  totalDiscount = 0;
  totalGstAmount = 0;
  ngOnInit(): void {
    this.permission.forEach(element => {    
      if (element.ModuleName === 'EyeReport') {
             this.EyeRrportRag = element.Edit;
           }
         });
    this.range = 'Today';
    this.getDateRange();
    this.dtOptions = {
      // Declare the use of the extension in the dom parameter
      pagingType: 'full_numbers',
      pageLength: 200000,
      colReorder: true,
      dom: 'Bfrtip',
      scrollY:'50vh',
      scrollCollapse: false,
      scrollX: true,
      // Configure the buttons
      buttons: [
        // 'columnsToggle',
        'colvis',
        'copy',
        {
          extend: 'print',
          messageTop:  'Eye Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Eye Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // {
        //   extend: 'excel',
        //   messageTop: 'Eye Report Generated On ' + moment().format('LLLL') ,
        //   exportOptions: {
        //     columns: ':visible'
        //   },
        //   title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdfHtml5',
          messageTop: 'Eye Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            columns: ':visible',
            modifier: {
              columns: ':visible'
            
              
            }
          },
          header: true,
          title: 'Eye Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        }
      ],
      retrieve: true
    };
    this.spinner.show();
 
    this.getProductList();
    this.getCustomerList();
   
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
  }

  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
      }

  searchData() {
    this.spinner.show();
    let whereList = '';
    this.totalQty = 0;
    this.SubTotal = 0;
    this.totalInvoiceAmt = 0;
    this.totalDiscount = 0;
    this.totalGstAmount = 0;
    if (this.filter.date1 !== '' && this.filter.date1 !== null && this.filter.FilterTypes === 'CreatedOn'){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(spectacle_rx.CreatedOn, "%Y-%m-%d")  between' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null  && this.filter.FilterTypes === 'CreatedOn'){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; 
    }

    if (this.filter.date1 !== '' && this.filter.date1 !== null && this.filter.FilterTypes === 'ExpiryDate'){
      let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
      whereList = whereList + ' and spectacle_rx.ExpiryDate between' +  `'${date1}'`; }
      if (this.filter.date2 !== '' && this.filter.date2 !== null  && this.filter.FilterTypes === 'ExpiryDate'){
        let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
        whereList = whereList + 'and' + `'${date2}'`; 
      }
  
      if ( this.filter.ShopID !== 0 && this.filter.ShopID !== null ) {
        whereList = whereList + ' and Shop.ID = ' + this.filter.ShopID;
      }

    this.companyService.getGenericListByParem('EyeTestNotification', whereList ).subscribe(data => {
      this.dataList = data.result;
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.CreatedOn = moment(el.CreatedOn).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   el.ExpiryDate = moment(el.ExpiryDate).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      // this.dataList = tempArray;
      console.log(this.dataList,"HHH")
    
      this.dtTrigger.next();
    this.spinner.hide();

    }, (err) => {
      console.log(err);
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }



  getCustomerList() {
    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerList = res.result;
    this.spinner.hide();

    }, (err) => {
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    this.spinner.hide();

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.filter.ShopID = this.shopList[0].ID
      }
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();

      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product',1).subscribe(data => {
      this.prodList = data.result;
    this.spinner.hide();
     
    }, (err) => {
       this.spinner.hide();
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
     
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exporteye');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
  
  }


  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }
  
  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
