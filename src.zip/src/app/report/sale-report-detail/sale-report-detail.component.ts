import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../../services/company.service';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";
import jspdf from 'jspdf';
import html2canvas from 'html2canvas';
import * as XLSX from 'xlsx';
import { NgSwitchCase } from '@angular/common';
import { environment } from '../../../environments/environment';


@Component({
  selector: 'app-sale-report-detail',
  templateUrl: './sale-report-detail.component.html',
  styleUrls: ['./sale-report-detail.component.css'],
})
export class SaleReportDetailComponent implements OnInit {

  dtTrigger: Subject<SaleReportDetailComponent> = new Subject();
  dtTrigger1: Subject<SaleReportDetailComponent> = new Subject();
  env = environment;
  dtOptions: any = {};

  fileName= 'SaleDetailReportExcel.xlsx';
  fileName1= 'SaleReportExcel.xlsx';

  no = false;
  disp = true;
  disp1 = true;
  btnS = false;
  
  searchValue:any;
  EnteredValue : any;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  

  fullList: any;
  itemList= [];
  itemList1= [];
  gstdividelist = [];
  sgst = 0;
  cgst = 0;
  range: any;
  disableDates: boolean = true;
  gstList: any;
  specList: any;
  pName: any;
  SaleDetailsReportRag: any;
  SaleReportRag: any;
  customerListGST: any;
  employeeList: any;
  constructor(private companyService: CompanyService,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,) { }
              filter: any =  {PaymentStatus: 'All', ProductStatus:'All' ,date1: moment().startOf('month').format('YYYY-MM-DD'),
              date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), customerID: 'All', ShopID: 0, ProductTypeName: '',FilterTypes:'BillDate',customerGSTNo:'All', EmployeeID:'All'};
            
              data = {CustomerName: false, MobileNo : false, InvoiceNo:false, InvoiceDate:false,ShopName:false,PaymentStatus:false,Qty:false,Discount:false, SubTotal:false, GSTAmount:false, GrandTotal:false, ProductStatus:false,  DeliveryDate:false, }

  filter2: any =  {PaymentStatus: 'All',ProductStatus:'All', date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'),customerID: 'All', ShopID: 0, ProductCategory:'All', ProductName: '' ,  GSTType:'All',FilterTypes:'BillDate',GSTPercentage:'All',Option:'All',customerGSTNo:'All', Status:'All'};

  customerList: any;
  shopList = [];
  detailList = [];

  dataList: any;
  prodList: any[];
  selectedProduct: any[];
  totalQty = 0;
  subTotal = 0;
  totalInvoiceAmt = 0;
  totalDiscount = 0;
  totalGstAmount = 0;

  
  SubTotal = 0;
  
  Paid = 0;
  Balance = 0;
  AddlDiscount1 = 0;
 
  ngOnInit(): void {
    this.permission.forEach(element => {    
      if (element.ModuleName === 'SaleReport') {
             this.SaleReportRag = element.Edit;
           }
         });
         this.permission.forEach(element => {    
          if (element.ModuleName === 'SaleDetailsReport') {
                 this.SaleDetailsReportRag = element.Edit;
               }
               
             });
    this.spinner.show();
    this.range = 'Today';
    this.dtOptions = {
  
      pagingType: 'full_numbers',
      pageLength: 200000,
      colReorder: true,
      dom: 'Bfrtip',
      scrollY:'45vh',
      scrollCollapse: false,
      scrollX: true,
 
      buttons: [
      
        'colvis',
        'copy',
        {
          extend: 'print',
          messageTop:  'Sale Report Generated On ' + moment().format('LLLL'),
          exportOptions: {
            columns: ':visible',
            orientation: 'landscape'
          },
          header: true,
          title: 'Sale Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        },
        // {
        //   extend: 'excel',
        //   messageTop: 'Sale Report Generated On ' + moment().format('LLLL') ,
        //   exportOptions: {
        //     columns: ':visible'
        //   },
        //   title: this.loggedInCompany.Name + ' / ' + this.loggedInShop.Name,
        // },
        {
          extend: 'pdfHtml5',
          footer: true ,
          messageTop: 'Sale Report Generated On ' + moment().format('LLLL'),
          orientation: 'landscape',
          pageSize: 'LEGAL',
          exportOptions: {
            columns: ':visible',
            modifier: {
              page: 'current'
            }
          },
          header: true,
          title: 'Sale Report' + ' / ' + this.loggedInShop.Name + ' / ' + this.loggedInShop.AreaName,
          customize: function (doc) {
            doc.styles.tableHeader.fontSize = 10 ;
            doc.styles.tableFooter.fontSize = 8 ;
            doc.styles.tableHeader.alignment = 'left';
            doc.styles.tableFooter.alignment = 'left';
            doc.styles.tableFooter.fillColor = 'red';
            doc.styles.tableFooter.width = 50;
            doc.styles.tableFooter.whiteSpace = 'normal';
            doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
          }
        }
      ],
      
    
      retrieve: true


      
    };
    this.getGstList();
    this.getDateRange();
    this.getEmployeeList();
    
    this.getProductList();
    this.getCustomerListGST();
    this.spinner.show();
    this.getCustomerList();
    if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
      this.getShopListByID();
    } else {
      this.getShopList();

    }
   
  
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
        this.filter2.date1 = d1;
        this.filter2.date2 = d2;
      }

      getGstList() {
        this.companyService.getSupportMasterList('TaxType').subscribe(data => { 
          this.gstList = data.result;
          this.gstdividelist = [];
      data.result.forEach(ele => {
     
        if(ele.Name.toUpperCase() !== 'CGST-SGST'){
          let obj = {GstType: '', Amount: 0};
          obj.GstType = ele.Name;
          this.gstdividelist.push(obj);

        }
      })
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          this.spinner.hide();
          this.showNotification(
            'bg-red',
            'Data Not Loaded.',
            'top',
            'right'
          );
        });
      }

//   searchData() {
//     this.spinner.show();
//     let whereList = '';
//     this.totalQty = 0;
//     this.subTotal = 0;
//     this.totalInvoiceAmt = 0;
//     this.totalDiscount = 0;
//     this.totalGstAmount = 0;
//     this.sgst = 0;
//     this.cgst = 0;
//     if (this.filter.date1 !== '' && this.filter.date1 !== null && this.filter.FilterTypes === 'BillDate'){
//       let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
//       whereList = whereList + ' and BillMaster.BillDate between' +  `'${date1}'`; }
//       if (this.filter.date2 !== '' && this.filter.date2 !== null  && this.filter.FilterTypes === 'BillDate'){
//         let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
//         whereList = whereList + 'and' + `'${date2}'`; 
//       }
  
//       if (this.filter.date1 !== '' && this.filter.date1 !== null && this.filter.FilterTypes === 'DeliveryDate'){
//         let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
//         whereList = whereList + ' and BillMaster.DeliveryDate between' +  `'${date1}'`; }
//         if (this.filter.date2 !== '' && this.filter.date2 !== null  && this.filter.FilterTypes === 'DeliveryDate'){
//           let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
//           whereList = whereList + 'and' + `'${date2}'`; 
//         }
 
//     if (this.filter.ShopID !== 0 && this.filter.ShopID !== null){
//       whereList = whereList + ' and BillMaster.ShopID = ' +  this.filter.ShopID; }
//       if (this.filter.customerID !== 0 && this.filter.customerID !== null && this.filter.customerID !== 'All'){
//         whereList = whereList + ' and BillMaster.CustomerID = ' +  this.filter.customerID ; }
//     if (this.filter.ProductTypeName !== '' && this.filter.ProductTypeName !== null){
//       whereList = whereList + ' and BillDetail.ProductTypeName = '  + `'null'` ; }
//     if (this.filter.PaymentStatus !== '' && this.filter.PaymentStatus !== null && this.filter.PaymentStatus !== 'All'){
//       whereList = whereList + ' and BillMaster.PaymentStatus = '  + `'${this.filter.PaymentStatus}'`; }
//       if (this.filter.GSTType !== '' && this.filter.GSTType !== null && this.filter.GSTType !== 'All' ){
//         whereList = whereList + ' and BillDetail.GSTType = '  + `'${this.filter.GSTType}'`; }
//         if (this.filter.GSTType !== '' && this.filter.GSTType !== null && this.filter.GSTType !== 'All' ){
//           whereList = whereList + ' and BillDetail.GSTType = '  + `'${this.filter.GSTType}'`; }
//           if (this.filter.GSTPercentage !== '' && this.filter.GSTPercentage !== null && this.filter.GSTPercentage !== 'All' ){
//             whereList = whereList + ' and BillDetail.GSTPercentage = '  + `'${this.filter.GSTPercentage}'`; }
//             if (this.filter.ProductStatus !== '' && this.filter.ProductStatus !== null && this.filter.ProductStatus !== 'All'){
//               whereList = whereList + ' and BillMaster.ProductStatus = '  + `'${this.filter.ProductStatus}'`; }

//     this.companyService.getAggregateListByParem('BillMaster1', 'BillDetail', whereList ).subscribe(data => {
     
//       // let tempArray = [];
//       // data.result.forEach(el => {
//       //   el.DeliveryDate = moment(el.DeliveryDate).format(`${this.loggedInCompanySetting.DateFormat}`);
//       //   tempArray.push(el);
//       // })
//       this.itemList = data.result;
//       this.spinner.hide();
// console.log(this.itemList)
//       this.totalCalculation(this.itemList);
//       this.dtTrigger.next();
    
      
//     }, (err) => {
//       console.log(err);
//       this.spinner.hide();
//       this.showNotification(
//         'bg-red',
//         'Error Loading Data',
//         'top',
//         'right'
//       );
//     });
//   }

searchData() {
  this.spinner.show();
  let whereList = '';
  this.totalQty = 0;
  this.SubTotal = 0;
  this.totalInvoiceAmt = 0;
  this.totalDiscount = 0;
  this.totalGstAmount = 0;
  this.Paid = 0;
  this.Balance = 0;
  this.AddlDiscount1 = 0;
  this.sgst = 0;
  this.cgst = 0;
 
  if (this.filter.date1 !== '' && this.filter.date1 !== null && this.filter.FilterTypes === 'BillDate'){
  let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
  whereList = whereList + ' and BillMaster.BillDate between' +  `'${date1}'`; }
  if (this.filter.date2 !== '' && this.filter.date2 !== null  && this.filter.FilterTypes === 'BillDate'){
    let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
    whereList = whereList + 'and' + `'${date2}'`; 
  }

  if (this.filter.date1 !== '' && this.filter.date1 !== null && this.filter.FilterTypes === 'DeliveryDate'){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and BillMaster.DeliveryDate between' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null  && this.filter.FilterTypes === 'DeliveryDate'){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; 
    }
  if (this.filter.ShopID !== 0 && this.filter.ShopID !== null){
    whereList = whereList + ' and BillMaster.ShopID = ' +  this.filter.ShopID; }
    if (this.filter.customerID !== 0 && this.filter.customerID !== null && this.filter.customerID !== 'All'){
      whereList = whereList + ' and BillMaster.CustomerID = ' +  this.filter.customerID ; }
  if (this.filter.ProductTypeName !== '' && this.filter.ProductTypeName !== null){
    whereList = whereList + ' and BillDetail.ProductTypeName = '  + `'null'` ; }
  if (this.filter.PaymentStatus !== '' && this.filter.PaymentStatus !== null  && this.filter.PaymentStatus !== 'All'){
    whereList = whereList + ' and BillMaster.PaymentStatus = '  + `'${this.filter.PaymentStatus}'`; }
    if (this.filter.ProductStatus !== '' && this.filter.ProductStatus !== null  && this.filter.ProductStatus !== 'All'){
      whereList = whereList + ' and BillDetail.ProductStatus = '  + `'${this.filter.ProductStatus}'`; }
      if (this.filter.customerGSTNo !== 0 && this.filter.customerGSTNo !== null && this.filter.customerGSTNo !== 'All'){
        whereList = whereList + ' and Customer.GSTNo = ' +  this.filter.customerGSTNo ; }

        if (this.filter.EmployeeID !== 0 && this.filter.EmployeeID !== null && this.filter.EmployeeID !== 'All'){
          whereList = whereList + ' and BillMaster.Employee = ' +  this.filter.EmployeeID ; }
          
  this.companyService.getGenericListByParem('SaleReport', whereList ).subscribe(data => {


    // let tempArray = [];
    // data.result.forEach(el => {
    //   el.BillDate = moment(el.BillDate).format(`${this.loggedInCompanySetting.DateFormat}`);
    //   el.ProductDeliveryDate = moment(el.ProductDeliveryDate).format(`${this.loggedInCompanySetting.DateFormat}`);

    //   tempArray.push(el);
    // })
    this.dataList = data.result;

  this.spinner.hide();
 


    console.log(this.dataList,"HHH")
    this.totalCalculation1(this.dataList);
    this.dtTrigger.next();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}
  searchData1() {
    this.spinner.show();
    this.itemList1 = [];
    let whereList = '';

    this.totalQty = 0;
    this.subTotal = 0;
    this.totalInvoiceAmt = 0;
    this.totalDiscount = 0;
    this.totalGstAmount = 0;
    this.sgst = 0;
    this.cgst = 0;
    if (this.filter2.date1 !== '' && this.filter2.date1 !== null && this.filter2.FilterTypes === 'BillDate'){
      let date1 =  moment(this.filter2.date1).format('YYYY-MM-DD')
      whereList = whereList + ' and BillMaster.BillDate between' +  `'${date1}'`; }
      if (this.filter2.date2 !== '' && this.filter2.date2 !== null  && this.filter2.FilterTypes === 'BillDate'){
        let date2 =  moment(this.filter2.date2).format('YYYY-MM-DD')
        whereList = whereList + 'and' + `'${date2}'`; 
      }
  
      if (this.filter2.date1 !== '' && this.filter2.date1 !== null && this.filter2.FilterTypes === 'DeliveryDate'){
        let date1 =  moment(this.filter2.date1).format('YYYY-MM-DD')
        whereList = whereList + ' and BillMaster.DeliveryDate between' +  `'${date1}'`; }
        if (this.filter2.date2 !== '' && this.filter2.date2 !== null  && this.filter2.FilterTypes === 'DeliveryDate'){
          let date2 =  moment(this.filter2.date2).format('YYYY-MM-DD')
          whereList = whereList + 'and' + `'${date2}'`; 
        }
  
    
        if (this.filter.ShopID !== 0 && this.filter.ShopID !== null){
          whereList = whereList + ' and BillMaster.ShopID = ' +  this.filter.ShopID; }

      if (this.filter.ShopID !== 0 && this.filter.ShopID !== null){
        whereList = whereList + ' and BillMaster.ShopID = ' +  this.filter.ShopID; }
      
      if (this.filter2.customerID !== 0 && this.filter2.customerID !== null && this.filter2.customerID !== 'All'){
        whereList = whereList + ' and BillMaster.CustomerID = ' +  this.filter2.customerID ; }

    if ( this.filter2.ProductCategory !== 'All'){
      this.prodList.forEach(ele => {
        if (ele.ID === this.filter2.ProductCategory) {
          whereList = whereList + ' and BillDetail.ProductTypeName = ' +  `'${ele.Name}'` ;
        }
      })
      this.filters();
       }
      if (this.filter2.ProductName !== '') {
        whereList = whereList + ' and BillDetail.ProductName Like ' + '"' + this.filter2.ProductName + '%"';
      }
    if (this.filter2.PaymentStatus !== '' && this.filter2.PaymentStatus !== null && this.filter2.PaymentStatus !== 'All'){
      whereList = whereList + ' and BillMaster.PaymentStatus = '  + `'${this.filter2.PaymentStatus}'`; }
      if (this.filter2.GSTType !== '' && this.filter2.GSTType !== null &&  this.filter2.GSTType !== 'All'){
        whereList = whereList + ' and BillDetail.GSTType = '  + `'${this.filter2.GSTType}'`; }
        if (this.filter2.GSTPercentage !== '' && this.filter2.GSTPercentage !== null && this.filter2.GSTPercentage !== 'All' ){
          whereList = whereList + ' and BillDetail.GSTPercentage = '  + `'${this.filter2.GSTPercentage}'`; }
          if (this.filter2.ProductStatus !== '' && this.filter2.ProductStatus !== null && this.filter2.ProductStatus !== 'All'){
            whereList = whereList + ' and BillDetail.ProductStatus = '  + `'${this.filter2.ProductStatus}'`; }
            if (this.filter2.Option !== '' && this.filter2.Option !== null && this.filter2.Option !== 'All'){
              whereList = whereList + ' and BarcodeMaster.Option = '  + `'${this.filter2.Option}'`; }
              
              if (this.filter2.Status !== '' && this.filter2.Status !== null && this.filter2.Status !== 'All'){
                if(this.filter2.Status === 'Manual' && this.filter2.Status !== 'All'){
                  whereList = whereList + ' and BillDetail.Manual = '  + '1'; 
                }else if(this.filter2.Status === 'PreOrder'&& this.filter2.Status !== 'All'){
                  whereList = whereList + ' and BillDetail.PreOrder = '  + '1'; 
                } else if(this.filter2.Status === 'Barcode' && this.filter2.Status !== 'All'){
                  whereList = whereList + ' and BillDetail.PreOrder = '  + '0'; 
                  whereList = whereList + ' and BillDetail.Manual = '  + '0'; 
                }
                }
               

              if (this.filter2.customerGSTNo !== 0 && this.filter2.customerGSTNo !== null && this.filter2.customerGSTNo !== 'All'){
                whereList = whereList + ' and Customer.GSTNo = ' +  this.filter2.customerGSTNo ; }
                this.companyService.getGenericListByParem('saleTypeReport', whereList ).subscribe(data => {
      // this.companyService.getGenericListByParem('saleTypeReport', whereList )
      // let tempArray = [];
      // data.result.forEach(el => {
      //   el.ProductDeliveryDate = moment(el.ProductDeliveryDate).format(`${this.loggedInCompanySetting.DateFormat}`);
      //   tempArray.push(el);
      // })
      this.itemList1 = data.result;
     
console.log(this.itemList1);
      this.totalCalculation(this.itemList1);
      this.dtTrigger.next();
    this.spinner.hide();
      
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }
  
 


  generatePDF() {
    var data = document.getElementById('exportSup');
    html2canvas(data).then(canvas => {
      var imgHeight = canvas.height * 200 / canvas.width;
      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf();
      pdf.addImage(contentDataURL, 0, 0, 200, imgHeight)
      pdf.save('newPDF.pdf');
    });
  }

  totalCalculation(data) {
    this.gstdividelist.forEach(ele => {
      ele.Amount = 0;
  })
 
    for (var i = 0; i < data.length; i++) {
      this.totalQty = this.totalQty + data[i].Quantity;
      this.subTotal = this.convertToDecimal(this.subTotal + data[i].SubTotal,2);
      this.totalGstAmount =  this.convertToDecimal(this.totalGstAmount + data[i].GSTAmount,2);
      // this.billItem.SubTotal = this.convertToDecimal(+this.billItem.SubTotal, 2);
      this.totalInvoiceAmt =  this.convertToDecimal(this.totalInvoiceAmt + data[i].TotalAmount,2);
      this.totalDiscount =  this.convertToDecimal(this.totalDiscount + data[i].DiscountAmount,2);
      this.gstdividelist.forEach(ele => {
        if(data[i].GSTType === ele.GstType && data[i].Status !== 0 && data[i].GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount +=  data[i].GSTAmount;
        }
      })

      if(data[i].Status !== 0 && data[i].GSTType.toUpperCase() === 'CGST-SGST') {
         this.sgst +=  Number(data[i].GSTAmount) / 2 ;
         this.cgst +=  Number(data[i].GSTAmount) / 2 ;

      }
    }
console.log(this.totalGstAmount,' this.totalGstAmount');

  }
  totalCalculation1(data) {
    this.gstdividelist.forEach(ele => {
      ele.Amount = 0;
  })
    for (var i = 0; i < data.length; i++) {
      this.totalQty = this.totalQty + (data[i].Quantity);
      this.SubTotal = this.convertToDecimal(this.SubTotal + data[i].SubTotal,2);
      this.totalGstAmount = this.convertToDecimal(this.totalGstAmount + data[i].GSTAmount,2);
      this.totalInvoiceAmt = this.convertToDecimal(this.totalInvoiceAmt + data[i].TotalAmount,2);
      this.Balance = this.convertToDecimal(this.Balance +  data[i].DueAmount,2);
      this.AddlDiscount1 = this.convertToDecimal(this.AddlDiscount1 +  data[i].AddlDiscount,2);
      this.totalDiscount = this.convertToDecimal(this.totalDiscount + data[i].DiscountAmount,2);
      this.gstdividelist.forEach(ele => {
        if(data[i].GSTType === ele.GstType && data[i].Status !== 0 && data[i].GSTType.toUpperCase() !== 'CGST-SGST') {
          ele.Amount += Number(data[i].GSTAmount);
        }
      })
      if(data[i].Status !== 0 && data[i].GSTType.toUpperCase() === 'CGST-SGST') {
        this.sgst +=  Number(data[i].GSTAmount) / 2 ;
        this.cgst +=  Number(data[i].GSTAmount) / 2 ;
     }
    }
    this.Paid = (this.totalInvoiceAmt-this.AddlDiscount1) -  this.Balance ;
  }
 1
  convertToDecimal(num, x) {
    return Number(Math.round(parseFloat(num + 'e' + x)) + 'e-' + x);
  }
  getCustomerListGST() {
    this.spinner.show();

    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerListGST = res.result.filter(f => f.GSTNo !== '');
    this.spinner.hide();

    }, (err) => {
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  getCustomerList() {
    this.spinner.show();

    this.companyService.getShortListByCompany('Customer',1).subscribe(res => {
      this.customerList = res.result;
    this.spinner.hide();

    }, (err) => {
    this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  getShopList() {
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();

    }, (err) => { console.log(err);
      this.spinner.hide();

                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getShopListByID() {
    this.companyService.getShortDataByID('Shop', this.loggedInShop.ShopID).subscribe(data => {
      console.log(data.result , 'shoplistttt');
      this.shopList.push(data.result);
      if(this.shopList.length === 1) {
        this.filter.ShopID = this.shopList[0].ID
      }
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();

      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }



  getProductList() {
    this.companyService.getShortListByCompanyOrderBy('Product',1).subscribe(data => {
      this.prodList = data.result;
    this.spinner.hide();
     
    }, (err) => {
       this.spinner.hide();
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
     
      this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
    });
  }

  getfieldList() {
    if(this.filter2.ProductCategory !== 'All'){

   
    this.prodList.forEach(element => {
      if (element.ID === this.filter2.ProductCategory) {
        this.selectedProduct = element.Name;
        this.pName = element.Name.toUpperCase();
      }
    })
    this.companyService.getProdFieldList(this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      this.getSptTableData();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      // this.showFailure(err, 'Error Loading Data.');
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }else{
    this.specList = [];
    this.filter2.ProductName = '';
    this.filter2.ProductCategory = 'All';
  }
  }

  getSptTableData() {
    this.specList.forEach(element => {
      if (element.FieldType === 'DropDown' && element.Ref === '0') {
        this.companyService.getProductSupportData(element.SptTableName, '0').subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  getFieldSupportData(index) {
    this.specList.forEach(element => {
      if (element.Ref === this.specList[index].FieldName.toString()) {
        this.companyService.getProductSupportData(element.SptTableName, this.specList[index].SelectedValue).subscribe(data => {
          element.SptTableData = data.result;
          element.SptFilterData = data.result;
          this.showNotification(
            'bg-green',
            'Data Loaded successfully',
            'top',
            'right'
          );
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      }
    });

  }

  filters() {
    let productName = '';
    let productcat = '';
    this.specList.forEach(element => {
      if (productName === '') {
        productName =  element.SelectedValue;
      } else if (element.SelectedValue !== '') {
        productName += '/' + element.SelectedValue;
      }
    });
    this.filter2.ProductName =  productName;
  }

  exportEx(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportSup');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
  
  }
  exportEx1(): void
  {
    /* pass here the table id */
    let element = document.getElementById('exportSale');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
  
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
    /* save to file */  
    XLSX.writeFile(wb, this.fileName1);
  
  }
  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

   getEmployeeList() {
    this.companyService.getShortListByCompany('User', 1).subscribe(data => {
      this.employeeList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }
  
  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
