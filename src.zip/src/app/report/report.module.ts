import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatRadioModule} from '@angular/material/radio';
import {MatListModule} from '@angular/material/list';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxSpinnerModule } from 'ngx-spinner';

import { ReportRoutingModule } from './report-routing.module';
import { ReportComponent } from './report.component';
import { InventoryReportComponent } from './inventory-report/inventory-report.component';
import { SaleReportComponent } from './sale-report/sale-report.component';
import { TransferReportComponent } from './Transfer-product-report/Transfer-report.component';

import { SaleReportDetailComponent } from './sale-report-detail/sale-report-detail.component';
import { ProductExpiryReportComponent } from './product-expiry-report/product-expiry-report.component';


import { CashReportComponent } from './cash-report/cash-report.component';
import { ExpenseReportComponent } from './expense-report/expense-report.component';
import { PettyCaseReportComponent } from './pettyCase-report/pettyCase-report.component';
import { CaseCounterReportComponent } from './CaseCounter-report/CaseCounter-report.component';




import { PurchaseReportComponent } from './purchase-report/purchase-report.component';

import { AccountingReportComponent } from './accounting-report/accounting-report.component';
import { CustomerReportComponent } from './customer-report/customer-report.component';
import { DataTablesModule } from 'angular-datatables';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { NameFilterSaleCustomer} from './../filter/nameFilterSaleCustomer';
import { ReportItemFilterSep} from './../filter/reportitemFilterSep';
import { EyeReportComponent } from './eye-report/eye-report.component';
import { ServiceReportComponent } from './service-report/service-report.component';
import { ReminderReportComponent } from './reminder-report/reminder-report.component';
import { LaserReportComponent } from './laser-report/laser-report.component';
import { ProductSummaryComponent } from './product-summary/product-summary.component';
import { ProfitComponent } from './profit/profit.component';
import { Inventory2ReportComponent } from './inventory2-report/inventory2-report.component';







@NgModule({
  declarations: [ReportComponent,EyeReportComponent, LaserReportComponent,ServiceReportComponent, NameFilterSaleCustomer, ReportItemFilterSep ,ProductExpiryReportComponent, InventoryReportComponent, SaleReportComponent,TransferReportComponent, SaleReportDetailComponent,CashReportComponent, ExpenseReportComponent,PettyCaseReportComponent,CaseCounterReportComponent, PurchaseReportComponent, AccountingReportComponent, CustomerReportComponent,ReminderReportComponent,ProductSummaryComponent, ProfitComponent, Inventory2ReportComponent],
  imports: [
    CommonModule,
    ReportRoutingModule,
    NgxDatatableModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSlideToggleModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSortModule,
    MatToolbarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatTabsModule,
    MaterialFileInputModule,
    NgxSpinnerModule,
    PerfectScrollbarModule,
    MatRadioModule,
    MatListModule,
    NgxMatSelectSearchModule,
    DataTablesModule
  ]
})
export class ReportModule { }
