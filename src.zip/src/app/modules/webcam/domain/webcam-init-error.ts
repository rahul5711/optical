export class WebcamInitError {
  public message: string = null;
  public mediaStreamError: MediaStreamError = null;
}
