import { Component, OnInit } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-product-management',
  templateUrl: './department-management.component.html'
})
export class DepartmentManagementComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

productList: any[];
specList: any;

newSpec: any = {ID : null, ProductName: '', Name : '', Seq: null,  Type: '', Ref: 0, SptTableName: ''  };
selectedDepartment: any = '';
selectedDepartmentHead: any = '';
depList: any[];
showAdd = false;
newDepartment = {ID: null, CompanyID: null, Name: "", DepartmentHead: "", ShopID: null, Status: 1};
fieldType: any[] = [{ID: 1, Name: "DropDown"}, {ID: 2, Name: "Text"}, {ID: 3, Name: "boolean"}];
  selectedDepartmentID: any;
  editDepartmentManagement: any;
  addDepartmentManagement: any;
  deleteDepartmentManagement: any;

constructor(private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
            private spinner: NgxSpinnerService,
            private snackBar: MatSnackBar
) {}

  ngOnInit() {
    this.spinner.show();
    this.getDepartmentList();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'DepartmentManagement') {
             this.editDepartmentManagement = element.Edit;
             this.addDepartmentManagement = element.Add;
             this.deleteDepartmentManagement = element.Delete;
           }
         });
  
  }

  showData(){
    this.depList.forEach(element => {
      if (element.Name === this.selectedDepartment)
       {this.selectedDepartmentHead = element.DepartmentHead; this.selectedDepartmentID = element.ID; }
    });
  }

  getDepartmentList(){
    this.companyService.getShortListByCompany('Department', 1).subscribe(data => {
        this.depList = data.result;
        this.spinner.hide();
      }, (err) => { console.log(err);
        this.spinner.hide();
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }


  saveDepartment(){
    if (this.newDepartment.Name !== ''){
      this.companyService.saveData('Department', this.newDepartment).subscribe(data => {
        this.getDepartmentList();
        }, (err) => { console.log(err);
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
    }
  }

  deleteDepartment(){
    this.spinner.show();
      this.companyService.deleteData('Department', this.selectedDepartmentID).subscribe(data => {
        this.selectedDepartmentHead = "";
      this.getDepartmentList();
      this.spinner.hide();
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }



  onSubmit() {
   
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
