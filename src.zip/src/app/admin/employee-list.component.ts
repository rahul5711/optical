import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import * as moment from 'moment';
import { count, findIndex } from 'rxjs/operators';



@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styles: ['.CompanyAdmin_class { color: #2d56c3; background-color: #ff944f9e;}']
})
export class EmployeeListComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  permission = JSON.parse(localStorage.getItem('Permission'));
 
  dataList: any;
  temp = [];
  term:any;
  stringUrl: string;
  editEmployeeList = false;
  // addEmployeeList = false.toString();
  addEmployeeList = false;
  deleteEmployeeList = false;
  datasList: any[];
  mode: any;
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute) { }

    gridview = true;
    reslat = [];
  ngOnInit() {
   
    this.permission.forEach(element => {    
 if (element.ModuleName === 'EmployeeList') {
        this.editEmployeeList = element.Edit;
        this.addEmployeeList = element.Add;
        this.deleteEmployeeList = element.Delete;  
      }
      
    });

   
    this.spinner.show();
    this.companyService.getExtendedListByCompany1('UserFullList', this.loggedInCompany.ID, this.loggedInShop.ID).subscribe(data => {
      // let tempArray = [];
      //   data.result.forEach(el => {
      //     el.Anniversary = moment(el.Anniversary).format(`${this.loggedInCompanySetting.DateFormat}`);
      //     el.DOB = moment(el.DOB).format(`${this.loggedInCompanySetting.DateFormat}`);

      //     tempArray.push(el);
      //   })
        this.dataList = data.result;

       
        
   
      this.santizePictureList();
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  
  }

  santizePictureList() {
    this.dataList.forEach(element => {
      element.PhotoURL = this.sanitize(element.PhotoURL);
    });
  }

  sanitize(imgName: string) {
    if (imgName !== null && imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
    } else {
      this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
    return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('User', this.dataList[i].ID).subscribe(data => {
          this.dataList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  // deleteItem(i){
  //   let yes = confirm("Are you sure want to delete");
  //   if (yes) {
  //   this.companyService.deleteData('User', this.dataList[i].ID).subscribe(data => {
  //   this.dataList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  // }
  //   }


  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }
  

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}


function checkAdult(checkAdult: any) {
  throw new Error('Function not implemented.');
}

