import { Component, OnInit } from '@angular/core';
import { Shop} from '../model/Shop';
import { CompanyService} from '../services/company.service';
import { AdminService} from '../services/admin.service';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { ThemePalette } from '@angular/material/core';
import { Subject } from 'rxjs';
import * as moment from 'moment';


@Component({
  selector: 'app-CompanyLoginHistory',
  templateUrl: './CompanyLoginHistory.component.html',
  styleUrls: ['./CompanyLoginHistory.component.css']
})
export class CompanyLoginHistoryComponent implements OnInit {
  dtTrigger: Subject<CompanyLoginHistoryComponent> = new Subject();
  dtTrigger1: Subject<CompanyLoginHistoryComponent> = new Subject();

  dtOptions: any = {};
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  data: any={ Company:'All'}
  filter: any =  { date1: moment().startOf('month').format('YYYY-MM-DD'), date2: moment().add( 2 , 'days').format('YYYY-MM-DD'),};

  
stringUrl: string;
  dataList: any;
  term:any;
  range: any;
  disableDates: boolean = true;
  companyList: any;
  constructor(private companyService: CompanyService,
              private adminService: AdminService,
              private router: Router,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,
              private sanitizer: DomSanitizer,
              private route: ActivatedRoute,
) {}


ngOnInit(){
  this.range = 'Today';
  this.getDateRange();
  this.dtOptions = {
    // Declare the use of the extension in the dom parameter
    pagingType: 'full_numbers',
    pageLength: 100,
    colReorder: true,
    dom: 'Bfrtip',
    scrollY:'50vh',
    scrollCollapse: false,
    scrollX: true,
    // Configure the buttons
    buttons: [
      // 'columnsToggle',
      'colvis',
      'copy',
      {
        extend: 'print',
        messageTop:  'Cash Report Generated On ' + moment().format('LLLL'),
        exportOptions: {
          columns: ':visible',
          orientation: 'landscape'
        },
        header: true,
        title: this.loggedInCompany + ' / ' ,
        customize: function (doc) {
          doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
        }
      },
      {
        extend: 'excel',
        messageTop: 'Cash Report Generated On ' + moment().format('LLLL') ,
        exportOptions: {
          columns: ':visible'
        },
        title: this.loggedInCompany + ' / ' ,
      },
      {
        extend: 'pdfHtml5',
        messageTop: 'Cash Report Generated On ' + moment().format('LLLL'),
        orientation: 'landscape',
        pageSize: 'LEGAL',
        exportOptions: {
          modifier: {
            page: 'current'
          }
        },
        header: true,
        title: this.loggedInCompany + ' / ' ,
        customize: function (doc) {
          doc.defaultStyle.fontSize = 8; //<-- set fontsize to 16 instead of 10 
        }
      }
    ],
    retrieve: true
  };
  this.getList();
  this.onSubmit();
  
 
  
}

getList() {
  this.adminService.getCompanyList('Company').subscribe(data => {
    this.companyList = data.result;
    
  
    this.spinner.hide();
    this.showNotification(
      'bg-green',
      'Data Loaded successfully',
      'top',
      'right'
    );
  }, (err) => { console.log(err);
                this.spinner.hide();
                this.showNotification(
                  'bg-red',
                  'Data Not Loaded.',
                  'top',
                  'right'
                );
              });
}

// onPlanChange(value){  
//   if(this.id !== 0) {
//     this.data.EffectiveDate = new Date();
//   }
//   if (value === 1) {
//       const d = new Date().setDate(this.data.EffectiveDate.getDate() + 15);
//       const date = new Date(d);
//       this.data.CancellationDate = date;
//   }
//   if (value === 2) {
//     const e = new Date().setDate(this.data.EffectiveDate.getDate() + 30);
//     const date1 = new Date(e);
//     this.data.CancellationDate = date1;
//   }
//   if (value === 3) {
//   const f = new Date().setDate(this.data.EffectiveDate.getDate() + 181);
//   const date2 = new Date(f);
//   this.data.CancellationDate = date2;
//   }
//   if (value === 4) {
//     const a = new Date().setDate(this.data.EffectiveDate.getDate() + 365);
//     const date3 = new Date(a);
//     this.data.CancellationDate = date3;
//     }
// }
onSubmit() {
let whereList = '';

if (this.filter.date1 !== '' && this.filter.date1 !== null){
  let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
  whereList = whereList + ' and DATE_FORMAT(LoginHistory.LoginTime, "%Y-%m-%d")  between ' +  `'${date1}'`; }
  if (this.filter.date2 !== '' && this.filter.date2 !== null){
    let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
    whereList = whereList + ' and ' + `'${date2}'`; }
  if (this.data.Company !== 0 && this.data.Company !== 'All' ){
    whereList = whereList + ' and LoginHistory.CompanyID = ' +  this.data.Company; }
  

this.adminService.getfilterList('getLoginHistory', whereList).subscribe(data => {
  this.dataList = data.result;
  this.dtTrigger.next();
}, (err) => {
  console.log(err);
});

}

getDateRange(){
  let d1 = moment().startOf('month').format('YYYY-MM-DD');
  let d2 = moment().format('YYYY-MM-DD'); 
  if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
      switch (this.range) {
        case "Today":
          d1 = moment().format('YYYY-MM-DD');
          d2 = moment().format('YYYY-MM-DD');
          break;
        case "Yesterday":
          d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
          d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
          break;
        case "This Week":
          d1 = moment().startOf('week').format('YYYY-MM-DD'); 
          d2 = moment().format('YYYY-MM-DD');
          break;
        case "Last Week":
          d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
          d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
          break;
        case "This Month":
          d1 = moment().startOf('month').format('YYYY-MM-DD'); 
          d2 = moment().format('YYYY-MM-DD');
        break;
        case "Last Month":
          d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
          d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
          break;
        case "This Quarter":
          d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
          d2 = d2 = moment().format('YYYY-MM-DD');
          break;
        case "Last Quarter":
          d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
          d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
          break;
        case "This Year":
          d1 = moment().startOf('year').format('YYYY-MM-DD'); 
          d2 = d2 = moment().format('YYYY-MM-DD');
          break;
        case "Last Year":
          d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
          d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
          break;
                
        default:
          
          break;
      }
      this.filter.date1 = d1;
      this.filter.date2 = d2;
    }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


}
