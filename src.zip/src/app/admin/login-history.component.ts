import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { CompanyService} from '../services/company.service';
import {DomSanitizer} from '@angular/platform-browser';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from '../../environments/environment';
import * as moment from 'moment';

@Component({
  selector: 'app-login-history',
  templateUrl: './login-history.component.html',
  styleUrls: ['./login-history.component.css'],
  
})

export class LoginHistoryComponent implements OnInit {

  term:any;
  gridview = true;
  env = environment;
  stringUrl: string;
  dataList: any;
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));


  filter: any =  {PaymentStatus: '', date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), UserID: 0,  };
  range: string;
  disableDates: boolean;
  itemList: any;
  userList: any;
  
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.range = 'Today';
    this.getDateRange();
    this.getuserList();
    this.spinner.show();
    this.companyService.getShortListByCompany('LoginHistory', 1).subscribe(data => {
      // let tempArray = [];
      //     data.result.forEach(el => {
      //       el.LoginTime = moment(el.LoginTime).format(`${this.loggedInCompanySetting.DateFormat}`);
      //       tempArray.push(el);
      //     })
          this.dataList = data.result;
      this.spinner.hide();
     
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
    
  }
  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
      }
 
  searchData() {
    this.spinner.show();
    let whereList = '';
  
    if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(LoginHistory.LoginTime, "%Y-%m-%d")  between' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
    if (this.filter.UserID !== 0 && this.filter.UserID !== null){
      whereList = whereList + ' and LoginHistory.UserID = ' +  this.filter.UserID; }
    
      
   
      
        this.companyService.getGenericListByParem('FilterLoginHistory', whereList ).subscribe(data => {
          let tempArray = [];
          data.result.forEach(el => {
            el.LoginTime = moment(el.LoginTime).format(`${this.loggedInCompanySetting.DateFormat}`);
            tempArray.push(el);
          })
          this.dataList = tempArray;
;
    this.spinner.hide();
      
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data',
        'top',
        'right'
      );
    });
  }

  getuserList() {
    this.companyService.getShortListByCompany('User',1).subscribe(data => {
      this.userList = data.result;
      this.spinner.hide();

    }, (err) => { console.log(err);
      this.spinner.hide();

                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  convertDate(date){
    return moment(date).format(`${this.loggedInCompanySetting.DateFormat}`);
   }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


}

