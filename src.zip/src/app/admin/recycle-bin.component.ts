import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { CompanyService} from '../services/company.service';
import {DomSanitizer} from '@angular/platform-browser';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from '../../environments/environment';
import * as moment from 'moment';

@Component({
  selector: 'app-recycle-bin',
  templateUrl: './recycle-bin.component.html',

})
export class RecycleBinComponent implements OnInit {

  term:any;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  suppliers: any;
  customers: any;
  shops: any;
  purchases: any;
  range: any;
  disableDates: boolean = true;
  whereList = '';
  filter: any =  {date1: moment().startOf('month').format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), UserID:'All',};
  userList: any;
  Employees: any;
  doctors: any;
  fitters: any;
  employees: any;
  userLists: any;
  dataList: any;
  constructor(
    private companyService: CompanyService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    // this.spinner.show();
    this.range = 'Today';
    this.getDateRange();
    this.getSuppliers();
    this.getCustomers();
    this.getShops();
    this.getPurchases();
    this.getDoctor();
    this.getFitter();
    this.getuserList();
    this.getuserLists();
    this.getBillMaster();
   
    
  }
  getBillMaster() {
  
    this.companyService.getdeletedata('BillMaster').subscribe(data => {
      this.dataList = data.data;
      console.log( this.dataList,' this.dataList');
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }
  

  getSuppliers() {
    this.spinner.show();
    this.companyService.getdeletedata('Supplier').subscribe(data => {
      this.spinner.hide();
      this.suppliers = data.data;
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getCustomers() {
    this.spinner.show();
    this.companyService.getdeletedata('Customer').subscribe(data => {
      this.spinner.hide();
      this.customers = data.data;
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }


  getuserLists() {
    this.companyService.getShortListByCompany('User',1).subscribe(data => {
    this.userLists = data.result;
    this.spinner.hide();
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getuserList() {
    this.companyService.getGenericListByParem('deleteUsers', '').subscribe(data => {
      this.userList = data.result;
      this.spinner.hide();
      console.log(this.userList , 'userList');

    }, (err) => { console.log(err);
      this.spinner.hide();

                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  

  getShops() {
    this.spinner.show();
    this.companyService.getdeletedata('Shop').subscribe(data => {
      this.spinner.hide();
      this.shops = data.data;
      console.log(this.shops , 'shops');

    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getPurchases() {
    this.spinner.show();
    this.companyService.getdeletedata('PurchaseMaster').subscribe(data => {
      this.spinner.hide();
      this.purchases = data.data;
      console.log(this.purchases , 'PurchaseMaster');
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

 

  getDoctor() {
    this.spinner.show();
    this.companyService.getdeletedata('Doctor').subscribe(data => {
      this.spinner.hide();
      this.doctors = data.data;
      console.log(this.doctors , 'Doctor');
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  getFitter() {
    this.spinner.show();
    this.companyService.getdeletedata('Fitter').subscribe(data => {
      this.spinner.hide();
      this.fitters = data.data;
      console.log(this.fitters , 'Fitter');
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  deletePermanent(ID, tableName) {
    this.spinner.show();
    this.companyService.deletePermanent(tableName, ID).subscribe(data => {
      this.showNotification(
        'bg-red',
        'Data Deleted',
        'top',
        'right'
      );
      if(tableName === 'Supplier') {
        this.getSuppliers(); 
       } else if (tableName === 'Customer') {
         this.getCustomers();
       }else if (tableName === 'PurchaseMaster') {
         this.getPurchases();
       }else if (tableName === 'Shop') {
        this.getShops();
       } else if (tableName === 'User') {
        this.getuserList();
       }else if (tableName === 'Doctor') {
        this.getDoctor();
       }else if (tableName === 'Fitter') {
        this.getFitter();
       }else if (tableName === 'BillMaster') {
        this.getBillMaster();
       }
      this.spinner.hide();
     
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  Retrive(ID, tableName) {
    this.spinner.show();
    this.companyService.Retrive(tableName, ID).subscribe(data => {
      this.showNotification(
        'bg-green',
        'Data Restore Successfull',
        'top',
        'right'
      );
      if(tableName === 'Supplier') {
       this.getSuppliers(); 
      } else if (tableName === 'Customer') {
        this.getCustomers();
      }else if (tableName === 'PurchaseMaster') {
        this.getPurchases();
      }else if (tableName === 'Shop') {
        this.getShops();
      }else if (tableName === 'User') {
        this.getuserList();
      }else if (tableName === 'Doctor') {
        this.getDoctor();
      }else if (tableName === 'Fitter') {
        this.getFitter();
      }else if (tableName === 'BillMaster') {
        this.getBillMaster();
       }
      this.spinner.hide()
     
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }


  getDateRange(){
    let d1 = moment().startOf('month').format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
      }

 
Search() {
  this.filterSupplier(); 
  this.filterCustomer(); 
  this.filterPurchase(); 
  this.filterShop();  
  this.getuserList();
  this.filterDoctor();
  this.filterFitter();
  this.filterBillMaster();
}


filterBillMaster() {
  
  let whereList = '';
  if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(BillMaster.UpdatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
      if (this.filter.UserID !== '' && this.filter.UserID !== null  ){
        whereList = whereList + ' and BillMaster.UpdatedBy = '  + `'${this.filter.UserID}'`; }
  this.companyService.getGenericListByParem('BillMaster', whereList ).subscribe(data => {
    this.suppliers = data.result;
    this.spinner.hide();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}

filterSupplier() {
  
  let whereList = '';
  if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(Supplier.UpdatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
      if (this.filter.UserID !== '' && this.filter.UserID !== null  ){
        whereList = whereList + ' and Supplier.UpdatedBy = '  + `'${this.filter.UserID}'`; }
  this.companyService.getGenericListByParem('Supplier', whereList ).subscribe(data => {
    this.suppliers = data.result;
    this.spinner.hide();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}

filterCustomer() {
  let whereList = '';
  if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(Customer.UpdatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
      if (this.filter.UserID !== '' && this.filter.UserID !== null  ){
        whereList = whereList + ' and Customer.UpdatedBy = '  + `'${this.filter.UserID}'`; }
  this.companyService.getGenericListByParem('FilterCustomer', whereList ).subscribe(data => {
    this.customers = data.result;
    this.spinner.hide();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}

filterPurchase() {
  let whereList = '';
  if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(PurchaseMaster.UpdatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
      if (this.filter.UserID !== '' && this.filter.UserID !== null  ){
        whereList = whereList + ' and PurchaseMaster.UpdatedBy = '  + `'${this.filter.UserID}'`; }
  this.companyService.getGenericListByParem('FilterPurchaseMaster', whereList ).subscribe(data => {
    this.purchases = data.result;
    this.spinner.hide();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}


filterShop() {
  let whereList = '';
  if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(Shop.UpdatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
      if (this.filter.UserID !== '' && this.filter.UserID !== null  ){
        whereList = whereList + ' and Shop.UpdatedBy = '  + `'${this.filter.UserID}'`; }
  this.companyService.getGenericListByParem('FilterShops', whereList ).subscribe(data => {
    this.shops = data.result;
    this.spinner.hide();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}

filterDoctor() {
  let whereList = '';
  if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(Doctor.UpdatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
      if (this.filter.UserID !== '' && this.filter.UserID !== null  ){
        whereList = whereList + ' and Doctor.UpdatedBy = '  + `'${this.filter.UserID}'`; }
  this.companyService.getGenericListByParem('FilterDoctors', whereList ).subscribe(data => {
    this.doctors = data.result;
    this.spinner.hide();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}

filterFitter() {
  let whereList = '';
  if (this.filter.date1 !== '' && this.filter.date1 !== null){
    let date1 =  moment(this.filter.date1).format('YYYY-MM-DD')
    whereList = whereList + ' and DATE_FORMAT(Fitter.UpdatedOn, "%Y-%m-%d") between ' +  `'${date1}'`; }
    if (this.filter.date2 !== '' && this.filter.date2 !== null){
      let date2 =  moment(this.filter.date2).format('YYYY-MM-DD')
      whereList = whereList + 'and' + `'${date2}'`; }
      if (this.filter.UserID !== '' && this.filter.UserID !== null  ){
        whereList = whereList + ' and Fitter.UpdatedBy = '  + `'${this.filter.UserID}'`; }
  this.companyService.getGenericListByParem('FilterFitters', whereList ).subscribe(data => {
    this.fitters = data.result;
    this.spinner.hide();

  }, (err) => {
    console.log(err);
  this.spinner.hide();
    this.showNotification(
      'bg-red',
      'Error Loading Data',
      'top',
      'right'
    );
  });
}

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


}

