import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-message-setting',
  templateUrl: './message-setting.component.html'
})
export class MessageSettingComponent implements OnInit {
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany')).ID;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'))


  smsSettingList: any = [
    {MessageName: 'Billing (Advance)', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Billing (Final Delivery)', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Billing (Order Ready)', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Birthday', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Anniversary', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Eye Testing', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Contactlens Expiry', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Solution Expiry', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Credit Note', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Comfort Feedback', MessageID: '', Required: true, MessageText: ''},
    {MessageName: 'Service', MessageID: '', Required: true, MessageText: ''},
  ];

  whatsappSettingList: any = [

    {MessageName1: 'Customer_Birthday', MessageText1: ''},
    {MessageName1: 'Customer_Anniversary', MessageText1: ''},
    {MessageName1: 'Customer_Bill Advance', MessageText1: ''},
    {MessageName1: 'Customer_Bill FinalDelivery', MessageText1: ''},
    {MessageName1: 'Customer_Bill OrderReady', MessageText1: ''},
    {MessageName1: 'Customer_Eye Testing', MessageText1: ''},
    {MessageName1: 'Customer_Eye Prescription', MessageText1: ''},
    {MessageName1: 'Customer_Contactlens Expiry', MessageText1: ''},
    {MessageName1: 'Customer_Solution Expiry', MessageText1: ''},
    {MessageName1: 'Customer_Credit Note', MessageText1: ''},
    {MessageName1: 'Customer_Comfort Feedback', MessageText1: ''},
    {MessageName1: 'Customer_Service', MessageText1: ''},

 
  ];


  constructor(private companyService: CompanyService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private route: ActivatedRoute,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    let tempSMS = JSON.parse(this.loggedInCompanySetting.SmsSetting);
    if (tempSMS.length !== 0){
      this.smsSettingList = tempSMS
    } 
    this.getwhst()

  }

  getwhst(){
    let tempwhatsSMS = JSON.parse(this.loggedInCompanySetting.WhatsappSetting);
    if (tempwhatsSMS.length !== 0 && tempwhatsSMS !== null){
    this.whatsappSettingList = tempwhatsSMS
    }
  }

  save(){
    this.loggedInCompanySetting.SmsSetting = JSON.stringify(this.smsSettingList);
    this.spinner.show();
    this.companyService.saveData('CompanySetting', this.loggedInCompanySetting).subscribe(data => {
      alert("Please logout and login again to Activate changes in SMS Settings");
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Saved successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Saved.',
                    'top',
                    'right'
                  );
    });
  }


  save1(){
    this.loggedInCompanySetting.WhatsappSetting = JSON.stringify(this.whatsappSettingList);
    this.spinner.show();
    this.companyService.saveData('CompanySetting', this.loggedInCompanySetting).subscribe(data => {
      alert("Please logout and login again to Activate changes in SMS Settings");
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Saved successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Saved.',
                    'top',
                    'right'
                  );
    });
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}


