import { Component, OnInit } from '@angular/core';
import { AdminService} from '../services/admin.service';
import { User} from '../model/User';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { CompanyService } from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-employee',
  templateUrl: './Employee.component.html'
})
export class EmployeeComponent implements OnInit {
  dispalyAllFields = true;
  imgArray: any = [];
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  editEmployeeList = false;
  // addEmployeeList = false.toString();
  addEmployeeList = false;
  deleteEmployeeList = false;
  public id =  parseInt(this.route.snapshot.paramMap.get('id'), 10);
  mobNumberPattern = "^((\\+91-?)|0)?[0-9]{10}$";
data1: User = { ID : null, CompanyID : this.loggedInCompany.ID , Name : null, UserGroup : "Employee", DOB : null, Anniversary : null, MobileNo1 : null,
  MobileNo2 : null, PhoneNo : null, Email : null, Address : null, Branch : '', FaxNo : null, Website : null, PhotoURL : null, Document: null,
  LoginName : "", Password : "", Status : 1, CreatedBy : null, UpdatedBy : null, CreatedOn : "", UpdatedOn : null, CommissionType: 0, CommissionMode: 0,
  CommissionValue: 0, CommissionValueNB: 0
};

userShop: any = {ID: null, UserID: this.id, ShopID: null, RoleID: null, Status: 1, CreatedOn: null, CreatedBy: null};

userImage: any;
usershopList: any = [];
  disableSuperAdminFields = false;
  toggleChecked = false;
  stringUrl: string;
  shopList: any;
  roleList: any;
  color: ThemePalette = 'primary';
  oldLoginName = "";
constructor(private adminService: AdminService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private spinner: NgxSpinnerService,
            private route: ActivatedRoute,
            private snackBar: MatSnackBar,
            private companyService: CompanyService,
            private compressImage: CompressImageService
  ) {}



  ngOnInit() {


    this.permission.forEach(element => {    
      if (element.ModuleName === 'EmployeeList') {
             this.editEmployeeList = element.Edit;
             this.addEmployeeList = element.Add;
             this.deleteEmployeeList = element.Delete;  
           }
           
         });
    if (this.loggedInUser.UserGroup !== 'SuperAdmin'){this.disableSuperAdminFields = true; }

    if (this.id !== 0) {
  
    this.adminService.getDataByID(this.id, 'getEmployeeByID' , 'User').subscribe(data => {
      this.spinner.hide();
      this.data1 = data.result;
      this.data1.CommissionType = data.result.CommissionType.toString();
        this.data1.CommissionMode = data.result.CommissionMode.toString();
      if (data.result.Anniversary === '0000-00-00') {
        this.data1.Anniversary = null;
      }
      if (data.result.DOB === '0000-00-00') {
        this.data1.DOB = null;
      }
      this.oldLoginName =  this.data1.LoginName;
      
     
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
      this.userImage = this.sanitize(this.data1.PhotoURL);
      let document = JSON.parse(data.result.Document);
      for(var i = 0; i < document.length; i++) {
        let Obj: any = {ImageName: '' , Src: ''};
        Obj.ImageName = document[i].ImageName;
        Obj.Src = this.sanitize(document[i].ImageName);
        this.imgArray.push(Obj);
      }
     
      // this.imgArray = JSON.parse(data.result.Document);
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }
  

  this.spinner.show();
      this.getUserShopList();
    this.getShopList();
    this.getRoleList();

  }
  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
  }

 

  uploadImage(e,mode) {
    let image: File = e.target.files[0]
    console.log(`Image size before compressed: ${image.size} bytes.`)
    this.compressImage.compress(image)
      .pipe(take(1)).subscribe(compressedImage => {
        console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
        const frmData = new FormData();
        frmData.append('file', compressedImage);
        this.adminService.uploadFile(frmData).subscribe(data => {
          this.data1.PhotoURL = data.fileName;
          this.userImage = this.sanitize(this.data1.PhotoURL);
          
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Image successfully Uploaded',
            'bottom',
            'right'
          );
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Image Not Uploaded.',
            'bottom',
            'right'
          );
        });
  })}

  onSubmit() {
    this.data1.Document = JSON.stringify(this.imgArray);
      this.spinner.show();
      if(this.oldLoginName != this.data1.LoginName){
        this.companyService.checkforDuplicate('User', this.data1.LoginName).subscribe(res => {
         if(res.result === false)
         {this.spinner.hide(); alert ("Login Name alredy Exist, Please Use Unique Name"); } 
         else {
          this.adminService.saveData('User', this.data1).subscribe(data1 => {
            this.router.navigate(['/admin/employeeList']);
            this.spinner.hide();
            this.showNotification(
              'bg-green',
              'Data Saved successfully',
              'top',
              'right'
            );
          }, (err) => { console.log(err);
                        this.spinner.hide();
                        this.showNotification(
                          'bg-red',
                          'Data Not Saved.',
                          'top',
                          'right'
                        );
          });

         }
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
        });
      } else {
        this.adminService.saveData('User', this.data1).subscribe(data1 => {
          this.router.navigate(['/admin/employeeList']);
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Data Saved successfully',
            'top',
            'right'
          );
        }, (err) => { console.log(err);
                      this.spinner.hide();
                      this.showNotification(
                        'bg-red',
                        'Data Not Saved.',
                        'top',
                        'right'
                      );
        });
      }
      
  }

  saveUserShop() {
    this.spinner.show();
    let count = 0;
    this.usershopList.forEach(element => {
      if (element.ShopID === this.userShop.ShopID )
      {count = count + 1; }
    });
    
    if(count === 0) {
    this.adminService.saveData('UserShop', this.userShop).subscribe(data1 => {
      this.getUserShopList();
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Saved successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Saved.',
                    'top',
                    'right'
                  );
    });
  } else {
    this.spinner.hide();
    Swal.fire({
      icon: 'error',
      title: 'Duplicate or Empty Values are not allowed',
      text: '',
      footer: ''
    });
  }

      // this.usershopList = this.data1;
}

    editAssignedShop(data) {
      Object.assign(this.userShop = data);
    }

  getShopList() {
    this.companyService.getShortListByCompany('Shop', 1).subscribe(data => {
      this.shopList = data.result;
      this.spinner.hide();
    }, (err) => { console.log(err);
      this.spinner.hide();

                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }

  getUserShopList() {
    this.companyService.geListByOtherID('UserShop1', this.id).subscribe(res => {
      this.usershopList = res.result;
      this.spinner.hide();

    }, (err) => {
      console.log(err);
      this.spinner.hide();

      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  checkforDuplicate(){
    if(this.oldLoginName != this.data1.LoginName){
      this.companyService.checkforDuplicate('User', this.data1.LoginName).subscribe(res => {
       if(res.result === false){alert ("Login Name alredy Exist, Please Use Unique Name")}
      }, (err) => {
        console.log(err);
        this.showNotification(
          'bg-red',
          'Error Loading Data.',
          'top',
          'right'
        );
      });
    }
  }

  getRoleList() {
    this.companyService.getShortListByCompany('Role', 1).subscribe(data => {
      this.roleList = data.result;
      this.spinner.hide();

    }, (err) => { console.log(err);
      this.spinner.hide();

                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }

  add() {
    this.imgArray.push({ImageName: '' , Src: ''});
  }

  uploadImage1(e, i){
    const frmData = new FormData();
    frmData.append('file', e.target.files[0]);
    this.adminService.uploadFile(frmData).subscribe(data => {
      this.imgArray[i].ImageName = data.fileName;
      this.imgArray[i].Src = this.sanitize(this.imgArray[i].ImageName);

    this.showNotification(
      'bg-green',
      'Image successfully Uploaded',
      'top',
      'right'
    );

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  download(imgArray) {
    const url = 'http://opticalguru.relinksys.com:50080/zip?id=' + JSON.stringify(imgArray);
    window.open(url, '_blank');
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed ) {
        this.companyService.deleteData('UserShop', this.usershopList[i].ID).subscribe(data => {
          this.usershopList.splice(i, 1);
        console.log( this.usershopList)
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }
  

  onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  checkEmailDuplicate() {
    let Param = `Email = '${this.data1.Email}'`
    this.adminService.getForgetPassword('User', Param).subscribe(data => {
   if(data.result.length !== 0) {
     this.data1.Email = null;
    alert("you can not fill duplicate email id");
   }

       }, (err) => { console.log(err);   });
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
