import { Component, OnInit } from '@angular/core';
import { CompanyService } from './../../services/company.service';
import { AdminService } from './../../services/admin.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from './../../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import {WebcamImage} from './../../modules/webcam/domain/webcam-image';

import {WebcamUtil} from './../../modules/webcam/util/webcam.util';
import {WebcamInitError} from './../../modules/webcam/domain/webcam-init-error';
import {Observable, Subject} from 'rxjs';
import * as moment from 'moment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
@Component({
  selector: 'app-customer-category',
  templateUrl: './customer-category.component.html'
})
export class CustomerCategoryComponent implements OnInit {
  shopList = [];
  categoryList: any;
  dataList = [];
  shopid: any;
  constructor(private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
) { }

data = {ID: null , ShopName: null , Category: null, From: 0, To: null}

  ngOnInit(): void {
    this.spinner.show();

    this.getShopList();
    this.getCategoryList();
    this.spinner.hide();

  }

  getShopList() {
    this.spinner.show();
    
    this.companyService.getShortListByCompany('Shop',1).subscribe(data => {
      this.shopList = data.result;
    this.spinner.hide();

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }

  getCategoryList() {
    this.spinner.show();

    this.companyService.getSupportMasterList('CustomerCategory').subscribe(data => { 
      this.categoryList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      // this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Data Not Loaded.',
        'top',
        'right'
      );
    });
  }

  saveCategory() {
    this.spinner.show();
    let count = 0;
    this.dataList.forEach(element => {
      if (element.ShopID === this.data.ShopName &&  element.CategoryID === this.data.Category){count = count + 1; }

    });
    if (count === 0 && this.data.Category !== null && Number(this.data.To) > Number(this.data.From)){
   
    this.companyService.saveData('CustomerCategory', this.data).subscribe(data => {
      this.data.From = null;
      this.data.To = null;
      this.data.Category = null;
      this.data.ShopName = this.shopid;
      this.getCustomerCategoryByID(this.shopid);
      console.log(this.data , 'datatatatat');
      this.showNotification(
        'bg-success',
        'Data Saved.',
        'top',
        'right'
      );
      this.spinner.hide();
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Saved.',
                    'top',
                    'right'
                  );
}); 
    }else { 
      this.spinner.hide();

      // alert ("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed or Can not set less value of From',
        text: '',
        footer: ''
      });  
      this.dataList = [];
  }
  }

  
  deleteItem(){
    this.spinner.show();

    this.companyService.deleteDataOtherID('CustomerCategory', this.data.ShopName).subscribe(data => {
      this.getCustomerCategoryByID(this.data.ShopName);
    this.showNotification(
    'bg-red',
    'Data Deleted Successfully',
    'top',
    'right'
    );
    }, (err) => {
    this.showNotification(
    'bg-red',
    'Could Not Delete Data.',
    'top',
    'right'
    );
    });
    }

  getCustomerCategoryByID(id) {
    this.spinner.show();
    this.shopid = id;
    this.companyService.geListByOtherID('CustomerCategory' , id).subscribe(data => {
      this.spinner.hide();
      this.dataList = data.result;
    }, (err) => { console.log(err);
                  this.spinner.show();
    });
  }

  selectedFromValue() {
    let len = this.dataList.length;
    if (len !== 0) {
      let len2 = len;
      this.data.From = Number(this.dataList[0].Too) + 1;
      console.log(this.dataList[0].Too , 'this.dataList[len2].Too');
    }
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
