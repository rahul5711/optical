import { Component, Input, OnInit, Output } from '@angular/core';
import { CompanyService } from '../../services/company.service';
import { AdminService } from '../../services/admin.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import {WebcamImage} from '../../modules/webcam/domain/webcam-image';

import {WebcamUtil} from '../../modules/webcam/util/webcam.util';
import {WebcamInitError} from '../../modules/webcam/domain/webcam-init-error';
import {Observable, Subject} from 'rxjs';
import * as moment from 'moment';
import Swal from 'sweetalert2/dist/sweetalert2.js';
@Component({
  selector: 'app-notification-category',
  templateUrl: './notification-category.component.html',
  styleUrls: ['./notification-category.component.css']
})
export class NotificationCategoryComponent implements OnInit {
  


 
bdayRange = 'Today';
bdayTbl = 'Customer';
anniRange = 'Today';
anniTbl = 'Customer';
deliRange = 'Today';
deliTbl = '';
penRange = 'Today';
penTbl = '';
supplierRange = 'Today';
supplierTbl = '';
eyeTestRange = 'Today';
eyeTestTbl = '';
contactRange = 'Today';
contactTbl = 'Customer';
solutionRange = 'Today';
solutionTbl = 'Customer';
ComfortRange = 'Today'
ComforTbl = 'Customer';
 

loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  
  tabList: any;
  tabsList: any;
  deliList: any;
  penList: any;
  supplierList: any;
  ccontabList: any;
  scontabList: any;
  ssoltabList: any;
  csoltabList: any;
  eyeTestList: any;
  ServiceMsg : any;
  confortList: any;
  shopList: any;

 

  constructor(private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
) { }


  ngOnInit(): void {



    this.getBdayData(); 
    this.getAnniData();
    this.getDeliData();
    this.getPenData();
    this.getSupplierData();
    this.getEyeTestData();
    this.getContactData();
    this.getComfortData();
    this.getServiceData();
    
  }


  setComfortBtnColor(color){
    this.ComfortRange = color;
   }
  setBdayBtnColor(color){
   this.bdayRange = color;
  }
  setAnniBtnColor(color){
    this.anniRange = color;
   }
   setDeliBtnColor(color){
    this.deliRange = color;
   }
   setPenBtnColor(color){
    this.penRange = color;
   }
   setSuppBtnColor(color){
    this.supplierRange = color;
   }
   setEyeBtnColor(color){
    this.eyeTestRange = color;
   }
   setContactBtnColor(color){
    this.contactRange = color;
   }
   setSolutionBtnColor(color){
    this.solutionRange = color;
   }

  tabClickBday(event) {
    this.bdayTbl = event.tab.textLabel;
    this.getBdayData();
}

tabClickAnni(event) {
  this.anniTbl = event.tab.textLabel;
  this.getAnniData();
}

tabClickContact(event) {
  this.contactTbl = event.tab.textLabel;
  this.getContactData();
}
tabClickSolution(event) {
  this.solutionTbl = event.tab.textLabel;
  this.getSolutionData();
}

getSolutionData() {
  var BDate = '';
  let whereList = '';
  let tab = '';
   if(this.solutionRange === 'Today'){ BDate =  moment().format('YYYY-MM-DD');}else if (this.solutionRange === 'Tomorrow'){
    BDate = moment().add(1, 'days').format('YYYY-MM-DD'); }else if(this.solutionRange === 'Yestreday'){BDate = moment().subtract(1, 'days').format('YYYY-MM-DD');
   }
   if(this.solutionTbl === 'Supplier'){
    tab = 'SupplierSolutionNotification';
    whereList =  '  AND PurchaseDetail.ProductName  LIKE ' +  `'%${BDate}%'`;

   }else if (this.solutionTbl === 'Customer'){
    tab = 'CustomerSolutionNotification';
    whereList =  '  AND BillDetail.ProductName  LIKE ' +  `'%${BDate}%'`;
   }
   if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
    whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;
  }else{
    whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;

  }
this.companyService.getGenericListByParem(tab, whereList).subscribe(data => {
  if(this.solutionTbl === 'Supplier') {
    this.ssoltabList = data.result;

  } else if(this.solutionTbl === 'Customer') {
    this.csoltabList = data.result;

  }

  }, (err) => {
    console.log(err);
    
  });
}

getContactData() {
  var BDate = '';
  let whereList = '';
  let tab = '';
   if(this.contactRange === 'Today')
   { BDate =  moment().format('YYYY-MM-DD');}
   else if (this.contactRange === 'Tomorrow')
   {
    BDate = moment().add(1, 'days').format('YYYY-MM-DD'); }
    else if(this.contactRange === 'Yestreday')
    {BDate = moment().subtract(1, 'days').format('YYYY-MM-DD');
   }
   if(this.contactTbl === 'Supplier'){
    tab = 'SupplierContactLensNotification';
    whereList =  '  AND PurchaseDetail.ProductName  LIKE ' +  `'%${BDate}%'`;
   }else if (this.contactTbl === 'Customer'){
    tab = 'CustomerContactLensNotification';
    whereList =  '  AND BillDetail.ProductName  LIKE ' +  `'%${BDate}%'`;
   }
   if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
    whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;
  }else{
    whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;

  }
this.companyService.getGenericListByParem(tab, whereList).subscribe(data => {
  if(this.contactTbl === 'Supplier') {
    this.scontabList = data.result;

  } else if(this.contactTbl === 'Customer') {
    this.ccontabList = data.result;

  }
  }, (err) => {
    console.log(err);
    
  });
}

  getBdayData() {
    var BDate = '';
    let whereList = '';
    let tab = '';
     if(this.bdayRange === 'Today')
     { BDate =  moment().format('YYYY-MM-DD');}
     else if (this.bdayRange === 'Tomorrow'){
      BDate = moment().add(1, 'days').format('YYYY-MM-DD'); }
      else if(this.bdayRange === 'Yestreday')
      {BDate = moment().subtract(1, 'days').format('YYYY-MM-DD');
     }

 
     if(this.bdayTbl === 'Supplier'){
      tab = 'SupplierNotification';
      whereList = `Supplier.DOB / '${BDate}'`;
     }else if (this.bdayTbl === 'Customer'){
      tab = 'CustomerNotification';
      whereList = `Customer.DOB  / '${BDate}'`;
     }else if (this.bdayTbl === 'Employee'){
      tab = 'EmployeeNotification';
      whereList = `User.DOB / '${BDate}'`;
    }else if (this.bdayTbl === 'Fitter'){
      tab = 'FitterNotification';
      whereList = `Fitter.DOB / '${BDate}'`;
    }else if (this.bdayTbl === 'Doctor'){
      tab = 'DoctorNotification';
      whereList = `Doctor.DOB / '${BDate}'`;
    }

  this.companyService.getGenericListByParem(tab, whereList).subscribe(data => {
    this.tabList = data.result;

    }, (err) => {
      console.log(err);
      
    });
  }



  getAnniData() {
    var ADate = '';
    let whereList = '';
    let tabs = '';
     if(this.anniRange === 'Today')
     { ADate =  moment().format('YYYY-MM-DD');}
     else if (this.anniRange === 'Tomorrow'){
      ADate = moment().add(1, 'days').format('YYYY-MM-DD'); }
      else if(this.anniRange === 'Yestreday'){ADate = moment().subtract(1, 'days').format('YYYY-MM-DD');
     }
     if(this.anniTbl === 'Supplier'){
      tabs = 'SupplierNotification';
      whereList = `Supplier.Anniversary / '${ADate}'`;
     }else if (this.anniTbl === 'Customer'){
      tabs = 'CustomerNotification';
      whereList = `Customer.Anniversary  / '${ADate}'`;
     }else if (this.anniTbl === 'Employee'){
      tabs = 'EmployeeNotification';
      whereList = `User.Anniversary / '${ADate}'`;
    }else if (this.anniTbl === 'Fitter'){
      tabs = 'FitterNotification';
      whereList = `Fitter.Anniversary / '${ADate}'`;
    }else if (this.anniTbl === 'Doctor'){
      tabs = 'DoctorNotification';
      whereList = `Doctor.Anniversary / '${ADate}'`;
    }

  this.companyService.getGenericListByParem(tabs, whereList).subscribe(data => {
    this.tabsList = data.result;

    }, (err) => {
      console.log(err);
      
    });
  }

  getDeliData() {
    var ADate = '';
    let whereList = '';
     if(this.deliRange === 'Today')
     { ADate =  moment().format('YYYY-MM-DD');}
     else if (this.deliRange === 'Tomorrow'){
      ADate = moment().add(1, 'days').format('YYYY-MM-DD'); }
      else if(this.deliRange === 'Yestreday'){ADate = moment().subtract(1, 'days').format('YYYY-MM-DD');
     }
     
   whereList =  ' and BillMaster.DeliveryDate = ' +  `'${ADate}'`;
  this.companyService.getGenericListByParem('DeliveryNotification', whereList).subscribe(data => {
    this.deliList = data.result;

    }, (err) => {
      console.log(err);
      
    });
  }

  getPenData() {
    var ADate = '';
    let whereList = '';
    let shopid = '';
     if(this.penRange === 'Today')
     { ADate =  moment().format('YYYY-MM-DD');
     whereList =   ' and BillMaster.DeliveryDate  = ' +  `'${ADate}'`; }
     
     else if (this.penRange === 'Tomorrow'){
      ADate = moment().add(1, 'days').format('YYYY-MM-DD'); 
      whereList =   ' and BillMaster.DeliveryDate  = ' +  `'${ADate}'`; }
      else if(this.penRange === 'Yestreday'){ADate = moment().subtract(1, 'days').format('YYYY-MM-DD');
      whereList =   ' and BillMaster.DeliveryDate = ' +  `'${ADate}'`; 
     }
     
      if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;
      }else{
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;

      }
    
     
   whereList = whereList;
  this.companyService.getGenericListByParem('DeliveryNotification', whereList).subscribe(data => {
    let tempArray = [];
    data.result.forEach(el => {
      el.DeliveryDate = moment(el.DeliveryDate).format(`${this.loggedInCompanySetting.DateFormat}`);
     

      tempArray.push(el);
    })
    
    this.penList = tempArray;


    }, (err) => {
      console.log(err);
      
    });
  }

  getSupplierData() {
    var ADate = '';
    let whereList = '';
     if(this.supplierRange === 'Today')
     { ADate =  moment().format('YYYY-MM-DD');}
     else if (this.supplierRange === 'Tomorrow'){
      ADate = moment().add(1, 'days').format('YYYY-MM-DD');  }
      else if(this.supplierRange === 'Yestreday'){ADate = moment().subtract(1, 'days').format('YYYY-MM-DD');}

      whereList =  ' and PaymentMaster.PaymentDate = ' +  `'${ADate}'`;
      if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;
      }else{
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;

      }
  this.companyService.getGenericListByParem('SupplierPayNotification', whereList).subscribe(data => {
    this.supplierList = data.result;

    }, (err) => {
      console.log(err);
      
    });
  }

  getEyeTestData() {
    var ADate = '';
    let whereList = '';
     if(this.eyeTestRange === 'Today')
     { ADate =  moment().format('YYYY-MM-DD');}
     else if (this.eyeTestRange === 'Tomorrow'){
      ADate = moment().add(1, 'days').format('YYYY-MM-DD');  }
      else if(this.eyeTestRange === 'Yestreday'){ADate = moment().subtract(1, 'days').format('YYYY-MM-DD');}

      whereList =  ' and spectacle_rx.ExpiryDate = ' +  `'${ADate}'`;
  this.companyService.getGenericListByParem('EyeTestNotification', whereList).subscribe(data => {
    this.eyeTestList = data.result;

    }, (err) => {
      console.log(err);
      
    });
  }

  getComfortData() {
    var ADate = '';
    let whereList = '';
      let date1 = moment().subtract(this.loggedInCompanySetting.FeedbackDate, 'days').format('YYYY-MM-DD');
      whereList = whereList + ' and DATE_FORMAT(BillDetail.CreatedOn, "%Y-%m-%d") = ' +  `'${date1}'`; 
      if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;
      }else{
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;

      }
  this.companyService.getGenericListByParem('ServiceNotification', whereList).subscribe(data => {
    this.confortList = data.result;

    }, (err) => {
      console.log(err);
      
    });
  }

  getServiceData() {
    var ADate = '';
    let whereList = '';
      let date1 = moment().subtract(this.loggedInCompanySetting.ServiceDate, 'days').format('YYYY-MM-DD');
      whereList = whereList + ' and DATE_FORMAT(BillDetail.CreatedOn, "%Y-%m-%d") = ' +  `'${date1}'`; 
      if (this.loggedInShop.ShopID !== 0 && this.loggedInUser.UserGroup === 'Employee') {
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;
      }else{
        whereList = whereList + ' and BillMaster.ShopID = ' + `'${this.loggedInShop.ShopID}'`;

      }
  this.companyService.getGenericListByParem('ServiceNotification', whereList).subscribe(data => {
    this.ServiceMsg = data.result;

    }, (err) => {
      console.log(err);
      
    });
  }

  sendWhcus(data,mode) {
    
    let temp = JSON.parse(this.loggedInCompanySetting.WhatsappSetting);
    let Sms12 = ''
    if(temp !== '' && temp !== null && temp !== 'null'){
      Sms12 = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Birthday')].MessageText1;
    }else{
     Sms12 = ''
    }
    
    let Sms1 = ''
    if(Sms12 !==  ''){
      Sms1 = Sms12
    }else{
      Sms1 = 'Wish You Happy Birthday Get Special Discount Today'
    }
   if(mode === "Cust_Bday"){
    var msg = `Hi ${data.Name},%0A`+
    // `Wish You Happy Birthday Get Special Discount Today%0A`+
    `${Sms1}%0A`+
     `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0A${this.loggedInShop.Website}`;
     var mob = "91" + data.MobileNo1;
    var url = `https://wa.me/${mob}?text=${msg}`;
    window.open(url, "_blank");
   } else if(mode === "Supp_Bday"){
    var msg = `Hi ${data.Name},%0A`+
    `${Sms1}%0A`+
     `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0A${this.loggedInShop.Website}`;
     var mob = "91" + data.MobileNo1;
    var url = `https://wa.me/${mob}?text=${msg}`;
    window.open(url, "_blank");
   }else if(mode === "Employee_Bday"){
    var msg = `Hi ${data.Name},%0A` +
    `${Sms1}%0A`+
     `${this.loggedInShop.Name }%0A${this.loggedInShop.MobileNo1}%0A${this.loggedInShop.Website}`;
     var mob = "91" + data.MobileNo1;
    var url = `https://wa.me/${mob}?text=${msg}`;
    window.open(url, "_blank");
   }else if(mode === "Fitter_Bday"){
    var msg = `Hi ${data.Name},%0A`+
    `${Sms1}%0A`+
     `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0A${this.loggedInShop.Website}`;
     var mob = "91" + data.MobileNo1;
    var url = `https://wa.me/${mob}?text=${msg}`;
    window.open(url, "_blank");
   }else if(mode === "Doctor_Bday"){
    var msg = `Hi ${data.Name},%0A` +
    `${Sms1}%0A`+
     `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0A${this.loggedInShop.Website}`;
     var mob = "91" + data.MobileNo1;
    var url = `https://wa.me/${mob}?text=${msg}`;
    window.open(url, "_blank");
   }
  }

  sendemail(data,mode){
    if(mode === "CustBday"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'CustomerBday').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "SuppBday"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'SupplierBday').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "EmpBday"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'EmployeeBday').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "FittBday"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'FitterBday').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "DocBday"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'DoctorBday').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "Cus_Anni"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'Customer_Anni').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "Supp_Anni"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'Supplier_Anni').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "Employ_Anni"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'employee_Anni').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "Fitt_Anni"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'fitter_Anni').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "doc_Anni"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'doctor_Anni').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "orderPen"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'order_Pending').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "eyeTest"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'EyeTests').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "contancts"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'Contact_lens').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "CustSolution"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'CustomerSolution').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "ComfortTest"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'ComfortFeedback').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }else if(mode === "ServiceMsgs"){
      let temp = {Name: data.Name, Email: data.Email, ShopName: this.loggedInShop.Name, ShopMoblie: this.loggedInShop.MobileNo1,ShopWebsite: this.loggedInShop.Website,};
      console.log(temp);
       this.adminService.sendEmail(temp, 'ServicenewMsg').subscribe(data2 => {
         this.showNotification(
           'bg-red',
           'Mail Send.',
           'top',
           'right'
         ); 
       }, (err) => { console.log(err);
                     
       });
    }
   
  }

  sendWhAnni(data,mode){
    let temp = JSON.parse(this.loggedInCompanySetting.WhatsappSetting);
    let Sms12 = ''
    if(temp !== '' && temp !== null && temp !== 'null'){
      Sms12 = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Anniversary')].MessageText1;
    }else{
     Sms12 = ''
    }

    let Sms1 = ''
    if(Sms12 !==  ''){
      Sms1 = Sms12
    }else{
      Sms1 = 'Happy Anniversary. May you yo love bird stay happy and blessed always.'
    }
    if(mode === "Cust_Anni"){
      var msg = `Hi ${data.Name},%0A`+
      // `Happy Anniversary. May you yo love bird stay happy and blessed always.%0A`+
      `${Sms1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     } else if(mode === "Supp_Anni"){
      var msg = `Hi ${data.Name},%0A`+
      `${Sms1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     } else if(mode === "Employee_Anni"){
      var msg = `Hi ${data.Name},%0A`+
      `${Sms1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     } else if(mode === "Fitter_Anni"){
      var msg = `Hi ${data.Name},%0A`+
      `${Sms1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     } else if(mode === "Doctor_Anni"){
      var msg = `Hi ${data.Name},%0A`+
      `${Sms1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     }else if(mode === "order"){
      let Smsw = ''
      if(temp !== '' && temp !== null && temp !== 'null'){
        Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Bill OrderReady')].MessageText1;
      }else{
        Smsw = ''
      }

      let Smsw1 = ''
    if(Smsw !==  ''){
      Smsw1 = Smsw
    }else{
      Smsw1 = 'Your order is ready for delivery Please collect it soon.'
    }
      var msg = `Hi ${data.CustomerName},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.CustomerMobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     }else if(mode === "eye"){

      let Smsw = ''
      if(temp !== '' && temp !== null && temp !== 'null'){
        Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Eye Testing')].MessageText1;
      }else{
        Smsw = ''
      }

      let Smsw1 = ''
    if(Smsw !==  ''){
      Smsw1 = Smsw
    }else{
      Smsw1 = 'Your Eye checkup is due Please call us to book your appointment.'
    }
      var msg = `Hi ${data.Name},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     }else if(mode === "Comfort"){

      let Smsw = ''
      if(temp !== '' && temp !== null && temp !== 'null'){
        Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Comfort Feedback')].MessageText1;
      }else{
        Smsw = ''
      }

      let Smsw1 = ''
    if(Smsw !==  ''){
      Smsw1 = Smsw
    }else{
      Smsw1 = 'We are curious to know about the comfort and quality of Spectacles that u bought from our store.'
    }

      var msg = `Hi ${data.Name},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     }else if(mode === "Services"){
      let Smsw = ''
      if(temp !== '' && temp !== null && temp !== 'null'){
        Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Service')].MessageText1;
      }else{
        Smsw = ''
      }

      let Smsw1 = ''
    if(Smsw !==  ''){
      Smsw1 = Smsw
    }else{
      Smsw1 = 'Just a Gental reminder about your FREE service is coming up. Please contact.'
    }
      var msg = `Hi ${data.Name},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
     }
  }

  sendWhContact(data , mode){
    let temp = JSON.parse(this.loggedInCompanySetting.WhatsappSetting);
    let Smsw = ''
    if(temp !== '' && temp !== null && temp !== 'null'){
      Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Contactlens Expiry')].MessageText1;
    }else{
      Smsw = ''
    }

    let Smsw1 = ''
    if(Smsw !==  ''){
     Smsw1 = Smsw
    }else{
     Smsw1 = 'Today Your Contact lens will be expire. Please Contact soon.'
    }
    if(mode === "Cust_Contact" ){
     
      var msg = `Hi ${data.Name},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
    } else if(mode === "Supp_Contact"){
      var msg = `Hi ${data.Name},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
    }

  }

  sendWhSolution(data , mode){
    let temp = JSON.parse(this.loggedInCompanySetting.WhatsappSetting);
    let Smsw = ''
    if(temp !== '' && temp !== null && temp !== 'null'){
      Smsw = temp[temp.findIndex(element => element.MessageName1 === 'Customer_Solution Expiry')].MessageText1;
    }else{
      Smsw = ''
    }
    
    let Smsw1 = ''
    if(Smsw !==  ''){
     Smsw1 = Smsw
    }else{
     Smsw1 = 'Today Your Solution lens will be expire. Please Contact soon.'
    }
    if(mode === "Cust_Solution" ){
      var msg = `Hi ${data.Name},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
    } else if(mode === "Supp_Solution"){
      var msg = `Hi ${data.Name},%0A`+
      `${Smsw1}%0A`+
       `${this.loggedInShop.Name}%0A${this.loggedInShop.MobileNo1}%0AVisit: ${this.loggedInShop.Website}`;
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
    }

  }

  sendMsg(data) {
    let temp = JSON.parse(this.loggedInCompanySetting.SmsSetting);
    let val = '';
    let CustomerName = data.Name;
    let phoneNo = data.MobileNo1;
    let ShopName = this.loggedInShop.Name;
    let ContactNo = this.loggedInShop.MobileNo1;
    let Website = this.loggedInCompany.Website;
    let senderID = this.loggedInCompanySetting.SenderID
    let msgAPIKey = this.loggedInCompanySetting.MsgAPIKey
   
   
    
    let message = '';
    let templateID = '';

    let Sms = temp[temp.findIndex(element => element.MessageName === 'Birthday')].MessageText;
    templateID  = temp[temp.findIndex(element => element.MessageName === 'Birthday')].MessageID;
    message = eval('`'+Sms+'`');
    this.companyService.sendSms1(phoneNo, message, templateID, senderID,msgAPIKey).subscribe(data => {
      this.showNotification(
        'bg-green',
        'MSG Sent successfully',
        'top',
        'right'
      );
      }, (err) => {
        console.log(err);
        
      });
  }

//   sendMsgAnni(data) {
//     let temp = JSON.parse(this.loggedInCompanySetting.SmsSetting);
//     let val = '';
//     let CustomerName = data.Name;
//     let phoneNo = data.MobileNo1;
//     let ShopName = this.loggedInShop.Name;
//     let ContactNo = this.loggedInShop.MobileNo1;
//     let Website = this.loggedInCompany.Website;
//     let message = '';
//     let templateID = '';

//     let Sms = temp[temp.findIndex(element => element.MessageName === 'Anniversary')].MessageText;
//     templateID  = temp[temp.findIndex(element => element.MessageName === 'Anniversary')].MessageID;
//     message = eval('`'+Sms+'`');
//     this.companyService.sendSms(phoneNo, message, templateID).subscribe(data => {
//       this.showNotification(
//         'bg-green',
//         'MSG Sent successfully',
//         'top',
//         'right'
//       );
//       }, (err) => {
//         console.log(err);
        
//       });
//   }

//   sendMsgOdr(data, mode) {
//     let temp = JSON.parse(this.loggedInCompanySetting.SmsSetting);
//     let val = '';
//     let CustomerName = data.CustomerName;
//     let phoneNo = data.CustomerMobileNo1;
//     let ShopName = this.loggedInShop.Name;
//     let ContactNo = this.loggedInShop.MobileNo1;
//     let Website = this.loggedInCompany.Website;
//     let message = '';
//     let templateID = '';
// if(mode === "orderPending"){
//   let Sms = temp[temp.findIndex(element => element.MessageName === 'CustomerOrder')].MessageText;
//   templateID  = temp[temp.findIndex(element => element.MessageName === 'CustomerOrder')].MessageID;
//   message = eval('`'+Sms+'`');
//   this.companyService.sendSms(phoneNo, message, templateID).subscribe(data => {
//     this.showNotification(
//       'bg-green',
//       'MSG Sent successfully',
//       'top',
//       'right'
//     );
//     }, (err) => {
//       console.log(err);
      
//     });
// }else if(mode === "eyeTesting"){
//   let Sms = temp[temp.findIndex(element => element.MessageName === 'CustomerOrder')].MessageText;
//   templateID  = temp[temp.findIndex(element => element.MessageName === 'CustomerOrder')].MessageID;
//   message = eval('`'+Sms+'`');
//   this.companyService.sendSms(phoneNo, message, templateID).subscribe(data => {
//     this.showNotification(
//       'bg-green',
//       'MSG Sent successfully',
//       'top',
//       'right'
//     );
//     }, (err) => {
//       console.log(err);
      
//     });
// }
    
//   }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
function STR_TO_DATE(DOB: any, arg1: string): any {
  throw new Error('Function not implemented.');
}

function DATE_FORMAT(arg0: any, arg1: string) {
  throw new Error('Function not implemented.');
}

