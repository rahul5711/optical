import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { SharedModule} from './../shared/shared.module';
import { AdminDashboardComponent } from './admin-dashboard.component';
import { CompanyComponent } from './company.component';
import { DepartmentManagementComponent } from './department-management.component';
import { CompanyListComponent } from './company-list.component';
import { ShopComponent } from './shop.component';
import { ShopListComponent } from './shop-list.component';
import { EmployeeComponent } from './employee.component';
import { EmployeeListComponent } from './employee-list.component';
import { RolePermissionComponent } from './role-permission.component';
import { MessageSettingComponent } from './message-setting.component';
import { CompanyDashboardComponent } from './company-dashboard.component';
import { CompanySettingComponent } from './company-setting.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatRadioModule} from '@angular/material/radio';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PhonePipe } from './../shared/pipes/phone.pipe';
import {UploadFilesComponent} from './../shared/components/upload-files/upload-files.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { LoginHistoryComponent } from './login-history.component';
import { RecycleBinComponent } from './recycle-bin.component';
import { ColorPickerModule } from 'ngx-color-picker';
import { LoginSettingComponent } from './login-setting.component';
import { SubscriptionComponent } from './Subscription.component';
import { CompanyLoginHistoryComponent } from './CompanyLoginHistory.component';

import { NotificationComponent } from './Notification.component';
import { ProductManagementCompnayComponent } from './product-management-Compnay.component';
import { CompnayAssignComponent } from './Compnay-assign.component';


import { DataTablesModule } from 'angular-datatables';



import { CustomerCategoryComponent } from './customer-category/customer-category.component';
import { NotificationCategoryComponent } from './notification-category/notification-category.component';
import { AutoFoucsDirectivesDirective } from './auto-foucs-directives.directive';


@NgModule({
  declarations: [AdminDashboardComponent, CompanyComponent, CompanyListComponent, ShopComponent,
    ShopListComponent, EmployeeComponent, EmployeeListComponent, RolePermissionComponent, MessageSettingComponent, CompanyDashboardComponent,
    CompanySettingComponent, PhonePipe, UploadFilesComponent, ProductManagementCompnayComponent,CompnayAssignComponent, 
    DepartmentManagementComponent, CompanyLoginHistoryComponent,LoginHistoryComponent,RecycleBinComponent,NotificationComponent, CustomerCategoryComponent,LoginSettingComponent,SubscriptionComponent , NotificationCategoryComponent,AutoFoucsDirectivesDirective],
  imports: [
    
    CommonModule,
    MatRadioModule,
    AdminRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    NgxDatatableModule,
    DataTablesModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSortModule,
    MatToolbarModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatTabsModule,
    MaterialFileInputModule,
    AdminRoutingModule,
    NgxSpinnerModule,
    PerfectScrollbarModule,
    Ng2SearchPipeModule,
    ColorPickerModule,
  ]
})
export class AdminModule { }
