import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard.component';
import { CompanyComponent } from './company.component';
import { CompanyDashboardComponent } from './company-dashboard.component';
import { EmployeeListComponent } from './employee-list.component';
import { RolePermissionComponent } from './role-permission.component';
import { MessageSettingComponent } from './message-setting.component';
import { CompanyListComponent } from './company-list.component';
import { EmployeeComponent } from './employee.component';
import { ShopComponent } from './shop.component';
import { ShopListComponent } from './shop-list.component';
import { CompanySettingComponent } from './company-setting.component';
import { DepartmentManagementComponent } from './department-management.component';
import { LoginHistoryComponent } from './login-history.component';
import { RecycleBinComponent } from './recycle-bin.component';
import { CustomerCategoryComponent } from './customer-category/customer-category.component';
import { LoginSettingComponent } from './login-setting.component';
import { SubscriptionComponent } from './Subscription.component';
import { CompanyLoginHistoryComponent } from './CompanyLoginHistory.component';
import { ProductManagementCompnayComponent } from './product-management-Compnay.component';
import { CompnayAssignComponent } from './Compnay-assign.component';


import { NotificationComponent } from './Notification.component';
import { NotificationCategoryComponent } from './notification-category/notification-category.component';





// const routes: Routes = [];
const routes: Routes = [
{ path: '',
children: [
  { path: '', component: AdminDashboardComponent },
  { path: 'adminDashboard', component: AdminDashboardComponent },
  { path: 'companyDashboard', component: CompanyDashboardComponent },
  { path: 'company/:id', component: CompanyComponent },
  { path: 'companyList', component: CompanyListComponent },
  { path: 'employeeList', component: EmployeeListComponent },
  { path: 'Employee/:id', component: EmployeeComponent },
  { path: 'rolePermission', component: RolePermissionComponent },
  { path: 'messageSetting', component: MessageSettingComponent },
  { path: 'shop/:id', component: ShopComponent },
  { path: 'shopList', component: ShopListComponent },
  { path: 'companySetting', component: CompanySettingComponent },
  { path: 'departmentManagement', component: DepartmentManagementComponent },
  { path: 'loginHistory', component: LoginHistoryComponent },
  { path: 'recyclebin', component: RecycleBinComponent },
  { path: 'customerCategory', component: CustomerCategoryComponent },
  { path: 'notificationCategory', component: NotificationCategoryComponent },
  { path: 'loginSetting', component: LoginSettingComponent },
  { path: 'subscriptionPlan', component: SubscriptionComponent },
  { path: 'companyLoginHistory', component: CompanyLoginHistoryComponent },
  { path: 'Notification', component: NotificationComponent },
  { path: 'ProductManagementCompnay', component: ProductManagementCompnayComponent },
  { path: 'CompanyAssign', component: CompnayAssignComponent },


]}
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }

