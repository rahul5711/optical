import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { AdminService } from '../services/admin.service';
import { environment } from '../../environments/environment';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-company-setting',
  templateUrl: './company-setting.component.html',
  styleUrls: ['./company-setting.component.css']
})
export class CompanySettingComponent implements OnInit {
  companyWatermark: any;
  companyWholeSalePrice: any;
  billFormatList: any;

  constructor(private snackBar: MatSnackBar,
              private companyService: CompanyService,
              private adminService: AdminService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private spinner: NgxSpinnerService,
              private route: ActivatedRoute,
              private compressImage: CompressImageService) {
   }

  stringUrl: string;
  env = environment;
  companyImage: any;
  dataList: any;
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));


  dataFormat: any = [
    {ID: 'llll', Name: 'Wed, Feb 10, 2021 7:03 PM'},
    {ID: 'LLLL', Name: 'Wednesday, February 10, 2021 7:02 PM'},
    {ID: 'lll', Name: 'Feb 10, 2021 7:00 PM'},
    {ID: 'LLL', Name: 'February 10, 2021 7:00 PM'},
    {ID: 'LL', Name: 'February 10, 2021'},
    {ID: 'll', Name: 'Feb 10, 2021'},
    {ID: 'L', Name: '02/10/2021'},
    {ID: 'l', Name: '2/10/2021'},
    {ID: 'DD/MM/YYYY', Name: '10/02/2021'},
    {ID: 'DD-MM-YYYY', Name: '10-02-2021'}

  ];

  wlcmArray: any = [];

  wlcmArray1: any = [];

 
  data: any = {ID: null, CompanyLanguage: 'English', Locale: 'en-IN', CompanyCurrency: '', CurrencyFormat: null, DateFormat: null,
    CompanyTagline: '', BillHeader: '', BillFooter: '', RewardsPointValidity: '', EmailReport: null,
     WholeSalePrice: false, Composite: false, RetailRate: false,  Color1: '', FontApi:'', FontsStyle: '', HSNCode: false, Discount: false, GSTNo: false, Rate: false, SubTotal: false, Total: false, CGSTSGST: false, 
     WelComeNote: '',BillFormat:null,SenderID: '',MsgAPIKey:'', SmsSetting: '',DataFormat: 0,RewardPercentage:0, RewardExpiryDate: '30',AppliedReward:0, MobileNo:'2', MessageReport: null, LogoURL: '', WatermarkLogoURL: '', InvoiceFormat: 'option.ejs', LoginTimeStart: '', LoginTimeEnd: '', year: false, month: false, partycode: false, type: false , BarCode:'', FeedbackDate:'', ServiceDate:'',DeliveryDay:'',WhatsappSetting:''}; Composite = false; AppliedDiscount=false; 
  ngOnInit() {
    if (this.loggedInCompany.WholeSale === 'true') {
      this.data.WholeSalePrice = true;
    } else {
      this.data.WholeSalePrice = false
    }
    this.Composite = false; 
    this. getBillList();
    this.getSettingList();
    this.companyImage = this.sanitize(this.data.LogoURL);
 
   
  }

  onSubmit() {
    this.spinner.show();
    this.data.WelComeNote = JSON.stringify(this.wlcmArray1);
    this.companyService.saveData('CompanySetting', this.data).subscribe(data => {
      this.spinner.hide();
      this.getSettingList();
      this.showNotification(
        'bg-green',
        'Data Saved successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Saved.',
                    'top',
                    'right'
                  );
    });
  }


  
  

  uploadImage(e,mode) {
    let image: File = e.target.files[0]
    console.log(`Image size before compressed: ${image.size} bytes.`)
    this.compressImage.compress(image)
      .pipe(take(1)).subscribe(compressedImage => {
        console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
        const frmData = new FormData();
        frmData.append('file', compressedImage);
        this.adminService.uploadFile(frmData).subscribe(data => {
          this.showNotification(
            'bg-green',
            'Image successfully Uploaded',
            'bottom',
            'right'
          );
          console.log(data.fileName, 'url')
          switch (mode) {
            case "Company":
              this.data.LogoURL = data.fileName;
              this.companyImage = this.sanitize(this.data.LogoURL);
              break;
            case "Watermark":
              this.data.WatermarkLogoURL = data.fileName;
              this.companyWatermark = this.sanitize(this.data.WatermarkLogoURL);
              break;
          }
          this.showNotification(
            'bg-green',
            'Image successfully Uploaded',
            'bottom',
            'right'
          );
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Image Not Uploaded.',
            'top',
            'right'
          );
        });
  })}

 

  getBillList() {
    this.adminService.getSupportMasterList('BillFormat').subscribe(data => { 
      this.billFormatList = data.result;
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => {
      this.spinner.hide();
      
    });
  }

  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
  }

  getSettingList() {
    this.spinner.show();
    this.companyService.getShortListByCompany('CompanySetting', 1).subscribe(data => {
      if(data.result.length !== 0){
      this.data = data.result[0];
      this.data.dataFormat = data.result[0].dataFormat;
     

      if (data.result[0].WelComeNote !== null || data.result[0].WelComeNote !== 'null' || data.result[0].WelComeNote !== undefined) {
      this.wlcmArray1 = JSON.parse(data.result[0].WelComeNote);
      }
      if(data.result[0].WholeSalePrice === 'true') {
        this.data.WholeSalePrice = true;
      } else if (data.result[0].WholeSalePrice === 'false' || data.result[0].WholeSalePrice === null) {
        this.data.WholeSalePrice = false;
      }

      if(data.result[0].RetailRate === 'true') {
        this.data.RetailRate = true;
      } else if (data.result[0].RetailRate === 'false' || data.result[0].RetailRate === null) {
        this.data.RetailRate = false;
      }
      if(data.result[0].Composite === 'true') {
        this.data.Composite = true;
      } else if (data.result[0].Composite === 'false' || data.result[0].Composite === null) {
        this.data.Composite = false;
      }
      
      if(data.result[0].HSNCode === 'true') {
        this.data.HSNCode = true;
      } else if (data.result[0].HSNCode === 'false' || data.result[0].HSNCode === null) {
        this.data.HSNCode = false;
      }
      
      if(data.result[0].Discount === 'true') {
        this.data.Discount = true;
      } else if (data.result[0].Discount === 'false' || data.result[0].Discount === null) {
        this.data.Discount = false;
      }
      if(data.result[0].GSTNo === 'true') {
        this.data.GSTNo = true;
      } else if (data.result[0].GSTNo === 'false' || data.result[0].GSTNo === null) {
        this.data.GSTNo = false;
      }

      if(data.result[0].Rate === 'true') {
        this.data.Rate = true;
      } else if (data.result[0].Rate === 'false' || data.result[0].Rate === null) {
        this.data.Rate = false;
      }

      if(data.result[0].SubTotal === 'true') {
        this.data.SubTotal = true;
      } else if (data.result[0].SubTotal === 'false' || data.result[0].SubTotal === null) {
        this.data.SubTotal = false;
      }

      if(data.result[0].CGSTSGST === 'true') {
        this.data.CGSTSGST = true;
      } else if (data.result[0].CGSTSGST === 'false' || data.result[0].CGSTSGST === null) {
        this.data.CGSTSGST = false;
      }
      
      if(data.result[0].Total === 'true') {
        this.data.Total = true;
      } else if (data.result[0].Total === 'false' || data.result[0].Total === null) {
        this.data.Total = false;
      }

      if(data.result[0].year === 'true') {
        this.data.year = true;
      } else if (data.result[0].year === 'false' || data.result[0].year === null) {
        this.data.year = false;
      }

      if(data.result[0].month === 'true') {
        this.data.month = true;
      } else if (data.result[0].month === 'false' || data.result[0].month === null) {
        this.data.month = false;
      }

      if(data.result[0].partycode === 'true') {
        this.data.partycode = true;
      } else if (data.result[0].partycode === 'false' || data.result[0].partycode === null) {
        this.data.partycode = false;
      }

      if(data.result[0].type === 'true') {
        this.data.type = true;
      } else if (data.result[0].type === 'false' || data.result[0].type === null) {
        this.data.type = false;
      }

      if(data.result[0].AppliedDiscount === 'true') {
        this.data.AppliedDiscount = true;
      } else if (data.result[0].AppliedDiscount === 'false' || data.result[0].AppliedDiscount === null) {
        this.data.AppliedDiscount = false;
      }

      console.log(this.data , 'fdsjfhfhf');


     
    }
      this.spinner.hide();
      this.santizePictureList();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                 
    });

    
  }

  onEdit(data) {
    Object.assign(this.data = data);
  }

  santizePictureList() {
    this.dataList.forEach(element => {
    element.LogoURL = this.sanitize(element.LogoURL);
    element.WatermarkLogoURL = this.sanitize(element.WatermarkLogoURL);

  });
  }

  addRow() {
    this.wlcmArray1.push({NoteType: '', Content: ''});
  }
  delete(i) {
    this.wlcmArray1.splice(this.wlcmArray.indexOf(this.wlcmArray[i]), 1);
  }


 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
    
}
