import { Component, OnInit } from '@angular/core';
import { AdminService} from '../services/admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {
  term:any;
  gridview = true;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  stringUrl: string;
  constructor(private adminService: AdminService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private route: ActivatedRoute,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService
  ) { }

  fileName= 'CompanyListExcel.xlsx';
  dataList: any;
  ngOnInit() {
    this.spinner.show();
    this.adminService.getCompanyList('Company').subscribe(data => {
      this.dataList = data.result;
      console.log(data);
      console.log(this.dataList,'ghghghghghg');
      this.santizePictureList();
      this.spinner.hide();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
                });
  }

  santizePictureList() {
    this.dataList.forEach(element => {
    element.LogoURL = this.sanitize(element.LogoURL);
    
  });
  }

sanitize(imgName: string) {
  if (imgName !== null && imgName !== '') {
    this.stringUrl = this.env.apiUrl + imgName;
   } else {
     this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
  return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
}

exportEx(): void
{
  /* pass here the table id */
  let element = document.getElementById('exportsss');
  const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
// delete (ws['O1'])
ws['!cols'] = [];
ws['!cols'][0] = { hidden: true };

  /* generate workbook and add the worksheet */
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

  /* save to file */  
  XLSX.writeFile(wb, this.fileName);

}

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
