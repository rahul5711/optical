import { Component, OnInit } from '@angular/core';
import { AdminService} from '../services/admin.service';
import { User} from '../model/User';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { CompanyService } from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-login-setting',
  templateUrl: './login-setting.component.html'
})
export class LoginSettingComponent implements OnInit {
  stringUrl: string;

  imgArray: any = [];
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  permission = JSON.parse(localStorage.getItem('Permission'));

  image: any = {FirstImage:"", SecondImage:"", ThirdImage:"", ForthImage:""}
  sociaLinks: any = {Facebook:"", Facebook1:"", Instagram:"", linkedin:"", Google:""}
  news: any = {ID: null, CompanyID: 0, Name: "", TableName:null,   Status: 1}
  newsList = [];
  notification: any = { ID: null, CompanyID: 0, Name: "", TableName:null, Notification: '',  Status: 1 }
  notificationList = [];
  sociaLink: any = {ID: null, CompanyID: 0, Name: "", TableName:null,   Status: 1}
  socialLinkList = [];
  images: any = {ID: null, CompanyID: 0, Name: "", TableName:null,   Status: 1}
  imagesList = [];
  companyImage: any;

  firstImage: any;
  secondImage: any;
  thirdImage: any;
  forthImage: any;


constructor(private adminService: AdminService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private spinner: NgxSpinnerService,
            private route: ActivatedRoute,
            private snackBar: MatSnackBar,
            private companyService: CompanyService
  ) {}



  ngOnInit() {
    this.getNews();
    this.getNotification();
    this.getSocialLink();
  this.getImageList();
  }

  onSubmit() {
    console.log(this.image)
    this.images.TableName = 'Images';
    this.images.Name = JSON.stringify(this.image);
    this.adminService.saveData('SupportMaster', this.images).subscribe(data => {
      this.getImageList();
      this.showNotification(
        'bg-success',
        'Data Saved',
        'top',
        'right'
      );
      }, (err) => { console.log(err);           
      });
 
  }

  getImageList() {
    this.adminService.getSupportList('SupportMaster','Images').subscribe(data => {
      this.imagesList = data.result;
      this.images = this.imagesList[0];
      let imageParse = JSON.parse(this.imagesList[0].Name);
      this.image.FirstImage = imageParse.FirstImage;
      this.firstImage = this.sanitize(this.image.FirstImage);

      this.image.SecondImage = imageParse.SecondImage;
      this.secondImage = this.sanitize(this.image.SecondImage);

      this.image.ThirdImage = imageParse.ThirdImage;
      this.thirdImage = this.sanitize(this.image.ThirdImage);

      this.image.ForthImage = imageParse.ForthImage;
      this.forthImage = this.sanitize(this.image.ForthImage);


       }, (err) => { console.log(err);   });
  }

  

  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
  }

  uploadImage(e, mode){
    const frmData = new FormData();
    frmData.append('file', e.target.files[0]);
    this.adminService.uploadFile(frmData).subscribe(data => {
      if(mode === 'first') {
        this.image.FirstImage = data.fileName;
        this.firstImage = this.sanitize(this.image.FirstImage);
      } else if(mode === 'second') {
        this.image.SecondImage = data.fileName;
        this.secondImage = this.sanitize(this.image.SecondImage);
      } else if(mode === 'third') {
        this.image.ThirdImage = data.fileName;
        this.thirdImage = this.sanitize(this.image.ThirdImage);
      }else if(mode === 'fourth') {
        this.image.ForthImage = data.fileName;
        this.forthImage = this.sanitize(this.image.ForthImage);
      }
    
    this.showNotification(
      'bg-green',
      'Image successfully Uploaded',
      'top',
      'right'
    );

    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
  }


  onSubmit1() {
    this.sociaLink.TableName = 'SocialLinks';
    this.sociaLink.Name = JSON.stringify(this.sociaLinks);
    this.adminService.saveData('SupportMaster', this.sociaLink).subscribe(data => {
      this.getSocialLink();
      this.showNotification(
        'bg-success',
        'Data Saved',
        'top',
        'right'
      );
      }, (err) => { console.log(err);           
      });
 
  }

  getSocialLink() {
    this.adminService.getSupportList('SupportMaster','SocialLinks').subscribe(data => {
      this.socialLinkList = data.result;
      this.sociaLink = this.socialLinkList[0];
      let socialParse = JSON.parse(this.socialLinkList[0].Name);
      this.sociaLinks.Facebook = socialParse.Facebook;
      this.sociaLinks.Facebook1 = socialParse.Facebook1;
      this.sociaLinks.Instagram = socialParse.Instagram;
      this.sociaLinks.linkedin = socialParse.linkedin;
      this.sociaLinks.Google = socialParse.Google;


     
       }, (err) => { console.log(err);   });
  }

  //  news 
  onSubmit2() {
      this.news.TableName = 'News';
      this.adminService.saveData('SupportMaster', this.news).subscribe(data => {
        this.getNews();
        this.showNotification(
          'bg-success',
          'Data Saved',
          'top',
          'right'
        );
        }, (err) => { console.log(err);           
        });
  }

  getNews() {
    this.adminService.getSupportList('SupportMaster','News').subscribe(data => {
      this.newsList = data.result;
      this.news = this.newsList[0];
    
       }, (err) => { console.log(err);   });
  }


//  notification

  onSubmit3() {
    console.log(this.notification)
    this.notification.TableName = 'Notification';
    this.adminService.saveData('SupportMaster', this.notification).subscribe(data => {
      this.getNotification();
      this.showNotification(
        'bg-success',
        'Data Saved',
        'top',
        'right'
      );
      }, (err) => { console.log(err);           
      });
 
  }

  getNotification() {
    this.adminService.getSupportList('SupportMaster','Notification').subscribe(data => {
      this.notificationList = data.result;
      this.notification = this.notificationList[0];
       }, (err) => { console.log(err);   });
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
