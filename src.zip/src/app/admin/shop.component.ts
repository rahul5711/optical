import { Component, OnInit } from '@angular/core';
import { Shop} from '../model/Shop';
import { CompanyService} from '../services/company.service';
import { AdminService} from '../services/admin.service';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { ThemePalette } from '@angular/material/core';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html'
})
export class ShopComponent implements OnInit {
  dispalyAllFields = true;
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  permission= JSON.parse(localStorage.getItem('Permission'));
 
  editShopList = false;
  addShopList = false;
  deleteShopList = false;
data: any = { ID : null,  CompanyID: null, Name : null, AreaName: null, MobileNo1 : null, MobileNo2 : null, PhoneNo : null, Address : null, Email : null, Website : null, GSTNo : null, CINNo : null, BarcodeName: null, Discount: false, GSTnumber: false, LogoURL : null,HSNCode: false, CustGSTNo:false, Rate:false, Discounts:false, Tax:false, SubTotal:false, Total:false,  ShopTiming : 'MON-SAT 10 AM - 8 PM, SUN OFF', WelcomeNote : '',   Status : 1,
  CreatedBy : null, CreatedOn : null, UpdatedBy : null, UpdatedOn : null, ShopStatus: 0,
};

stringUrl: string;
  companyImage: any;
  toggleChecked = false;
  color: ThemePalette = 'primary';
  f = false;
  wlcmArray: any = [];

  wlcmArray1: any = [];
  constructor(private companyService: CompanyService,
              private adminService: AdminService,
              private router: Router,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService,
              private sanitizer: DomSanitizer,
              private route: ActivatedRoute,
              private compressImage: CompressImageService
) {}

public id =  parseInt(this.route.snapshot.paramMap.get('id'), 10);

ngOnInit(){
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ShopList') {
             this.editShopList = element.Edit;
             this.addShopList = element.Add;
             this.deleteShopList = element.Delete;
           }
         });
  if (this.id !== 0) {
    this.spinner.show();
    this.companyService.getDataByID(this.id, 'getShopByID', 'Shop').subscribe(data => {
      this.spinner.hide();
      this.data = data.result;

      
      if(data.result.length !== 0){

        if(data.result.WelcomeNote !== null || data.result.WelcomeNote !== 'null' || data.result.WelcomeNote !== undefined) {
          this.wlcmArray1 = JSON.parse(data.result.WelcomeNote);
        }

        if(data.result.Discount === 'true') {
         this.data.Discount = true;
       } else if (data.result.Discount === 'false' ) {
         this.data.Discount = false;
       }
       if(data.result.GSTnumber === 'true') {
         this.data.GSTnumber = true;
       } else if (data.result.GSTnumber === 'false' ) {
         this.data.GSTnumber = false;
       } 
       if(data.result.HSNCode === 'true') {
        this.data.HSNCode = true;
      } else if (data.result.HSNCode === 'false' ) {
        this.data.HSNCode = false;
      } 
      if(data.result.CustGSTNo === 'true') {
        this.data.CustGSTNo = true;
      } else if (data.result.CustGSTNo === 'false' ) {
        this.data.CustGSTNo = false;
      }
      if(data.result.Rate === 'true') {
        this.data.Rate = true;
      } else if (data.result.Rate === 'false' ) {
        this.data.Rate = false;
      }
      if(data.result.Discounts === 'true') {
        this.data.Discounts = true;
      } else if (data.result.Discounts === 'false' ) {
        this.data.Discounts = false;
      }
      if(data.result.Tax === 'true') {
        this.data.Tax = true;
      } else if (data.result.Tax === 'false' ) {
        this.data.Tax = false;
      }
      if(data.result.SubTotal === 'true') {
        this.data.SubTotal = true;
      } else if (data.result.SubTotal === 'false' ) {
        this.data.SubTotal = false;
      }
      if(data.result.Total === 'true') {
        this.data.Total = true;
      } else if (data.result.Total === 'false' ) {
        this.data.Total = false;
      }
     
     }
      this.companyImage = this.sanitize(this.data.LogoURL);
    }, (err) => { console.log(err);
                  this.spinner.show();
    });
    
  }

}
  sanitize(imgName: string) {
    if (imgName !== null || imgName !== '') {
      this.stringUrl = this.env.apiUrl + imgName;
      return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } 
      else {return null; }
  }

 

  uploadImage(e,mode) {
    let image: File = e.target.files[0]
    console.log(`Image size before compressed: ${image.size} bytes.`)
    this.compressImage.compress(image)
      .pipe(take(1)).subscribe(compressedImage => {
        console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
        const frmData = new FormData();
        frmData.append('file', compressedImage);
        this.adminService.uploadFile(frmData).subscribe(data => {
          this.data.LogoURL = data.fileName;
          this.companyImage = this.sanitize(this.data.LogoURL);
          
          this.spinner.hide();
          this.showNotification(
            'bg-green',
            'Image successfully Uploaded',
            'bottom',
            'right'
          );
        }, (err) => {
          console.log(err);
          this.showNotification(
            'bg-red',
            'Image Not Uploaded.',
            'bottom',
            'right'
          );
        });
  })}

  copyData(val) {
    if (val) {
      this.data.GSTNo = this.loggedInCompany.GSTNo;
      this.data.CINNo = this.loggedInCompany.CINNo;
      this.data.Address = this.loggedInCompany.Address;
      this.data.Website = this.loggedInCompany.Website;
      this.data.Email = this.loggedInCompany.Email;
      this.data.LogoURL = this.loggedInCompany.LogoURL;
      this.data.PhoneNo = this.loggedInCompany.PhoneNo;
      this.data.MobileNo1 = this.loggedInCompany.MobileNo1;
      this.data.MobileNo2 = this.loggedInCompany.MobileNo2;
     
      this.data.HSNCode = this.loggedInCompanySetting.HSNCode;
      this.data.CustGSTNo = this.loggedInCompanySetting.GSTNo;
      this.data.Rate = this.loggedInCompanySetting.Rate;
      this.data.Discounts = this.loggedInCompanySetting.Discount;
      this.data.Tax = this.loggedInCompanySetting.CGSTSGST;
      this.data.SubTotal = this.loggedInCompanySetting.SubTotal;
      this.data.Total = this.loggedInCompanySetting.Total;
     
      
    }
  }

//   EnterSubmit(event, form) {
//     //keycode for
//  if (event.keyCode === 13) {
// alert('Enter key is pressed, form will be submitted')

// //calling submit method if key pressed is Enter.
// } }
// //function to submit the form submitit(form){
  


  onSubmit() {
  
    this.spinner.show();
    this.data.WelcomeNote = JSON.stringify(this.wlcmArray1);
    this.companyService.saveData('Shop', this.data).subscribe(data => {
      this.router.navigate(['/admin/shopList']);
      this.spinner.hide();
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Saved.',
                    'top',
                    'right'
                  );
});
  }

 

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

  addRow() {
    this.wlcmArray1.push({NoteType: 'Note', Content: ''});
  }
  delete(i) {
    this.wlcmArray1.splice(this.wlcmArray.indexOf(this.wlcmArray[i]), 1);
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


}
