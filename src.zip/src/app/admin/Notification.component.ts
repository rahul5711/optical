import { Component, OnInit } from '@angular/core';

import { CompanyService} from '../services/company.service';
import { AdminService} from '../services/admin.service';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { ThemePalette } from '@angular/material/core';
import { Subject } from 'rxjs';
import * as moment from 'moment';
import { UpperCasePipe } from '@angular/common';
import { PatternValidator } from '@angular/forms';


@Component({
  selector: 'app-Notification',
  templateUrl: './Notification.component.html',
  styleUrls: ['./Notification.component.css']
})
export class NotificationComponent implements OnInit {
  env = environment;
  bdayLink= '';
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  bdayList: any;
  lettar = UpperCasePipe;
  data: any={date1:"",}
  AnniversaryList: any;
  PlanExList: any;
  msgTemplate = [{"MessageName":"CustomerOrder","MessageID":"1307163237976266927","Required":true,"MessageText":"Hi ${ CustomerName }  Your order is ready for delivery Please collect it soon  Relinksys Software Pvt. Ltd ${ShopName}  ${ContactNo}  visit: ${Website}"},{"MessageName":"CustomerDelivery","MessageID":"1307163237989210790","Required":true,"MessageText":"Hi ${ CustomerName }  Thank you for being our valued customer Please visit again Open Bill :  ${ BillPDFLink}  Relinksys Software Pvt. Ltd  ${ ShopName}  ${ ContactNo} visit:  ${ Website}"},{"MessageName":"CustomerBill","MessageID":"1307163237961913349","Required":true,"MessageText":"Hi ${ CustomerName }  Thanks for shopping with us.  Open Bil :  ${ BillPDFLink}  Relinksys Software Pvt. Ltd  ${ShopName}  ${ContactNo} visit:  ${Website}"},{"MessageName":"CustomerCreditNote","MessageID":"","Required":true,"MessageText":""},{"MessageName":"Birthday","MessageID":"1307163237875741317","Required":true,"MessageText":"Hi ${ CustomerName }\nWish You Happy Birthday Get Special Discount Today\nRelinksys software ${ ShopName }\n${ ContactNo }\nVisit : ${Website}"},{"MessageName":"Anniversary","MessageID":"1307163237884851256","Required":true,"MessageText":"Hi ${ CustomerName } \nHappy Anniversary. May you two love birds stay happy and blessed always.\nRelinksys Sofdtware Pvt. Ltd ${ ShopName }\n${ ContactNo }\nVisit : ${Website}"},{"MessageName":"CustomerEyeTesting","MessageID":"","Required":true,"MessageText":""},{"MessageName":"CustomerContactlensExp","MessageID":"","Required":true,"MessageText":""}]
  constructor(private companyService: CompanyService,
    private adminService: AdminService,
    private router: Router,
    private snackBar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute,
) {}


ngOnInit(){
 this.getAnniversaryList();
 this.getPlanExList();
 this.getBdayList();
 
  
}

getBdayList(){
  let whereList = '';


  let date = new Date();
  let date1 =  moment(date).format('YYYY-MM-DD')
  whereList = whereList + ' and DATE_FORMAT(User.DOB, "%Y-%m-%d") between  ' +  `'${date1}'`;
  let date2 =  moment(date).add(3, 'days').format('YYYY-MM-DD')
   whereList = whereList + ' and ' + `'${date2}'`;
  // whereList = whereList + ' and Company.CancellationDate between ' +  `'${date1}'`; }


this.adminService.getfilterList('CompanyFilter', whereList).subscribe(data => {
  this.bdayList = data.result;
  const url = this.env.apiUrl + data;
  this.bdayLink = url;
  console.log(this.bdayList,"hpy bdta")
 
}, (err) => {
  console.log(err);
});
}

getAnniversaryList(){
  let whereList = '';


  let date = new Date();
  let date1 =  moment(date).format('YYYY-MM-DD')
  whereList = whereList + ' and DATE_FORMAT(User.Anniversary, "%Y-%m-%d") between ' +  `'${date1}'`;
  let date2 =  moment(date).add(3, 'days').format('YYYY-MM-DD')
  whereList = whereList + ' and ' + `'${date2}'`;
this.adminService.getfilterList('CompanyFilter', whereList).subscribe(data => {
  this.AnniversaryList = data.result
  console.log(this.AnniversaryList,"hpy anni")
}, (err) => {
  console.log(err);
});
}

getPlanExList(){
  let whereList = '';
  let date = new Date();
  let date2 =  moment(date).format('YYYY-MM-DD');
  let date1 = moment(date).subtract(5, 'days').format('YYYY-MM-DD');
    whereList = whereList + ' and DATE_FORMAT(Company.CancellationDate, "%Y-%m-%d") > ' +  `'${date1}'`;
      whereList = whereList + ' and DATE_FORMAT(Company.CancellationDate, "%Y-%m-%d") < ' +  `'${date2}'`;
this.adminService.getfilterList('CompanyFilter', whereList).subscribe(data => {
  this.PlanExList = data.result;
  console.log(this.PlanExList,"hpy plan")

 
}, (err) => {
  console.log(err);
});
}

sendCreditwh(data) {
  
    var url = `https://wa.me/${this.bdayList.MobileNo1}?text=`;
    window.open(url, "_blank");

}

sendWhbday(data){
  var msg = `Hi ${data.Name},%0A`+
      `Wish You Happy Birthday Get Special Discount Today%0A`+
       `Relinksys Software Pvt Ltd%0A`+
       `9766666284%0A`+
       `www.relinksys.com%0A`
       var mob = "91" + data.MobileNo1;
      var url = `https://wa.me/${mob}?text=${msg}`;
      window.open(url, "_blank");
  console.log(data)
}


sendMsgbday(data) {
  let temp = this.msgTemplate;
  let val = '';
  let phoneNo = data.MobileNo1;
    let CustomerName = data.Name;
    let ShopName = 'Pvt. Ltd';
    let ContactNo = '9766666248';
    let Website = 'www.relinksys.com';
  let message = '';
  let templateID = '';
  message = temp[temp.findIndex(element => element.MessageName === 'Birthday')].MessageText;
  templateID  = temp[temp.findIndex(element => element.MessageName === 'Birthday')].MessageID;
  message = eval('`'+message+'`');
  this.adminService.sendSms(phoneNo, message, templateID).subscribe(data => {
    this.showNotification(
      'bg-green',
      'Msg send successfully',
      'top',
      'right'
    );
  }, (err) => {
    this.showNotification(
      'bg-red',
      'Data Not Loaded.',
      'top',
      'right'
    );
  });
}

sendMsgAnni(data) {
  let temp = this.msgTemplate;
  let val = '';
  let phoneNo = data.MobileNo1;
    let CustomerName = data.Name;
    let ShopName = '';
    let ContactNo = '9766666248';
    let Website = 'www.relinksys.com';
  let message = '';
  let templateID = '';
  message = temp[temp.findIndex(element => element.MessageName === 'Anniversary')].MessageText;
  templateID  = temp[temp.findIndex(element => element.MessageName === 'Anniversary')].MessageID;
  message = eval('`'+message+'`');
  this.adminService.sendSms(phoneNo, message, templateID).subscribe(data => {
    this.showNotification(
      'bg-green',
      'Msg send successfully',
      'top',
      'right'
    );
  }, (err) => {
    this.showNotification(
      'bg-red',
      'Data Not Loaded.',
      'top',
      'right'
    );
  });
}



sendWhAnni(data){
  var msg = `Hi ${data.Name},%0A`+
  `Happy Anniversary. May you yo love bird stay happy and blessed always%0A`+
  `Relinksys Software Pvt Ltd%0A`+
  `9766666284%0A`+
  `www.relinksys.com%0A`
   var mob = "91" + data.MobileNo1;
  var url = `https://wa.me/${mob}?text=${msg}`;
  window.open(url, "_blank");
}

sendWhPlan(data){
  var msg = `Hi ${data.Name},%0A`+
  `You are Plan Expiry%0A`+
  `Relinksys Software Pvt Ltd%0A`+
  `9766666284%0A`+
  `www.relinksys.com%0A`
   var mob = "91" + data.MobileNo1;
  var url = `https://wa.me/${mob}?text=${msg}`;
  window.open(url, "_blank");
}

sendmailbday(data,mode){
  if(mode === "customBday"){
    let temp = {Name: data.Name, Email: data.Email};
    console.log(temp);
     this.adminService.sendEmail(temp, 'custom_Bday').subscribe(data2 => {
       this.showNotification(
         'bg-red',
         'Mail Send.',
         'top',
         'right'
       ); 
     }, (err) => { console.log(err);
                   
     });
  } else if(mode === "AnniversaryBday"){
    let temp = {Name: data.Name, Email: data.Email};
    console.log(temp);
     this.adminService.sendEmail(temp, 'Anniversary_Bday').subscribe(data2 => {
       this.showNotification(
         'bg-red',
         'Mail Send.',
         'top',
         'right'
       ); 
     }, (err) => { console.log(err);
                   
     });
  }else if(mode === "PlanEx"){
    let temp = {Name: data.Name, Email: data.Email};
    console.log(temp);
     this.adminService.sendEmail(temp, 'Plan_Ex').subscribe(data2 => {
       this.showNotification(
         'bg-red',
         'Mail Send.',
         'top',
         'right'
       ); 
     }, (err) => { console.log(err);
                   
     });
  }
}

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
