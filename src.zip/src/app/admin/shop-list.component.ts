import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Shop} from '../model/Shop';
import { CompanyService} from '../services/company.service';
import {DomSanitizer} from '@angular/platform-browser';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from '../../environments/environment';
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-shop-list',
  templateUrl: './shop-list.component.html'
})
export class ShopListComponent implements OnInit {
  term:any;
  gridview = true;
  env = environment;
  stringUrl: string;
  dataList: Shop[];
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  permission= JSON.parse(localStorage.getItem('Permission'));
 
  editShopList = false;
  addShopList = false;
  deleteShopList = false;


  constructor(
    private companyService: CompanyService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,
    private sanitizer: DomSanitizer,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.spinner.show();
    this.permission.forEach(element => {    
      if (element.ModuleName === 'ShopList') {
             this.editShopList = element.Edit;
             this.addShopList = element.Add;
             this.deleteShopList = element.Delete;
           }
         });
         
      

     this.companyService.getExtendedListByCompany1('ShopFullList', this.loggedInCompany.ID, '0').subscribe(data => {
      this.dataList = data.result;
      // localStorage.setItem('LoggedINShop', JSON.stringify(data.result));
      this.spinner.hide();
      this.santizePictureList();
      this.showNotification(
        'bg-green',
        'Data Loaded successfully',
        'top',
        'right'
      );
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Loaded.',
                    'top',
                    'right'
                  );
    });
    
  }

  santizePictureList() {
    this.dataList.forEach(element => {
    element.LogoURL = this.sanitize(element.LogoURL);
  });
  }

sanitize(imgName: string) {
  if (imgName !== "null" && imgName !== '') {
    this.stringUrl = this.env.apiUrl + imgName;
   } else {
     this.stringUrl = this.env.apiUrl + 'no-image.jpg';
    }
  return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl);
}
deleteItem(i){
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      this.companyService.deleteData('Shop', this.dataList[i].ID).subscribe(data => {
        this.dataList.splice(i, 1);
        this.showNotification(
        'bg-green',
        'Data Deleted Successfully',
        'top',
        'right'
        );
        }, (err) => {
        this.showNotification(
        'bg-red',
        'Could Not Delete Data.',
        'top',
        'right'
        );
        });
      Swal.fire(
        'Deleted!',
        'Your file has been deleted.',
        'success'
      )
    }
  })
}



 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

newShop(){
  if (this.dataList.length >= this.loggedInCompany.NoOfShops){
Swal.fire({
  icon: 'error',
  title: 'ERROR',
  text: 'You Can Not Add a New Shop',
  footer: 'New Shop Can Not Be Added as Your Plan Does Not Allow'
});
  } else {
    this.router.navigate(['/admin/shop/0']);
  }
}
}
