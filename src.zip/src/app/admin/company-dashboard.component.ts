import { Component, Input, OnInit } from '@angular/core';
import * as moment from 'moment';
import { CompanyService } from '../services/company.service';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-company-dashboard',
  templateUrl: './company-dashboard.component.html',
  styleUrls: ['./company-dashboard.component.css']
})
export class CompanyDashboardComponent implements OnInit {

 

  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInShop = JSON.parse(localStorage.getItem('LoggedINShop'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  permission = JSON.parse(localStorage.getItem('Permission'));
  
  viewCompanyInfo = true; viewEmployee= true; viewEmployeeList= true; viewNewShop= true; viewShopList= true; viewRolePermission= true; viewCompanySetting: any= true;
  viewProductType= true; viewManageProducts= true; viewServiceManagement= true; viewSupplier= true; viewSupplierList= true; viewPurchaseList= true; 
  viewPurchase= true;  viewTransferProduct= true;  viewPreOrderProduct= true;  viewPreOrderHistory= true;
  viewCustomerList= true; viewNewCustomer= true;  viewDoctorManagement= true;  viewDoctorList= true;  viewBillingList= true; 
  viewBilling= true; viewPaymentList= true; viewPayment= true; viewReceivableList= true;  viewReceive= true; 
  viewInventory= true; viewSale= true; viewAccounting= true; viewCustomer= true; 
  viewProductTransfer = true; viewProductManagement = true;

  range: any;
  filter: any =  {date1: moment().format('YYYY-MM-DD'),
  date2: moment().add( 2 , 'days').format('YYYY-MM-DD'), customerID: 0, ShopID: 0, ProductTypeName: ''};
  disableDates: boolean = true;
  dataList: any;
  shopList: any;
  plusIcon = false;
  dataList1: any;




  constructor(private companyService: CompanyService,
        private spinner: NgxSpinnerService,
    private snackBar: MatSnackBar,) {
  }

  ngOnInit() {


    
    this.getShopList();
    this.range = 'Today';
    this.getDateRange();
    this.searchData();
    this.permission.forEach(element => {
      if (element.ModuleName === 'Supplier') {
        this.viewSupplier = element.MView;
      } else if (element.ModuleName === 'SupplierList') {
        this.viewSupplierList = element.MView;
      }else if (element.ModuleName === 'Purchase') {
        this.viewPurchase = element.MView;
      }else if (element.ModuleName === 'PurchaseList') {
        this.viewPurchaseList = element.MView;
      }else if (element.ModuleName === 'CompanyInfo') {
        this.viewCompanyInfo = element.MView;
      }else if (element.ModuleName === 'Employee') {
        this.viewEmployee = element.MView;
      }else if (element.ModuleName === 'EmployeeList') {
        this.viewEmployeeList = element.MView;
      }else if (element.ModuleName === 'Shop') {
        this.viewNewShop = element.MView;
      }else if (element.ModuleName === 'ShopList') {
        this.viewShopList = element.MView;
      }else if (element.ModuleName === 'RolePermission') {
        this.viewRolePermission = element.MView;
      }else if (element.ModuleName === "CompanySetting") {
        this.viewCompanySetting = element.MView;
      }else if (element.ModuleName === 'ProductType') {
        this.viewProductType = element.MView;
      }else if (element.ModuleName === 'ManageProduct') {
        this.viewManageProducts = element.MView;
      }else if (element.ModuleName === 'ServiceManagement') {
        this.viewServiceManagement = element.MView;
      }else if (element.ModuleName === 'TransferProduct') {
        this.viewTransferProduct  = element.MView;
      }else if (element.ModuleName === 'PreOrderProduct') {
        this.viewPreOrderProduct = element.MView;
      }else if (element.ModuleName === 'PreOrderHistory') {
        this.viewPreOrderHistory = element.MView;
      }else if ( element.ModuleName === 'CustomerList') {
        this.viewCustomerList = element.MView;
      }else if(element.ModuleName === 'NewCustomer'){
        this.viewNewCustomer = element.MView;
      }else if(element.ModuleName === 'DoctorManagement'){
        this.viewDoctorManagement = element.MView;
      }else if(element.ModuleName === 'DoctorList'){
        this.viewDoctorList = element.MView;
      }else if(element.ModuleName = 'BillingList'){
        this.viewBillingList = element.MView;
      }else if(element.ModuleName === 'Billing'){
        this.viewBilling = element.MView;
      }else if(element.ModuleName === 'PaymentList'){
        this.viewPaymentList = element.MView;        
      }else if(element.ModuleName === 'Payment'){
        this.viewPayment = element.MView;
      }else if(element.ModuleName === 'ReceivableList'){
        this.viewReceivableList = element.MView;
      }else if(element.ModuleName === 'Receive'){
        this.viewReceive = element.MView;
      }else if(element.ModuleName === 'Inventory'){
        this.viewInventory = element.MView;
      }else if(element.ModuleName === 'Sale'){
        this.viewSale = element.MView;
      }else if(element.ModuleName === 'Accounting'){
        this.viewAccounting = element.MView;
      }else if(element.ModuleName === 'Customer'){
        this.viewCustomer = element.MView;
      }
    });


    this.companyService.getExtendedListByCompany1('DashBillmaster', this.loggedInCompany?.ID, this.loggedInShop?.ID).subscribe(data => {
      this.dataList1 = data.result;
      // localStorage.setItem('LoggedINShop', JSON.stringify(data.result));
      this.spinner.hide();
   
    
    }, (err) => { console.log(err);
                  this.spinner.hide();
                 
    });

  }

  
  getDateRange(){
    let d1 = moment().format('YYYY-MM-DD');
    let d2 = moment().format('YYYY-MM-DD'); 
    if(this.range === 'Custom Range'){ this.disableDates = false} else { this.disableDates = true}
        switch (this.range) {
          case "Today":
            d1 = moment().format('YYYY-MM-DD');
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Yesterday":
            d1 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'days').format('YYYY-MM-DD'); 
            break;
          case "This Week":
            d1 = moment().startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Week":
            d1 = moment().subtract(7, 'days').startOf('week').format('YYYY-MM-DD'); 
            d2 = moment().subtract(7, 'days').endOf('week').format('YYYY-MM-DD'); 
            break;
          case "This Month":
            d1 = moment().startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().format('YYYY-MM-DD');
          break;
          case "Last Month":
            d1 = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD'); 
            break;
          case "This Quarter":
            d1 = moment().startOf('quarter').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Quarter":
            d1 = moment().subtract(1, 'quarters').startOf('quarter').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'quarters').endOf('quarter').format('YYYY-MM-DD'); 
            break;
          case "This Year":
            d1 = moment().startOf('year').format('YYYY-MM-DD'); 
            d2 = d2 = moment().format('YYYY-MM-DD');
            break;
          case "Last Year":
            d1 = moment().subtract(1, 'years').startOf('year').format('YYYY-MM-DD'); 
            d2 = moment().subtract(1, 'years').endOf('year').format('YYYY-MM-DD'); 
            break;
                  
          default:
            
            break;
        }
        this.filter.date1 = d1;
        this.filter.date2 = d2;
      }

      searchData() {
        this.companyService.getDashboardData(this.filter.date1, this.filter.date2, this.filter.ShopID ).subscribe(data => {
          this.dataList = data.result;    
        }, (err) => {
          console.log(err);
        });
      }

      getShopList() {
        this.companyService.getShortListByCompany('Shop', 0).subscribe(data => {
          this.shopList = data.result;
        
        }, (err) => {
          console.log(err);
          // this.showFailure(err, 'Error Loading Data.');
         
        });
      }

      
}
