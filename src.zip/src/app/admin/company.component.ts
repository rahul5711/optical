import { Component, OnInit } from '@angular/core';
import { Company} from '../model/Company';
import { AdminService} from '../services/admin.service';
import { User} from '../model/User';
import {DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { ThemePalette } from '@angular/material/core';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { CompanyService } from '../services/company.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import {CompressImageService} from '../services/compress-image.service'
import { take } from 'rxjs/operators';

@Component({ selector: 'app-company', templateUrl: './company.component.html'
})

export class CompanyComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  
data: Company = {
  ID: null, CompanyName: null, MobileNo1: null, MobileNo2: null, PhoneNo: null, Address: null, Country: null, State: null, City: null, Email: null, Website: null,
  GSTNo: null, CINNo: null, LogoURL: null, Remark: null, Plan: null, Version: null, NoOfShops: null, EffectiveDate: new Date(),
  CancellationDate: null, WhatsappMsg: false, EmailMsg: false, WholeSale: false, RetailPrice: false, Status: 1, CreatedBy: null, CreatedOn: null, UpdatedBy: null, UpdatedOn: null,
  dataFormat: undefined
};
data1: any = { ID : null, CompanyID : null, Name : "", UserGroup : "", DOB : null, Anniversary : null, MobileNo1 : null,
  MobileNo2 : null, PhoneNo : null, Email : null, Address : null, Branch : null, FaxNo : null, Website : null, PhotoURL : null,
  LoginName : "", Password : "", Status : 1, CreatedBy : null, UpdatedBy : null, CreatedOn : "", UpdatedOn : null
};

color: ThemePalette = 'primary';
plans: any[] = [
{ID: 1, Name: 'Trial Plan (15 Days)', days: 15},
{ID: 2, Name: 'Monthly Plan (30 Days)', days: 30}, 
{ID: 3, Name: 'Half Yearly Plan (180 Days)', days: 180},
{ID: 4, Name: 'Yearly Plan (365 Days)' , days: 360}];
  stringUrl: string;
  companyImage: any;
  userImage: any;
  disableSuperAdminFields = false;
  toggleChecked = false;
  companySettingDefault = { ID:null, CompanyID:null, CompanyLanguage:"English", CompanyCurrency:"INR", CurrencyFormat:"4.2-2",DateFormat:"llll",CompanyTagline:"",BillHeader:"",BillFooter:null,RewardsPointValidity:null,
  EmailReport:0,MessageReport:0,LogoURL:null,Status:1, SenderID: '', SmsSetting: ''
  };


  oldLoginName = "";
  
constructor(private adminService: AdminService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
            private spinner: NgxSpinnerService,
            private snackBar: MatSnackBar,
            private companyService: CompanyService,
            private compressImage: CompressImageService
  ) {}
 


public id =  parseInt(this.route.snapshot.paramMap.get('id'), 10);

ngOnInit(){
  if (this.loggedInUser.UserGroup !== 'SuperAdmin' ) {
    this.disableSuperAdminFields = true;
  }
  
  if (this.id !== 0) {
    this.spinner.show();
    this.adminService.getDataByID(this.id , 'getCompanyByID', 'Company').subscribe(data => {
      this.spinner.hide();
      this.data = data.result;
      this.data.CompanyName = data.result.Name;

      if (data.result.MobileNo2 == 'null' || data.result.MobileNo2 == null ) {
        this.data.MobileNo2 = null;
      }
      if(data.result.WhatsappMsg === 'true') {
        this.data.WhatsappMsg = true;
      } else if (data.result.WhatsappMsg === 'false' || data.result.WhatsappMsg === null) {
        this.data.WhatsappMsg = false;
      }
      if(data.result.EmailMsg === 'true') {
        this.data.EmailMsg = true;
      } else if (data.result.EmailMsg === 'false' || data.result.EmailMsg === null) {
        this.data.EmailMsg = false;
      }
      if(data.result.WholeSale === 'true') {
        this.data.WholeSale = true;
      } else if (data.result.WholeSale === 'false' || data.result.WholeSale === null) {
        this.data.WholeSale = false;
      }

      if(data.result.RetailPrice === 'true') {
        this.data.RetailPrice = true;
      } else if (data.result.RetailPrice === 'false' || data.result.RetailPrice === null) {
        this.data.RetailPrice = false; 
      }
       
      
      console.log(data , 'data');
      this.companyImage = this.sanitize(this.data.LogoURL);
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }
  
  if (this.id !== 0) {
    this.spinner.show();
    this.adminService.getDataByID(this.id, 'getOwnerDataByID', 'User').subscribe(data => {
      this.spinner.hide();
      this.data1 = data.result;

     this.oldLoginName =  this.data1.LoginName;

      if (data.result.Anniversary === '0000-00-00') {
        this.data1.Anniversary = null;
      }
      if (data.result.DOB === '0000-00-00') {
        this.data1.DOB = null;
      }
      
      console.log(data , 'data1');

      this.userImage = this.sanitize(this.data1.PhotoURL);
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }

}

onPlanChange(value){  
  if(this.id !== 0) {
    this.data.EffectiveDate = new Date();
  }
  if (value === 1) {
      const d = new Date().setDate(this.data.EffectiveDate.getDate() + 15);
      const date = new Date(d);
      this.data.CancellationDate = date;
  }
  if (value === 2) {
    const e = new Date().setDate(this.data.EffectiveDate.getDate() + 30);
    const date1 = new Date(e);
    this.data.CancellationDate = date1;
  }
  if (value === 3) {
  const f = new Date().setDate(this.data.EffectiveDate.getDate() + 181);
  const date2 = new Date(f);
  this.data.CancellationDate = date2;
  }
  if (value === 4) {
    const a = new Date().setDate(this.data.EffectiveDate.getDate() + 365);
    const date3 = new Date(a);
    this.data.CancellationDate = date3;
    }
}

sanitize(imgName: string) {
  if (imgName !== null || imgName !== '') {
    this.stringUrl = this.env.apiUrl + imgName;
    return this.sanitizer.bypassSecurityTrustUrl(this.stringUrl); } else {return null; }
}

uploadImage(e, mode){
  let image: File = e.target.files[0]
  console.log(`Image size before compressed: ${image.size} bytes.`)
  this.compressImage.compress(image)
    .pipe(take(1)).subscribe(compressedImage => {
      console.log(`Image size after compressed: ${compressedImage.size} bytes.`)
      const frmData = new FormData();
      frmData.append('file', compressedImage);
  this.adminService.uploadFile(frmData).subscribe(data => {
  this.showNotification(
    'bg-green',
    'Image successfully Uploaded',
    'top',
    'right'
  );
  if (mode === 'Company'){
    this.data.LogoURL = data.fileName;
    this.companyImage = this.sanitize(this.data.LogoURL);
  } else if (mode === 'User'){
    this.data1.PhotoURL = data.fileName;
    this.userImage = this.sanitize(this.data1.PhotoURL);
  }
  }, (err) => { console.log(err);
                this.showNotification(
                  'bg-red',
                  'Error Uploading Image.',
                  'top',
                  'right'
                );
  });
})}


checkforDuplicate(){
  if(this.oldLoginName !== this.data1.LoginName){
    this.companyService.checkforDuplicate('User', this.data1.LoginName).subscribe(res => {
      console.log(res , 'ressssssssssss');
    //  if(res.result === false)
    //  {Swal.fire({
    //   icon: 'question',
    //   title: 'Alredy Exist',
    //   text: 'Login Name Alredy Exist, Please Use Unique Name!',
     
    // })
    // }
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }
}


onsubmit1() {
  if(this.oldLoginName !== this.data1.LoginName){
    this.companyService.checkforDuplicate('User', this.data1.LoginName).subscribe(res => {
      if(res.result === false){
        this.spinner.hide(); 
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Login Name alredy Exist, Please Use Unique Name!',
         
        });
        // alert ("Login Name alredy Exist, Please Use Unique Name");
       } else {
      this.onSubmit();
      }
     }, (err) => {
       console.log(err);
       this.showNotification(
         'bg-red',
         'Error Loading Data.',
         'top',
         'right'
       );
     });
  } else if(this.data1.ID !== null){
    this.onSubmit();
  }
}

onSubmit() {
  this.spinner.show();

  this.adminService.saveData('Company', this.data).subscribe(data => {
    console.log(data.result);
    
    if (this.id === 0 && data.result.insertId !== undefined ){
      this.data1.CompanyID = data.result.insertId;

      this.companySettingDefault.CompanyID = this.data1.CompanyID;
      this.adminService.saveData('CompanySetting', this.companySettingDefault).subscribe(data2 => {
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Saved.',
          'top',
          'right'
        );
        }, (err) => { console.log(err);
                      this.spinner.hide();
                      this.showNotification(
                        'bg-red',
                        'Data Not Save.',
                        'top',
                        'right'
                      );
        });

        

    }
   
    this.data1.UserGroup = 'CompanyAdmin';
   this.data1.Document = [];
   this.data1.CommissionType = 0;
   this.data1.CommissionMode = 0;
   this.data1. CommissionValue = 0;
   this.data1.CommissionValueNB = 0;
    this.adminService.saveData('User', this.data1).subscribe(data1 => {
      
    this.spinner.hide();
    this.showNotification(
      'bg-green',
      'Data Saved.',
      'top',
      'right'
    );
    if (this.loggedInUser.UserGroup !== 'SuperAdmin'){
    this.disableSuperAdminFields = true;
  }
   //  for email sent 
   if (this.id === 0){
   this.sendemail();
   }

    if (!this.disableSuperAdminFields){
      this.router.navigate(['/admin/companyList']);
    } else {
      this.router.navigate(['/admin/companyDashboard']);
    }
    }, (err) => { console.log(err);
                  this.spinner.hide();
                  this.showNotification(
                    'bg-red',
                    'Data Not Save.',
                    'top',
                    'right'
                  );
    });
  }, (err) => { console.log(err);
                this.spinner.hide();
                this.showNotification(
                  'bg-red',
                  'Error Loading Data.',
                  'top',
                  'right'
                );
  });
  
}

  copyData(val) {
    if (val) {
      this.data1.Name = this.data.CompanyName;
      this.data1.MobileNo1 = this.data.MobileNo1;
      this.data1.MobileNo2 = this.data.MobileNo2;
      this.data1.PhoneNo = this.data.PhoneNo;
      this.data1.Address = this.data.Address;
      this.data1.Email = this.data.Email;
    }
  }


  sendemail() {

    this.adminService.getDataByID(this.data1.CompanyID, 'getOwnerDataByID', 'User').subscribe(data => {
    this.adminService.sendEmail(data.result, 'registermail').subscribe(data2 => {
      this.showNotification(
        'bg-red',
        'Mail Send.',
        'top',
        'right'
      ); 
    }, (err) => { console.log(err);
                  
    });
    }, (err) => { console.log(err);            
    });
   
  }

  checkEmailDuplicate() {
    let Param = `Email = '${this.data1.Email}'`
    this.adminService.getForgetPassword('User', Param).subscribe(data => {
   if(data.result.length !== 0) {
     this.data.Email = null;
    alert("you cant fill duplicate email id");
   }

       }, (err) => { console.log(err);   });
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
