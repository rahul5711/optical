import { Component, OnInit } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { AdminService} from '../services/admin.service';

import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-compnay-assign',
  templateUrl: './compnay-assign.component.html'
})
export class CompnayAssignComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
 

  searchValue:any;
  companyList: any;


 data: any = {companyid:''}
  item = [];

constructor(private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
            private spinner: NgxSpinnerService,
            private snackBar: MatSnackBar,
            private adminService: AdminService,

            
) {}

  ngOnInit() {
    this.spinner.show();
    this.getCompanysList();
 
  }

  getCompanysList(){
    this.adminService.getCompanyList('Company').subscribe(data => {
        this.companyList = data.result;
        this.spinner.hide();

      }, (err) => { console.log(err);
        this.spinner.hide();

                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }

  onSubmit(){
    this.adminService.assignProduct(this.data).subscribe(data => {
console.log(data.success);
if(data.success === 'Success') {
  this.adminService.getProductAssignList(this.data.companyid).subscribe(data => {
    this.item = data.result;
    this.showNotification(
      'bg-green',
      'Data Saved',
      'top',
      'right'
    );
}, (err) => { console.log(err);
          this.showNotification(
            'bg-red',
            'Error Loading Data.',
            'top',
            'right'
          );
});
}

    }, (err) => { console.log(err);
                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }


  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }


  getAssignList() {
    this.adminService.getProductAssignList(this.data.companyid).subscribe(data => {
            this.item = data.result;
    }, (err) => { console.log(err);
                  this.showNotification(
                    'bg-red',
                    'Error Loading Data.',
                    'top',
                    'right'
                  );
    });
  }

}
