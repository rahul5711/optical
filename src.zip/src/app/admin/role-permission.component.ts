import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../services/company.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2/dist/sweetalert2.js';



@Component({
  selector: 'app-role-permission',
  templateUrl: './role-permission.component.html'
})
export class RolePermissionComponent implements OnInit {
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany')).ID;
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));

  roleList = [];
  selectedRole = {ID: null, Name: "", CompanyID: this.loggedInCompany, Permission: "", Status: 1};
  showAdd = false;

  moduleList: any = [
    {ModuleName: 'CompanyInfo', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Employee', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'EmployeeList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Shop', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ShopList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'RolePermission', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CompanySetting', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'DepartmentManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'LoginHistory', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ProductType', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ManageProduct', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ServiceManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ChargeManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'AddManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Supplier', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SupplierList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Purchase', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseReturn', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseConvert', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'TransferProduct', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'AcceptTranfer', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PreOrderProduct', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PreOrderHistory', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ProductInventory', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SearchBarcode', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Fitter', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'FitterList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'FitterInvoice', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'FitterInvoiceList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'PaymentList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'Payment', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'ReceivableList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    // {ModuleName: 'Receivable', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'NewCustomer', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CustomerList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Billing', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'BillingList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'DoctorManagement', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'DoctorList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CashRegister', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Payment', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PaymentList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Payroll', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'payrollList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'Expense', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ExpenseList', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'InventoryReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SaleReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SalePaymentReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SaleProfitReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'AccountingReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CustomerReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CashCollectionReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'LaserReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ReminderReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ServiceReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ExpiryReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'TransferReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'EyeReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PurchaseReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'SaleDetailsReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ProductSummaryReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'ExpenseReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'PettyCashReport', MView: true, Edit: true, Add: true, View: true, Delete: true},
    {ModuleName: 'CashCounterReport', MView: true, Edit: true, Add: true, View: true, Delete: true},



  ];
  displayModule: any;

  constructor(private companyService: CompanyService,
              private router: Router,
              private sanitizer: DomSanitizer,
              private route: ActivatedRoute,
              private snackBar: MatSnackBar,
              private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    this.getRoleList();
  }

  getRoleList() {
    this.spinner.show();
    this.companyService.getShortListByCompany('Role',1).subscribe(data => {
      this.roleList = data.result;
      this.spinner.hide();
      console.log(data.result, 'rolelist');
    }, (err) => {
      console.log(err);
      this.spinner.hide();
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  setdata() {
    if (this.selectedRole.ID === null) {
      this.selectedRole.Permission = JSON.stringify(this.moduleList);
      this.displayModule = this.moduleList;
    } else {
          // tslint:disable-next-line: prefer-for-of
          for (var i = 0; i < this.roleList.length; i++ ) {
          if (this.roleList[i].ID === this.selectedRole.ID){
            if (this.roleList[i].Permission === ""){
          this.displayModule = this.moduleList;
        } else {
          this.displayModule = JSON.parse(this.roleList[i].Permission);
        }
      }
    }
    }
  }

  getModuleList() {
    this.companyService.geListByOtherID('Module', this.selectedRole.ID).subscribe(data => {
      this.moduleList = data.result;
      this.showNotification(
        'bg-green',
        'Data Loaded',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Error Loading Data.',
        'top',
        'right'
      );
    });
  }

  saveRole() {
    let count = 0;
    this.roleList.forEach(element => {
      if (element.Name.toLowerCase() === this.selectedRole.Name.toLowerCase().trim()){count = count + 1; }

    });
    if (count === 0 && this.selectedRole.Name !== '' && this.selectedRole.Name !== null && this.selectedRole.Name !== undefined) {
      this.selectedRole.ID = null;
      this.spinner.show();
      this.selectedRole.Permission = JSON.stringify(this.moduleList);
      this.selectedRole.CompanyID = this.loggedInCompany;
      this.companyService.saveData('Role', this.selectedRole).subscribe(data => {
        this.getRoleList();
        this.selectedRole.Name = "";
        this.spinner.hide();
        this.showNotification(
          'bg-green',
          'Data Saved',
          'top',
          'right'
        );
      }, (err) => {
        console.log(err);
        this.spinner.hide();
        this.showNotification(
          'bg-red',
          'Data Not Saved.',
          'top',
          'right'
        );
      });
    } else {
      //  alert ("Duplicate or Empty Values are not allowed");
      Swal.fire({
        icon: 'error',
        title: 'Duplicate or Empty Values are not allowed',
        text: '',
        footer: ''
      });
  this.selectedRole.Name = ""; }
  
  }

  savePermission() {
    this.selectedRole.Permission = JSON.stringify(this.displayModule);
    this.companyService.saveData('Role', this.selectedRole).subscribe(data => {
      this.getRoleList();
      this.showNotification(
        'bg-green',
        'Data Saved',
        'top',
        'right'
      );
    }, (err) => {
      console.log(err);
      this.showNotification(
        'bg-red',
        'Data Not Saved.',
        'top',
        'right'
      );
    });
  }


  // deleteRole() {
  //   this.companyService.deleteData('Role', this.selectedRole.ID).subscribe(data => {
      
  //     this.getRoleList();
  //     this.showNotification(
  //       'bg-green',
  //       'Data Deleted',
  //       'top',
  //       'right'
  //     );
  //   }, (err) => {
  //     console.log(err);
  //     this.showNotification(
  //       'bg-red',
  //       'Data Not Deleted.',
  //       'top',
  //       'right'
  //     );
  //   });
  // }

  deleteRole(){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.companyService.deleteData('Role', this.selectedRole.ID).subscribe(data => {
      
          this.getRoleList();
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  setPermissionValue(i) {
    if(this.displayModule[i].MView === true) {
      this.displayModule[i].View = false;
      this.displayModule[i].Edit = false;
      this.displayModule[i].Add = false;
      this.displayModule[i].Delete = false;

    } else {
      this.displayModule[i].View = true;
      this.displayModule[i].Edit = true;
      this.displayModule[i].Add = true;
      this.displayModule[i].Delete = true;

    }
  }

   onChange(event) {
    if (this.loggedInCompanySetting.DataFormat === '1') {
      event = event.toUpperCase()
    } else if (this.loggedInCompanySetting.DataFormat == '2') {
      event = event.toTitleCase()
    }
    return event;
  }

 showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }
}


