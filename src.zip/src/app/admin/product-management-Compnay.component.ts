import { Component, OnInit } from '@angular/core';
import { CompanyService} from '../services/company.service';
import { DomSanitizer} from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from "ngx-spinner";
import { AdminService} from '../services/admin.service';

import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-product-management-Compnay',
  templateUrl: './product-management-Compnay.component.html'
})
export class ProductManagementCompnayComponent implements OnInit {
  env = environment;
  loggedInUser = JSON.parse(localStorage.getItem('LoggedINUser'));
  permission= JSON.parse(localStorage.getItem('Permission'));
  loggedInCompanySetting = JSON.parse(localStorage.getItem('LoggedINCompanySetting'));
  loggedInCompany = JSON.parse(localStorage.getItem('LoggedINCompany'));
 

  editManageProduct = false;
  addManageProduct = false;
 

productList: any[];
specList: any;

newSpec: any = {ID : null, ProductName: '', Name : '', Seq: null,  Type: '', Ref: 0, SptTableName: '', Required: false  };
selectedProduct: any = '';
selectedHSNCode: any = '';
prodList: any[];
showAdd = false;
newProduct = {Name: "", HSNCode: ""};
fieldType: any[] = [{ID: 1, Name: "DropDown"}, {ID: 2, Name: "Text"}, {ID: 3, Name: "boolean"} , {ID: 4, Name: "Date"}];
  selectedProductID: any;
  searchValue:any;


constructor(private companyService: CompanyService,
            private router: Router,
            private sanitizer: DomSanitizer,
            private route: ActivatedRoute,
            private spinner: NgxSpinnerService,
            private snackBar: MatSnackBar,
            private adminService: AdminService,

            
) {}

  ngOnInit() {
    this.spinner.show();
    this.getProductList();
 
  }

  getProductList(){
    this.adminService.getCompanyList('Product').subscribe(data => {
        this.prodList = data.result;
        this.spinner.hide();

      }, (err) => { console.log(err);
        this.spinner.hide();

                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
  }


  getfieldList(){
    this.prodList.forEach(element => {
      if (element.Name === this.selectedProduct) {
        this.selectedHSNCode = element.HSNCode;
        this.selectedProductID = element.ID; 
      }
    });
    if (this.selectedProduct !== null || this.selectedProduct !== '' ){
    this.adminService.getDataByName('ProductSpec', this.selectedProduct).subscribe(data => {
      this.specList = data.result;
      }, (err) => { console.log(err);
                    this.showNotification(
                      'bg-red',
                      'Error Loading Data.',
                      'top',
                      'right'
                    );
      });
    }
  }

  //  onChange(event) {
  //   if (this.loggedInCompanySetting.DataFormat === '1') {
  //     event = event.toUpperCase()
  //   } else if (this.loggedInCompanySetting.DataFormat == '2') {
  //     event = event.toTitleCase()
  //   }
  //   return event;
  // }

  saveSpec(){
      this.spinner.show();
      let count = 0;
      this.specList.forEach(element => {
        if (element.Name.toLowerCase() === this.newSpec.Name.toLowerCase() ){
          count = count + 1; 
        }
      });
      if (count === 0 && this.newSpec.Name !== '' && this.newSpec.Type !== ''){
      this.newSpec.ProductName = this.selectedProduct;
      if (this.newSpec.Type === 'DropDown' && this.newSpec.SptTableName === ''){
          this.newSpec.SptTableName = this.newSpec.Name + Math.floor(Math.random() * 999999) + 1 ;
      }
      let specData = this.newSpec;
      specData.ProductName = this.selectedProduct;
      console.log(this.selectedProduct)
      this.newSpec = {ID : null, ProductName: '', Name : '', Seq: null,  Type: '', Ref: 0, SptTableName: '', Required: false  };
      this.adminService.saveData('ProductSpec', specData).subscribe(data => {
        this.getfieldList();
        this.spinner.hide();
        }, (err) => { console.log(err);
          this.spinner.hide();
  
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
      } else {
        this.spinner.hide();
  
        // alert('Can not Save. Missing required fields');
        Swal.fire({
          icon: 'error',
          title: 'Duplicate or Empty Values are not allowed',
          text: ' Fill all Required Fields ',
          footer: ''
        });
       }

  }

  // checkDuplicateProduct() {
  //   this.prodList.forEach(element => {
  //     if (element.Name.toLowerCase() === this.newProduct.Name.toLowerCase() ){
  //       Swal.fire({
  //         icon: 'error',
  //         title: 'Duplicate or Empty Values are not allowed',
  //         text: '',
  //         footer: ''
  //       });
  //     }

  //   });
  // }

  saveProduct(){
      this.adminService.saveData('Product', this.newProduct).subscribe(data => {
          this.prodList = data.result;
        }, (err) => { console.log(err);
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
   
  this.newProduct.Name = ""; 
  }

  deleteProductType(){
    if (this.specList.length === 0 ) {
      this.adminService.deleteData1('Product', this.selectedProductID ).subscribe(data => {
        this.newProduct.HSNCode = "";
        this.selectedHSNCode = "";
        this.getProductList();
        }, (err) => { console.log(err);
                      this.showNotification(
                        'bg-red',
                        'Error Loading Data.',
                        'top',
                        'right'
                      );
        });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'ERROR',
        text: 'First delete related Feild',
        footer: ''
      }); 
    }

   
  }

 

  generateTableName(){
    if (this.newSpec.Type === 'DropDown'){
    if (this.newSpec.SptTableName !== '' || this.newSpec.SptTableName !== null) {
      this.newSpec.SptTableName = this.newSpec.Name + Math.floor(Math.random() * 1000) + 1 ;
    }
  }
  }

  onSubmit() {
    // this.adminService.saveData('Company', this.data).subscribe(data => {
    //   if (this.id === 0){
    //     this.data1.CompanyID = data.insertId; }
    //   this.data1.UserGroup = 'CompanyAdmin';
    //   this.adminService.saveData('User', this.data1).subscribe(data1 => {
    //   }, (err) => { console.log(err);
    //                 this.showFailure(err, 'Error Loading Data.');
    //   });
    // }, (err) => { console.log(err);
    //               this.showFailure(err, 'Error Loading Data.');
    // });
  }

  deleteItem(i){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.adminService.deleteData1('ProductSpec', this.specList[i].ID).subscribe(data => {
          this.specList.splice(i, 1);
          this.showNotification(
          'bg-green',
          'Data Deleted Successfully',
          'top',
          'right'
          );
          }, (err) => {
          this.showNotification(
          'bg-red',
          'Could Not Delete Data.',
          'top',
          'right'
          );
          });
        Swal.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
      }
    })
  }

  // deleteItem(i){
  //   this.companyService.deleteData('ProductSpec', this.specList[i].ID).subscribe(data => {
  //   this.specList.splice(i, 1);
  //   this.showNotification(
  //   'bg-green',
  //   'Data Deleted Successfully',
  //   'top',
  //   'right'
  //   );
  //   }, (err) => {
  //   this.showNotification(
  //   'bg-red',
  //   'Could Not Delete Data.',
  //   'top',
  //   'right'
  //   );
  //   });
  //   }

  showNotification(colorName, text, placementFrom, placementAlign) {
  
    this.snackBar.open(text, '', {
      duration: 2000,
      // verticalPosition: placementFrom,
      horizontalPosition: 'left',
      panelClass: colorName,
      verticalPosition: 'bottom'
      
    });
  }

}
