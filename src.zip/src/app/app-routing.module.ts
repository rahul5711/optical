import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './common/welcome.component';
import { LoginComponent } from './common/login.component';
import { DoctorLoginComponent } from './common/doctor-login.component';
import { DashboardComponent } from './common/dashboard.component';

import { CommonComponent } from './common/common.component';
import { AuthGuard } from './auth/auth.guard';


const routes: Routes = [
{path: '' , component: WelcomeComponent},
{path: 'login' , component: LoginComponent},
{path: 'doctor-login' , component: DoctorLoginComponent},
{path: '', component: CommonComponent,
children: [
  { path: 'admin',  loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),canActivate: [AuthGuard]},
  { path: 'report', loadChildren: () => import('./report/report.module').then(m => m.ReportModule),canActivate: [AuthGuard] },
  { path: 'inventory', loadChildren: () => import('./inventory/inventory.module').then(m => m.InventoryModule),canActivate: [AuthGuard] },
  { path: 'prodservice', loadChildren: () => import('./prodservice/prodservice.module').then(m => m.ProdserviceModule),canActivate: [AuthGuard] },
  { path: 'sale', loadChildren: () => import('./sale/sale.module').then(m => m.SaleModule),canActivate: [AuthGuard] },
  { path: 'companypay', loadChildren: () => import('./companypay/companypay.module').then(m => m.CompanypayModule),canActivate: [AuthGuard] },
  { path: 'barcode', loadChildren: () => import('./barcode/barcode.module').then(m => m.BarcodeModule),canActivate: [AuthGuard] },
  { path: 'po', loadChildren: () => import('./po/po.module').then(m => m.PoModule),canActivate: [AuthGuard] },
  
]
},

{path: '**', component: DashboardComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
