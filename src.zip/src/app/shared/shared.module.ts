import { NgModule } from '@angular/core';
// import { UploadFilesComponent } from './components/upload-files/upload-files.component';
@NgModule({
  declarations: [
    // UploadFilesComponent
  ],
  imports: []
})
export class SharedModule {}
