import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-barcode-setting',
  templateUrl: './barcode-setting.component.html',
  styleUrls: ['./barcode-setting.component.css']
})
export class BarcodeSettingComponent implements OnInit {

  constructor() { }
  value = 1234567890;

  ngOnInit(): void {
  }

}
