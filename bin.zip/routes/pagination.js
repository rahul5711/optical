var express = require("express");
var paginationRouter = express();
var paginationController = require("../controllers/paginationController");


paginationRouter.post("/getList", paginationController.getList);
paginationRouter.post("/getsearchList", paginationController.getsearchList);

paginationRouter.get("/preOrderStatus", paginationController.getPreOrderStatus);


module.exports = paginationRouter;