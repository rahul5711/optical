var express = require("express");
var sampleRouter = express();
var sampleController = require("../controllers/sampleController");

sampleRouter.get("/", sampleController.getAllDataByID);

sampleRouter.get("/productSupportData", sampleController.getProductSupportData);
sampleRouter.get(
  "/saveProductSupportData",
  sampleController.saveProductSupportData
);
sampleRouter.delete("/delete", sampleController.deleteData);
sampleRouter.post("/save", sampleController.saveData);

sampleRouter.get(
  "/shortListByGlobalID",
  sampleController.getShortListByGlobalID
);
sampleRouter.get(
  "/extendedListByGlobalID",
  sampleController.getShortListByGlobalID
);

sampleRouter.get("/shortDataByID", sampleController.getShortDataByID);
sampleRouter.get("/extendedDataByID", sampleController.getExtendedDataByID);

sampleRouter.get("/shortListByParem", sampleController.getShortListByParam);
sampleRouter.get(
  "/extendedListByParem",
  sampleController.getExtendedListByParem
);

module.exports = sampleRouter;
