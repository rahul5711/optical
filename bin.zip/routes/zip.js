var express = require('express');
const stat = require('fs').statSync;
const AdmZip = require('adm-zip');

var zipRouter = express();

zipRouter.get('/', function (req, res, next) { 
    const zip = new AdmZip();
    const imageList = JSON.parse(req.query.id);
    imageList.forEach(xpath => {
        const urlPath = appRoot + '/uploads/' + xpath.ImageName;
        const p = stat(urlPath);
        if (p.isFile()) {
            zip.addLocalFile(urlPath);
        } else if (p.isDirectory()) {
            // zip.addLocalFolder(path, urlPath);
        }           
    });
    const downloadName = `${Date.now()}.zip`;
    const data = zip.toBuffer();
        res.set("Content-Type","application/octet-stream");
        res.set("Content-Disposition",`attachment; filename=${downloadName}`);
        res.set("Content-Length",data.length);
        res.send(data);
});


module.exports = zipRouter;
