var express = require("express");
var uploadRouter = express();
var multer = require("multer");

const storage = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, "uploads");
  },
  filename: (req, file, callback) => {
    callback(null, Date.now() + `_${file.originalname}`);
  },
});
var upload = multer({ storage: storage });

uploadRouter.get("/", function (req, res) {
  res.end("file catcher example");
});

uploadRouter.post("/", upload.single("file"), function (req, res, next) {
  const file = req.body;
  const fileName = req.file.filename;
  if (!file) {
    const error = new Error("pls upload a file");
    err.httpStatusCode = 400;
    return next(error);
  } else {
    return res.json({ fileName: fileName });
  }
});

uploadRouter.post("/multiple", upload.array("file"), function (req, res, next) {
  const file = req.body;
  const fileName = req.file;
  if (!file) {
    const error = new Error("pls upload a file");
    err.httpStatusCode = 400;
    return next(error);
  } else {
    return res.json({ fileName: fileName });
  }
});

module.exports = uploadRouter;
