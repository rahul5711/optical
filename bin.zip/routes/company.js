var express = require("express");
var companyRouter = express();
var companyController = require("../controllers/companyController");
const { saveSmallData } = require("../services/companyService");

companyRouter.get("/", companyController.getAllDataByID);
companyRouter.get("/dataByID", companyController.getDataByID);
companyRouter.get("/fieldList", companyController.getFieldList);
companyRouter.get("/dataByName", companyController.getDataByName);
companyRouter.get("/productSupportData", companyController.getProductSupportData);
companyRouter.post("/saveProductSupportData", companyController.saveProductSupportData);
companyRouter.get("/OwnerDataByID", companyController.getOwnerDataByID);
companyRouter.delete("/deleteOtherID", companyController.deleteOtherID);
companyRouter.delete("/delete", companyController.deleteData);
companyRouter.delete("/deletePreOrder", companyController.deletePreOrder);
companyRouter.post("/save", companyController.saveData);
companyRouter.get("/permissionByRole", companyController.getpermissionByRole);
companyRouter.get("/barCodeListBySearchString", companyController.getBarCodeListBySearchString);
companyRouter.get("/barPreOrderCodeListBySearchString", companyController.getBarPreOrderCodeListBySearchString);
companyRouter.post("/transferProduct", companyController.transferProduct);
companyRouter.post("/cancelTransfer", companyController.cancelTransfer);
companyRouter.post("/acceptTransfer", companyController.acceptTransfer);
companyRouter.get("/productDataByBarCodeNo", companyController.getProductDataByBarCodeNo);
companyRouter.get("/barCodeDataByProduct", companyController.getBarCodeDataByProduct);
companyRouter.post('/printChallan', companyController.printChallan);
companyRouter.post("/savePurchase", companyController.savePurchase);
companyRouter.post("/updatePurchase", companyController.updatePurchase);
companyRouter.post("/saveBill", companyController.saveBill);
companyRouter.post("/updateBill", companyController.updateBill);
companyRouter.post("/updateCurrection", companyController.updateCurrection);
companyRouter.post("/updateProductStatus", companyController.updateProductStatus);
companyRouter.get("/getBillData", companyController.getBillData);
companyRouter.get("/getcheckInvoicNo", companyController.getcheckInvoicNo);
companyRouter.get("/getcheckInvoicNoComm", companyController.getcheckInvoicNoComm);
companyRouter.get("/getcheckInvoicNoFitter", companyController.getcheckInvoicNoFitter);
companyRouter.post("/applyPayment", companyController.applyPayment);

//  delete data

companyRouter.get("/getdeletedata", companyController.getdeletedata);
companyRouter.delete("/deletePermanent", companyController.deletePermanent);
companyRouter.delete("/Retrive", companyController.Retrive);
// purchase return
companyRouter.post("/purchaseReturn", companyController.purchaseReturn);
companyRouter.post("/saveSmallData", companyController.saveSmallData);
// get search barcode list
companyRouter.get("/getSearchBarCodeFilter", companyController.getSearchBarCodeFilter);
// filter by parameter
companyRouter.post("/filterDataByParam", companyController.filterDataByParam);
// Use below functions to get All List Data for the Company
companyRouter.get("/getShortListByCompanyOrderBy", companyController.getShortListByCompanyOrderBy);
companyRouter.get("/shortListByCompany", companyController.getShortListByCompany);
companyRouter.get("/extendedListByCompany", companyController.getExtendedListByCompany);
companyRouter.get("/extendedListByCompany1", companyController.getExtendedListByCompany1);
companyRouter.get("/extendedCustomerListBy", companyController.getExtendedCustomerListBy);

// Use below functions to get one DataObject on Tables PRIMARY KEY
companyRouter.get("/shortDataByID", companyController.getShortDataByID);
companyRouter.get("/extendedDataByID", companyController.getExtendedDataByID);

// Use below functions to get List Data on Tables PRIMARY KEY
companyRouter.get("/shortListByID", companyController.getShortListByID);
companyRouter.get("/extendedListByID", companyController.getExtendedListByID);

// Use below functions to get List Data by Providing a Parameter Object from FrontEnd
companyRouter.get("/shortListByParem", companyController.getShortListByParam);
companyRouter.get("/extendedListByParem", companyController.getExtendedListByParem);
companyRouter.get("/getPaymentListByPaymentType", companyController.getPaymentListByPaymentType);

// Use below functions to get List Data by Providing a Parameter Object from FrontEnd
companyRouter.get("/shortListByParemNew", companyController.getShortListByParamNew);
companyRouter.get("/shortListByParemNewBill", companyController.shortListByParemNewBill);
companyRouter.get("/extendedListByParemNew", companyController.getExtendedListByParemNew);
companyRouter.get("/getGenericListByParemSalePayment", companyController.getGenericListByParemSalePayment);
companyRouter.get("/genericListByParem", companyController.getGenericListByParem);
companyRouter.get("/newpurchasereports", companyController.getnewpurchasereports);
companyRouter.get("/laserReportpdf", companyController.getLaserReportpdf);
companyRouter.get("/laserReportSubpdf", companyController.getlaserReportSubpdf);
companyRouter.get("/laserReportemppdf", companyController.getlaserReportemppdf);
companyRouter.get("/PurchasePDF", companyController.PurchasePDF);

companyRouter.get("/agreegateListByParem", companyController.getAggregateListByParem);
companyRouter.get("/getGenericListByParemSaleReport", companyController.getGenericListByParemSaleReport);


companyRouter.get("/listByOtherID", companyController.getListByOtherID);
companyRouter.get("/listByOtherID1", companyController.getListByOtherID1);
companyRouter.get("/searchDataByFilter", companyController.getSearchDataByFilter);
companyRouter.get("/getSearchDataByFilterForCashRegister", companyController.getSearchDataByFilterForCashRegister);
companyRouter.get(
    "/purchaseFullDataByID",
    companyController.getPurchaseFullDataByID
);
companyRouter.get("/fitterInvoiceFullDataByID", companyController.getFitterInvoiceFullDataByID);

companyRouter.get("/commissionInvoiceFullDataByID", companyController.getCommissionInvoiceFullDataByID);

companyRouter.get("/preOrderStatus", companyController.getPreOrderStatus);
companyRouter.post("/setPreOrderStatus", companyController.setPreOrderStatus);
companyRouter.post("/setPreOrderStatusPo", companyController.setPreOrderStatusPo);


companyRouter.get("/checkforDuplicate", companyController.checkforDuplicate);
companyRouter.post("/generateBill", companyController.getnerateBill);

companyRouter.post("/generateOrderForm", companyController.generateOrderForm);

companyRouter.post("/customerNote", companyController.customerNote);
companyRouter.post("/billPayment", companyController.billPayment);
companyRouter.post("/billSubPayment", companyController.billSubPayment);

companyRouter.post("/BarcodePrint", companyController.BarcodePrint);
companyRouter.post("/BarcodePrintAll", companyController.BarcodePrintAll);
companyRouter.post("/BarcodePrintAlls", companyController.BarcodePrintAlls);






companyRouter.get("/getCredit", companyController.getCredit);


companyRouter.get("/getPreorderPurchaseList",companyController.getPreorderPurchaseList);
companyRouter.get("/getListByPage",companyController.getListByPage);




companyRouter.post("/printLens", companyController.printLens);
companyRouter.post("/AssignFitterPDF", companyController.AssignFitterPDF);
companyRouter.post("/AssignSupplierPDF", companyController.AssignSupplierPDF);


companyRouter.post("/getExistingProduct", companyController.getExistingProduct);

companyRouter.get("/supportMasterList", companyController.getSupportMasterList);

companyRouter.get("/cashRegisterData", companyController.getCashRegisterData);
companyRouter.get("/getCommissionList", companyController.getCommissionList);
companyRouter.get("/getDashboardData", companyController.getDashboardData);

companyRouter.get(
    "/getSmsReport",
    companyController.getSmsReport
);


companyRouter.get("/sendsms", companyController.sendsms);
companyRouter.get("/getchack", companyController.getchack);
companyRouter.get("/customeridd", companyController.customeridd);


module.exports = companyRouter;