var express = require("express");
var loginRouter = express();
var loginController = require("../controllers/loginController");

loginRouter.post("/", loginController.login);
loginRouter.post("/doctor", loginController.doctorLogin);

module.exports = loginRouter;
