var express = require("express");
var poRouter = express();
var poController = require("../controllers/poController");

poRouter.post("/savePurchase", poController.savePurchase);
poRouter.post("/updatePurchase", poController.updatePurchase);

poRouter.get(
    "/purchaseFullDataByID",
    poController.getPurchaseFullDataByID
);

module.exports = poRouter;