var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');



router.post('/', (req, res) => {
    let user = req.body;
    if (req.query.Mode === 'registermail') {
        user.MailContent = `<h4>Dear ${user.Name}</h4>
    <h4> <span style="color:rgb(243, 113, 53); font-size:15px;"> Congratulation </span> Thanks for being our valued customer. We are so gratefull for the pleasure of serving you and hope we met your expectations.</h4>
    <p>
    Your login credential is <br>
    URL: navient.in/dev/OTPG/web <br>
    ID: ${user.LoginName}<br>
    PASSWORD: ${user.Password}
    </p>
    <h5>Thanks for your Business</h5> 
     <div style="position: relative;width:100%;">
     <p style="border-right: 2px solid #000; position: absolute;  width:40%; height:80px; float: left; padding-right:2%;">
     <img src="http://navient.in:50080/relinksyslogo.png" alt="LOGO" width:100%; style=" padding-top:4%;" ></img> 
     </p>
     <h6 style="width:85%; position: absolute; padding-left:2%; padding-top:4%;">
     <span style="padding-left:2%; color:rgb(243, 113, 53);"> Relinksys Software Pvt. Ltd. </span><br>
     <span style="padding-left:2%;">  Branch : Pune </span><br>
     <span style="padding-left:2%;">  Mob : 9766666248/9130366248 </span><br>
     <span style="padding-left:2%;">  Web : www.relinksys.com </span><br>
<hr style="padding-left:2%;">
<span style="color:rgb(243, 113, 53); padding-left:2%; width:50%; "> Follow
<span style="width:5%; margin-left:4%;" >
 <a href="https://www.facebook.com/relinksys" style="width:5%;">
<img src="http://navient.in:50080/facebook.png" alt="LOGO" width="10px"  style=" style="width:5%; position: absolute;" ></img> </a>
</span>
<span style="width:5% margin-left:2%; text-align: center;" >
 <a href="https://www.instagram.com/relinksys/" style="width:5%;">
<img src="http://navient.in:50080/instagram.png" alt="LOGO" width="10px"  style=" style="width:5%;  position: absolute;" ></img> </a>
</span>
<span style="width:5%; " >
 <a href="https://www.facebook.com/Bestopticalsoftware" style="width:5%;">
<img src="http://navient.in:50080/facebook.png" alt="LOGO" width="10px"  style=" style="width:5%; position: absolute;" ></img> </a>
</span>
 </span>
     </h6>
     </div>`
    }
    if (req.query.Mode === 'customerbill') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
      <h4>Thanks  you for being our valued customer. We are so gratefull for the pleasure of serving you and hope we met your expectations. Please Visit Again</h4>
      <p>
      ${user.ShopName} <br>
      ${user.ShopMoblie} <br>
     Visit : ${user.ShopWebsite} <br>
     Please give your valuable Review for us.
      </p>
      <h5>Open Bill : ${user.Billlink}</h5>`
    }
    if (req.query.Mode === 'customerCreditnote') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
      <h4>Save your credit note copy.</h4>
      <h5>Save your Credit Note : ${user.Pdflink}</h5>
      <p>
      ${user.ShopName} <br>
      ${user.ShopMoblie} <br>
      </p>`
    }
    if (req.query.Mode === 'spectacleLens') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
      <h4>We know the world is full of choices. Thank you for choosing us! For your Eye Testing. We hope you like our services </h4>
      <h5>Open Prescription : ${user.spectaclelist}</h5>
      <p>
      ${user.ShopName} <br>
      ${user.ShopMoblie} <br>
      Visit : ${user.ShopWebsite} <br>
      Please give your valuable Review for us.

      </p>`
    }
    if (req.query.Mode === 'contactLens') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
      <h4>We know the world is full of choices. Thank you for choosing us! For your Eye Testing. We hope you like our services </h4>
      <h5>Open Prescription : ${user.contactlens}</h5>
      <p>
      ${user.ShopName} <br>
      ${user.ShopMoblie} <br>
      Visit : ${user.ShopWebsite} <br>
      Please give your valuable Review for us.

      </p>`
    }
    if (req.query.Mode === 'OtherRxLens') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
      <h4>We know the world is full of choices. Thank you for choosing us! For your Eye Testing. We hope you like our services </h4>
      <h5>Open Prescription : ${user.OtherRx}</h5>
      <p>
      ${user.ShopName} <br>
      ${user.ShopMoblie} <br>
      Visit : ${user.ShopWebsite} <br>
      Please give your valuable Review for us.

      </p>`
    }
    if (req.query.Mode === 'custom_Bday') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Wish You Happy Birthday Get Special Discount Today </h4>
<p>
Relinksys Software Pvt Ltd <br>
9766666284 <br>
Visit : www.relinksys.com
</p>`
    }
    if (req.query.Mode === 'Anniversary_Bday') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Happy Anniversary. May you yo love bird stay happy and blessed always </h4>
<p>
Relinksys Software Pvt Ltd <br>
9766666284 <br>
Visit : www.relinksys.com
</p>`
    }
    if (req.query.Mode === 'Plan_Ex') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> You are Plan Expiry </h4>
<p>
Relinksys Software Pvt Ltd <br>
9766666284 <br>
Visit : www.relinksys.com <br>
Please give your valuable Review for us.
</p>`
    }
    if (req.query.Mode === 'CustomerBday') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
    <h4> Wish You Happy Birthday Get Special Discount Today </h4>
    <p>
    ${user.ShopName} <br>
    ${user.ShopMoblie} <br>
    Visit : ${user.ShopWebsite} <br>
    </p>`
    }
    if (req.query.Mode === 'SupplierBday') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
  <h4> Wish You Happy Birthday Get Special Discount Today </h4>
  <p>
  ${user.ShopName} <br>
  ${user.ShopMoblie} <br>
  Visit : ${user.ShopWebsite} <br>
  </p>`
    }
    if (req.query.Mode === 'EmployeeBday') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Wish You Happy Birthday Get Special Discount Today </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'FitterBday') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Wish You Happy Birthday Get Special Discount Today </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'DoctorBday') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Wish You Happy Birthday Get Special Discount Today </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'Customer_Anni') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Happy Anniversary. May you yo love bird stay happy and blessed always </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'Supplier_Anni') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Happy Anniversary. May you yo love bird stay happy and blessed always </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'employee_Anni') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Happy Anniversary. May you yo love bird stay happy and blessed always </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'fitter_Anni') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Happy Anniversary. May you yo love bird stay happy and blessed always </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'doctor_Anni') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Happy Anniversary. May you yo love bird stay happy and blessed always </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'order_Pending') {
        user.MailContent = `<h4>Hi ${user.CustomerName}</h4>
<h4> Your order is ready for delivery Please collect it soon </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
</p>`
    }
    if (req.query.Mode === 'EyeTests') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4> Your Eye checkup is due Please call us to book your appointment </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
Please give your valuable Review for us.
</p>`
    }
    if (req.query.Mode === 'Contact_lens') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4>Today Your Contact lens will be expire. Please Contact soon </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
Please give your valuable Review for us.
</p>`
    }
    if (req.query.Mode === 'CustomerSolution') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4>Today Your Solution will be expire. Please Contact soon </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
Please give your valuable Review for us.
</p>`
    }
    if (req.query.Mode === 'ServicenewMsg') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4>Just a Gental reminder about your FREE service is coming up. Please contac </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
Please give your valuable Review for us.
</p>`
    }

    if (req.query.Mode === 'ComfortFeedback') {
        user.MailContent = `<h4>Hi ${user.Name}</h4>
<h4>We are curious to know about the comfort and quality of Spectacles that u bought from our store. </h4>
<p>
${user.ShopName} <br>
${user.ShopMoblie} <br>
Visit : ${user.ShopWebsite} <br>
Please give your valuable Review for us.
</p>`
    }

    if (req.query.Mode === 'forgetPassword') {
        user.MailContent = `<h4>Dear ${user.Name},</h4>

        <h4>Your Login Credential is <br>  
        Username : <span style="color:green;"> ${user.LoginName} </span> <br> 
        Password : <span style="color:green;"> ${user.Password} </span></h4>
         <h3>  
         Thanks Regards 
         <p style="color:#000;">
         Relinksys Software Pvt Ltd <br>
         9766666248/9130366248 <br>
         E-Mail : relinksys@gmail.com <br>
         Visit : www.relinksys.com
         </p>
         </h3> 
`
    }
    sendMail(user, info => {

        res.send(info);
    });
});

async function sendMail(user, callback) {

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        service: 'Gmail',
        //  host: "smtp.gmail.com",
        //  port: 587,
        //  secure: false, // true for 465, false for other ports

        auth: {
            // user: 'otpgnavient@gmail.com',
            // pass: 'lifeislikeaboxofchocolate'
            // user: 'leads.risksure@gmail.com',
            // pass: 'sabir@1152'
            user: 'relinksyspvtltd@gmail.com',
            pass: 'Mehulpatil@123'
        }
    });


    let mailOptions = {
        from: '"Relinksys Software PVT LTD"<santoshoptical@gmail.com>', // sender address
        to: user.Email, // list of receivers
        subject: "Message from OpticalGuru", // Subject line
        html: `${user.MailContent}<br>
      `
    };

    // send mail with defined transport object
    let info

    try {
        // assign a value here
        info = await transporter.sendMail(mailOptions);
    } catch (err1) {
        console.log(err1);
    }


    callback(info);
}



module.exports = router;