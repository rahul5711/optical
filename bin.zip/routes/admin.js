var express = require("express");
var adminRouter = express();
var adminController = require("../controllers/adminController");

adminRouter.get("/", adminController.getAllData);

adminRouter.get("/supportMasterList", adminController.getsupportMasterList);

adminRouter.get("/getProductAssignList", adminController.getProductAssignList);

adminRouter.get("/companylist", adminController.getCompanyList);

adminRouter.get("/dataByID", adminController.getDataByID);
// adminRouter.get('/OwnerDataByID' , adminController.getOwnerDataByID);
adminRouter.delete("/delete", adminController.deleteData);
adminRouter.post("/save", adminController.saveData);
adminRouter.get("/sendsms", adminController.sendsms);
adminRouter.get("/dataByName", adminController.getDataByName);
adminRouter.get("/shortListByCompany", adminController.getShortListByCompany);
adminRouter.delete("/delete1", adminController.deleteData1);

adminRouter.post("/assignProduct", adminController.assignProduct);



module.exports = adminRouter;