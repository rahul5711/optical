module.exports = {
    db: {
      uri: 'mysql://navientdb:8837aur9B@194.163.162.248/OTPGPRODDEMO', 
       // uri: 'mysql://root:@localhost/OTPGPRODDEMO',
        // uri: 'mysql://relinksys_optica:RELinksys@_$123@198.38.93.60/relinksys_optical',
        connectionLimit: 100,
        acquireTimeout: 100000,
        connectTimeout: 100000
        
    },
    secret: 'asc-256-OTPG', 
    algorithm: "HS512"
} 