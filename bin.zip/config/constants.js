module.exports = {
    appURL: "http://localhost:50080/",
}