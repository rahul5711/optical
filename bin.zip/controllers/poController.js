var config = require("../config/index");
var constents = require("../config/constants");
var poService = require("../services/poService");
let ejs = require("ejs");
let pdf = require("html-pdf");
let path = require("path");
var moment = require("moment");
const clientConfig = require("../config/constants");
var TinyURL = require('tinyurl');

class poController {


static savePurchase(req, res) {
    poService
        .savePurchase(
            req.body,
            JSON.parse(req.query.LoggedOnUser),
            req.query.CompanyID,
            req.query.Mode

        )
        .then((response) => {
            res.json(response);
        })
        .catch((error) => {
            res.json(error);
        });
}

static updatePurchase(req, res) {
    poService
        .updatePurchase(
            req.body,
            JSON.parse(req.query.LoggedOnUser),
            req.query.CompanyID,
            req.query.Mode
        )
        .then((response) => {
            res.json(response);
        })
        .catch((error) => {
            res.json(error);
        });
}

static getPurchaseFullDataByID(req, res) {
    poService
        .getPurchaseFullDataByID(
            req.query.ID,
            JSON.parse(req.query.LoggedOnUser),
            req.query.CompanyID
        )
        .then((response) => {
            res.json(response);
        })
        .catch((error) => {
            res.json(error);
        });
}

}

module.exports = poController;