var config = require("../config/index");
var sampleService = require("../services/sampleService");

class companyController {
  static getAllDataByID(req, res) {
    sampleService
      .getAllDataByID(
        req.query.TableName,
        JSON.parse(req.query.LoggedOnUser).GlobalID
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static getShortListByGlobalID(req, res) {
    sampleService
      .getShortListByGlobalID(
        req.query.TableName,
        JSON.parse(req.query.LoggedOnUser),
        GlobalID
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static getExtendedListByGlobalID(req, res) {
    sampleService
      .getExtendedListByGlobalID(
        req.query.TableName,
        JSON.parse(req.query.LoggedOnUser),
        req.query.GlobalID
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static getShortDataByID(req, res) {
    sampleService
      .getShortDataByID(req.query.TableName, req.query.ID, GlobalID)
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static getExtendedDataByID(req, res) {
    sampleService
      .getExtendedDataByID(
        req.query.TableName,
        req.query.ID,
        req.query.GlobalID
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static getExtendedListByParem(req, res) {
    sampleService
      .getExtendedListByParem(
        req.query.TableName,
        req.query.Parem,
        req.query.GlobalID
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static getShortListByParam(req, res) {
    sampleService
      .getShortListByParem(
        req.query.TableName,
        req.query.Parem,
        req.query.GlobalID
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static getProductSupportData(req, res) {
    sampleService
      .getProductSupportData(
        req.query.TableName,
        req.query.Ref,
        JSON.parse(req.query.LoggedOnUser)
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static saveProductSupportData(req, res) {
    sampleService
      .saveProductSupportData(
        req.query.TableName,
        req.query.Ref,
        req.query.SelectedValue,
        JSON.parse(req.query.LoggedOnUser)
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static deleteData(req, res) {
    sampleService
      .del(
        JSON.parse(req.query.LoggedOnUser),
        req.query.TableName,
        req.query.ID
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static saveData(req, res) {
    sampleService
      .saveData(
        req.body,
        JSON.parse(req.query.LoggedOnUser),
        req.query.TableName
      )
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }
}
module.exports = sampleController;
