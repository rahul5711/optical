var config = require("../config/index");
var adminService = require("../services/adminService");
let ejs = require("ejs");
let pdf = require("html-pdf");
let path = require("path");
var moment = require("moment");
var mailService = require("../services/mailService");
var smsService = require("../services/smsService");
var constents = require("../config/constants");

class adminController {
    static getAllData(req, res) {
        switch (req.query.Mode) {
            case "getAllData":
                adminService
                    .getAllData(req.query.TableName)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;
            case "getAllDataByID":
                adminService
                    .getAllDataByID(req.query.TableName, req.query.ID)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;
            case "getAllDataByParem":
                adminService
                    .getAllDataByParem(req.query.TableName, req.query.parem)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;

            case "getSupportData":
                adminService
                    .getSupportData(req.query.TableName, req.query.parem)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;

            case "getfilterList":
            case "CompanyFilter":

                adminService
                    .getfilterList(req.query.TableName, req.query.parem)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;

            case "getLoginHistory":
                adminService
                    .getLoginHistory(req.query.TableName, req.query.parem)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;
        }
    }

    static getDataByID(req, res) {
        switch (req.query.Mode) {
            case "getEmployeeByID":
            case "getCompanyByID":
            case "getEmployeeByID":
            case "getDoctorByID":
            case "getPayrollByID":
            case "getExpenseByID":
                adminService
                    .getDataByID(req.query.TableName, req.query.ID)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;

            case "getOwnerDataByID":
                adminService
                    .getOwnerDataByID(req.query.TableName, req.query.ID)
                    .then((response) => {
                        res.json(response);
                    })
                    .catch((error) => {
                        res.json(error);
                    });
                break;
        }
    }

    static deleteData(req, res) {
        adminService
            .del(req.query.loggedOnUser, req.query.TableName, req.query.id)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static deleteData1(req, res) {
        adminService
            .deleteData1(
                JSON.parse(req.query.LoggedOnUser),
                req.query.TableName,
                req.query.ID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static saveData(req, res) {
        adminService
            .saveData(
                req.body,
                JSON.parse(req.query.loggedOnUser),
                req.query.TableName
            )
            .then((response) => {
                res.json(response);
                // if (req.query.TableName === 'Company') {
                //     adminService
                //         .getDataByID('Company', response.result.insertId)
                //         .then((response) => {
                //             console.log(response, 'company details');
                //             //  mail 

                //             var printdata = response.result;
                //             let email = "";

                //             email = printdata.Email;



                //             ejs.renderFile(
                //                 path.join(appRoot, "./views/", "company.ejs"), { data: printdata },
                //                 (err, data) => {
                //                     if (err) {
                //                         res.send(err);
                //                     } else {

                //                         mailService
                //                             .sendMail(
                //                                 data,
                //                                 email,
                //                                 printdata,
                //                                 printdata
                //                             )
                //                             .then((res) => {
                //                                 // res.json(res);
                //                             })
                //                             .catch((error) => {
                //                                 res.json(error);
                //                             });
                //                     }
                //                 }
                //             );


                //             // end mail
                //         })
                //         .catch((error) => {
                //             res.json(error);
                //         });
                // }
            })
            .catch((error) => {
                res.json(error);
            });
    }
    static assignProduct(req, res) {
        adminService
            .assignProduct(
                req.body,
                JSON.parse(req.query.loggedOnUser),
                req.query.TableName
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }


    static getDataByName(req, res) {
        adminService
            .getDataByName(
                req.query.TableName,
                req.query.Name,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
               
            ) 
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
            console.log(req.query.Name,"req.query.Name,")
    }

    static getsupportMasterList(req, res) {
        adminService
            .getsupportMasterList(req.query.TableName, JSON.parse(req.query.loggedOnUser).CompanyID)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }
    static getProductAssignList(req, res) {
        adminService
            .getProductAssignList(req.query.TableName, JSON.parse(req.query.loggedOnUser).CompanyID)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getCompanyList(req, res) {
        adminService
            .getCompanyList(req.query.TableName)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    
    static getShortListByCompany(req, res) {
        companyService
            .getShortListByCompany(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.DelMode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static sendsms(req, res) {
        smsService
            .sendSMS(
                req.query.MobileNo,
                req.query.MsgText,
                req.query.TemplateID,
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }
}

module.exports = adminController;