var config = require("../config/index");
const jwt = require("jsonwebtoken");
var MyService = require("../services/myServices");
class MyController {
  static getUsers(req, res) {
    MyService.getdata()
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        console.log(error);
        res.json(error);
      });
  }

  static getUsersByid(req, res) {
    console.log(req.params);
    MyService.getUsersByid(req.params.id)
      .then((response) => {
        console.log(response);
        res.json(response);
      })
      .catch((error) => {
        console.log(error);
        res.json(error);
      });
  }

  static deleteUserByid(req, res) {
    console.log(req.params);
    MyService.deleteUserByid(req.params.id)
      .then((response) => {
        console.log(response);
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static usersave(req, res) {
    MyService.usersave(req.body)
      .then((response) => {
        MyService.getUsersByid(response.insertId)
          .then((response) => {
            res.json(response);
          })
          .catch((error) => {
            res.json(error);
          });
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static login(req, res) {
    MyService.login(req.body)
      .then((response) => {
        const user = {
          id: response[0].id,
          Name: response[0].Name,
          Password: response[0].Password,
        };
        jwt.sign({ user }, "secretkey", { expiresIn: "30" }, (err, token) => {
          res.json({
            token,
            response,
          });
        });
      })
      .catch((error) => {
        console.log(error);
        res.json(error);
      });
  }
}
module.exports = MyController;
