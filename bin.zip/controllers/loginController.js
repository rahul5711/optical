var config = require("../config/index");
var loginService = require("../services/loginService");
class loginController {
  static login(req, res) {
    loginService
      .getLoginData(req.body)
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }

  static doctorLogin(req, res) {
    console.log("doctor");
    loginService
      .getDoctorLoginData(req.body)
      .then((response) => {
        res.json(response);
      })
      .catch((error) => {
        res.json(error);
      });
  }
}
module.exports = loginController;
