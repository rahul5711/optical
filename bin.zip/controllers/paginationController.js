var paginationService = require("../services/paginationService");



class paginationController { 
    static getList(req, res) {
        paginationService
        .getListData(
            req.query.TableName,
            req.query.CompanyID,
            JSON.parse(req.query.LoggedOnUser),

            req.query.ShopID,

            req.body
        )
        .then((response) => {
            res.json(response);
        })
        .catch((error) => {
            res.json(error);
        });
    }
    static getsearchList(req, res) {
        paginationService
        .getsearchListData(
            req.query.TableName,
            req.query.CompanyID,
            JSON.parse(req.query.LoggedOnUser),

            req.query.ShopID,

            req.body
        )
        .then((response) => {
            res.json(response);
        })
        .catch((error) => {
            res.json(error);
        });
    }

    static getPreOrderStatus(req, res) {
        paginationService
            .getPreOrderStatus(
                req.query.Mode,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID,
                req.query.dtm,

            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

}


module.exports = paginationController;