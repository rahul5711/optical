var config = require("../config/index");
var constents = require("../config/constants");
var companyService = require("../services/companyService");
var mailService = require("../services/mailService");
var smsService = require("../services/smsService");
let ejs = require("ejs");
let pdf = require("html-pdf");
let path = require("path");
var moment = require("moment");
const clientConfig = require("../config/constants");
const { Console } = require("console");
var TinyURL = require('tinyurl');

class companyController {
    static getBillData(req, res) {
        companyService
            .getBillData(
                req.query.ID,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getcheckInvoicNo(req, res) {
        companyService
            .getcheckInvoicNo(
                req.query.Param,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getcheckInvoicNoComm(req, res) {
        companyService
            .getcheckInvoicNoComm(
                req.query.Param,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getcheckInvoicNoFitter(req, res) {
        companyService
            .getcheckInvoicNoFitter(
                req.query.Param,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getdeletedata(req, res) {
        companyService
            .getdeletedata(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                JSON.parse(req.query.loggedInShop)
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getSearchBarCodeFilter(req, res) {
        companyService
            .getSearchBarCodeFilter(
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID,
                req.query.PurchaseDetailID,
                req.query.ShopMode,
                req.query.mode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static filterDataByParam(req, res) {
        companyService
            .filterDataByParam(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.TableName
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static checkforDuplicate(req, res) {
        companyService
            .checkforDuplicate(req.query.TableName, req.query.LoginName)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getCredit(req, res) {
        companyService
            .getCredit(
                req.query.ID,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.CreditEntity
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getPreOrderStatus(req, res) {
        companyService
            .getPreOrderStatus(
                req.query.Mode,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID,
                req.query.TableName

            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static setPreOrderStatus(req, res) {
        companyService
            .setPreOrderStatus(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.Mode,
                req.query.CompanyID,
                req.query.TableName

            )
            .then((response) => {
                var printdata = req.body;
                if (req.query.Mode === "Assign" || req.query.Mode === "AssignFitter") {
                    let email = "";
                    if (req.query.Mode === "Assign") {
                        email = printdata.supplier.Email;
                    } else {
                        email = printdata.fitter.Email;
                    }
                    // if (printdata.EyeMeasurement) {
                    printdata.filterList.forEach((element) => {
                        element.Measurement = JSON.parse(element.MeasurementID);
                    });
                    // }
                    var file = "PREODER-" + moment().format() + ".pdf";
                    var appURL = clientConfig.appURL;
                    var fileName = "uploads/" + file;
                    printdata.LogoURL = appURL + printdata.loggedInCompany.LogoURL;
                    printdata.todaydate = moment().format(
                        printdata.loggedInCompanySetting.DateFormat
                    );
                    ejs.renderFile(
                        path.join(appRoot, "./views/", "PreOrderEmail.ejs"), { data: printdata },
                        (err, data) => {
                            if (err) {
                                res.send(err);
                            } else {
                                mailService
                                    .sendMail(
                                        data,
                                        email,
                                        printdata.loggedInCompany,
                                        printdata.loggedInShop
                                    )
                                    .then((res) => {
                                        res.json(res);
                                    })
                                    .catch((error) => {
                                        res.json(error);
                                    });
                            }
                        }
                    );
                } else {
                    res.json("Success");
                }
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static setPreOrderStatusPo(req, res) {
        companyService
            .setPreOrderStatusPo(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.Mode,
                req.query.CompanyID,
                req.query.TableName

            )
            .then((response) => {
                var printdata = req.body;
                if (req.query.Mode === "Assign" || req.query.Mode === "AssignFitter") {
                    let email = "";
                    if (req.query.Mode === "Assign") {
                        email = printdata.supplier.Email;
                    } else {
                        email = printdata.fitter.Email;
                    }
                    // if (printdata.EyeMeasurement) {
                    printdata.filterList.forEach((element) => {
                        element.Measurement = JSON.parse(element.MeasurementID);
                    });
                    // }
                    var file = "PREODER-" + moment().format() + ".pdf";
                    var appURL = clientConfig.appURL;
                    var fileName = "uploads/" + file;
                    printdata.LogoURL = appURL + printdata.loggedInCompany.LogoURL;
                    printdata.todaydate = moment().format(
                        printdata.loggedInCompanySetting.DateFormat
                    );
                    ejs.renderFile(
                        path.join(appRoot, "./views/", "PreOrderEmail.ejs"), { data: printdata },
                        (err, data) => {
                            if (err) {
                                res.send(err);
                            } else {
                                mailService
                                    .sendMail(
                                        data,
                                        email,
                                        printdata.loggedInCompany,
                                        printdata.loggedInShop
                                    )
                                    .then((res) => {
                                        res.json(res);
                                    })
                                    .catch((error) => {
                                        res.json(error);
                                    });
                            }
                        }
                    );
                } else {
                    res.json("Success");
                }
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getnerateBill(req, res) {
        var printdata = req.body;
        var paidlist = req.body.paidList;
        var unpaidlist = req.body.unpaidList;
        var servicelists = req.body.serviceList;
        var billItemlists = req.body.billItemList;
        var shop = req.body.loggedInShop;

        if(shop.WelcomeNote !== ''  || shop.WelcomeNote !== undefined && shop.WelcomeNote !== 'No Terms and Conditions' ){
            var welcomenotes = JSON.parse(shop.WelcomeNote);
        }else{
            var welcomenotes = [ { NoteType: '', Content: '' } ]
            JSON.parse(welcomenotes)
        }

        var welNotes = [];

        welcomenotes.forEach((ele) => {
            if (ele.NoteType === "Note") {
                welNotes.push(ele);
            }else{
                welNotes = { NoteType: '', Content: '' }
            }
        });



        var welcomenote = JSON.parse(req.body.loggedInCompanySetting.WelComeNote);
        var recivePayment = 0;
        var welNote = [];

        var tempBillItem = [];
        var tempBillItems = [];
        var customerReward = 0;
        var customerReturn = 0;
        paidlist.forEach(ele => {
            if (ele.PaymentMode === 'Customer Reward') {
                customerReward = customerReward + Number(ele.Amount);
            }
            if (ele.PaymentMode === 'Customer Return') {
                if (ele.DueAmount !== 0) {
                    customerReturn = customerReturn + Number(ele.Amount);
                }
            }
        })
        printdata.customerReward = customerReward;
        printdata.customerReturn = customerReturn;

        var printFormat = "";
        var orientation = "";
        billItemlists.forEach((element) => {
            if (element.GSTType.toUpperCase() === "CGST-SGST" && element.Status === 1) {
                let item = {
                    ProductName: "",
                    HSNCode: "",
                    UnitPrice: null,
                    Quantity: null,
                    SubTotal: null,
                    DiscountAmount: null,
                    GSTPercentage: null,
                    GSTAmount: null,
                    GSTType: "",
                    TotalAmount: null,
                    Remark: null,
                    Warranty: null,
                };
                item.ProductName = element.ProductName;
                item.HSNCode = element.HSNCode;
                item.UnitPrice = element.UnitPrice;
                item.Quantity = element.Quantity;
                item.SubTotal = element.SubTotal;
                item.DiscountAmount = element.DiscountAmount;
                item.GSTPercentage = element.GSTPercentage / 2;
                item.GSTAmount = element.GSTAmount / 2;
                item.GSTType = element.GSTType;
                item.TotalAmount = element.TotalAmount;
                item.Remark = element.Remark;
                item.Warranty = element.Warranty;
                tempBillItem.push(item);
            } else if (element.Status === 1) {
                tempBillItem.push(element);
            }
        });

        printdata.billItemList = tempBillItem;
        // console.log(printdata.billItemList);

        servicelists.forEach((element) => {
            if (element.GSTType.toUpperCase() === "CGST-SGST" && element.Status === 1) {
                let items = {
                    ServiceType: "",
                    Description: "",
                    Price: null,
                    GSTPercentage: null,
                    GSTAmount: null,
                    GSTType: "",
                    TotalAmount: null,
                };
                items.ServiceType = element.ServiceType;
                items.Description = element.Description;
                items.Price = element.Price;
                items.GSTPercentage = element.GSTPercentage / 2;
                items.GSTAmount = element.GSTAmount / 2;
                items.GSTType = element.GSTType;
                items.TotalAmount = element.TotalAmount;

                tempBillItems.push(items);
            } else if (element.Status === 1) {
                tempBillItems.push(element);
            }
        });

        printdata.service = tempBillItems;
        console.log( printdata.service);
        // printdata = servicelists[0].GSTType;
        // if (printdata.GSTTypes === "CGST/SGST") {
        //     printdata.GSTAmts = printdata.serviceList.GSTAmount / 2;
        // } else {
        //     printdata.GSTAmts = printdata.serviceList.GSTAmount;
        // }

        if (req.body.loggedInCompanySetting.WholeSalePrice === "true") {
            welcomenote.forEach((ele) => {
                if (ele.NoteType === "wholesale") {
                    welNote.push(ele);
                }
            });
        } else if (req.body.loggedInCompanySetting.RetailRate === "true") {
            welcomenote.forEach((ele) => {
                if (ele.NoteType === "retail") {
                    welNote.push(ele);
                }
            });
        }
        var x = [];
        billItemlists.forEach((element) => {
            if (element.MeasurementID !== "null" && element.MeasurementID !== "undefined" && element.MeasurementID !== undefined && element.MeasurementID !== ''  && x.length === 0 ) {
                x.push(JSON.parse(element.MeasurementID));
            }
        });
        // x.push(JSON.parse(billItemlists[0].MeasurementID));
        printdata.EyeMeasurement = x;

        console.log(printdata.EyeMeasurement.MeasurementID,'printdata.EyeMeasurementprintdata.EyeMeasurement');
        if (req.body.loggedInCompanySetting.WholeSalePrice === "true") {
            printFormat = "A4";
            orientation = "portrait";
            var lasts = `<div style="width:100%;display:inline-block;padding-left:25px; padding-right:25px;">
 <div style="width:40%;float:left;">
     <span style = "font-size:10px;font-weight:bold; text-align: left;"> Shop Timing: </span>
     <p style = "font-size:7px; margin:0; padding:0;">${printdata.loggedInShop.ShopTiming} </p>
      </div>
      <div style="width:40%;float:left;">
     <span style = "font-size:10px;font-weight:bold; text-align: left;">  </span>
     <p style = "font-size:10px; margin:0; padding:0; color:${printdata.loggedInCompanySetting.Color1};">${printdata.loggedInCompanySetting.CompanyTagline} </p>
      </div>
         <div style="width:20%;float:left;padding-top: 7px;text-align: center;">
          <hr style = "width:100%;border: 1px dotted ;margin: 0;padding: 0;">
              <h3 style = "font-size:10px;" > Signature </h3>
               </div>
               </div>`

        } else {
            printFormat = "A5";
            orientation = "portrait";
        }
        printdata.billItemList = printdata.billItemList.filter((element) => {
            return element.Status !== 0;
        });
        paidlist.forEach((element) => {
            element.PaymentDate = moment(element.PaymentDate).format("LL");
            recivePayment = recivePayment + element.Amount;

        });
        printdata.recivePayment = recivePayment;
        var fileName = "";
        var file = "";

        // var appURL = "http://localhost:50080/";

        if (req.query.Mode === "Invoice") {
            file =
                printdata.billMaster.InvoiceNo +
                "CM-" +
                Math.trunc(Math.random() * 10000).toString() +
                ".pdf";
            printdata.paidStatus = "Unpaid";
            printdata.bill = "Cash Memo";
        } else {
            file =
                printdata.billMaster.InvoiceNo +
                "INV-" +
                Math.trunc(Math.random() * 10000).toString() +
                ".pdf";
            printdata.paidStatus = "Paid";
            printdata.bill = "Tax Invoice";
        }
        fileName = "uploads/" + "customerInvoice/" + file;

        var parem = req.query.Mode + " = 'customerInvoice/" + file + "'";
        printdata.quantity = unpaidlist[0].Quantity;

        printdata.DiscountAmt = unpaidlist[0].DiscountAmount;
        printdata.DueAmounts = unpaidlist[0].DueAmount;

        let DueAmounta = 0
        for (var i = 0; i < unpaidlist.length; i++) {
            DueAmounta = DueAmounta + unpaidlist[i].DueAmount;

        }
        printdata.DueAmounta = DueAmounta


           if(billItemlists.length !== 0){
               printdata.GSTTypes = billItemlists[0].GSTType;


        if (printdata.GSTTypes.toUpperCase() === "CGST-SGST") {
            printdata.GSTAmt = printdata.billMaster.GSTAmount / 2;
        } else {
            printdata.GSTAmt = printdata.billMaster.GSTAmount;
        }
    }
        printdata.wlcm = welNote;
        var appURL = clientConfig.appURL;

        if(shop.LogoURL === 'null' || shop.LogoURL === 'NULL'  && shop.LogoURL === undefined){
            printdata.LogoURL = appURL + printdata.loggedInCompanySetting.LogoURL;
            console.log(printdata.LogoURL ,'loggedInCompanySetting');
        }else{
            printdata.LogoURL = appURL + shop.LogoURL;
            console.log(printdata.LogoURL ,'shop');

        }


        printdata.Address = appURL + "companyAssets/" + "Location.png";
        printdata.mix = appURL  + "qr.jpeg";
        printdata.MobileNo1 = appURL + "companyAssets/" + "mob1.png";
        printdata.PhoneNo = appURL + "companyAssets/" + "phone.png";
        printdata.Email = appURL + "companyAssets/" + "email3.png";
        printdata.Watermark = appURL + printdata.loggedInCompanySetting.WatermarkLogoURL;
        printdata.Composite = printdata.loggedInCompanySetting.Composite;
        if (req.query.Mode !== "Invoice") {
            if (printdata.Composite === "true") {
                printdata.InvoiceName = "Bill of Supply";
                printdata.TotalValue = "Value of Supply";
                printdata.Note = "Composition Taxable person, Not eligible to collect tax on supplies.";
                printdata.Notes = "Note:";

            } else {
                printdata.InvoiceName = "Invoice No.";
                printdata.InvoiceDetails = "INVOIVE DETAILS";

                printdata.TotalValue = "Total";
                printdata.Note = "Composition Taxable person, Not eligible to collect tax on supplies.";
                printdata.Notes = "Note:";

            }
        } else {
            printdata.InvoiceName = "Memo No.";
            printdata.InvoiceDetails = "MEMO DETAILS";

            printdata.TotalValue = "Total";
            printdata.Note = "";
            printdata.Notes = "";


        }
        printdata.WholeSalePrice = printdata.loggedInCompanySetting.WholeSalePrice;
        printdata.color1 = printdata.loggedInCompanySetting.Color1;
        printdata.font = printdata.loggedInCompanySetting.FontsStyle;
        printdata.fontapi = printdata.loggedInCompanySetting.FontApi;



        printdata.RetailRate = printdata.loggedInCompanySetting.RetailRate;

        printdata.HSNcode = printdata.loggedInCompanySetting.HSNCode;

        printdata.Discount = printdata.loggedInCompanySetting.Discount;
        printdata.ApplsDiscount = printdata.loggedInCompanySetting.AppliedDiscount;

        printdata.GStNo = printdata.loggedInCompanySetting.GSTNo;
        printdata.rate = printdata.loggedInCompanySetting.Rate;
        printdata.subTotal = printdata.loggedInCompanySetting.SubTotal;
        printdata.total = printdata.loggedInCompanySetting.Total;
        printdata.CgstSgst = printdata.loggedInCompanySetting.CGSTSGST;

        printdata.ShopHSNCode = printdata.loggedInShop.HSNCode;
        printdata.ShopCustGSTNo = printdata.loggedInShop.CustGSTNo;
        printdata.ShopRate = printdata.loggedInShop.Rate;
        printdata.ShopDiscounts = printdata.loggedInShop.Discounts;
        printdata.ShopTax = printdata.loggedInShop.Tax;
        printdata.ShopSubTotal = printdata.loggedInShop.SubTotal;
        printdata.ShopTotal = printdata.loggedInShop.Total;






        printdata.x =
            (printdata.WholeSalePrice === "true" ||
                printdata.RetailRate === "true") &&
            !(printdata.Composite === "true");

        printdata.Name = appURL + "companyAssets/" + "user.png";
        printdata.billMaster.BillDate = moment(
            printdata.billMaster.BillDate
        ).format(printdata.loggedInCompanySetting.DateFormat);
        printdata.billMaster.DeliveryDate = moment(
            printdata.billMaster.DeliveryDate
        ).format(printdata.loggedInCompanySetting.DateFormat);
        printdata.currencyFormat = printdata.loggedInCompanySetting.CompanyCurrency;
        printdata.currencyLocale = printdata.loggedInCompanySetting.Locale;
        printdata.paidList = paidlist;
        // printdata.loggedInShop.WelcomeNote = printdata.loggedInShop.WelcomeNote.replace(
        //     "\r\n",
        //     "<br />\r\n"
        // );
        var BillFormat = printdata.loggedInCompanySetting.BillFormat;
        if (BillFormat === "null") {
            BillFormat = BillFormat;
        }
        BillFormat = BillFormat;
        var appURL = clientConfig.appURL;
        let url = appURL + "customerInvoice/" + file;
        let updateUrl = '';
        updateUrl = url;
 console.log(updateUrl);
        // TinyURL.shorten(url, function(res) {
        //     updateUrl = res;
        // });
        ejs.renderFile(
            path.join(appRoot, "./views/", BillFormat), { data: printdata },
            (err, data) => {
                if (err) {
                    console.log("HTML RENDER ERROR", err);
                    res.send(err);
                } else {
                    let options = {
                        // "width": "2.3in",
                        // "height": "3.3in",
                        format: printFormat,

                        orientation: orientation,
                        header: {
                            height: "1mm",
                        },
                        footer: {
                            height: "12mm",
                            contents: {
                                last: lasts
                            },
                        },
                    };

                    pdf.create(data, options).toFile(fileName, function(err, data) {
                        if (err) {
                            console.log("PDF RENDER ERROR", err);
                            res.send(err);
                        } else {
                            // smsService.sendSMS('8878899962');
                            companyService
                                .updateData(
                                    printdata.billMaster.ID,
                                    parem,
                                    JSON.parse(req.query.LoggedOnUser),
                                    "BillMaster",
                                    req.query.CompanyID
                                )
                                .then((response) => {
                                    response.result = updateUrl;
                                    console.log(response.result,'response.result');
                                    res.json(response);
                                    // if(CompanySetting.SMS === true){
                                    // }
                                })
                                .catch((error) => {
                                    res.json(error);
                                });
                        }
                    });
                }
            }
        );
    }

    static generateOrderForm(req, res) {
        var company = JSON.parse(req.query.CompanyID);
        var printdata = req.body;
        console.log(printdata.billList);

        var Measurement = JSON.parse(req.body.body.MeasurementID);
        var Customer = req.body.customer;
        var Shop = req.body.Shop;
        var Company = req.body.Company;
        var OrderNo = Math.trunc(Math.random() * 10000).toString();
        var printFormat = "A5";
        var orientation = "portrait";
        printdata.Customer = Customer;
        printdata.Measurement = Measurement;
        printdata.Shop = Shop;
        printdata.Company = Company;
        printdata.OrderNo = OrderNo;
        printFormat = "A5";
        orientation = "portrait";
        var file = "order_form.ejs" + printdata.CompanyID + ".pdf";
        var formatName = "order_form.ejs";
        // var appURL = "http://navient.online:50080/";
        // var appURL = "http://194.163.162.248:50080/";
        var fileName = "";
        fileName = "uploads/" + file;
        var appURL = clientConfig.appURL;
        printdata.LogoURL = appURL + printdata.Company.LogoURL;
        printdata.mix = appURL + "companyAssets/" + "mix.png";
        printdata.logo = appURL + "companyAssets/" + "logo.png";

        ejs.renderFile(
            path.join(appRoot, "./views/", formatName), { data: printdata },
            (err, data) => {
                if (err) {
                    res.send(err);
                } else {
                    let options = {
                        // "height": "11.25in",
                        // "width": "8.5in",
                        format: printFormat,
                        orientation: orientation,
                        header: {
                            height: "2mm",
                        },
                        footer: {
                            height: "2mm",
                        },
                    };
                    pdf.create(data, options).toFile(fileName, function(err, data) {
                        if (err) {
                            res.send(err);
                        } else {
                            res.json(file);
                        }
                    });
                }
            }
        );
    }

    // static printLens(req, res) {
    //     var company = JSON.parse(req.query.Company);
    //     var printdata = req.body;
    //     var printFormat = "A5";
    //     var orientation = "landscape";
    //     var fileName = "";
    //     var file = "";
    //     var formatName = "cust_rx.ejs";
    //     var tableName = "";
    //     var appURL = "http://194.163.162.248:50080/";
    //     if (req.query.Mode === "CL") {
    //         file =
    //             printdata.Customer.ID +
    //             "-CL-" +
    //             Math.trunc(Math.random() * 10000).toString() +
    //             ".pdf";
    //         formatName = "cust_rx.ejs";
    //         tableName = "contact_lens_rx";
    //     } else {
    //         file =
    //             printdata.Customer.ID +
    //             "-SL-" +
    //             Math.trunc(Math.random() * 10000).toString() +
    //             ".pdf";
    //         formatName = "cust_rx.ejs";
    //         tableName = "spectacle_rx";
    //     }
    //     fileName = "uploads/" + file;

    //     var parem = "FileURL" + " = '" + file + "'";

    //     printdata.LogoURL = appURL + printdata.loggedInCompanySetting.LogoURL;
    //     printdata.Company = company;
    //     printdata.Address = appURL + "companyAssets/" + "Location.png";
    //     printdata.MobileNo1 = appURL + "companyAssets/" + "mob1.png";
    //     printdata.PhoneNo = appURL + "companyAssets/" + "phone.png";
    //     printdata.Email = appURL + "companyAssets/" + "email3.png";
    //     printdata.Watermark =
    //         appURL + printdata.loggedInCompanySetting.WatermarkLogoURL;
    //     printdata.Name = appURL + "companyAssets/" + "user.png";

    //     ejs.renderFile(
    //         path.join(appRoot, "./views/", formatName), { data: printdata },
    //         (err, data) => {
    //             if (err) {
    //                 res.send(err);
    //             } else {
    //                 let options = {
    //                     // "width": "2.3in",
    //                     // "height": "3.3in",
    //                     format: printFormat,

    //                     orientation: orientation,
    //                     header: {
    //                         height: "1mm",
    //                     },
    //                     footer: {
    //                         height: "12mm",

    //                     },

    //                 };
    //                 pdf.create(data, options).toFile(fileName, function(err, data) {
    //                     if (err) {
    //                         res.send(err);
    //                     } else {
    //                         companyService
    //                             .updateData(
    //                                 printdata.Measurement.ID,
    //                                 parem,
    //                                 JSON.parse(req.query.LoggedOnUser),
    //                                 tableName,
    //                                 company.ID
    //                             )
    //                             .then((response) => {
    //                                 response.result = file;
    //                                 res.json(response);
    //                             })
    //                             .catch((error) => {
    //                                 res.json(error);
    //                             });
    //                     }
    //                 });
    //             }
    //         }
    //     );
    // }

    static printLens(req, res) {
        var company = JSON.parse(req.query.Company);
        var printdata = req.body;

        // printdata.Customer.VisitDate = moment().format('DD/MM/YYYY');
        console.log(printdata,"printdata")
        var welcomenotes = JSON.parse(req.body.loggedInCompanySetting.WelComeNote);
        printdata.Mode = req.query.Mode;
        var printFormat = "A5";
        var orientation = "portrait";
        var fileName = "";
        var file = "";
        var formatName = "cust_rx.ejs";
        var tableName = "";

        var welNote = [];
        welcomenotes.forEach((ele) => {
            if (ele.NoteType === "CustomerPower") {
                welNote.push(ele);
            }
        });

        printdata.wlcm = welNote;

        if (req.query.Mode === "CL") {
            file = printdata.Customer.ID + "-CL-" + Math.trunc(Math.random() * 10000).toString() + ".pdf";
            formatName = "cust_rx.ejs";
            tableName = "contact_lens_rx";
            printdata.rx = "Contact Rx";
        } else if (req.query.Mode === "SL") {
            file = printdata.Customer.ID + "-SL-" + Math.trunc(Math.random() * 10000).toString() + ".pdf";
            formatName = "cust_rx.ejs";
            tableName = "spectacle_rx";
            printdata.rx = "Spectacle Rx";

        } else if (req.query.Mode === "OL") {
            file = printdata.Customer.ID + "-OL-" + Math.trunc(Math.random() * 10000).toString() + ".pdf";
            formatName = "cust_rx.ejs";
            tableName = "other_rx";


            if (printdata.exdata === "spectacle") {
                printdata.rx = "Spectacle";
            } else if (printdata.exdata === "contactLens") {
                printdata.rx = "ContactLens";
            }
            printFormat = "A5";
            orientation = "portrait";

        }
        var appURL = clientConfig.appURL;

        // var appURL = "http://localhost:50080/";

        // fileName = "uploads/" + file;
        fileName = "uploads/" + file;

        var parem = "FileURL" + " = '" + file + "'";
        let url = appURL + file;
        let updateUrl = '';
        updateUrl = url;

        TinyURL.shorten(url, function(res) {
            updateUrl = res;
        });
        printdata.LogoURL = appURL + printdata.loggedInCompanySetting.LogoURL;
        printdata.Company = company;
        printdata.Address = appURL + "companyAssets/" + "Location.png";
        printdata.MobileNo1 = appURL + "companyAssets/" + "mob1.png";
        printdata.PhoneNo = appURL + "companyAssets/" + "phone.png";
        printdata.Email = appURL + "companyAssets/" + "email3.png";
        printdata.Watermark =
            appURL + printdata.loggedInCompanySetting.WatermarkLogoURL;
        printdata.Name = appURL + "companyAssets/" + "user.png";

        ejs.renderFile(
            path.join(appRoot, "./views/", formatName), { data: printdata },
            (err, data) => {
                if (err) {
                    res.send(err);
                } else {
                    let options = {
                        // "width": "2.3in",
                        // "height": "3.3in",
                        format: printFormat,

                        orientation: orientation,
                        header: {
                            height: "0.5mm",
                        },
                        footer: {
                            height: "20mm",
                            contents: {

                            },
                        },

                    };
                    pdf.create(data, options).toFile(fileName, function(err, data) {
                        if (err) {
                            res.send(err);
                        } else {
                            companyService
                                .updateData(
                                    printdata.Measurement.ID,
                                    parem,
                                    JSON.parse(req.query.LoggedOnUser),
                                    tableName,
                                    company.ID
                                )
                                .then((response) => {
                                    response.result = updateUrl;
                                    res.json(response);
                                })
                                .catch((error) => {
                                    res.json(error);
                                });
                        }
                    });
                }
            }
        );
    }


    static AssignFitterPDF(req, res) {

        var printdata = req.body;
        var shop = JSON.parse(req.query.Shop);
        printdata.Shop = shop;
        var fileName = "";
        var formatName = "laserReport.ejs";
        printdata.todaydate = moment().format("DD/MM/YYYY");
        var file = formatName + Math.trunc(Math.random() * 10000).toString() + ".pdf";


        fileName = "uploads/" + file;

        // var parem = "FileURL" + " = '" + file + "'";

        ejs.renderFile(path.join(appRoot, './views/', formatName), { data: printdata }, (err, data) => {
            if (err) {
                res.send(err);
            } else {
                let options = {
                    "height": "11.25in",
                    "width": "8.5in",
                    "header": {
                        "height": "2mm"
                    },
                    "footer": {
                        "height": "20mm",
                    },
                };
                pdf.create(data, options).toFile(fileName, function(err, data) {
                    if (err) {
                        res.send(err);
                    } else {
                        res.json(file);
                    }
                });
            }
        });
    }


    static AssignSupplierPDF(req, res) {

        var printdata = req.body;
        var shop = printdata.Shop;
        var company = printdata.Company;
        var ProductList = printdata.productList;
        var appURL = clientConfig.appURL;
        printdata.LogoURL = appURL + printdata.Company.LogoURL;
        console.log(printdata.LogoURL);

        console.log(printdata);
      let totalQty = 0
      let  gstTotal = 0
      let  totalAmount = 0
      let  totalPurchaseRate = 0

        for (var i = 0; i < printdata.productList.length; i++) {
            totalQty = totalQty + printdata.productList[i].Qty;
            gstTotal = gstTotal +  printdata.productList[i].GSTAmount;

            totalAmount = totalAmount + printdata.productList[i].UnitPrice * printdata.productList[i].Qty + printdata.productList[i].GSTAmount;
            totalPurchaseRate = totalPurchaseRate + printdata.productList[i].UnitPrice * printdata.productList[i].Qty;
        }

        printdata.totalQty = totalQty;
        printdata.gstTotal = gstTotal;
        printdata.totalAmount = totalAmount;
        printdata.totalPurchaseRate = totalPurchaseRate;

        var shop = JSON.parse(req.query.Shop);
        printdata.Shop = shop;
        var fileName = "";
        var formatName = "assignSuppdf.ejs";
        printdata.todaydate = moment().format("DD/MM/YYYY");
        var file = formatName + Math.trunc(Math.random() * 10000).toString() + ".pdf";


        fileName = "uploads/" + file;

        ejs.renderFile(path.join(appRoot, './views/', formatName), { data: printdata }, (err, data) => {
            if (err) {
                res.send(err);
            } else {
                let options = {
                    "height": "11.25in",
                    "width": "8.5in",
                    header: {
                        height: "5mm"
                    },
                    footer: {
                      height: "30mm",
                        contents: {
                            last: ` <section style="width: 96%; border-top:1px solid #000;">
                            <div style="width: 10%; float:right;line-height: 25px; text-align: right;">
                                <div  >  ${printdata.totalQty}</div>
                                <div  >   ${parseFloat(printdata.gstTotal).toFixed(2)}</div>
                                <div  >  ${printdata.totalPurchaseRate}</div>
                                <div  >   ${parseFloat(printdata.totalAmount).toFixed(2)}</div>
                              </div>
                             <div style="width: 20%; float:right; line-height: 25px;">
                               <div style="text-align: left; font-weight: bold;font-size: 16px;"> Total Qty </div>
                               <div style="text-align: left; font-weight: bold;font-size: 16px;"> Total GSTAmt </div>
                               <div style="text-align: left; font-weight: bold;font-size: 16px;"> Total Purchase Rate </div>
                               <div style="text-align: left; font-weight: bold;font-size: 16px;"> Total Amount </div>
                             </div>


                         </section>`,
                        },
                    },
                };
                pdf.create(data, options).toFile(fileName, function(err, data) {
                    if (err) {
                        res.send(err);
                    } else {
                        res.json(file);
                    }
                });
            }
        });
    }

    static PurchasePDF(req, res) {

        var printdata = req.body;
        console.log(printdata);
        var SelectedPurchaseMasters = req.body.selectedPurchaseMaster;
        var itemLists = req.body.itemList;
        printdata.selectedPurchaseMaster = SelectedPurchaseMasters;
        printdata.itemList = itemLists;

let SubTotal =  parseFloat(printdata.selectedPurchaseMaster.SubTotal).toFixed(2)
let DiscountAmount =  parseFloat(printdata.selectedPurchaseMaster.DiscountAmount).toFixed(2)
let GSTAmount =  parseFloat(printdata.selectedPurchaseMaster.GSTAmount).toFixed(2)
let TotalAmount =  parseFloat(printdata.selectedPurchaseMaster.TotalAmount).toFixed(2)



        console.log(SubTotal);

        var appURL = clientConfig.appURL;
        printdata.LogoURL = appURL + printdata.Company.LogoURL;
        console.log(printdata.LogoURL);
        var shop = JSON.parse(req.query.Shop);
        printdata.Shop = shop;
        var fileName = "";
        var formatName = "PurchasePDF.ejs";

        var file = formatName + Math.trunc(Math.random() * 10000).toString() + ".pdf";
        fileName = "uploads/" + file;

        // var parem = "FileURL" + " = '" + file + "'";


        ejs.renderFile(path.join(appRoot, './views/', formatName), { data: printdata }, (err, data) => {
            if (err) {
                res.send(err);
            } else {
                let options = {
                    "height": "11.25in",
                    "width": "8.5in",
                    header: {
                        height: "5mm"
                    },
                    footer: {
                      height: "5mm",
                        contents: {
                            last: ``,
                        },
                    },
                };
                pdf.create(data, options).toFile(fileName, function(err, data) {
                    if (err) {
                        res.send(err);
                    } else {
                        res.json(file);
                    }
                });
            }
        });
    }

    static async customerNote1(req, res) {
            try {
                let response = { result: null, success: null };
                let printdata = req.body;
                let companyID = req.query.CompanyID;
                printdata.Company = req.query.LoggedOnUser;
                printdata.CompanySetting = req.query.Company;
                printdata.CustomerCredit = await companyService.getCustomerCreditInfo('Customer Credit', printdata.customerID, printdata.Shop.ID, companyID);
                printdata.CustomerReturn = await companyService.getCustomerCreditInfo('Customer', printdata.customerID, printdata.Shop.ID, companyID);
                var printFormat = "A5";
                var orientation = "portrait";
                printdata.CustomerCreditTotal = printdata.CustomerCredit.reduce((sum, item) => sum + item.Amount, 0);
                printdata.CustomerReturnTotal = printdata.CustomerReturn.reduce((sum, item) => sum + item.Amount, 0);
                var file = "credit_note.ejs" + printdata.customerID + ".pdf";
                var formatName = "credit_note.ejs";
                var appURL = "http://localhost:50080/";
                var fileName = "uploads/" + file;
                printdata.mix = constents.appURL + "companyAssets/" + "mix.png";
                printdata.LogoURL = constents.appURL + printdata.Company.LogoURL;
                printdata.LogoURL = constents.appURL + printdata.Company.LogoURL;
                printdata.IssueDate = moment().format(printdata.CompanySetting.DateFormat);
                printdata.ValidDate = moment().format(printdata.CompanySetting.DateFormat);
                response.result.html = ejs.renderFile(path.join(appRoot, "./views/", formatName), { data: printdata });
                let options = {
                    format: printFormat,
                    orientation: orientation,
                    header: { height: "0mm", },
                    footer: { height: "2mm", }
                };
                response.result.pdfData = pdf.create(response.result.html, options).toFile(fileName);
                response.result.fileName = fileName;
                if (CompanySetting.Email === true) {
                    response.result.mail = mailService.sendMail(data, email, printdata.loggedInCompany, printdata.loggedInShop);
                }
                if (CompanySetting.SMS === true) {
                    response.result.sms = smsService.sendSMS(mobileNumbers, messages, countryDialCode);
                }
                return response;

            } catch (err) {
                console.log("Error Generating ", err);
                throw err;
            } finally {

            }
        }
        // get rid of below function if above works

    static customerNote(req, res) {
        var printdata = req.body;
        console.log(printdata);
        var paidList = req.body.paidList;
        var billItemList = req.body.billItemList;
        var Shop = req.body.Shop;
        var customerID = req.body.customerID;
        var customerDetail = req.body.customerDetail;
        var applyPayment = req.body.applyPayment;
        var Company = req.body.Company;
        var welNote = [];

        var welcomenote = JSON.parse(JSON.parse(req.query.Company).WelComeNote);


        welcomenote.forEach((ele) => {
            if (ele.NoteType === "CustomerCredit") {
                welNote.push(ele);
            }
        });

        printdata.wlcm = welNote;

        var printFormat = "A5";
        var orientation = "portrait";
        var total = printdata.paidList.reduce((sum, item) => sum + item.Amount, 0);
        printdata.billItemList = billItemList;
        printdata.paidList = paidList;
        printdata.Shop = Shop;
        printdata.ShopName = Shop.Name;
        printdata.Company = Company;
        printdata.color1 = Company.Color1;
        var appURL = clientConfig.appURL;
        printdata.font = Company.FontsStyle;
        printdata.fontapi = Company.FontApi;
        printdata.LogoURL = appURL + printdata.Company.LogoURL;
        // printdata.LogoURL = appURL + printdata.loggedInCompanySetting.LogoURL;
        console.log(printdata.LogoURL,'printdata.LogoURL');


        printdata.customerID = customerID;
        printdata.customerDetail = customerDetail;


        printFormat = "A5";
        orientation = "portrait";
        printdata.total = total;
        printdata.applyPayment = applyPayment;

        var file = "credit_note.ejs" + printdata.customerID + ".pdf";
        var formatName = "credit_note.ejs";
        // var appURL = "http://localhost:50080/";
        var appURL = clientConfig.appURL;

        var fileName = "";
        fileName = "uploads/" + file;
        printdata.mix = appURL + "companyAssets/" + "mix.png";
        printdata.logo = appURL + "companyAssets/" + "logo.png";

        let url = appURL + file;
        let updateUrl = '';
        updateUrl = url;
        TinyURL.shorten(url, function(res) {
            updateUrl = res;
        });
        ejs.renderFile(
            path.join(appRoot, "./views/", formatName), { data: printdata },
            (err, data) => {
                if (err) {
                    res.send(err);
                } else {
                    let options = {
                        // "height": "11.25in",
                        // "width": "8.5in",
                        format: printFormat,
                        orientation: orientation,
                        header: {
                            height: "2mm",
                        },
                        footer: {
                            height: "2mm",
                        },
                    };
                    pdf.create(data, options).toFile(fileName, function(err, data) {
                        if (err) {
                            res.send(err);
                        } else {
                            res.json(updateUrl);
                        }
                    });

                }
            }
        );
    }

    static billPayment(req, res) {

        var printdata = req.body;
        printdata.From = moment(printdata.From).format('DD-MM-YYYY')
        printdata.To = moment(printdata.To).format('DD-MM-YYYY')
        printdata.Name = printdata.Company.Name;
        printdata.MobileNo1 = printdata.Company.MobileNo1;
        printdata.MobileNo2 = printdata.Company.MobileNo2;
        printdata.Address = printdata.Company.Address;

        console.log( printdata,' printdata');
        var formatName = "LedgerReport.ejs";

        var file = "LedgerReport.ejs" + ".pdf";
        // var appURL = "http://localhost:50080/";
        var appURL = clientConfig.appURL;

        var fileName = "";
        fileName = "uploads/" + file;

        let url = appURL + file;
        let updateUrl = '';
        TinyURL.shorten(url, function(res) {
            updateUrl = res;
        });
        ejs.renderFile(path.join(appRoot, './views/', formatName), { data: printdata }, (err, data) => {
                if (err) {
                    res.send(err);
                } else {
                    let options = {
                        "height": "11.25in",
                        "width": "8.5in",
                    };
                    pdf.create(data, options).toFile(fileName, function(err, data) {
                        if (err) {
                            res.send(err);
                        } else {
                            res.json(updateUrl);
                        }
                    });

                }
            }
        );
    }

    static billSubPayment(req, res) {

        var printdata = req.body;
        console.log( printdata,' printdata111');

        printdata.From = moment(printdata.From).format('DD-MM-YYYY')
        printdata.To = moment(printdata.To).format('DD-MM-YYYY')
        printdata.Name = printdata.Company.Name;
        printdata.MobileNo1 = printdata.Company.MobileNo1;
        printdata.MobileNo2 = printdata.Company.MobileNo2;
        printdata.Address = printdata.Company.Address;




        var formatName = "SupplierLedgerReport.ejs";

        var file = "SupplierLedgerReport.ejs" + ".pdf";
        // var appURL = "http://localhost:50080/";
        var appURL = clientConfig.appURL;

        var fileName = "";
        fileName = "uploads/" + file;

        let url = appURL + file;
        let updateUrl = '';
        TinyURL.shorten(url, function(res) {
            updateUrl = res;
        });
        ejs.renderFile(path.join(appRoot, './views/', formatName), { data: printdata }, (err, data) => {
                if (err) {
                    res.send(err);
                } else {
                    let options = {
                        "height": "11.25in",
                        "width": "8.5in",
                    };
                    pdf.create(data, options).toFile(fileName, function(err, data) {
                        if (err) {
                            res.send(err);
                        } else {
                            res.json(updateUrl);
                        }
                    });

                }
            }
        );
    }


    static BarcodePrint(req, res) {
        var printdata = req.body;

        let array = [];


        let len = printdata.Quantity;
        if(printdata.ProductTypeName !== 'SUNGLASSES' && printdata.ProductTypeName !== 'SUNGLASS'){
            let ProductFullName = ele.ProductName;
            let ProductName = printdata.ProductName.split("/")[1];
            let ProductNames = printdata.ProductName.split("/")[2].substr(0, 15);
            printdata.ProductName = ProductName;
            printdata.ProductNames = ProductNames;
            ele.ProductFullName = ProductFullName;

        } else {
            let ProductFullName = ele.ProductName;
            let ProductName = printdata.ProductName.split("/")[0];
            let ProductNames = printdata.ProductName.split("/")[1].substr(0, 15);
            printdata.ProductName = ProductName;
            printdata.ProductNames = ProductNames;
            ele.ProductFullName = ProductFullName;

        }


        array.push(printdata);

        let modifyarray = [];
        for (var i = 0; i < len; i++) {

            modifyarray.push(array[0])
        }
        printdata = modifyarray;
        // printdata.forEach(ele => {
        //     let ProductName = ele.ProductName.split("/")[1];
        //     let ProductNames = ele.ProductName.split("/")[2].substr(0, 15);
        //     ele.ProductName = ProductName;
        //     ele.ProductNames = ProductNames;

        // })
        printdata.CompanyBarcode = JSON.parse(req.query.Company).BarCode;

        var file = "barcode.ejs" + ".pdf";
        var formatName = "barcode.ejs";
        // var appURL = "http://localhost:50080/";
        var appURL = clientConfig.appURL;

        var fileName = "";
        fileName = "uploads/" + file;

        let url = appURL + file;
        let updateUrl = '';
        TinyURL.shorten(url, function(res) {
            updateUrl = res;
        });
        ejs.renderFile(
            path.join(appRoot, "./views/", formatName), { data: printdata },
            (err, data) => {
                if (err) {
                    res.send(err);
                } else {
                    let options;
                    if (printdata.CompanyBarcode == 2) {
                        options = {
                            "height": "0.70in",
                            "width": "4.41in",
                        };
                    }

                    if (printdata.CompanyBarcode == 0) {
                        options = {
                            "height": "0.80in",
                            "width": "4.41in",
                        };
                    }

                    if (printdata.CompanyBarcode == 1) {
                        options = {
                            "height": "0.70in",
                            "width": "4.41in",
                        };
                    }

                    if (printdata.CompanyBarcode == 3) {
                            options = {
                            "height": "27mm",
                            "width": "38mm",
                        };
                    }

                    pdf.create(data, options).toFile(fileName, function(err, data) {
                        if (err) {
                            res.send(err);
                        } else {
                            res.json(updateUrl);
                        }
                    });

                }
            }
        );
    }

    static BarcodePrintAll(req, res) {
        let printdata = req.body;
        console.log(printdata,'printdata');
        let modifyarray = [];
        let len = 0;


        printdata.forEach(ele => {
            len = len + 1;
            if(ele.ProductTypeName !== 'SUNGLASSES' && ele.ProductTypeName !== 'SUNGLASS'){
                let ProductName = ele.ProductName.split("/")[1];
                let ProductNames = ele.ProductName.split("/")[2];
                let ProductFullName = ele.ProductName

                ele.ProductFullName = ProductFullName;
                ele.ProductName = ProductName;
                if(ele.CompanyID != '9'){
                    ele.ProductNames = ProductNames;
                }
            } else {
                let ProductName = ele.ProductName.split("/")[0];
                let ProductNames = ele.ProductName.split("/")[1];
                let ProductFullName = ele.ProductName

                ele.ProductFullName = ProductFullName;
                ele.ProductName = ProductName;
                if(ele.CompanyID != '9'){
                    ele.ProductNames = ProductNames;
                }
            }

            for (var i = 0; i < ele.Quantity; i++) {
                modifyarray.push(ele)
            }

        })
        if (printdata.length === len) {
            printdata = modifyarray;
            printdata.CompanyBarcode = JSON.parse(req.query.Company).BarCode;
            console.log(printdata.CompanyBarcode);


            var file = "barcode.ejs" + ".pdf";
            var formatName = "barcode.ejs";
            // var appURL = "http://localhost:50080/";
            var appURL = clientConfig.appURL;

            var fileName = "";
            fileName = "uploads/" + file;

            let url = appURL + file;
            let updateUrl = '';
            TinyURL.shorten(url, function(res) {
                updateUrl = res;
            });

            ejs.renderFile(
                path.join(appRoot, "./views/", formatName), { data: printdata },
                (err, data) => {
                    if (err) {
                        res.send(err);
                    } else {
                        let options;
                        if (printdata.CompanyBarcode == 0) {
                            options = {
                                "height": "0.80in",
                                "width": "4.41in",
                            };
                        }

                        if (printdata.CompanyBarcode == 1) {
                            options = {
                                "height": "0.70in",
                                "width": "4.41in",
                            };
                        }
                        if (printdata.CompanyBarcode == 2) {
                            options = {
                                "height": "0.70in",
                                "width": "4.41in",
                                // "height": "0.90in",
                                // "width": "6.00in",
                            };
                        }
                        if (printdata.CompanyBarcode == 3) {
                            options = {
                            "height": "27mm",
                            "width": "38mm",
                            };
                        }

                        if (printdata.CompanyBarcode == 4) {
                            options = {
                            "height": "27mm",
                            "width": "38mm",
                            };
                        }

                        if (printdata.CompanyBarcode == 5) {
                            options = {
                                "height": "0.70in",
                                "width": "4.41in",
                            };
                        }

                        if (printdata.CompanyBarcode == 6) {
                            options = {
                                "height": "0.70in",
                                "width": "4.41in",
                                // "height": "0.90in",
                                // "width": "6.00in",
                            };
                        }



                        options.timeout = 540000,  // in milliseconds

                        pdf.create(data, options).toFile(fileName, function(err, data) {
                            if (err) {
                                res.send(err);
                            } else {
                                res.json(updateUrl);
                            }
                        });

                    }
                }
            );
        }

    }
    static BarcodePrintAlls(req, res) {
        // req.setTimeout(0);
        let printdata = req.body;
        console.log(printdata,'printdata');
        // let modifyarray = [];
        let len = 0;


        // printdata.forEach(ele => {
        //     len = len + 1;
        //     if(ele.ProductTypeName !== 'SUNGLASSES' && ele.ProductTypeName !== 'SUNGLASS'){
        //         let ProductFullName = ele.ProductName
        //         let ProductName = ele.ProductName.split("/")[1];
        //         if(ele.CompanyID != '9'){
        //             let ProductNames = ele.ProductName.split("/")[2].substr(0, 15);
        //             ele.ProductNames = ProductNames;
        //         }
        //         ele.ProductFullName = ProductFullName;
        //         ele.ProductName = ProductName;
        //     } else {
        //         let ProductFullName = ele.ProductName
        //         let ProductName = ele.ProductName.split("/")[0];
        //         if(ele.CompanyID != '9'){
        //             let ProductNames = ele.ProductName.split("/")[2].substr(0, 15);
        //             ele.ProductNames = ProductNames;
        //         }
        //         ele.ProductFullName = ProductFullName;
        //         ele.ProductName = ProductName;
        //     }


        //     for (var i = 0; i < ele.Quantity; i++) {
        //         modifyarray.push(ele)
        //     }

        // })
        // if (printdata.length === len) {
            // printdata = modifyarray;
            printdata.CompanyBarcode = JSON.parse(req.query.Company).BarCode;
            console.log(printdata.CompanyBarcode);


            var file = "barcode.ejs" + ".pdf";
            var formatName = "barcode.ejs";
            // var appURL = "http://localhost:50080/";
            var appURL = clientConfig.appURL;

            var fileName = "";
            fileName = "uploads/" + file;

            let url = appURL + file;
            let updateUrl = '';
            TinyURL.shorten(url, function(res) {
                updateUrl = res;
            });

            ejs.renderFile(
                path.join(appRoot, "./views/", formatName), { data: printdata },
                (err, data) => {
                    if (err) {
                        res.send(err);
                    } else {
                        let options;

                        if (printdata.CompanyBarcode == 5) {
                            options = {
                                "height": "0.70in",
                                "width": "4.41in",
                            };
                        }
                        if (printdata.CompanyBarcode == 4) {
                            options = {
                            "height": "27mm",
                            "width": "38mm",
                            };
                        }
                        if (printdata.CompanyBarcode == 3) {
                            options = {
                            "height": "27mm",
                            "width": "38mm",
                            };
                        }
                        if (printdata.CompanyBarcode == 2) {
                            options = {
                                "height": "0.70in",
                                "width": "4.41in",
                            };
                        }

                        if (printdata.CompanyBarcode == 0) {
                            options = {
                                "height": "0.80in",
                                "width": "4.41in",
                            };
                        }

                        if (printdata.CompanyBarcode == 1) {
                            options = {
                                "height": "0.70in",
                                "width": "4.41in",
                            };
                        }

                        options.timeout = 540000,  // in milliseconds

                        pdf.create(data, options).toFile(fileName, function(err, data) {
                            if (err) {
                                console.log(err, 'err');
                                res.send(err);
                            } else {
                                res.json(updateUrl);
                            }
                        });

                    }
                }
            );
        // }

    }




    static printChallan(req, res) {
        var company = JSON.parse(req.query.Company);
        if (req.query.Type === 'single') {


            var printdata = req.body;
            const txdata = [];
            txdata.push(req.body);
            printdata.TXdata = txdata;

            var fileName = "";
            var PassNo = Math.trunc(Math.random() * 10000).toString();
            var file = "TransferProduct" + printdata.CompanyID + PassNo + ".pdf";
            var formatName = "TransferProduct.ejs";
            var tableName = "TransferMaster";
            var appURL = "http://navient.in:50060/";
            fileName = "uploads/" + file;
            var parem = "FileURL" + " = '" + file + "'";




            printdata.PassNo = PassNo;
        } else if (req.query.Type === 'multi') {
            var printdata = req.body[0];
            const txdata = [];
            req.body.forEach(ele => {
                txdata.push(ele);
            })
            printdata.TXdata = txdata;
            var fileName = "";
            var PassNo = Math.trunc(Math.random() * 10000).toString();
            var file = "TransferProduct" + printdata.CompanyID + PassNo + ".pdf";
            var formatName = "TransferProduct.ejs";
            var tableName = "TransferMaster";
            var appURL = "http://navient.in:50060/";
            fileName = "uploads/" + file;
            var parem = "FileURL" + " = '" + file + "'";




            printdata.PassNo = PassNo;
        }
        ejs.renderFile(path.join(appRoot, './views/', formatName), { data: printdata }, (err, data) => {
            if (err) {
                res.send(err);
            } else {
                let options = {
                    "height": "11.25in",
                    "width": "8.5in",
                    "header": {
                        "height": "20mm"
                    },
                    "footer": {
                        "height": "20mm",
                    },
                };
                pdf.create(data, options).toFile(fileName, function(err, data) {
                    if (err) {
                        res.send(err);
                    } else {
                        res.json(file);
                    }
                });
            }
        });
    };

    static getProductDataByBarCodeNo(req, res) {
        companyService
            .getProductDataByBarCodeNo(
                req.query,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID,
                req.query.PreOrder,
                req.query.ShopMode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getBarCodeListBySearchString(req, res) {
        companyService
            .getBarCodeListBySearchString(
                req.query.SearchString,
                req.query.ProductName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.ShopID,
                req.query.CompanyID,
                req.query.ShopMode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getBarPreOrderCodeListBySearchString(req, res) {
        companyService
            .getBarPreOrderCodeListBySearchString(
                req.query.SearchString,
                req.query.ProductName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.ShopID,
                req.query.CompanyID,
                req.query.ShopMode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getPurchaseFullDataByID(req, res) {
        companyService
            .getPurchaseFullDataByID(
                req.query.ID,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getFitterInvoiceFullDataByID(req, res) {
        companyService
            .getFitterInvoiceFullDataByID(
                req.query.ID,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getCommissionInvoiceFullDataByID(req, res) {
        companyService
            .getCommissionInvoiceFullDataByID(
                req.query.ID,
                req.query.UserType,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getSupportMasterList(req, res) {
        companyService
            .getSupportMasterList(req.query.TableName, req.query.CompanyID)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getCashRegisterData(req, res) {
        companyService
            .getCashRegisterData(req.query.ShopID, req.query.CompanyID)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getBarCodeDataByProduct(req, res) {
        companyService
            .getBarCodeDataByProduct(
                req.query,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static savePurchase(req, res) {
        companyService
            .savePurchase(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.Mode

            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExistingProduct(req, res) {
        companyService
            .getExistingProduct(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static updatePurchase(req, res) {
        companyService
            .updatePurchase(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.Mode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static transferProduct(req, res) {
        companyService
            .transferProduct(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static cancelTransfer(req, res) {
        companyService
            .cancelTransfer(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static acceptTransfer(req, res) {
        companyService
            .acceptTransfer(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static saveBill(req, res) {
        companyService
            .saveBill(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static updateBill(req, res) {
        companyService
            .updateBill(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                JSON.parse(req.query.Company)
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }
    static updateCurrection(req, res) {
        companyService
            .updateCurrection(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                JSON.parse(req.query.Company)
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static updateProductStatus(req, res) {
        companyService
            .updateProductStatus(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.id
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static applyPayment(req, res) {
        companyService
            .applyPayment(
                req.body,
                req.query.UserMode,
                req.query.Mode,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                JSON.parse(req.query.Company)
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static purchaseReturn(req, res) {
        companyService
            .purchaseReturn(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getAllDataByID(req, res) {
        companyService
            .getAllDataByID(req.query.TableName, req.query.CompanyID)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getShortListByCompany(req, res) {
        companyService
            .getShortListByCompany(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.DelMode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getShortListByCompanyOrderBy(req, res) {
        companyService
            .getShortListByCompanyOrderBy(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.DelMode
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedListByCompany(req, res) {
        companyService
            .getExtendedListByCompany(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                JSON.parse(req.query.CompanyID).CompanyID,
                JSON.parse(req.query.ShopID).ID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedListByCompany1(req, res) {
        companyService
            .getExtendedListByCompany(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedCustomerListBy(req, res) {
        companyService
            .getExtendedCustomerListBy(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedCustomerListBy2(req, res) {
        companyService
            .getExtendedCustomerListBy2(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID,
                req.query.Page,

            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }
    static getShortDataByID(req, res) {
        companyService
            .getShortDataByID(req.query.TableName, req.query.ID, req.query.CompanyID)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }
    static getSearchDataByFilterForCashRegister(req, res) {
        companyService
            .getSearchDataByFilterForCashRegister(
                req.query.TableName,
                req.query.CompanyID,
                req.query.filter
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedDataByID(req, res) {
        companyService
            .getExtendedDataByID(
                req.query.TableName,
                req.query.ID,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getShortListByID(req, res) {
        companyService
            .getExtendedListByID(
                req.query.TableName,
                req.query.ID,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedListByID(req, res) {
        companyService
            .getExtendedListByID(
                req.query.TableName,
                req.query.ID,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedListByParem(req, res) {
        companyService
            .getExtendedListByParem(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getPaymentListByPaymentType(req, res) {
        companyService
            .getPaymentListByPaymentType(
                req.query.PaymentType,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getShortListByParam(req, res) {
        companyService
            .getShortListByParem(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getShortListByParamNew(req, res) {
        companyService
            .getShortListByParemNew(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }
    static shortListByParemNewBill(req, res) {
        companyService
            .shortListByParemNewBill(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getExtendedListByParemNew(req, res) {
        companyService
            .getExtendedListByParemNew(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getGenericListByParem(req, res) {
        companyService
            .getGenericListByParem(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);

            })
            .catch((error) => {
                res.json(error);
            });
    }
    static getnewpurchasereports(req, res) {
        companyService
            .newpurchasereports(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);

            })
            .catch((error) => {
                res.json(error);
            });
    }





    static getGenericListByParemSalePayment(req, res) {
        companyService
            .getGenericListByParemSalePayment(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }


    static getGenericListByParemSaleReport(req, res) {
        companyService
            .getGenericListByParemSaleReport(
                req.query.TableName,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getLaserReportpdf(req, res) {
        companyService
            .getLaserReportpdf(
                req.query.CustomerID,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getlaserReportSubpdf(req, res) {
        companyService
            .getlaserReportSubpdf(
                req.query.SupplierID,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getlaserReportemppdf(req, res) {
        companyService
            .getlaserReportemppdf(
                req.query.EmployeeID,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getAggregateListByParem(req, res) {
        companyService
            .getAggregateListByParem(
                req.query.TableName1,
                req.query.TableName2,
                req.query.Parem,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getDataByID(req, res) {
        companyService
            .getDataByID(req.query.TableName, req.query.ID, req.query.CompanyID)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getListByOtherID(req, res) {
        companyService
            .getDataByOtherID(req.query.TableName, req.query.CompanyID, req.query.ID, JSON.parse(req.query.LoggedOnUser), req.query.Shop)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getListByOtherID1(req, res) {
        companyService
            .getDataByOtherID(req.query.TableName, req.query.CompanyID, req.query.ID, JSON.parse(req.query.LoggedOnUser), req.query.Shop)
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getPreorderPurchaseList(req, res) {
        companyService
            .getPreorderPurchaseList(
                req.query.Mode,
                req.query.CompanyID,
                req.query.ID,
                req.query.ShopID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getListByPage(req, res) {
        companyService
            .getListByPage(
                req.query.Mode,
                req.query.CompanyID,
                req.query.ID,
                req.query.ShopID,
                req.query.pageLimit
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getSearchDataByFilter(req, res) {
        companyService
            .getSearchDataByFilter(
                req.query.TableName,
                req.query.CompanyID,
                req.query.filter
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getpermissionByRole(req, res) {
        companyService
            .getPermissionByRole(
                req.query.ID,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getFieldList(req, res) {
        companyService
            .getFieldList(
                req.query.ProductTypeName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getDataByName(req, res) {
        companyService
            .getDataByName(
                req.query.TableName,
                req.query.Name,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getProductSupportData(req, res) {
        companyService
            .getProductSupportData(
                req.query.TableName,
                req.query.Ref,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static saveProductSupportData(req, res) {
        companyService
            .saveProductSupportData(
                req.query.TableName,
                req.query.Ref,
                req.body.SelectedValue,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getOwnerDataByID(req, res) {
        companyService
            .getOwnerDataByID(
                req.query.TableName,
                req.query.ID,
                JSON.parse(req.query.LoggedOnUser)
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }


    static getCommissionList(req, res) {
        companyService
            .getCommissionList(
                req.query.Parem,
                req.query.UserType,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getDashboardData(req, res) {
        companyService
            .getDashboardData(
                req.query.Date1,
                req.query.Date2,
                req.query.ShopID,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getSmsReport(req, res) {
        smsService
            .sendSMS(
                req.query.MobileNo,
                req.query.MsgText,
                req.query.TemplateID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static deleteData(req, res) {
        companyService
            .deleteData(
                JSON.parse(req.query.LoggedOnUser),
                req.query.TableName,
                req.query.ID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static deleteOtherID(req, res) {
        companyService
            .deleteOtherID(
                JSON.parse(req.query.LoggedOnUser),
                req.query.TableName,
                req.query.ID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static deletePreOrder(req, res) {
        companyService
            .deletePreOrder(
                JSON.parse(req.query.LoggedOnUser),
                req.query.TableName,
                req.query.ID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static deletePermanent(req, res) {
        companyService
            .deletePermanent(
                JSON.parse(req.query.LoggedOnUser),
                req.query.TableName,
                req.query.ID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static Retrive(req, res) {
        companyService
            .Retrive(
                JSON.parse(req.query.LoggedOnUser),
                req.query.TableName,
                req.query.ID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }


    static saveData(req, res) {
        companyService
            .saveData(
                req.body,
                JSON.parse(req.query.LoggedOnUser),
                req.query.TableName,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static saveSmallData(req, res) {
        companyService
            .saveSmallData(
                req.query.TableName,
                req.query.ID,
                req.body,
                req.query.CompanyID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static sendsms(req, res) {
        smsService
            .sendSMS(
                req.query.MobileNo,
                req.query.MsgText,
                req.query.TemplateID,
                req.query.SenderID,
                req.query.MsgAPIKey,

            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }

    static getchack(req, res) {
        companyService
            .getchack()
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }



    static customeridd(req, res) {
        companyService
            .customeridd(
                req.query.TableName,
                JSON.parse(req.query.LoggedOnUser),
                req.query.CompanyID,
                req.query.ShopID
            )
            .then((response) => {
                res.json(response);
            })
            .catch((error) => {
                res.json(error);
            });
    }
}
module.exports = companyController;