"use strict";
// var msg91 = require("@walkover/msg91")("API_KEY", "SENDER_ID", "ROUTE_NO" );

class smsService {
    // async..await is not allowed in global scope, must use a wrapper
    static async sendSMS(MobileNo, MsgText, TemplateID , SenderID,MsgAPIKey) {
        // 361603AWZWarIp60b48fdcP1
        var msg91 = require("@walkover/msg91")(`${MsgAPIKey}`, `${SenderID}`, "4");
        // sendSms.senderId
        const mobileNumbers = [];

        const messages = MsgText;

        // const messages = "DEAR Rahul Gothi WISH YOU HAPPY BIRTHDAY GET 20 OFF RELINK 9752885711";


        const countryDialCode = "91";
        const templateId = "1307162209333288467"
        const modifyNo = countryDialCode.concat(MobileNo);
        mobileNumbers.push(modifyNo);



        msg91.send(mobileNumbers, `${MsgText}`, TemplateID, function(err, response) {
            console.log(err);
            console.log(response, 'response');
        });
        console.log(msg91,'msg91msg91');
    }
}
module.exports = smsService;