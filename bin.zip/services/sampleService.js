const mysql = require("../newdb.js");
class samoleService {
  // This function is used to get all data from a table which has a global Key
  // Example in School Project SchoolID is Global key as each table all data for a school can be queried.
  // Each LoggedOnUser is not required but is kept in the query parameters

  static async getShortListByGlobalID(TableName, LoggedOnUser, GlobalID) {
    const connection = await mysql.connection();
    try {
      console.log(
        "Calling Function for Table " +
          TableName +
          "to get all Data from one Table"
      );

      // Create a response object. response.data
      let response = { data: null, success: null };

      // Call getShortQuery function to build the query
      let qry = this.getShortQuery(TableName, LoggedOnUser, GlobalID);
      let data = await connection.query(qry);

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at getShortListQuery", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  // This function is used to get all data from a table which has a global Key
  // Example in School Project SchoolID is Global key as each table all data for a school can be queried.
  // However since current table will have Foreign Keys from Other tables. We will create a Full
  // Query for Each Foreign Key-Value by Joining with other Tables.

  // Each LoggedOnUser is not required but is kept in the query parameters

  static async getExtendedListByCompany(TableName, LoggedOnUser, GlobalID) {
    const connection = await mysql.connection();
    try {
      console.log(
        "Calling Function for Table " +
          TableName +
          "to get all Data from multiple tables by Joining"
      );
      // Create a response object. response.data
      let response = { data: null, success: null };

      // Call getExtendedQuery function to build the query

      let qry = this.getExtendedQuery(TableName, LoggedOnUser, GlobalID);
      let data = await connection.query(qry);

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at getExtendedListQuery", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  // This function is used to get all data from a table which has a global Key and Table Primary Key Is provided
  // Example in School Project SchoolID is Global key as each table all data for a school can be queried.
  // Each Table will have ID as Primary Key.

  static async getShortDataByID(TableName, ID, GlobalID) {
    const connection = await mysql.connection();
    try {
      console.log(
        "Calling Function for Table " +
          TableName +
          "to get one row of  data from one Table"
      );
      // Create a response object. response.data
      let response = { data: null, success: null };

      // Call getShortQueryByID function to build the query
      let qry = this.getShortQueryByID(TableName, ID, GlobalID);
      let data = await connection.query(qry);

      // Note here we are trying to assign first row of response. as we are interested in only one row.
      response.result = data[0];
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at getShortQueryByID", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  // This function is used to get one row of Data by Primary Key from a table which has a global Key
  // Example in School Project SchoolID is Global key as each table all data for a school can be queried.
  // However since current table will have Foreign Keys from Other tables. We will create a Full
  // Query for Each Foreign Key-Value by Joining with other Tables.

  // Each LoggedOnUser is not required but is kept in the query parameters

  static async getExtendedDataByID(TableName, ID, GlobalID) {
    const connection = await mysql.connection();
    try {
      console.log(
        "Calling Function for Table " +
          TableName +
          "to get all Data from multiple tables by Joining"
      );
      // Create a response object. response.data
      let response = { data: null, success: null };

      let qry = this.getExtendedQueryByID(TableName, ID, GlobalID);
      let data = await connection.query(qry);

      // Note here we are trying to assign first row of response. as we are interested in only one row.
      response.result = data[0];
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at getExtendedDataByID", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  // This function is used to get all data from a table which has a global Key but there are Paremeters that need to be passed
  // Param variable will be like {Field1: "fieldValue", Field2: "fieldValue2 ........."}
  // Each LoggedOnUser is not required but is kept in the query parameters

  static async getShortListByParem(TableName, Parem, GlobalID) {
    // first build Where Clause by iterating thru object
    let whereList = "";
    for (const [key, value] of Object.entries(JSON.parse(Parem))) {
      if (whereList !== "") {
        whereList = whereList + " and ";
      }
      whereList = whereList + " " + `${key} =  ${value}`;
    }
    const connection = await mysql.connection();
    try {
      console.log(
        "Calling Function for Table " +
          TableName +
          "to get all Data from multiple tables by Joining"
      );
      // Create a response object. response.data
      let response = { data: null, success: null };

      // call the function to build query
      let qry = this.getShortListByPare(TableName, whereList, GlobalID);
      let data = await connection.query(qry);

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  static async getExtendedListByParem(TableName, Parem, GlobalID) {
    let whereList = "";
    for (const [key, value] of Object.entries(JSON.parse(Parem))) {
      whereList = whereList + " " + `${key}: ${value}`;
    }
    const connection = await mysql.connection();
    try {
      console.log("at query login...");
      let response = { data: null, success: null };

      let qry = this.getExtendedListByParem(TableName, LoggedOnUser, GlobalID);
      let data = await connection.query(qry);

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  static async getProductSupportData(TableName, Ref, LoggedOnUser) {
    const connection = await mysql.connection();
    try {
      console.log("at query login...");
      let response = { data: null, success: null };

      let data = await connection.query(
        `select * from SpecSptTable where RefID = '${Ref}' and TableName = '${TableName}' and Status = 1`
      );

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  static async saveProductSupportData(
    TableName,
    Ref,
    SelectedValue,
    LoggedOnUser
  ) {
    const connection = await mysql.connection();
    try {
      console.log("at query login...");
      let response = { data: null, success: null };
      let data = await connection.query(
        `insert into SpecSptTable (TableName,  RefID, TableValue, Status) values ('${TableName}','${Ref}','${SelectedValue}',1)`
      );

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  static async saveData(Body, LoggedOnUser, TableName) {
    const connection = await mysql.connection();
    try {
      console.log("at query login...");
      let response = { data: null, success: null };
      let qry = this.getQuery(Body, LoggedOnUser, TableName);
      let data = await connection.query(qry);

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  static async deleteData(LoggedOnUser, TableName, id) {
    const connection = await mysql.connection();
    try {
      console.log("at query login...");
      let response = { data: null, success: null };

      let data = await connection.query(
        `update ${TableName} set Status = 0 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ID = '${ID}' `
      );

      response.result = data;
      response.success = "Success";

      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  static getQuery(Body, LoggedOnUser, TableName) {
    let qry = "";
    switch (TableName) {
      case "ProductSpec":
        if (Body.ID === null || Body.ID === undefined) {
          qry = `insert into ${TableName} (ProductName,  GlobalID, Name,  Seq,  Type,  Ref,  SptTableName, Status, CreatedBy , CreatedOn ) values ('${Body.ProductName}', '${LoggedOnUser.GlobalID}', '${Body.Name}', '${Body.Seq}', '${Body.Type}', '${Body.Ref}','${Body.SptTableName}', 1 , '${LoggedOnUser.ID}', now())`;
        } else {
          qry = `update ${TableName} set ProductName = '${Body.ProductName}' , GlobalID = '${LoggedOnUser.GlobalID}' , Name = '${Body.Name}', Seq = '${Body.Seq}' , Type = '${Body.Type}' , Ref = '${Body.Ref}' , SptTableName = '${Body.SptTableName}' ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
        }
        break;
      case "Product":
        if (Body.ID === null || Body.ID === undefined) {
          qry = `insert into ${TableName} (Name,  GlobalID, HSNCode, Status, CreatedBy , CreatedOn ) values ('${Body.Name}', '${LoggedOnUser.GlobalID}', '${Body.HSNCode}', 1 , '${LoggedOnUser.ID}', now())`;
        } else {
          qry = `update ${TableName} set Name = '${Body.Name}' , GlobalID = '${LoggedOnUser.GlobalID}' , HSNCode = '${Body.HSNCode}' ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
        }
        break;

      case "User":
        if (Body.ID === null || Body.ID === undefined) {
          qry = `insert into ${TableName} (GlobalID,  Name,  UserGroup,  DOB,  Anniversary,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  Branch,  PhotoURL,  LoginName,  Password, Status, CreatedBy , CreatedOn ) values ('${LoggedOnUser.GlobalID}', '${Body.UserName}', '${Body.UserGroup}', '${Body.DOB}', '${Body.Anniversary}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.Branch}','${Body.PhotoURL}','${Body.LoginName}','${Body.Password}', 1 , '${LoggedOnUser.ID}', now())`;
        } else {
          qry = `update ${TableName} set GlobalID = '${Body.GlobalID}' , Name = '${Body.Name}' , UserGroup = '${Body.UserGroup}' , DOB = '${Body.DOB}' , Anniversary = '${Body.Anniversary}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Branch = '${Body.Branch}' , PhotoURL = '${Body.PhotoURL}' , LoginName = '${Body.LoginName}' , Password = '${Body.Password}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
        }
        break;

      case "Shop":
        if (Body.ID === null || Body.ID === undefined) {
          qry = `insert into ${TableName} (Name, GlobalID,  MobileNo1,  MobileNo2,  PhoneNo,  Address,  Email,  Website,  GSTNo,  CINNo,  LogoURL,   ShopTiming, WelcomeNote,  Status, CreatedBy , CreatedOn ) values 
                 ('${Body.Name}', '${LoggedOnUser.GlobalID}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}', '${Body.Address}', '${Body.Email}','${Body.Website}','${Body.GSTNo}','${Body.CINNo}','${Body.LogoURL}','${Body.ShopTiming}','${Body.WelcomeNote}', 1 , '${LoggedOnUser.ID}', now())`;
        } else {
          qry = `update ${TableName} set Name = '${Body.Name}' , GlobalID = '${Body.GlobalID}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Address = '${Body.Address}' , Email = '${Body.Email}' , Website = '${Body.Website}' , GSTNo = '${Body.GSTNo}' , CINNo = '${Body.CINNo}' , LogoURL = '${Body.LogoURL}' , ShopTiming = '${Body.ShopTiming}' , WelcomeNote = '${Body.WelcomeNote}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
        }
        break;
      case "Role":
        qry = `insert into ${TableName} (Name, GlobalID, Status, CreatedBy , CreatedOn ) values 
                 ('${Body.Name}', '${LoggedOnUser.GlobalID}', 1 , '${LoggedOnUser.ID}', now())`;
        break;

      case "Supplier":
        if (Body.ID === null || Body.ID === undefined) {
          qry = `insert into ${TableName} (GlobalID,  Name, DOB,  Anniversary,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  Website,  PhotoURL,  CINNO, GSTNo,  Fax, ContactPerson, Remark,  Status, CreatedBy , CreatedOn ) values ('${LoggedOnUser.GlobalID}', '${Body.Name}', '${Body.DOB}', '${Body.Anniversary}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.Website}','${Body.PhotoURL}','${Body.CINNo}','${Body.GSTNo}','${Body.Fax}','${Body.ContactPerson}','${Body.Remark}', 1 , '${LoggedOnUser.ID}', now())`;
        } else {
          qry = `update ${TableName} set GlobalID = '${Body.GlobalID}' , Name = '${Body.Name}' ,  DOB = '${Body.DOB}' , Anniversary = '${Body.Anniversary}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Website = '${Body.website}' , PhotoURL = '${Body.PhotoURL}' , CINNo = '${Body.CINNo}' , GSTNo = '${Body.GSTNo}', Fax = '${Body.Fax}', ContactPerson = '${Body.ContactPerson}', Remark = '${Body.Remark}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
        }
        break;
    }
    return qry;
  }

  static getShortQuery(TableName, LoggedOnUser, GlobalID) {
    let qry = `select * from  ${TableName} where Status = 1 and GlobalID = '${GlobalID}' Order By ID Desc`;
    return qry;
  }

  static getExtendedQuery(TableName, LoggedOnUser, GlobalID) {
    let qry = "";
    switch (TableName) {
      case "PurchaseMaster":
        qry = `Select PurchaseMaster.*, Shop.Name as ShopName, Supplier.Name as SupplierName from PurchaseMaster Left Join Shop on PurchaseMaster.ShopID = Shop.ID inner join Supplier on Supplier.ID = PurchaseMaster.SupplierID Where PurchaseMaster.Status = 1 and PurchaseMaster.GlobalID = '${GlobalID}' Order By PurchaseMaster.ID`;
        break;
    }
    return qry;
  }

  static getShortQueryByID(TableName, ID, GlobalID) {
    let qry = `select * from  ${TableName} where Status = 1 and GlobalID = '${GlobalID}' and ID = '${ID}'`;
    return qry;
  }

  static getExtendedQueryByID(TableName, ID, GlobalID) {
    let qry = "";
    switch (TableName) {
      case "PurchaseMaster":
        qry = `Select *, Shop.Name as ShopName, Supplier.Name as SupplierName from PurchaseMaster Inner Join Shop on PurchaseMaster.ShopID = Shop.ID inner join Supplier on Supplier.ID = PurchaseMaster.SupplierID Where PurchaseMaster.Status = 1 and PurchaseMaster.GlobalID = '${GlobalID}' and PurchaseMaster.ID = '${ID}'`;
        break;
    }
    return qry;
  }

  static getShortListByPare(TableName, Parem, GlobalID) {
    let qry = "";
    switch (TableName) {
      case "PurchaseDetail":
        qry =
          `select * from  ${TableName} where Status = 1 and GlobalID = '${GlobalID}' and ` +
          Parem;
        break;
    }
    return qry;
  }
}
module.exports = companyService;
