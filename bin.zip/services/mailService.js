"use strict";
const nodemailer = require("nodemailer");
var moment = require("moment");

class mailService {
    // async..await is not allowed in global scope, must use a wrapper
    static async sendMail(html, email, mycompany, myshop) {
        // Generate test SMTP service account from ethereal.email
        // Only needed if you don't have a real mail account for testing
        let testAccount = await nodemailer.createTestAccount();

        // create reusable transporter object using the default SMTP transport
        let transporter = nodemailer.createTransport({
            // host: "smtp.gmail.com",
            // port: 587,
            // secure: false, // true for 465, false for other ports
            service: 'Gmail',
            auth: {
                user: 'relinksyspvtltd@gmail.com',
                pass: 'relinksys@123'
            },
        });

        let toEmail = "vinayk.vk868@gmail.com, " + email;
        let sub =
            "Order from " + mycompany.Name + " On Date " + moment().format("ll");
        // send mail with defined transport object
        let info = await transporter.sendMail({
            from: '"Avinash Navient" <otpgnavient@gmail.com>', // sender address
            to: toEmail, // list of receivers
            cc: myshop.Email,
            subject: sub, // Subject line
            text: "", // plain text body
            html: html, // html body
        });

        console.log("Message sent: %s", info.messageId);
        // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
        return info;
        // Preview only available when sending through an Ethereal account
        console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
        // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
    }


    //  for content mail 


}
module.exports = mailService;