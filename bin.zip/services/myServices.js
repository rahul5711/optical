const db = require("../db");
const jwt = require("jsonwebtoken");
class MyService {
  static getUsers() {
    let connection;
    return new Promise((resolve, reject) => {
      db.getConnection()
        .then((conn) => {
          connection = conn;
          return db.beginTransaction(connection);
        })
        .then(() => {
          connection.query(`select * from users`, (err, result) => {
            if (err) {
              console.log(err);
              db.rollbackTransaction(connection);
              db.releaseConnection(connection);
              return reject(err);
            } else {
              db.commitTransaction(connection);
              db.releaseConnection(connection);
              return resolve(result);
            }
          });
        })
        .catch((err) => {
          console.log(err, "Error");
        });
    });
  }

  static getUsersByid(id) {
    console.log(id);
    let connection;
    return new Promise((resolve, reject) => {
      db.getConnection()
        .then((conn) => {
          connection = conn;
          return db.beginTransaction(connection);
        })
        .then(() => {
          connection.query(
            `select * from users where id = ${id} `,
            (err, result) => {
              if (err) {
                console.log(err);
                db.rollbackTransaction(connection);
                db.releaseConnection(connection);
                return reject(err);
              } else {
                db.commitTransaction(connection);
                db.releaseConnection(connection);
                return resolve(result);
              }
            }
          );
        })
        .catch((err) => {
          console.log(err, "Error");
        });
    });
  }

  static deleteUserByid(id) {
    console.log(id);
    let connection;
    return new Promise((resolve, reject) => {
      db.getConnection()
        .then((conn) => {
          connection = conn;
          return db.beginTransaction(connection);
        })
        .then(() => {
          connection.query(
            `delete from users where id = ${id} `,
            (err, result) => {
              if (err) {
                console.log(err);
                db.rollbackTransaction(connection);
                db.releaseConnection(connection);
                return reject(err);
              } else {
                db.commitTransaction(connection);
                db.releaseConnection(connection);
                return resolve(result);
              }
            }
          );
        })
        .catch((err) => {
          console.log(err, "Error");
        });
    });
  }

  static usersave(data) {
    console.log(data.Name, "name");
    let connection;
    return new Promise((resolve, reject) => {
      db.getConnection()
        .then((conn) => {
          connection = conn;
          return db.beginTransaction(connection);
        })
        .then(() => {
          connection.query(
            `insert into users(Name , Email , Password) values ('${data.Name}' , '${data.Email}' , '${data.Password}')`,
            (err, result) => {
              if (err) {
                console.log(err);
                db.rollbackTransaction(connection);
                db.releaseConnection(connection);
                return reject(err);
              } else {
                db.commitTransaction(connection);
                db.releaseConnection(connection);
                return resolve(result);
              }
            }
          );
        })
        .catch((err) => {
          console.log(err, "Error");
        });
    });
  }

  static login(data) {
    console.log(data.Username, "name");
    let connection;
    return new Promise((resolve, reject) => {
      db.getConnection()
        .then((conn) => {
          connection = conn;
          return db.beginTransaction(connection);
        })
        .then(() => {
          connection.query(
            `select * from users where Name = '${data.Username}' and Password = '${data.Password}'`,
            (err, result) => {
              if (err) {
                console.log(err);
                db.rollbackTransaction(connection);
                db.releaseConnection(connection);
                return reject(err);
              } else {
                db.commitTransaction(connection);
                db.releaseConnection(connection);
                return resolve(result);
              }
            }
          );
        })
        .catch((err) => {
          console.log(err, "Error");
        });
    });
  }

  static async getdata() {
    try {
      const data = await this.getUsers();
      const userbyid = await this.getUsersByid(data[1].id);
      console.log(data, "data");
      console.log(userbyid, "userbyid");
      return userbyid;
    } catch (error) {
      console.log(error);
    }
  }
}
module.exports = MyService;
