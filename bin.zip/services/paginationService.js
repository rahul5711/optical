const mysql = require("../newdb.js");
var moment = require("moment");
const e = require("express");

class paginationService {

    static getQuery(CompanyID,LoggedOnUser, ShopID, TableName , whereList,Supplierid) { 
        let qry = "";
        switch (TableName) {
            case "CustomerFullList":
                qry = `SELECT Customer.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser,Shop.Name AS ShopName , Shop.AreaName AS AreaName FROM Customer LEFT JOIN User ON User.ID = Customer.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Customer.UpdatedBy LEFT JOIN Shop ON Shop.ID = Customer.ID WHERE  Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1 ORDER BY Customer.ID DESC `;
            break;
            case "BillMaster":
                qry =
                    `SELECT BillMaster.*, Customer.Name AS CustomerName, Customer1.MobileNo1 AS CustomerMob,Customer1.Sno AS Sno,Customer1.Idd AS Idd, Shop.Name AS ShopName, Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID LEFT JOIN User ON User.ID = BillMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = BillMaster.UpdatedBy LEFT JOIN Customer AS Customer1 ON Customer1.ID = BillMaster.CustomerID WHERE  BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 1  and `
                    + whereList + 
                    ` Order By BillMaster.ID Desc `;
                break;

                case "SupplierfullList":
                    qry = `SELECT Supplier.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM Supplier  LEFT JOIN User ON User.ID = Supplier.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Supplier.UpdatedBy  WHERE  Supplier.CompanyID  = '${CompanyID}' AND Supplier.Status = 1 ORDER BY Supplier.ID DESC `;
                    break;

                    case "PreorderfullList":
                        qry = `SELECT DISTINCT(PurchaseDetail.ProductName),PurchaseDetail.ID, PurchaseDetail.Checked, PurchaseDetail.ProductTypeName, BarcodeMaster.Barcode AS BarCode, u.Name AS CreatedPerson, PurchaseDetail.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID LEFT JOIN User AS u ON u.ID = PurchaseDetail.CreatedBy WHERE BarcodeMaster.CurrentStatus = 'Pre Order' AND PurchaseDetail.ProductName !='' AND PurchaseDetail.ProductTypeName != '' AND PurchaseDetail.CompanyID  = '${CompanyID}' and BarcodeMaster.Status = 1 and PurchaseDetail.Status = 1 ORDER BY PurchaseDetail.ID DESC `;
                        break;
                        

                        case "DoctorFullList":
                            qry = ` SELECT Doctor.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                                FROM Doctor             
                                LEFT JOIN User ON User.ID = Doctor.CreatedBy 
                                LEFT JOIN User AS User1 ON User1.ID = Doctor.UpdatedBy 
                                WHERE  Doctor.CompanyID  = '${CompanyID}' AND Doctor.Status = 1 ORDER BY Doctor.ID DESC `;
                            break;

                case "PurchaseMaster":
                    if (LoggedOnUser.UserGroup !== 'CompanyAdmin') {
                        qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMaster LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE  PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}'  ORDER BY PurchaseMaster.ID DESC `;
                    } else {
                        qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMaster  LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE  PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' ORDER BY PurchaseMaster.ID DESC `;
                    }
                    break;
                    case "PurchaseMasterSupplier":
                        qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName, Supplier.Name AS SupplierName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMaster 
                            LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID 
                            LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID 
                            WHERE PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.SupplierID = ${Supplierid} ORDER BY PurchaseMaster.ID DESC `;
                        break;

                        case "PurchaseMasterPo":
                            if (LoggedOnUser.UserGroup !== 'CompanyAdmin') {
                                qry = `SELECT PurchaseMasterPo.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, PurchaseMasterPo.SupplierName as Sname, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMasterPo LEFT JOIN User ON User.ID = PurchaseMasterPo.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMasterPo.UpdatedBy LEFT JOIN Shop ON PurchaseMasterPo.ShopID = Shop.ID LEFT JOIN Supplier ON Supplier.ID = PurchaseMasterPo.SupplierID WHERE  PurchaseMasterPo.Status = 1 AND PurchaseMasterPo.CompanyID = '${CompanyID}' AND PurchaseMasterPo.ShopID = '${ShopID}'  ORDER BY PurchaseMasterPo.ID DESC `;
                            } else {
                                qry = `SELECT PurchaseMasterPo.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName,PurchaseMasterPo.SupplierName as Sname, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMasterPo  LEFT JOIN User ON User.ID = PurchaseMasterPo.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMasterPo.UpdatedBy LEFT JOIN Shop ON PurchaseMasterPO.ShopID = Shop.ID LEFT JOIN Supplier ON Supplier.ID = PurchaseMasterPo.SupplierID WHERE  PurchaseMasterPo.Status = 1 AND PurchaseMasterPO.CompanyID = '${CompanyID}' ORDER BY PurchaseMasterPO.ID DESC `;
                            }
        }

        return qry;

    }
  

    static getSearchQuery(CompanyID,LoggedOnUser, ShopID, TableName , whereList,Supplierid,searchQuery) { 
        let qry = "";
        switch (TableName) {
            case "CustomerFullList":
                qry = `SELECT Customer.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser,Shop.Name AS ShopName , Shop.AreaName AS AreaName FROM Customer LEFT JOIN User ON User.ID = Customer.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Customer.UpdatedBy LEFT JOIN Shop ON Shop.ID = Customer.ID WHERE
                 Customer.Name like '${searchQuery}%' and Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1 
                 OR Customer.MobileNo1 like '${searchQuery}%' and Customer.CompanyID  = '${CompanyID}' AND Customer.Status = 1 
                 OR Customer.Idd like '${searchQuery}%' and Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1 
                   OR Customer.Sno like '${searchQuery}%' and Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1  `;
            break;
            case "BillMaster":
                qry =
                    `SELECT BillMaster.*, Customer.Name AS CustomerName, Customer1.MobileNo1 AS CustomerMob,Customer1.Sno AS Sno,Customer1.Idd AS Idd, Shop.Name AS ShopName, Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID LEFT JOIN User ON User.ID = BillMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = BillMaster.UpdatedBy LEFT JOIN Customer AS Customer1 ON Customer1.ID = BillMaster.CustomerID WHERE 
                     BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 1 and Customer.Name like '${searchQuery}%' and  ${whereList} OR 
                     BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 1 and  Customer.MobileNo1 like '${searchQuery}%' and  ${whereList} OR BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 1 and BillMaster.InvoiceNo like '${searchQuery}%' and  ${whereList} OR BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 1 and Customer.Idd like '${searchQuery}%' and  ${whereList} OR
                      BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 1 and Customer.Sno like '${searchQuery}%' AND `
                     + whereList +
                    `  `;
                break;

                case "SupplierfullList":
                    qry = `SELECT Supplier.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM Supplier  LEFT JOIN User ON User.ID = Supplier.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Supplier.UpdatedBy  WHERE  Supplier.CompanyID  = '${CompanyID}' AND Supplier.Status = 1 ORDER BY Supplier.ID DESC `;
                    break;
                    case "PreorderfullList":
                        qry = `SELECT DISTINCT(PurchaseDetail.ProductName),PurchaseDetail.ID, PurchaseDetail.Checked, PurchaseDetail.ProductTypeName, BarcodeMaster.Barcode AS BarCode, u.Name AS CreatedPerson, PurchaseDetail.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID LEFT JOIN User AS u ON u.ID = PurchaseDetail.CreatedBy WHERE BarcodeMaster.CurrentStatus = 'Pre Order' AND PurchaseDetail.ProductName !='' AND PurchaseDetail.ProductTypeName != '' AND PurchaseDetail.CompanyID  = '${CompanyID}' and BarcodeMaster.Status = 1 and PurchaseDetail.Status = 1 ORDER BY PurchaseDetail.ID DESC `;
                        break;
                        case "DoctorFullList":
                            qry = ` SELECT Doctor.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                                FROM Doctor             
                                LEFT JOIN User ON User.ID = Doctor.CreatedBy 
                                LEFT JOIN User AS User1 ON User1.ID = Doctor.UpdatedBy 
                                WHERE  Doctor.CompanyID  = '${CompanyID}' AND Doctor.Status = 1 ORDER BY Doctor.ID DESC `;
                            break;

                case "PurchaseMaster":
                    if (LoggedOnUser.UserGroup !== 'CompanyAdmin') {
                        qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMaster LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE  PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and Supplier.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and User.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and User1.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and  Shop.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and PurchaseMaster.InvoiceNo like '${searchQuery}%' OR PurchaseMaster.PaymentStatus like '${searchQuery}%'   `;
                    } else {
                        qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMaster  LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE  PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' and Supplier.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and User.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and  User1.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and  Shop.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and PurchaseMaster.InvoiceNo like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}' and PurchaseMaster.PaymentStatus like '${searchQuery}%' ORDER BY PurchaseMaster.ID DESC `;
                    }
                    break;
                    case "PurchaseMasterSupplier":
                        qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName, Supplier.Name AS SupplierName,User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMaster 
                            LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID 
                            WHERE PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}'  and  PurchaseMaster.SupplierID = ${Supplierid} and Supplier.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}'  and  PurchaseMaster.SupplierID = ${Supplierid} and User1.Name like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}'  and  PurchaseMaster.SupplierID = ${Supplierid} and Shop.Name like '${searchQuery}%' OR  PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}'  and  PurchaseMaster.SupplierID = ${Supplierid} and PurchaseMaster.InvoiceNo like '${searchQuery}%' OR PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}'  and  PurchaseMaster.SupplierID = ${Supplierid} and  PurchaseMaster.PaymentStatus like '${searchQuery}%'  `;
                        break;
        }

        return qry;

    }
 
    static async getListData(TableName,CompanyID, LoggedOnUser, ShopID, Body) {

        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };
            
            let whereList = "";
            let Objects = Body.params;
            let Supplierid = Body.SupplierID ? Body.SupplierID : 0;

            console.log(Objects,'Objects');
            if (Objects !== null && Objects !== undefined ) {
                
                let p = Object.entries(Objects);
                for (const [key, value] of p) {
                    if (whereList !== "") {
                        whereList = whereList + " and ";
                    }
                    whereList = whereList + " " + `${key} =  ${value}`;
                }
            }
            
            console.log(whereList , 'fdfdfdfdfdfd');


            let qry = this.getQuery(CompanyID,LoggedOnUser, ShopID,TableName , whereList,Supplierid);

            let page = Body.currentPage;
            let limit = Body.itemsPerPage;
            let skip = page * limit - limit;

            let skipQuery = `LIMIT  ${limit} OFFSET ${skip}`

            let finalQuery = qry + skipQuery;

            let data = await connection.query(finalQuery);
            let count = await connection.query(qry);

            response.result = data;
            response.count = count.length;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async getsearchListData(TableName,CompanyID, LoggedOnUser, ShopID, Body) {

        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };
            let searchQuery = Body.searchQuery ? Body.searchQuery : ''
            let whereList = "";
            let Objects = Body.params;
            let Supplierid = Body.SupplierID ? Body.SupplierID : 0;

            if (Objects !== null && Objects !== undefined ) {
                
                let p = Object.entries(Objects);
                for (const [key, value] of p) {
                    if (whereList !== "") {
                        whereList = whereList + " and ";
                    }
                    whereList = whereList + " " + `${key} =  ${value}`;
                }
            }
            


            let qry = this.getSearchQuery(CompanyID,LoggedOnUser, ShopID,TableName , whereList,Supplierid,searchQuery);

            let page = Body.currentPage;
            let limit = Body.itemsPerPage;
            let skip = page * limit - limit;

            let skipQuery = `LIMIT  ${limit} OFFSET ${skip}`

            let finalQuery = qry + skipQuery;

            console.log(finalQuery);
            let data = await connection.query(finalQuery);
            let count = await connection.query(qry);

            response.result = data;
            response.count = count.length;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getPreOrderStatus(Mode, LoggedOnUser, CompanyID, ShopID, dtm) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qstring = "";
            let where = JSON.parse(dtm)
            let page = where.currentPage;
            let limit = where.itemsPerPage;
            let skip = page * limit - limit;
            let shop2 = where.shop
            let condition = where.where
            console.log(shop2 , 'shop2');
            let skipQuery = ` `

            let shop = ` `
            if (LoggedOnUser.UserGroup === 'CompanyAdmin' && shop2 !== 'Other' && shop2 !== 'Main') {
                shop = ` `
            } else if(shop2 !== 'Other' && shop2 !== 'Main') {
                shop =  ` and BarcodeMaster.ShopID = '${ShopID}'`  
            } else if(shop2 === 'Other') {
                shop =  ` BarcodeMaster.ShopID != '43' and`
            }else if(shop2 === 'Main') {
                shop =  ` BarcodeMaster.ShopID = '43' and`
            }
            if (condition === '') {
                skipQuery =   `LIMIT  ${limit} OFFSET ${skip}`

            }else{
                skipQuery = ` `;
            }
            console.log(skipQuery,'skipQuery');
            switch (Mode) {
                case "Unassigned":
                    qstring =
                        "BarcodeMaster.Po = '1' and BarcodeMaster.SupplierID = 0 AND BarcodeMaster.CurrentStatus = 'Pre Order'";
                    break;
                case "Assigned":
                    qstring =
                        "BarcodeMaster.Po = '2' OR BarcodeMaster.Po = '1' AND BarcodeMaster.CurrentStatus = 'Sold' OR BarcodeMaster.CurrentStatus = 'Pre Order' AND BarcodeMaster.SupplierID <> 0 and BarcodeMaster.Po != '0' and BarcodeMaster.Po != '3'";
                    break;
                case "QC Checked":
                    qstring = " BarcodeMaster.Po = 3 AND BarcodeMaster.CurrentStatus = 'Sold'";
                    break;
            }

            let qry = `SELECT 0 as Sel , COUNT(*) AS Qty, BarcodeMaster.*, Supplier.Name AS SupplierName, Fitter.Name as FitterName, Shop.Name as ShopName,Shop.AreaName as AreaName, BillDetail.ProductName, Customer.Name AS CustomerName, Customer.Idd AS CustIdd, Customer.Sno AS CustSn, Customer.MobileNo1 AS MobileNo, BillMaster.InvoiceNo, BillMaster.DeliveryDate,BillMaster.BillDate, User.Name as UpdatePerson, PurchaseDetail.ProductTypeName, PurchaseDetail.ProductTypeID, PurchaseDetail.UnitPrice AS PurchaseRate, PurchaseDetail.GSTPercentage, PurchaseDetail.GSTAmount, PurchaseDetail.GSTType,PurchaseDetail.Quantity  FROM BarcodeMaster LEFT JOIN Supplier ON Supplier.ID = BarcodeMaster.SupplierID Left Join PurchaseDetail on PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID Left Join BillDetail on BillDetail.ID = BarcodeMaster.BillDetailID Left Join BillMaster on BillMaster.ID = BillDetail.BillID Left Join Customer on Customer.ID = BillMaster.CustomerID Left Join Shop on Shop.ID = BarcodeMaster.ShopID Left Join Fitter on Fitter.ID = BarcodeMaster.FitterID left join User on User.ID = BarcodeMaster.UpdatedBy GROUP BY BarcodeMaster.BillDetailID  having    ${qstring} and BarcodeMaster.CompanyID = '${CompanyID}'   and ${shop} BarcodeMaster.BillDetailID != "null"  ${condition} Order By BarcodeMaster.ID Desc `;
            

            let finalQuery = qry + skipQuery;
            console.log(qry);

            let data = await connection.query(finalQuery);
            let count = await connection.query(qry);

            let productPre = await connection.query(`SELECT DISTINCT(PurchaseDetail.ProductName),PurchaseDetail.ID, PurchaseDetail.Checked, PurchaseDetail.ProductTypeName, BarcodeMaster.Barcode AS BarCode, u.Name AS CreatedPerson, PurchaseDetail.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID LEFT JOIN User AS u ON u.ID = PurchaseDetail.CreatedBy WHERE PurchaseDetail.CompanyID  = '${CompanyID}' and BarcodeMaster.Status = 1 and BarcodeMaster.CurrentStatus = 'Pre Order' AND PurchaseDetail.ProductName !='' AND PurchaseDetail.ProductTypeName != '' AND  PurchaseDetail.Status = 1 ORDER BY PurchaseDetail.ID DESC `);

            if (data.length !== 0) {
                
            data.forEach(element => {
   
                productPre.forEach(e => {
                    if (e.BarCode === element.Barcode) {
                      element.UnitPrice = e.UnitPrice;
                      element.GSTPercentage = e.GSTPercentage;
                      element.DiscountAmount = e.DiscountAmount;
                      element.GSTType = e.GSTType;
                     
                    }
          
                  })
                  element.GSTAmount = (+element.UnitPrice * +element.Qty - (element.DiscountAmount ? element.DiscountAmount : 0)) * +element.GSTPercentage / 100;
                  element.TotalAmount = (+element.UnitPrice * +element.Qty - (element.DiscountAmount ? element.DiscountAmount : 0)) + +element.GSTAmount;
              });
            }


            response.result = data;
            response.count = count.length;

           

            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

}

module.exports = paginationService;