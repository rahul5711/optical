const mysql = require("../newdb.js");
class adminService {
    static async getAllData(TableName) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getsupportMasterList(TableName, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from SupportMaster where TableName = '${TableName}' and Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async getProductAssignList(TableName, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `SELECT Company.Name, DATE_FORMAT(Product.CreatedOn , '%W %D %M %Y') AS CreatedOn, 'Product Assign By Admin' AS CreatedBy  FROM Product 
                LEFT JOIN Company ON Company.ID = Product.CompanyID
                WHERE Product.CompanyID = '${TableName}' AND Product.CreatedBy = 0 ORDER BY Product.ID DESC LIMIT 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getCompanyList(TableName) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getShortListQuery1(TableName);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getAllDataByID(TableName, ID) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where CompanyID =  ${ID} and Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getAllDataByParem(TableName, Parem) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where ${Parem} and Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getSupportData(TableName, Parem) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where TableName = '${Parem}' and Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getfilterList(TableName, Parem) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };
            let data = await connection.query(`SELECT Company.*, User.Name AS OwnerName, User.DOB, User.Anniversary FROM Company  LEFT JOIN User ON User.CompanyID = Company.ID  WHERE User.UserGroup = 'CompanyAdmin' And  Company.Status = 1` + Parem + " order by ID Desc");

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getLoginHistory(TableName, Parem) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };
            let data = await connection.query(`SELECT LoginHistory.*, Company.Name AS CompanyName FROM LoginHistory LEFT JOIN Company ON Company.ID = LoginHistory.CompanyID WHERE LoginHistory.Status = 1` + Parem + " order by LoginHistory.ID Desc");

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getShortListByCompany(
        TableName,
        LoggedOnUser,

        DelMode
    ) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getShortQuery(TableName, LoggedOnUser, DelMode);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }




    static async getDataByID(TableName, ID) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where ID = ${ID} and Status = 1`
            );

            response.result = data[0];
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getOwnerDataByID(TableName, ID) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where CompanyID = ${ID} and UserGroup = 'CompanyAdmin' and Status = 1`
            );

            response.result = data[0];
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async deleteData(LoggedOnUser, TableName, id) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let data = await connection.query(
                `update ${TableName} set Status = 0 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ID = '${ID}' `
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async saveData(Body, LoggedOnUser, TableName) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };

            let qry = this.getQuery(Body, LoggedOnUser, TableName);

            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async assignProduct(Body, LoggedOnUser, TableName) {
        const connection = await mysql.connection();
        try {
            console.log("at query login...");
            let response = { data: null, success: null };
            let adminProduct = await connection.query(`select * from Product where CompanyID = '0' and Status = 1`);

            if (adminProduct.length !== 0) {
                for (const el of adminProduct) {
                    let companyproduct = await connection.query(`select * from Product where Name = '${el.Name}' and HSNCode = '${el.HSNCode}' and CompanyID = '${Body.companyid}' and Status = 1`);
                    if (companyproduct.length === 0) {
                        let insertproduct = await connection.query(`insert into Product (Name,  CompanyID, HSNCode, Status, CreatedBy , CreatedOn ) values ('${el.Name}', '${Body.companyid}', '${el.HSNCode}', 1 , '0', now())`);
                    }
                }
            }

            let adminSpec = await connection.query(`select * from ProductSpec where CompanyID = '0' and Status = 1`);
            
            if (adminSpec.length !== 0) {
                for (const e of adminSpec) {
                  let companyspec =   await connection.query(`select * from ProductSpec where Status = 1 and CompanyID = '${Body.companyid}' and ProductName = '${e.ProductName}' and  Name = '${e.Name}' and Seq = '${e.Seq}'`);

                  if (companyspec.length === 0) {
                      let sptTableName = '';
                      if (e.Type === 'DropDown') {
                          sptTableName = e.SptTableName + Body.companyid;
                          console.log(sptTableName , 'sptTableNamesptTableName');

                      }
                      let insertspect = await connection.query(`insert into ProductSpec (ProductName,  CompanyID, Name, Required, Seq,  Type,  Ref,  SptTableName, Status, CreatedBy , CreatedOn ) values ('${e.ProductName}', '${Body.companyid}', '${e.Name}', ${e.Required}, '${e.Seq}', '${e.Type}', '${e.Ref}','${sptTableName}', 1 , '0', now())`) 
                  }
                }
            }

            // response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getDataByName(TableName, Name, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where ProductName = '${Name}' and Status = 1 and CompanyID = 0`
            );
            console.log(TableName, Name, data, "msgdede")
            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async deleteData1(LoggedOnUser, TableName, ID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data = await connection.query(
                `update ${TableName} set Status = 0 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ID = '${ID}' `
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }



    static getQuery(Body, LoggedOnUser, TableName) {
        let qry = "";
        switch (TableName) {
            case "Company":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Name,  MobileNo1,  MobileNo2,  PhoneNo,  Address, Country, State, City,  Email,  Website,  GSTNo,  CINNo,  LogoURL,  Remark,  Plan, Version, NoOfShops,  EffectiveDate,  CancellationDate, EmailMsg, WhatsappMsg, WholeSale,RetailPrice,  Status, CreatedBy , CreatedOn ) values ('${Body.CompanyName}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}', '${Body.Address}', '${Body.Country}', '${Body.State}', '${Body.City}', '${Body.Email}','${Body.Website}','${Body.GSTNo}','${Body.CINNo}','${Body.LogoURL}','${Body.Remark}','${Body.Plan}','${Body.Version}','${Body.NoOfShops}', '${Body.EffectiveDate}', '${Body.CancellationDate}', '${Body.EmailMsg}',  '${Body.WhatsappMsg}','${Body.WholeSale}', '${Body.RetailPrice}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set Name = '${Body.CompanyName}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Address = '${Body.Address}' , Country = '${Body.Country}' ,State = '${Body.State}' ,City = '${Body.City}' , Email = '${Body.Email}' , Website = '${Body.Website}' , GSTNo = '${Body.GSTNo}' , CINNo = '${Body.CINNo}' , LogoURL = '${Body.LogoURL}' , Remark = '${Body.Remark}' , Plan = '${Body.Plan}' ,  Version = '${Body.Version}' , NoOfShops = '${Body.NoOfShops}' , EffectiveDate = '${Body.EffectiveDate}' , CancellationDate = '${Body.CancellationDate}' , EmailMsg = '${Body.EmailMsg}' , WhatsappMsg = '${Body.WhatsappMsg}',WholeSale = '${Body.WholeSale}', RetailPrice = '${Body.RetailPrice}'  ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "Product":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Name,  CompanyID, HSNCode, Status, CreatedBy , CreatedOn ) values ('${Body.Name}', '${Body.CompanyID}', '${Body.HSNCode}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set Name = '${Body.Name}' , CompanyID = '${Body.CompanyID}' , HSNCode = '${Body.HSNCode}' ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "CompanySetting":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  CompanyLanguage, CompanyCurrency,  CurrencyFormat,  DateFormat,  CompanyTagline,  BillHeader,  BillFooter,  RewardsPointValidity,  EmailReport,  MessageReport,  LogoURL, Status, CreatedBy , CreatedOn) values ('${Body.CompanyID}', '${Body.CompanyLanguage}', '${Body.CompanyCurrency}', '${Body.CurrencyFormat}', '${Body.DateFormat}', '${Body.CompanyTagline}','${Body.BillHeader}','${Body.BillFooter}','${Body.RewardsPointValidity}','${Body.EmailReport}','${Body.MessageReport}','${Body.LogoURL}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , CompanyLanguage = '${Body.CompanyLanguage}' , CompanyCurrency = '${Body.CompanyCurrency}', CurrencyFormat = '${Body.CurrencyFormat}' , DateFormat = '${Body.DateFormat}' , CompanyTagline = '${Body.CompanyTagline}' , BillHeader = '${Body.BillHeader}' , BillFooter = '${Body.BillFooter}' , RewardsPointValidity = '${Body.RewardsPointValidity}' , EmailReport = '${Body.EmailReport}' , MessageReport = '${Body.MessageReport}' , LogoURL = '${Body.LogoURL}' ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}', CommissionType = '${Body.CommissionType}' ,CommissionMode = '${Body.CommissionMode}', CommissionValue = '${Body.CommissionValue}' where ID = ${Body.ID}`;
                }
                break;
            case "User":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  Name,  UserGroup,  DOB,  Anniversary,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  Branch,  PhotoURL, Document,  LoginName,  Password, Status, CreatedBy , CreatedOn, CommissionType, CommissionMode, CommissionValue, CommissionValueNB ) values ('${Body.CompanyID}', '${Body.Name}', '${Body.UserGroup}', '${Body.DOB}', '${Body.Anniversary}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.Branch}','${Body.PhotoURL}','${Body.Document}','${Body.LoginName}','${Body.Password}', 1 , '${LoggedOnUser.ID}', now(), '${Body.CommissionType}', '${Body.CommissionMode}', '${Body.CommissionValue}', '${Body.CommissionValueNB}')`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , Name = '${Body.Name}' , UserGroup = '${Body.UserGroup}' , DOB = '${Body.DOB}' , Anniversary = '${Body.Anniversary}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Branch = '${Body.Branch}' , PhotoURL = '${Body.PhotoURL}' , Document = '${Body.Document}' , LoginName = '${Body.LoginName}' , Password = '${Body.Password}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}', CommissionType = '${Body.CommissionType}' ,CommissionMode = '${Body.CommissionMode}', CommissionValue = '${Body.CommissionValue}', CommissionValueNB = '${Body.CommissionValueNB} ' where ID = ${Body.ID}`;
                }
                break;
            case "UserShop":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (UserID,  ShopID,  RoleID, Status, CreatedBy , CreatedOn ) values ('${Body.UserID}', '${Body.ShopID}', '${Body.RoleID}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set UserID = '${Body.UserID}' , ShopID = '${Body.ShopID}' , RoleID = '${Body.RoleID}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;
            case "Doctor":
                var loginPermission = Number(Body.LoginPermission);
                if (Body.ID === null || Body.ID === undefined && Body.Name !== null) {
                    qry = `insert into ${TableName} (CompanyID,  Name,  Designation,  Qualification,  HospitalName,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  Branch, Landmark, PhotoURL, DoctorType, DoctorLoyalty, LoyaltyPerPatient, LoginPermission, LoginName,  Password, Status, CreatedBy , CreatedOn, CommissionType, CommissionMode, CommissionValue, CommissionValueNB, DOB, Anniversary  ) values ('${Body.CompanyID}', '${Body.Name}', '${Body.Designation}', '${Body.Qualification}', '${Body.HospitalName}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.Branch}', '${Body.Landmark}','${Body.PhotoURL}', '${Body.DoctorType}', '${Body.DoctorLoyalty}', '${Body.LoyaltyPerPatient}', ${loginPermission}, '${Body.LoginName}','${Body.Password}', 1 , '${LoggedOnUser.ID}', now(), '${Body.CommissionType}', '${Body.CommissionMode}', '${Body.CommissionValue}', '${Body.CommissionValueNB}' , '${Body.DOB}' , '${Body.Anniversary}')`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}', Name = '${Body.Name}', Designation = '${Body.Designation}', Qualification = '${Body.Qualification}', HospitalName = '${Body.HospitalName}', MobileNo1 = '${Body.MobileNo1}', MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}', Email = '${Body.Email}',  Address = '${Body.Address}', Branch = '${Body.Branch}', Landmark = '${Body.Landmark}', PhotoURL = '${Body.PhotoURL}', DoctorType = '${Body.DoctorType}', DoctorLoyalty = '${Body.DoctorLoyalty}', LoyaltyPerPatient = '${Body.LoyaltyPerPatient}', LoginPermission = ${loginPermission}, LoginName = '${Body.LoginName}', Password = '${Body.Password}', Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}', CommissionType = '${Body.CommissionType}' ,CommissionMode = '${Body.CommissionMode}', CommissionValue = '${Body.CommissionValue}', CommissionValueNB = '${Body.CommissionValueNB}' , DOB = '${Body.DOB}' , Anniversary = '${Body.Anniversary}' where ID = ${Body.ID}`;
                }
                break;

            case "Payroll":
                var loginPermission = Number(Body.LoginPermission);
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  EmployeeID,  Month,  Year,  LeaveDays,  Salary, PaymentMode,  Comments,  Status, CreatedBy , CreatedOn ) values ('${Body.CompanyID}', '${Body.EmployeeID}', '${Body.Month}', '${Body.Year}', '${Body.LeaveDays}', '${Body.Salary}', '${Body.PaymentMode}', '${Body.Comments}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}', EmployeeID = '${Body.EmployeeID}', Month = '${Body.Month}', Year = '${Body.Year}', LeaveDays = '${Body.LeaveDays}', Salary = '${Body.Salary}', PaymentMode = '${Body.PaymentMode}',  Comments = '${Body.Comments}', Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;
            case "Expense":
                var loginPermission = Number(Body.LoginPermission);
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  ShopID, Name, Category, InvoiceNo, SubCategory,  Amount,  PaymentMode, CashType,  PaymentRefereceNo, Comments, ExpenseDate, Status, CreatedBy , CreatedOn ) values ('${Body.CompanyID}', '${Body.ShopID}', '${Body.Name}', '${Body.Category}', '${Body.InvoiceNo}', '${Body.SubCategory}', '${Body.Amount}', '${Body.PaymentMode}', '${Body.CashType}', '${Body.PaymentRefereceNo}','${Body.Comments}', '${Body.ExpenseDate}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}', ShopID = '${Body.ShopID}', Name = '${Body.Name}', Category = '${Body.Category}', InvoiceNo = '${Body.InvoiceNo}', SubCategory = '${Body.SubCategory}', Amount = '${Body.Amount}', PaymentMode = '${Body.PaymentMode}', CashType = '${Body.CashType}', PaymentRefereceNo = '${Body.PaymentRefereceNo}', Comments = '${Body.Comments}', ExpenseDate = '${Body.ExpenseDate}', Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "SupportMaster":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (TableName,Name, CompanyID,  Status) values ('${Body.TableName}','${Body.Name}', '${Body.CompanyID}', 1)`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}',  Name = '${Body.Name}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }

                break;

            case "ProductSpec":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (ProductName,  CompanyID, Name, Required, Seq,  Type,  Ref,  SptTableName, Status, CreatedBy , CreatedOn ) values ('${Body.ProductName}', '0', '${Body.Name}', ${Body.Required}, '${Body.Seq}', '${Body.Type}', '${Body.Ref}','${Body.SptTableName}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set ProductName = '${Body.ProductName}' , CompanyID = '0' , Name = '${Body.Name}',  Required = ${Body.Required}, Seq = '${Body.Seq}' , Type = '${Body.Type}' , Ref = '${Body.Ref}' , SptTableName = '${Body.SptTableName}' ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }


                break;

        }

        return qry;
    }

    static getShortListQuery1(TableName) {
        let qry = "";
        switch (TableName) {
            case "Company":
                qry = `SELECT Company.*, User.Name AS OwnerName FROM Company  LEFT JOIN User ON User.CompanyID = Company.ID  WHERE User.UserGroup = 'CompanyAdmin' And  Company.Status = 1 order by ID desc`
                break;

            case "Product":
                qry = `SELECT Product.*, Product.Name AS ProductName FROM Product WHERE Product.Status = 1 AND CompanyID = '0' ORDER BY ID DESC`
                break;
        }
        return qry;
    }


    static getShortQuery1(TableName, LoggedOnUser, DelMode) {
        let deleteMode = "";
        if (DelMode === "1") {
            deleteMode = " Status = 1 and ";
        }
        let qry = `select * from  ${TableName} where ${deleteMode}  CompanyID = '${CompanyID}' Order By Name ASC`;
        return qry;
    }


}
module.exports = adminService;