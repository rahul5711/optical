const mysql = require("../newdb.js");
var moment = require("moment-timezone");

class loginService {
  static async getLoginData(Body) {
    console.log(Body);
    const connection = await mysql.connection();
    try {
      let response = {
        loginUser: null,
        userCompany: null,
        userRole: null,
        loginCode: null,
      };
      let comment = "";
      let user = await connection.query(
        `select * from User where LoginName = '${Body.userEmail}' and Password = '${Body.userPassword}' and Status = 1`
      );
      if (user.length === 1) {
        response.loginUser = user[0];
        if (user[0].UserGroup !== "SuperAdmin") {
          let company = await connection.query(
            `select * from Company where ID = '${user[0].CompanyID}'`
          );
          response.userCompany = company[0];
          let setting = await connection.query(
            `select * from CompanySetting where CompanyID = '${user[0].CompanyID}'`
          );
          response.companySetting = setting[0];
          if (user[0].UserGroup === "CompanyAdmin") {
            response.loginCode = 1;
            comment = "login SuccessFully";
          } else {
            var currentTime = moment().tz("Asia/Kolkata").format("HH:mm");
            console.log(currentTime);
            if (
              currentTime >= setting[0].LoginTimeStart &&
              currentTime < setting[0].LoginTimeEnd
            ) {
              comment = "login SuccessFully";
              response.loginCode = 1;
            } else {
              comment = "User can not login during this time window";
              response.loginCode = 0;
            }
          }

          await connection.query(
            `Insert into LoginHistory (CompanyID, UserName, UserID, LoginTime, IpAddress, Comment) values (${user[0].CompanyID}, '${user[0].Name}', ${user[0].ID}, now(), '${Body.ipAddress}', '${comment}')`
          );
        } else {
          response.loginCode = 1;
        }
      }
      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }

  static async getDoctorLoginData(Body) {
    const connection = await mysql.connection();
    try {
      let response = { loginUser: null, userCompany: null, userRole: null };

      let user = await connection.query(
        `select * from Doctor where LoginName = '${Body.userEmail}' and Password = '${Body.userPassword}' AND LoginPermission = 1 and Status = 1`
      );
      if (user.length === 1) {
        response.loginUser = user[0];
        if (user[0].UserGroup !== "SuperAdmin") {
          let company = await connection.query(
            `select * from Company where ID = '${user[0].CompanyID}'`
          );
          response.userCompany = company[0];
        }
        if (user[0].UserGroup !== "SuperAdmin") {
          let setting = await connection.query(
            `select * from CompanySetting where CompanyID = '${user[0].CompanyID}'`
          );
          response.companySetting = setting[0];
        }
      }
      await connection.query("COMMIT");
      return response;
    } catch (err) {
      await connection.query("ROLLBACK");
      console.log("ROLLBACK at querySignUp", err);
      throw err;
    } finally {
      await connection.release();
    }
  }
}
module.exports = loginService;
