const mysql = require("../newdb.js");
var moment = require("moment");

class poService {
    static async savePurchase(Body, LoggedOnUser, CompanyID, Mode) {
      
        const connection = await mysql.connection();
        try {
            
            let response = { data: null, success: null };
            let purchaseMaseterData = Body.PurchaseMaster;
            let purchaseDetailData = JSON.parse(Body.PurchaseDetail);
            
            
            let pMasterID;
                let pMaster = await connection.query(
                    `insert into PurchaseMasterPo (SupplierID,SupplierName,CompanyID,ShopID,PurchaseDate,PaymentStatus,InvoiceNo, GSTNo, Quantity, SubTotal, DiscountAmount, GSTAmount, TotalAmount, DueAmount, Status,CreatedBy,CreatedOn ) values ('${purchaseMaseterData.SupplierID}','${purchaseMaseterData.SupplierName}',  '${CompanyID}', '${purchaseMaseterData.ShopID}', '${purchaseMaseterData.PurchaseDate}', 'Unpaid', '${purchaseMaseterData.InvoiceNo}', '${purchaseMaseterData.GSTNo}', '${purchaseMaseterData.Quantity}', '${purchaseMaseterData.SubTotal}', '${purchaseMaseterData.DiscountAmount}', '${purchaseMaseterData.GSTAmount}', '${purchaseMaseterData.TotalAmount}', '${purchaseMaseterData.TotalAmount}', '1',  '${LoggedOnUser.ID}', now())`
                );
                pMasterID = pMaster.insertId;
                response.pMasterID = pMasterID;

            

            for (const item of purchaseDetailData) {
                // purchaseDetailData.map(async(item) => {
                    item.Multiple = 0;
                    let y = 'XXXXXX';
                
                let pDetail = await connection.query(
                    `insert into PurchaseDetailPo (PurchaseID,CompanyID,ProductTypeID,ProductTypeName,ProductName,UnitPrice,Quantity,SubTotal,DiscountPercentage,DiscountAmount,GSTPercentage,GSTAmount,GSTType,TotalAmount, RetailPrice,WholeSalePrice,MultipleBarCode,BaseBarCode,WholeSale, Ledger,Status,CreatedBy,CreatedOn, NewBarcode, BrandType, UniqueBarcode, ProductExpDate ) values ('${pMasterID}', '${CompanyID}', '${item.ProductTypeID}','${item.ProductTypeName}','${item.ProductName}', '${item.UnitPrice}','${item.Quantity}', '${item.SubTotal}', '${item.DiscountPercentage}', '${item.DiscountAmount}','${item.GSTPercentage}', '${item.GSTAmount}', '${item.GSTType}' , '${item.TotalAmount}', '${item.RetailPrice}','${item.WholeSalePrice}', '${item.Multiple}', '${y}',  '${item.WholeSale}', '${item.Ledger}' , '1', '${LoggedOnUser.ID}', now() , '${item.NewBarcode}', '${item.BrandType}', '${item.UniqueBarcode}', '${item.ProductExpDate}')`
                );

                


                
                // });
            }
           

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async updatePurchase(Body, LoggedOnUser, CompanyID, Mode) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let purchaseMaseterData = Body.PurchaseMaster;
            let purchaseDetailData = JSON.parse(Body.PurchaseDetail);


            let pMaster = await connection.query(
                `Update  PurchaseMasterPo SET SupplierID = '${purchaseMaseterData.SupplierID}' , PurchaseDate = '${purchaseMaseterData.PurchaseDate}', InvoiceNo = '${purchaseMaseterData.InvoiceNo}', Quantity = '${purchaseMaseterData.Quantity}', SubTotal = '${purchaseMaseterData.SubTotal}',DueAmount = '${purchaseMaseterData.SubTotal}', DiscountAmount = '${purchaseMaseterData.DiscountAmount}', GSTAmount = '${purchaseMaseterData.GSTAmount}', TotalAmount = '${purchaseMaseterData.TotalAmount}', UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = '${purchaseMaseterData.ID}'`
            );


            for (const item of purchaseDetailData) {
                item.Multiple = 1;
                let y = 'XXXXXX';
               
                if (item.ID === null && item.Status !== 0) {
                    let PDetail = await connection.query(
                        `insert into PurchaseDetailPo (PurchaseID,CompanyID,ProductTypeID,ProductTypeName,ProductName,UnitPrice,Quantity,SubTotal,DiscountPercentage,DiscountAmount,GSTPercentage,GSTAmount,GSTType,TotalAmount, RetailPrice,WholeSalePrice,MultipleBarCode,BaseBarCode,WholeSale, Ledger,Status,CreatedBy,CreatedOn, NewBarcode, BrandType, UniqueBarcode,ProductExpDate) values ('${purchaseMaseterData.ID}', '${purchaseMaseterData.CompanyID}', '${item.ProductTypeID}','${item.ProductTypeName}','${item.ProductName}', '${item.UnitPrice}','${item.Quantity}', '${item.SubTotal}', '${item.DiscountPercentage}', '${item.DiscountAmount}','${item.GSTPercentage}', '${item.GSTAmount}', '${item.GSTType}' , '${item.TotalAmount}', '${item.RetailPrice}','${item.WholeSalePrice}', '${item.Multiple}', '${y}',  '${item.WholeSale}', '${item.Ledger}' , '1', '${LoggedOnUser.ID}', now() , '${item.NewBarcode}', ${item.BrandType}, '${item.UniqueBarcode}', '${item.ProductExpDate}')`
                    );
                

                    let pDetailID = PDetail.insertId;
                    let prodSpecData = item.Spec;
                    
                }

                if (item.Status === 0) {

                    let delItem = await connection.query(
                        `Update  PurchaseDetailPo SET Status = 0 , UpdatedBy = '${LoggedOnUser.ID}' where ID = '${item.ID}'`
                    );
                }

            }


            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getPurchaseFullDataByID(ID, LoggedOnUser, CompanyID) {
        let data = {
            PurchaseMaster: null,
            Product: null,
            PurchaseDetail: null,
            Charge: null,
        };
        let response = { data: null, success: null };

        const connection = await mysql.connection();
        try {
            let bMasterQry = `select PurchaseMasterPo.*, Supplier.Name as SupplierName ,PurchaseMasterPo.SupplierName AS Sname from  PurchaseMasterPo Left Join Supplier on Supplier.ID = PurchaseMasterPo.SupplierID where PurchaseMasterPo.CompanyID =  ${CompanyID} and PurchaseMasterPo.ID = ${ID} and PurchaseMasterPo.Status = 1`;
            let billMaseterData = await connection.query(bMasterQry);
            data.PurchaseMaster = billMaseterData[0];

            let billDetailData = await connection.query(
                `select * from  PurchaseDetailPo where CompanyID =  ${CompanyID} and PurchaseID = ${ID} order by ID desc`
            );
           
            data.PurchaseDetail = billDetailData;

           

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
}


module.exports = poService;