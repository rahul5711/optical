const mysql = require("../newdb.js");
var moment = require("moment");
const e = require("express");

class companyService {

    // convertToDecimal(num, x) {
    //     return Number(Math.round(parseFloat(num + 'e' + x)) + 'e-' + x);
    // }


    static async savePurchase(Body, LoggedOnUser, CompanyID, Mode) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let purchaseMaseterData = Body.PurchaseMaster;
            let purchaseDetailData = JSON.parse(Body.PurchaseDetail);
            let charge = Body.Charge;

            console.log(purchaseMaseterData , 'purchaseMaseterData');
            let currentStatus = "Available";
           if (purchaseMaseterData.preOrder === true) {
                currentStatus = "Pre Order";
            } else if (purchaseMaseterData.Manual === true) {
                currentStatus = "Not Available";
            }

            let pMasterID;
            if (purchaseMaseterData.preOrder === false) {
                let pMaster = await connection.query(
                    `insert into PurchaseMaster (SupplierID,CompanyID,ShopID,PurchaseDate,PaymentStatus,InvoiceNo, GSTNo, Quantity, SubTotal, DiscountAmount, GSTAmount, TotalAmount, DueAmount, Status,CreatedBy,CreatedOn ) values ('${purchaseMaseterData.SupplierID}', '${CompanyID}', '${purchaseMaseterData.ShopID}', '${purchaseMaseterData.PurchaseDate}', 'Unpaid', '${purchaseMaseterData.InvoiceNo}', '${purchaseMaseterData.GSTNo}', '${purchaseMaseterData.Quantity}', '${purchaseMaseterData.SubTotal}', '${purchaseMaseterData.DiscountAmount}', '${purchaseMaseterData.GSTAmount}', '${purchaseMaseterData.TotalAmount}', '${purchaseMaseterData.TotalAmount}', '1',  '${LoggedOnUser.ID}', now())`
                );
                pMasterID = pMaster.insertId;
                response.pMasterID = pMasterID;
            } else if (purchaseMaseterData.Manual === true) {
                pMasterID = -1;
            } else if (purchaseMaseterData.preOrder === true) {
                pMasterID = 0;
            }

            if (purchaseMaseterData.preOrder === true) {
                console.log('preorfer');

            } else if(purchaseMaseterData.Manual === true) {

                console.log('manual');
            } else  {
                console.log('stock');

            }


            let nextNumber = await connection.query(
                `SELECT BaseBarCode FROM PurchaseDetail
                LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID
                WHERE PurchaseDetail.CompanyID = '${CompanyID}' AND BarcodeMaster.CurrentStatus != 'Pre Order' AND BarcodeMaster.CurrentStatus != 'Not Available' AND PurchaseDetail.PurchaseID != "-1" AND PurchaseDetail.PurchaseID != "0" ORDER BY BaseBarCode DESC LIMIT 0,1`
            );
            let nextNum = await connection.query(
                `SELECT BaseBarcode FROM PurchaseDetail
                LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID
                WHERE PurchaseDetail.CompanyID = '${CompanyID}' AND BarcodeMaster.CurrentStatus = 'Pre Order' and BarcodeMaster.Status = 1 ORDER BY BarcodeMaster.ID DESC LIMIT 0,1`
            );
            let nextNum1 = await connection.query(
                `SELECT BaseBarCode FROM PurchaseDetail
                LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID
                WHERE PurchaseDetail.CompanyID = '${CompanyID}' AND PurchaseDetail.PurchaseID = '-1' AND BarcodeMaster.CurrentStatus = 'Not Available' ORDER BY BaseBarCode DESC LIMIT 0,1`
            );
            var x;
            if (purchaseMaseterData.preOrder !== true && nextNumber.length === 0) {
                x = 10000;
            } else if (purchaseMaseterData.preOrder !== true) {
                x = parseInt(nextNumber[0].BaseBarCode);
                if (isNaN(x) || x < 10000) {
                    x = 10000;
                } else {
                    x = x + 1;
                }
            }




            if(purchaseMaseterData.preOrder === true ){

                x = nextNum[0].BaseBarcode;

            }
            if (purchaseMaseterData.preOrder === true && nextNum.length === 0) {
                x = 90000;
                console.log('hii');
            } else if (purchaseMaseterData.preOrder === true ) {
                x = nextNum[0].BaseBarCode;

                if (isNaN(x) || Number(x) < 90000 || x === undefined) {
                    x = 90000;
                } else {
                    x = Number(x) + 1;
                }
            }

            // console.log(x, 'xx');
            // console.log(nextNum[0].BaseBarCode, 'nextNum[0].BaseBarCode');

            if (purchaseMaseterData.Manual === true && nextNum1.length === 0) {
                x = 1;
            }
            if (purchaseMaseterData.Manual === true && nextNum1.length !== 0) {
                x = parseInt(nextNum1[0].BaseBarCode);
                if (isNaN(x) || x < 1) {
                    x = 1;
                } else {
                    x = x + 1;
                }
            }

            // if (purchaseMaseterData.Manual === true) {
            //     x = 'xxxxxxxx';
            // }

            for (const item of purchaseDetailData) {
                // purchaseDetailData.map(async(item) => {
                if (item.Multiple === true) {
                    item.Multiple = 1;
                } else {
                    item.Multiple = 0;
                }
                let y;
                if (item.BaseBarCode === null) {
                    y = x;
                    x = x + 1;
                } else {
                    y = item.BaseBarCode;
                }
                let pDetail = await connection.query(
                    `insert into PurchaseDetail (PurchaseID,CompanyID,ProductTypeID,ProductTypeName,ProductName,UnitPrice,Quantity,SubTotal,DiscountPercentage,DiscountAmount,GSTPercentage,GSTAmount,GSTType,TotalAmount, RetailPrice,WholeSalePrice,MultipleBarCode,BaseBarCode,WholeSale, Ledger,Status,CreatedBy,CreatedOn, NewBarcode, BrandType, UniqueBarcode, ProductExpDate ) values ('${pMasterID}', '${CompanyID}', '${item.ProductTypeID}','${item.ProductTypeName}','${item.ProductName}', '${item.UnitPrice}','${item.Quantity}', '${item.SubTotal}', '${item.DiscountPercentage}', '${item.DiscountAmount}','${item.GSTPercentage}', '${item.GSTAmount}', '${item.GSTType}' , '${item.TotalAmount}', '${item.RetailPrice}','${item.WholeSalePrice}', '${item.Multiple}', '${y}',  '${item.WholeSale}', '${item.Ledger}' , '1', '${LoggedOnUser.ID}', now() , '${item.NewBarcode}', '${item.BrandType}', '${item.UniqueBarcode}', '${item.ProductExpDate}')`
                );

                let pDetailID = pDetail.insertId;
                let prodSpecData = item.Spec;
                // await Promise.all(
                //     prodSpecData.map(async(ele) => {
                //         let result = await connection.query(
                //             `insert into ProductDataSpec (PurchaseDetailID,ProductSpecID,ProductSpecValue,STATUS,CreatedBy,CreatedOn ) values ('${pDetailID}', '${ele.SpecID}', '${ele.SelectedValue}', '1', '${LoggedOnUser.ID}', now())`
                //         );
                //         response.result = result;
                //         response.success = "Success";
                //     })
                // );


                await Promise.all(
                    charge.map(async (ele) => {
                        let result = await connection.query(
                            `insert into PurchaseCharge (PurchaseID, ChargeType,CompanyID,Description, Amount, GSTPercentage, GSTAmount, GSTType, TotalAmount, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${ele.ChargeType}', '${CompanyID}', '${ele.Description}', '${ele.Amount}', '${ele.GSTPercentage}', '${ele.GSTAmount}', '${ele.GSTType}', '${ele.TotalAmount}', '1', '${LoggedOnUser.ID}', now())`
                        );
                    })
                );
                //    control x
                // });
            }
            if (purchaseMaseterData.preOrder === false) {
                let detailDataForBarCode = await connection.query(
                    `select * from PurchaseDetail where PurchaseID = '${pMasterID}'`
                );

                // await Promise.all(
                //     detailDataForBarCode.map(async(ele) => {
                for (const ele of detailDataForBarCode) {
                    let count = 0;
                    count = ele.Quantity;
                    let baseBarCode;
                    if (
                        ele.NewBarcode === "" ||
                        ele.NewBarcode === "null" ||
                        ele.NewBarcode === null ||
                        ele.NewBarcode === "undefined"
                    ) {
                        baseBarCode = parseInt(ele.BaseBarCode) * 1000;
                    } else {
                        baseBarCode = parseInt(ele.NewBarcode);
                    }
                    let j = 0;
                    for (j = 0; j < count; j++) {
                        if (ele.MultipleBarCode === 1) {
                            baseBarCode = baseBarCode + 1;
                        }
                        await connection.query(
                            `INSERT INTO BarcodeMaster (CompanyID, ShopID, PurchaseDetailID, GSTType, GSTPercentage, BarCode, AvailableDate, CurrentStatus, RetailPrice, RetailDiscount, MultipleBarcode, ForWholeSale, WholeSalePrice, WholeSaleDiscount, TransferStatus, TransferToShop, Status, CreatedBy, CreatedOn) values ('${CompanyID}', '${purchaseMaseterData.ShopID}', '${ele.ID}', '${ele.GSTType}', '${ele.GSTPercentage}', '${baseBarCode}', now() , '${currentStatus}', '${ele.RetailPrice}', 0 ,'${ele.MultipleBarCode}','${ele.WholeSale}','${ele.WholeSalePrice}',0, '', 0, '1', '${LoggedOnUser.ID}', now())`
                        );
                    }
                }
                //     })
                // );
            }
            if (purchaseMaseterData.preOrder === true) {
                let qty = 0;
                if (purchaseMaseterData.page === 'purchase') { qty = purchaseMaseterData.Quantity } else { qty = 1 }
                let detailDataForBarCode = await connection.query(
                    `select * from PurchaseDetail ORDER BY ID DESC LIMIT ${qty}`
                );

                // await Promise.all(
                //     detailDataForBarCode.map(async(ele) => {
                for (const ele of detailDataForBarCode) {
                    let count = 0;

                    if (purchaseMaseterData.page === 'purchase') { count = ele.Quantity; } else { count = 1 }
                    let baseBarCode;
                    if (
                        ele.NewBarcode === "" ||
                        ele.NewBarcode === "null" ||
                        ele.NewBarcode === null ||
                        ele.NewBarcode === "undefined"
                    ) {
                        baseBarCode = parseInt(ele.BaseBarCode) * 1000;
                    } else {
                        baseBarCode = parseInt(ele.NewBarcode);
                    }
                    let j = 0;
                    for (j = 0; j < count; j++) {
                        if (ele.MultipleBarCode === 1) {
                            baseBarCode = baseBarCode + 1;
                        }
                        await connection.query(
                            `INSERT INTO BarcodeMaster (CompanyID, ShopID, PurchaseDetailID, GSTType, GSTPercentage, BarCode, AvailableDate, CurrentStatus, RetailPrice, RetailDiscount, MultipleBarcode, ForWholeSale, WholeSalePrice, WholeSaleDiscount, TransferStatus, TransferToShop, Status, CreatedBy, CreatedOn) values ('${CompanyID}', '${purchaseMaseterData.ShopID}', '${ele.ID}', '${ele.GSTType}', '${ele.GSTPercentage}', '${baseBarCode}', now() , '${currentStatus}', '${ele.RetailPrice}', 0 ,'${ele.MultipleBarCode}','${ele.WholeSale}','${ele.WholeSalePrice}',0, '', 0, '1', '${LoggedOnUser.ID}', now())`
                        );
                    }
                }
                //     })
                // );
            }

            if (purchaseMaseterData.Manual === true) {
                let qty = 0;
                let detailDataForBarCode = await connection.query(
                    `select * from PurchaseDetail ORDER BY ID DESC LIMIT 1`
                );

                // await Promise.all(
                //     detailDataForBarCode.map(async(ele) => {
                for (const ele of detailDataForBarCode) {
                    let count = ele.Quantity;
                    let baseBarCode;
                    if (
                        ele.NewBarcode === "" ||
                        ele.NewBarcode === "null" ||
                        ele.NewBarcode === null ||
                        ele.NewBarcode === "undefined" || ele.NewBarcode === undefined
                    ) {
                        baseBarCode = ele.BaseBarCode;
                    } else {
                        baseBarCode = ele.NewBarcode;
                    }
                    let j = 0;
                    for (j = 0; j < count; j++) {
                        if (ele.MultipleBarCode === 1) {
                            baseBarCode = baseBarCode + 1;
                        }
                        await connection.query(
                            `INSERT INTO BarcodeMaster (CompanyID, ShopID, PurchaseDetailID, GSTType, GSTPercentage, BarCode, AvailableDate, CurrentStatus, RetailPrice, RetailDiscount, MultipleBarcode, ForWholeSale, WholeSalePrice, WholeSaleDiscount, TransferStatus, TransferToShop, Status, CreatedBy, CreatedOn) values ('${CompanyID}', '${purchaseMaseterData.ShopID}', '${ele.ID}', '${ele.GSTType}', '${ele.GSTPercentage}', '${baseBarCode}', now() , '${currentStatus}', '${ele.RetailPrice}', 0 ,'${ele.MultipleBarCode}','${ele.WholeSale}','${ele.WholeSalePrice}',0, '', 0, '1', '${LoggedOnUser.ID}', now())`
                        );
                    }
                }
                //     })
                // );
            }

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getExistingProduct(Body, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = `SELECT MAX(Barcode) AS MaxBarcode, PurchaseDetail.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID WHERE ProductName = '${Body.ProductName}' AND ProductTypeName = '${Body.ProductTypeName}' AND PurchaseDetail.RetailPrice = '${Body.RetailPrice}' AND PurchaseDetail.UnitPrice = '${Body.UnitPrice}' AND PurchaseDetail.MultipleBarcode = ${Body.Multiple} AND PurchaseDetail.CompanyID = '${CompanyID}'AND PurchaseDetail.Status = 1`;
            response.result = await connection.query(qry);

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async updatePurchase(Body, LoggedOnUser, CompanyID, Mode) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let purchaseMaseterData = Body.PurchaseMaster;
            let purchaseDetailData = JSON.parse(Body.PurchaseDetail);
            let charge = Body.Charge;


            switch (Mode) {
                case "Purchaseconvert":
                    console.log(Body, 'Body');
                    for (const item of purchaseDetailData) {
                        let selectMaster = await connection.query(
                            `select * from PurchaseMaster where ID = ${purchaseDetailData[0].PurchaseID}`
                        );
                        let updatedata = {
                            PurchaseDate: purchaseMaseterData.PurchaseDate,
                            Quantity: selectMaster[0].Quantity + Number(item.Quantity),
                            SubTotal: selectMaster[0].SubTotal + Number(item.SubTotal),
                            DiscountAmount: selectMaster[0].DiscountAmount + Number(item.DiscountAmount),
                            GSTAmount: selectMaster[0].GSTAmount + Number(item.GSTAmount),
                            TotalAmount: selectMaster[0].TotalAmount + Number(item.TotalAmount),
                            InvoiceNo: purchaseMaseterData.InvoiceNo
                        }
                        let selectBarcode1 = await connection.query(
                            `select * from BarcodeMaster where PurchaseDetailID = ${item.ID} and CurrentStatus = 'Pre Order'`
                        );
                        let selectPurchaseDetail = await connection.query(
                            `select * from PurchaseDetail where PurchaseID = 0 and ProductName = '${item.ProductName}' `
                        );
                        let UpdateMaster = await connection.query(
                            `update PurchaseMaster SET PurchaseDate = '${updatedata.PurchaseDate}', Quantity = '${updatedata.Quantity}',SubTotal = '${updatedata.SubTotal}',DiscountAmount = '${updatedata.DiscountAmount}',GSTAmount = '${updatedata.GSTAmount}',TotalAmount = '${updatedata.TotalAmount}',InvoiceNo = '${updatedata.InvoiceNo}',PStatus = '1' where ID = ${item.PurchaseID}`
                        );
                        item.Barcode = selectBarcode1[0].Barcode;
                        let BaseBarCode = Number(item.Barcode) / 1000;
                        let updateDetailItem = await connection.query(
                            `Update  PurchaseDetail SET UnitPrice = '${item.UnitPrice}',UniqueBarcode = '${item.UniqueBarcode}',Quantity = '${item.Quantity}',SubTotal = '${item.SubTotal}',DiscountPercentage = '${item.DiscountPercentage}',DiscountAmount = '${item.DiscountAmount}',GSTPercentage = '${item.GSTPercentage}',GSTAmount = '${item.GSTAmount}', GSTType = '${item.GSTType}',TotalAmount = '${item.TotalAmount}', RetailPrice = '${item.RetailPrice}',WholeSalePrice = '${item.WholeSalePrice}',BaseBarCode = '${BaseBarCode}', UpdatedBy = '${selectPurchaseDetail[0].ID}', ProductTypeID = '${selectPurchaseDetail[0].ProductTypeID}', ProductTypeName = '${selectPurchaseDetail[0].ProductTypeName}' where ID = '${selectBarcode1[0].PurchaseDetailID}' and ProductName = '${item.ProductName}'`
                        );
                        let selectBarcode = await connection.query(
                            `select * from BarcodeMaster where PurchaseDetailID = ${item.ID} and CurrentStatus = 'Pre Order'`
                        );
                        let lengthForInsert = Number(item.Quantity) - selectBarcode.length;
                        let updateBarcode = await connection.query(
                            `Update BarcodeMaster SET CurrentStatus = 'Sold' where PurchaseDetailID = ${item.ID} and CurrentStatus = 'Pre Order'`
                        );
                        let findPurchasedetailID = await connection.query(
                            `select * from PurchaseDetail where PurchaseID = '${item.PurchaseID}'`
                        );
                        for (var i = 0; i < lengthForInsert; i++) {
                            await connection.query(`INSERT INTO BarcodeMaster (CompanyID, ShopID, PurchaseDetailID, GSTType, GSTPercentage, BarCode, AvailableDate, CurrentStatus, RetailDiscount, MultipleBarcode, ForWholeSale, WholeSalePrice, WholeSaleDiscount, TransferStatus, TransferToShop, Status, CreatedBy, CreatedOn) values ('${item.CompanyID}', '${purchaseMaseterData.ShopID}', '${findPurchasedetailID[0].ID}', '${item.GSTType}', '${item.GSTPercentage}', '${item.Barcode}', now() , 'Available', 0 ,'${item.MultipleBarCode}',0,0,0, '', 0, '1', '${LoggedOnUser.ID}', now())`);
                        }
                    }
                    break;
                case "Purchase":
                    let pMaster = await connection.query(
                        `Update  PurchaseMaster SET SupplierID = '${purchaseMaseterData.SupplierID}' , PurchaseDate = '${purchaseMaseterData.PurchaseDate}', InvoiceNo = '${purchaseMaseterData.InvoiceNo}', Quantity = '${purchaseMaseterData.Quantity}', SubTotal = '${purchaseMaseterData.SubTotal}',DueAmount = '${purchaseMaseterData.SubTotal}', DiscountAmount = '${purchaseMaseterData.DiscountAmount}', GSTAmount = '${purchaseMaseterData.GSTAmount}', TotalAmount = '${purchaseMaseterData.TotalAmount}', UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = '${purchaseMaseterData.ID}'`
                    );

                    //   let pMasterID = pMaster.insertId;

                    // for (const item of purchaseDetailData) {
                    // let pDetail = await connection.query(
                    //   `Update PurchaseDetail SET PurchaseID = '${pMasterID}',CompanyID = '${CompanyID}',ProductTypeID = '${item.ProductTypeID}',ProductTypeName = '${item.ProductTypeName}',ProductName= '${item.ProductName}',UnitPrice = '${item.UnitPrice}',Quantity = '${item.Quantity}',SubTotal = '${item.SubTotal}',DiscountPercentage = '${item.DiscountPercentage}',DiscountAmount = '${item.DiscountAmount}',GSTPercentage = '${item.GSTPercentage}',GSTAmount= '${item.GSTAmount}',GSTType = '${item.GSTType}',TotalAmount = '${item.TotalAmount}', RetailPrice = '${item.RetailPrice}',WholeSalePrice = '${item.WholeSalePrice}',MultipleBarCode = '${item.MultipleBarCode}',BaseBarCode= '${item.BaseBarCode}',WholeSale = '${item.WholeSalePrice}', Ledger = '${item.Ledger}',Status = 1,CreatedBy = '${LoggedOnUser.ID}',CreatedOn = now() where ID = '${item.PurchaseDetailID}'`
                    // );
                    // if (item.ID === null) {


                    let nextNumber = await connection.query(
                        `SELECT BaseBarCode FROM PurchaseDetail
                        LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID
                        WHERE PurchaseDetail.CompanyID = '${CompanyID}' AND BarcodeMaster.CurrentStatus != 'Pre Order' AND BarcodeMaster.CurrentStatus != 'Not Available' AND PurchaseDetail.PurchaseID != "-1" AND PurchaseDetail.PurchaseID != "0" ORDER BY BaseBarCode DESC LIMIT 0,1`
                    );

                    let x;
                    if (nextNumber.length === 0) {
                        x = 10000;
                    } else {
                        x = parseInt(nextNumber[0].BaseBarCode);
                        if (isNaN(x) || x < 10000) {
                            x = 10000;
                        } else {
                            x = x + 1;
                        }
                    }

                    // purchaseDetailData.map(async(item) => {
                    for (const item of purchaseDetailData) {
                        if (item.Multiple === true) {
                            item.Multiple = 1;
                        } else {
                            item.Multiple = 0;
                        }
                        let y;
                        if (item.BaseBarCode === null) {
                            y = x;
                            x = x + 1;
                        } else {
                            y = item.BaseBarCode;
                        }
                        if (item.ID === null && item.Status !== 0) {
                            let PDetail = await connection.query(
                                `insert into PurchaseDetail (PurchaseID,CompanyID,ProductTypeID,ProductTypeName,ProductName,UnitPrice,Quantity,SubTotal,DiscountPercentage,DiscountAmount,GSTPercentage,GSTAmount,GSTType,TotalAmount, RetailPrice,WholeSalePrice,MultipleBarCode,BaseBarCode,WholeSale, Ledger,Status,CreatedBy,CreatedOn, NewBarcode, BrandType, UniqueBarcode,ProductExpDate) values ('${purchaseMaseterData.ID}', '${purchaseMaseterData.CompanyID}', '${item.ProductTypeID}','${item.ProductTypeName}','${item.ProductName}', '${item.UnitPrice}','${item.Quantity}', '${item.SubTotal}', '${item.DiscountPercentage}', '${item.DiscountAmount}','${item.GSTPercentage}', '${item.GSTAmount}', '${item.GSTType}' , '${item.TotalAmount}', '${item.RetailPrice}','${item.WholeSalePrice}', '${item.Multiple}', '${y}',  '${item.WholeSale}', '${item.Ledger}' , '1', '${LoggedOnUser.ID}', now() , '${item.NewBarcode}', ${item.BrandType}, '${item.UniqueBarcode}', '${item.ProductExpDate}')`
                            );
                            // }
                            // }

                            let pDetailID = PDetail.insertId;
                            let prodSpecData = item.Spec;
                            // await Promise.all(
                            //     prodSpecData.map(async(ele) => {
                            //         let result = await connection.query(
                            //             `insert into ProductDataSpec (PurchaseDetailID,ProductSpecID,ProductSpecValue,STATUS,CreatedBy,CreatedOn ) values ('${pDetailID}', '${ele.SpecID}', '${ele.SelectedValue}', '1', '${LoggedOnUser.ID}', now())`
                            //         );
                            //         response.result = result;
                            //         response.success = "Success";
                            //     })
                            // );
                            // }

                            // await Promise.all(
                            //     charge.map(async(ele) => {
                            //         let result = await connection.query(
                            //             `insert into PurchaseCharge (PurchaseID, ChargeType,CompanyID,Description, Amount, GSTPercentage, GSTAmount, GSTType, TotalAmount, Status,CreatedBy,CreatedOn ) values ('${purchaseMaseterData.ID}', '${ele.ChargeType}', '${CompanyID}', '${ele.Description}', '${ele.Amount}', '${ele.GSTPercentage}', '${ele.GSTAmount}', '${ele.GSTType}', '${ele.TotalAmount}', '1', '${LoggedOnUser.ID}', now())`
                            //         );
                            //     })
                            // );

                            let detailDataForBarCode = await connection.query(
                                `select * from PurchaseDetail where PurchaseID = '${purchaseMaseterData.ID}' ORDER BY ID DESC LIMIT 1`
                            );

                            await Promise.all(
                                detailDataForBarCode.map(async (ele) => {
                                    let count = ele.Quantity;
                                    let baseBarCode;
                                    if (
                                        ele.NewBarcode === "" ||
                                        ele.NewBarcode === "null" ||
                                        ele.NewBarcode === null ||
                                        ele.NewBarcode === "undefined"
                                    ) {
                                        baseBarCode = parseInt(ele.BaseBarCode) * 1000;
                                    } else {
                                        baseBarCode = parseInt(ele.NewBarcode);
                                    }
                                    let j = 0;
                                    for (j = 0; j < count; j++) {
                                        if (ele.MultipleBarCode === 1) {
                                            baseBarCode = baseBarCode + 1;
                                        }
                                        await connection.query(`INSERT INTO BarcodeMaster (CompanyID, ShopID, PurchaseDetailID, GSTType, GSTPercentage, BarCode, AvailableDate, CurrentStatus, RetailPrice, RetailDiscount, MultipleBarcode, ForWholeSale, WholeSalePrice, WholeSaleDiscount, TransferStatus, TransferToShop, Status, CreatedBy, CreatedOn) values ('${CompanyID}', '${purchaseMaseterData.ShopID}', '${ele.ID}', '${ele.GSTType}', '${ele.GSTPercentage}', '${baseBarCode}', now() , 'Available', '${ele.RetailPrice}', 0 ,'${ele.MultipleBarCode}','${ele.WholeSale}','${ele.WholeSalePrice}',0, '', 0, '1', '${LoggedOnUser.ID}', now())`);

                                    }
                                })
                            );
                        }

                        if (item.Status === 0) {
                            // let detailID = await connection.query(
                            //   `select * from  PurchaseDetail where  PurchaseID = '${item.ID}'`
                            // );

                            let delItem = await connection.query(
                                `Update  PurchaseDetail SET Status = 0 , UpdatedBy = '${LoggedOnUser.ID}' where ID = '${item.ID}'`
                            );
                            let delBarcode = await connection.query(
                                `Update  BarcodeMaster SET Status = 0 where PurchaseDetailID = '${item.ID}'`
                            );
                        }

                    }
                    // });
                    await Promise.all(
                        charge.map(async (ele) => {
                            if (ele.ID === null) {
                                let result = await connection.query(
                                    `insert into PurchaseCharge (PurchaseID, ChargeType,CompanyID,Description, Amount, GSTPercentage, GSTAmount, GSTType, TotalAmount, Status,CreatedBy,CreatedOn ) values ('${purchaseMaseterData.ID}', '${ele.ChargeType}', '${CompanyID}', '${ele.Description}', '${ele.Price}', '${ele.GSTPercentage}', '${ele.GSTAmount}', '${ele.GSTType}', '${ele.TotalAmount}', '1', '${LoggedOnUser.ID}', now())`
                                );
                            } else if (ele.Status === 0) {
                                let result = await connection.query(
                                    `update PurchaseCharge set Status = 0 where ID = '${ele.ID}'`
                                );
                            }
                        })
                    );


                    //  if add product after payment
                    // if payment exist check in this invoice
                    let doesexistPayment = await connection.query(
                        `select SUM(PaymentDetail.Amount) as PaidAmount from  PaymentDetail where BillID = '${purchaseMaseterData.InvoiceNo}' and CompanyID = '${CompanyID}' AND PaymentType = 'Vendor'`
                    );

                    if (doesexistPayment.length !== 0) {
                        let Dueamount = Number(purchaseMaseterData.TotalAmount) - Number(doesexistPayment[0].PaidAmount)

                        let pMasterUpdate = await connection.query(
                            `Update  PurchaseMaster SET DueAmount = '${Dueamount}' where ID = '${purchaseMaseterData.ID}'`
                        );
                    }
                    // }
                    break;
                case "Fitter":

                    // let pFitter = await connection.query(
                    //     `insert into FitterMaster (FitterID,CompanyID,ShopID,PurchaseDate,PaymentStatus,InvoiceNo, GSTNo, Quantity, TotalAmount, Status,CreatedBy,CreatedOn ) values ('${purchaseMaseterData.FitterID}', '${CompanyID}', '${purchaseMaseterData.ShopID}', '${purchaseMaseterData.PurchaseDate}', 'Unpaid', '${purchaseMaseterData.InvoiceNo}', '${purchaseMaseterData.GSTNo}', '${purchaseMaseterData.Quantity}','${purchaseMaseterData.TotalAmount}', '1',  '${LoggedOnUser.ID}', now())`
                    // );

                    let updateFitterMaster = await connection.query(`update FitterMaster set InvoiceNo = '${purchaseMaseterData.InvoiceNo}', Quantity = '${purchaseMaseterData.Quantity}', TotalAmount = '${purchaseMaseterData.TotalAmount}', PStatus = 1, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now(), PurchaseDate = now() where ID = '${purchaseDetailData[0].FitterMasterID}' and FitterID = '${purchaseMaseterData.FitterID}'`);

                // let pFitterID = pFitter.insertId;

                // for (const item of purchaseDetailData) {
                //     let fDetail = await connection.query(
                //         `Update FitterDetail SET FitterMasterID = '${pFitterID}',CompanyID = '${CompanyID}',ProductName= '${item.ProductName}',UnitPrice = '${item.UnitPrice}',Quantity = '${item.Quantity}',TotalAmount = '${item.TotalAmount}',Status = 1,CreatedBy = '${LoggedOnUser.ID}',CreatedOn = now() where ID = '${item.FitterDetailID}'`
                //     );
                // }
                // break;
                case "Doctor":
                case "Employee":
                    let pCommission = await connection.query(
                        `insert into CommissionMaster (UserID, UserType, CompanyID,ShopID,PurchaseDate,PaymentStatus,InvoiceNo, GSTNo, Quantity, TotalAmount, DueAmount, Status,CreatedBy,CreatedOn ) values ('${purchaseMaseterData.UserID}', '${Mode}', '${CompanyID}', '${purchaseMaseterData.ShopID}', '${purchaseMaseterData.PurchaseDate}', 'Unpaid', '${purchaseMaseterData.InvoiceNo}','${purchaseMaseterData.GSTNo}', '${purchaseMaseterData.Quantity}','${purchaseMaseterData.TotalAmount}','${purchaseMaseterData.DueAmount}', '1',  '${LoggedOnUser.ID}', now())`
                    );

                    let pCommissionID = pCommission.insertId;

                    for (const item of purchaseDetailData) {
                        let fDetail = await connection.query(
                            `Update CommissionDetail SET CommissionMasterID = '${pCommissionID}', UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now() where ID = '${item.ID}'`
                        );
                    }
                    break;

                case "PurchaseOne":

                    //   console.log(purchaseMaseterData , 'purchaseMaseterData');
                    //   console.log(purchaseDetailData , 'purchaseDetailData');
                    purchaseMaseterData.GSTAmount = 0
                    purchaseMaseterData.TotalAmount = 0

                    let totalAmt = 0;
                    let gstamt = 0;
                    let subtotal = 0;

                    for (const item of purchaseDetailData) {
                        if (item.Status === 1) {
                            item.SubTotal = (+item.UnitPrice) * +item.Quantity;
                            item.GSTAmount = (+item.SubTotal) * +item.GSTPercentage / 100;
                            item.TotalAmount = item.SubTotal + item.GSTAmount

                            totalAmt = totalAmt + item.TotalAmount;

                            gstamt = gstamt + item.GSTAmount;
                            subtotal = subtotal + item.SubTotal;
                            purchaseMaseterData.GSTAmount += (+item.SubTotal) * +item.GSTPercentage / 100;

                            purchaseMaseterData.TotalAmount += item.SubTotal +  item.GSTAmount
                            let fDetail = await connection.query(
                                `Update PurchaseDetail set UniqueBarcode = '${item.UniqueBarcode}', SubTotal = ${item.SubTotal},  GSTAmount = ${item.GSTAmount},  TotalAmount = ${item.TotalAmount} where ID = ${item.ID}`
                            )

                            // console.log(item.SubTotal , 'item.SubTotal');
                            // console.log(item.GSTAmount , 'item.GSTAmount');
                            // console.log(item.TotalAmount , 'item.TotalAmount');

                        }
                    }
                    purchaseMaseterData.TotalAmount = totalAmt
                    purchaseMaseterData.GSTAmount = gstamt
                    purchaseMaseterData.SubTotal = subtotal


                    // console.log(purchaseMaseterData , 'purchaseMaseterData.SubTotal');

                    let PSDetail = await connection.query(
                        `Update PurchaseMaster set SubTotal = ${purchaseMaseterData.SubTotal}, GSTAmount = ${purchaseMaseterData.GSTAmount}, TotalAmount = ${purchaseMaseterData.TotalAmount} where ID = ${purchaseMaseterData.ID}`
                    )

                    // console.log(PSDetail, 'PSDetail');

                    break;

            }

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async saveBill(Body, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let billMaseterData = Body.billMaster;
            let billDetailData = Body.billDetail;

            let service = Body.service;
            if (billMaseterData.ID === null || billMaseterData.ID === undefined) {
                // var newInvoiceID = new Date().toISOString().replace(/[`~!@#$%^&*()_|+\-=?TZ;:'",.<>\{\}\[\]\\\/]/gi, '').slice(2);
                var newInvoiceID = new Date()
                    .toISOString()
                    .replace(/[`~!@#$%^&*()_|+\-=?TZ;:'",.<>\{\}\[\]\\\/]/gi, "")
                    .substring(2, 6);
                let rw = "W";
                if (billDetailData.length !== 0 && !billDetailData[0].WholeSale) {
                    rw = "R";
                }

                let wholesale = 0

                if (rw === "R") {
                    wholesale = 0
                } else {
                    wholesale = 1
                }


                let qry1 = `SELECT BillMaster.ID ,BillMaster.InvoiceNo FROM BillDetail LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID WHERE BillMaster.CompanyID = '${CompanyID}' AND BillDetail.WholeSale = ${wholesale} and BillMaster.InvoiceNo LIKE '${newInvoiceID}%' ORDER BY BillMaster.ID DESC `;
                // let qry1 = `SELECT ID ,InvoiceNo FROM BillMaster WHERE ID IN (SELECT MAX(ID) AS MaxID FROM BillMaster WHERE CompanyID = '${CompanyID}' and InvoiceNo LIKE '${newInvoiceID}%' )`;
                let lastInvoiceID = await connection.query(qry1);
                if (
                    lastInvoiceID.length === 0 ||
                    lastInvoiceID[0].MaxID === null ||
                    lastInvoiceID[0].InvoiceNo.substring(0, 4) !== newInvoiceID
                ) {
                    newInvoiceID = newInvoiceID + rw + "00001";
                } else {
                    let temp3 = lastInvoiceID[0].InvoiceNo;
                    let temp1 = parseInt(temp3.substring(10, 5)) + 1;
                    let temp2 = "0000" + temp1;
                    newInvoiceID = newInvoiceID + rw + temp2.slice(-5);
                }
                billMaseterData.InvoiceNo = newInvoiceID;
            }

            // let pHistory = await connection.query(`insert into PaymentHistory(CompanyID,ShopID,BillDate,InvoiceNo,CustomerID,Amount,PaidAmount,DueAmount,Status,CreatedBy, CreatedOn) values (${CompanyID}, ${billMaseterData.ShopID}, '${billMaseterData.BillDate}', '${billMaseterData.InvoiceNo}', ${billMaseterData.CustomerID}, '${billMaseterData.TotalAmount - billMaseterData.AddlDiscount}', '0', '${billMaseterData.TotalAmount - billMaseterData.AddlDiscount}', 1, ${LoggedOnUser.ID}, now())`);

            let bMaster = await connection.query(
                `insert into BillMaster (CustomerID,CompanyID, Sno,ShopID,BillDate, DeliveryDate,  PaymentStatus,InvoiceNo, GSTNo, Quantity, SubTotal, DiscountAmount, GSTAmount,AddlDiscount, TotalAmount, DueAmount, Status,CreatedBy,CreatedOn, LastUpdate, Doctor, TrayNo, Employee) values ('${billMaseterData.CustomerID}', '${CompanyID}','${billMaseterData.Sno}', '${billMaseterData.ShopID}', '${billMaseterData.BillDate}','${billMaseterData.DeliveryDate}', 'Unpaid',  '${billMaseterData.InvoiceNo}', '${billMaseterData.GSTNo}', '${billMaseterData.Quantity}', '${billMaseterData.SubTotal}', '${billMaseterData.DiscountAmount}', '${billMaseterData.GSTAmount}', '${billMaseterData.AddlDiscount}', '${billMaseterData.TotalAmount}', '${billMaseterData.TotalAmount - billMaseterData.AddlDiscount}', '1',  '${LoggedOnUser.ID}', now(), now(), '${billMaseterData.Doctor}', '${billMaseterData.TrayNo}', '${billMaseterData.Employee}') `
            );

            let bMasterID = bMaster.insertId;
            response.result = bMasterID;
            await Promise.all(
                billDetailData.map(async (item) => {

                    let preorder = 0;
                    if (item.PreOrder === true) {
                        preorder = 1;
                    }
                    let manual = 0;
                    if (item.Manual === true) {
                        manual = 1;
                    }

                    let wholesale = 0

                    if (item.WholeSale === true) {
                        wholesale = 1;
                    }


                    let result = await connection.query(
                        `insert into BillDetail (BillID,CompanyID,ProductTypeID,ProductTypeName,ProductName,HSNCode,UnitPrice,Quantity,SubTotal,DiscountPercentage,DiscountAmount,GSTPercentage,GSTAmount,GSTType,TotalAmount,WholeSale, Manual, PreOrder,BaseBarCode,Barcode,Status, MeasurementID, Option, Family, CreatedBy,CreatedOn, SupplierID, Remark, Warranty, ProductExpDate) values ('${bMasterID}', '${CompanyID}', '${item.ProductTypeID}','${item.ProductTypeName}','${item.ProductName}', '${item.HSNCode}','${item.UnitPrice}','${item.Quantity}', '${item.SubTotal}', '${item.DiscountPercentage}', '${item.DiscountAmount}','${item.GSTPercentage}', '${item.GSTAmount}', '${item.GSTType}' , '${item.TotalAmount}', '${wholesale}','${manual}', ${preorder}, '${item.BaseBarCode}' , '${item.Barcode}' , '1','${item.MeasurementID}','${item.Option}','${item.Family}', '${LoggedOnUser.ID}', now(), '${item.SupplierID}', '${item.Remark}', '${item.Warranty}', '${item.ProductExpDate}')`
                    );
                })
            );

            await Promise.all(
                service.map(async (ele) => {
                    let result1 = await connection.query(
                        `insert into BillService ( BillID, ServiceType ,CompanyID,Description, Price, GSTPercentage, GSTAmount, GSTType, TotalAmount, Status,CreatedBy,CreatedOn ) values ('${bMasterID}', '${ele.ServiceType}', '${CompanyID}',  '${ele.Description}', '${ele.Price}', '${ele.GSTPercentage}', '${ele.GSTAmount}', '${ele.GSTType}', '${ele.TotalAmount}', '1', '${LoggedOnUser.ID}', now())`
                    );
                })
            );

            let detailDataForBarCode = await connection.query(
                `select * from BillDetail where BillID = '${bMasterID}'`
            );

            // await Promise.all(
            //     detailDataForBarCode.map(async(ele) => {
            for (const ele of detailDataForBarCode) {
                if (ele.PreOrder === 1) {
                    let count = ele.Quantity;
                    let baseBarCode = parseInt(ele.BaseBarCode) * 1000;
                    let j = 0;
                    for (j = 0; j < count; j++) {
                        let qrry = `INSERT INTO BarcodeMaster (CompanyID, ShopID, PurchaseDetailID, BillDetailID, GSTType, GSTPercentage, BarCode, AvailableDate, CurrentStatus,
                                RetailPrice, RetailDiscount, MultipleBarcode, ForWholeSale, WholeSalePrice, WholeSaleDiscount, PreOrder,Po, TransferStatus,
                                TransferToShop, MeasurementID, OPTION, Family, STATUS, CreatedBy, CreatedOn) VALUES ('${CompanyID}', '${billMaseterData.ShopID}', 0, '${ele.ID}', '${ele.GSTType}', '${ele.GSTPercentage}', '${ele.Barcode}', now() , 'Pre Order', '${ele.UnitPrice}', 0 ,'0','${ele.WholeSale}','${ele.UnitPrice}',0, '1', '1', '', 0, '${ele.MeasurementID}','${ele.Option}','${ele.Family}', '1', '${LoggedOnUser.ID}', now())`;
                        await connection.query(qrry);
                    }
                } else if (ele.Manual === 1) {

                    let qryx = `SELECT * FROM BarcodeMaster WHERE CompanyID = '${CompanyID}' AND ShopID = '${billMaseterData.ShopID}' AND CurrentStatus = "Not Available" AND STATUS =1 LIMIT ${ele.Quantity}`;
                    console.log(await connection.query(qryx), 'qryxqryxqryxqryxqryx');
                    let selectRows = await connection.query(qryx);

                    await Promise.all(
                        selectRows.map(async (ele1) => {
                            let qry = `Update BarcodeMaster set CurrentStatus = "Sold" , MeasurementID = '${ele.MeasurementID}', Family = '${ele.Family}',Option = '${ele.Option}', BillDetailID = '${ele.ID}', SupplierID = '${ele.SupplierID}' Where ID = '${ele1.ID}'`;
                            let resultn = await connection.query(qry);
                        })
                    );
                } else {
                    let qryx1 = `SELECT * FROM BarcodeMaster WHERE CompanyID = '${CompanyID}' AND ShopID = '${billMaseterData.ShopID}' AND CurrentStatus = "Available" AND STATUS =1 AND Barcode = '${ele.Barcode}' LIMIT ${ele.Quantity}`;
                    console.log(await connection.query(qryx1), 'qryqryqry');
                    let selectRows1 = await connection.query(qryx1);

                    await Promise.all(
                        selectRows1.map(async (ele1) => {
                            let qry1 = `Update BarcodeMaster set CurrentStatus = "Sold" , MeasurementID = '${ele.MeasurementID}', Family = '${ele.Family}',Option = '${ele.Option}', BillDetailID = '${ele.ID}', SupplierID = '${ele.SupplierID}' Where ID = '${ele1.ID}'`;
                            let resultn = await connection.query(qry1);
                        })
                    );
                }
            }
            //     })
            // );

            let commission = { Type: 0, Mode: 0, Value: 0, Amount: 0 }
            // Doctor Commission Calculations below. Idea is to first find If doctor is eligible for Commission then based on the commission type calculate amount and update BillMaster table
            let doctorData = await connection.query(`select * from Doctor where Doctor.ID = '${billMaseterData.Doctor}'`);
            if (doctorData.length !== 0 && doctorData[0].CommissionType == 1) {
                commission.Type = doctorData[0].CommissionType;
                if (doctorData[0].CommissionMode == 2) {
                    commission.Amount = doctorData[0].CommissionValue;
                    commission.Mode = doctorData[0].CommissionMode;
                    commission.Value = doctorData[0].CommissionValue;
                } else if (doctorData[0].CommissionMode == 1) {
                    commission.Type = doctorData[0].CommissionType;
                    commission.Amount = +billMaseterData.SubTotal * +doctorData[0].CommissionValue / 100;
                    commission.Mode = doctorData[0].CommissionMode;
                    commission.Value = doctorData[0].CommissionValue;
                }
            } else if (doctorData.length !== 0 && doctorData[0].CommissionType == 2) {
                let doctorResultB = await connection.query(`SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType = 1`);
                let doctorResultNB = await connection.query(`SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType <> 1`);
                commission.Type = doctorData[0].CommissionType;
                if (doctorData[0].CommissionMode == 2) {
                    // commission.Amount = subTotal;
                    // commission.Mode = doctorData[0].CommissionMode;
                    // commission.Value = doctorData[0].CommissionValue;
                } else if (doctorData[0].CommissionMode == 1) {
                    commission.Type = doctorData[0].CommissionType;
                    commission.Amount = doctorResultB[0].SubTotalVal * +doctorData[0].CommissionValue / 100 + doctorResultNB[0].SubTotalVal * +doctorData[0].CommissionValueNB / 100;
                    commission.Mode = doctorData[0].CommissionMode;
                    commission.Value = doctorData[0].CommissionValue;
                }
            }

            if (commission.Type !== 0 && commission.Amount !== 0) {
                await connection.query(`insert into CommissionDetail (CompanyID,ShopID,CommissionMasterID, UserType, UserID,BillMasterID, CommissionMode, CommissionType, CommissionValue, CommissionAmount, Status,CreatedBy,CreatedOn ) values ('${CompanyID}', '${billMaseterData.ShopID}', '0','Doctor', '${billMaseterData.Doctor}', '${bMasterID}', '${commission.Mode}','${commission.Type}','${commission.Value}','${commission.Amount}',  '1',  '${LoggedOnUser.ID}', now())`)
            }


            let commission1 = { Type: 0, Mode: 0, Value: 0, Amount: 0 }
            // Employee Commission Calculations below. Idea is to first find If Employee is eligible for Commission then based on the commission type calculate amount and update BillMaster table
            let userData = await connection.query(`select * from User where User.ID = '${billMaseterData.Employee}'`);
            if (userData.length !== 0 && userData[0].CommissionType == 1) {
                commission1.Type = userData[0].CommissionType;
                if (userData[0].CommissionMode == 2) {
                    commission1.Amount = userData[0].CommissionValue;
                    commission1.Mode = userData[0].CommissionMode;
                    commission1.Value = userData[0].CommissionValue;
                } else if (userData[0].CommissionMode == 1) {
                    commission1.Type = userData[0].CommissionType;
                    commission1.Amount = +billMaseterData.SubTotal * +userData[0].CommissionValue / 100;
                    commission1.Mode = userData[0].CommissionMode;
                    commission1.Value = userData[0].CommissionValue;
                }
            } else if (userData.length !== 0 && userData[0].CommissionType == 2) {
                let userResultB = await connection.query(`SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType = 1`);
                let userResultNB = await connection.query(`SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType <> 1`);
                commission1.Type = userData[0].CommissionType;
                if (userData[0].CommissionMode == 2) {
                    // commission1.Amount = subTotal;
                    // commission1.Mode = userData[0].CommissionMode;
                    // commission1.Value = userData[0].CommissionValue;
                } else if (userData[0].CommissionMode == 1) {
                    commission1.Type = userData[0].CommissionType;
                    commission1.Amount = userResultB[0].SubTotalVal * +userData[0].CommissionValue / 100 + userResultNB[0].SubTotalVal * +userData[0].CommissionValueNB / 100;
                    commission1.Mode = userData[0].CommissionMode;
                    commission1.Value = userData[0].CommissionValue;
                }
            }

            if (commission1.Type !== 0 && commission1.Amount !== 0) {
                await connection.query(`insert into CommissionDetail (CompanyID,ShopID,CommissionMasterID, UserType, UserID,BillMasterID, CommissionMode, CommissionType, CommissionValue, CommissionAmount, Status,CreatedBy,CreatedOn ) values ('${CompanyID}', '${billMaseterData.ShopID}', '0','Employee', '${userData[0].ID}', '${bMasterID}', '${commission1.Mode}','${commission1.Type}','${commission1.Value}','${commission1.Amount}',  '1',  '${LoggedOnUser.ID}', now())`)
            }


            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async updateProductStatus(Body, LoggedOnUser, CompanyID, BillID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let bodylength = 0;
            Body.forEach(el => {
                if (el.Status === 1) {
                    bodylength = bodylength + 1;
                }
            })
            await Promise.all(
                Body.map(async (item) => {
                    if (item.ProductStatus === true || item.ProductStatus === 1) {
                        await connection.query(
                            `Update BillDetail SET ProductStatus = 1, ProductDeliveryDate = now() Where ID = '${item.ID}'`
                        );
                    } else if (item.ProductStatus === false || item.ProductStatus === 0) {
                        await connection.query(
                            `Update BillDetail SET ProductStatus = 0, ProductDeliveryDate = 'null' Where ID = '${item.ID}'`
                        );
                    }
                })
            )

            let UpdatedProduct = await connection.query(
                `Select * from BillDetail where BillID = '${BillID}' and ProductStatus = 1 and Status = 1`
            );

            if (UpdatedProduct.length === bodylength) {
                let updateBillMaster = await connection.query(
                    `Update BillMaster set ProductStatus = 'Deliverd' Where ID = '${BillID}'`
                );
            } else {
                let updateBillMaster1 = await connection.query(
                    `Update BillMaster set ProductStatus = 'Pending' Where ID = '${BillID}'`
                );
            }
            await connection.query("COMMIT");
            return response;

        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }

    }

    static async updateCurrection(Body, LoggedOnUser, CompanyID, Company) {
        const connection = await mysql.connection();

        try {
            let response = { data: null, success: null };

            let billMaseterData = Body.billMaster;
            let billDetailData = Body.billDetail;
            let service = Body.service;
            let InvoiceNo = Body.billMaster.InvoiceNo.split("")[4]


            if (InvoiceNo === "W") {
                let totalqty = 0;
                let totalSub = 0;
                let totaldis = 0;
                let totalgst = 0;
                let totalgrnd = 0;
                billDetailData.forEach(ele =>{
                  ele.DiscountAmount = +ele.Quantity * +ele.UnitPrice * +ele.DiscountPercentage / 100;
                  ele.SubTotal = +ele.UnitPrice * +ele.Quantity - ele.DiscountAmount;
                  ele.GSTAmount = (+ele.UnitPrice * +ele.Quantity - ele.DiscountAmount) * +ele.GSTPercentage / 100;
                  ele.TotalAmount = ele.GSTAmount + ele.SubTotal

                  totalqty = totalqty + ele.Quantity
                  totalSub = totalSub + ele.SubTotal
                  totaldis = totaldis + ele.DiscountAmount
                  totalgst = totalgst + ele.GSTAmount
                  totalgrnd = totalgrnd + ele.TotalAmount


                })
                billMaseterData.Quantity = totalqty
                billMaseterData.SubTotal = totalSub
                billMaseterData.DiscountAmount = totaldis
                billMaseterData.GSTAmount = totalgst
                billMaseterData.TotalAmount = totalgrnd

            } else if(InvoiceNo === "R") {
                let totalqty = 0 ;
                let totalSub = 0;
                let totaldis = 0;
                let totalgst = 0;
                let totalgrnd = 0;
                billDetailData.forEach(ele =>{
                  ele.DiscountAmount = +ele.Quantity * +ele.UnitPrice * +ele.DiscountPercentage / 100;
                  ele.SubTotal = +ele.UnitPrice * +ele.Quantity - ele.DiscountAmount;
                  ele.GSTAmount = (+ele.UnitPrice * +ele.Quantity - ele.DiscountAmount) * +ele.GSTPercentage / 100;
                  ele.TotalAmount =  ele.SubTotal - ele.GSTAmount

                  totalqty = totalqty + ele.Quantity
                  totalSub = totalSub + ele.SubTotal
                  totaldis = totaldis + ele.DiscountAmount
                  totalgst = totalgst + ele.GSTAmount
                  totalgrnd = totalgrnd + ele.TotalAmount


                })
                billMaseterData.Quantity = totalqty
                billMaseterData.SubTotal = totalSub
                billMaseterData.DiscountAmount = totaldis
                billMaseterData.GSTAmount = totalgst
                billMaseterData.TotalAmount = totalgrnd



            }

            console.log(billDetailData , 'billDetailData');

            let paymentDoesExist = await connection.query(
                `select * from PaymentDetail where PaymentDetail.CompanyID = '${billMaseterData.CompanyID}' and PaymentDetail.BillID = '${billMaseterData.InvoiceNo}'`
            );


            if (paymentDoesExist.length !== 0 && billMaseterData.PaymentStatus === 'Paid') {
                let updateBilldetail = await connection.query(
                    `Update BillMaster set  Quantity = '${billMaseterData.Quantity}',  SubTotal = '${billMaseterData.SubTotal}',  DiscountAmount = '${billMaseterData.DiscountAmount}',  GSTAmount = '${billMaseterData.GSTAmount}', TotalAmount = '${billMaseterData.TotalAmount}'  Where ID = '${billMaseterData.ID}'`
                );
            } else if(paymentDoesExist.length === 0) {
                let updateBilldetail = await connection.query(
                    `Update BillMaster set  Quantity = '${billMaseterData.Quantity}',  SubTotal = '${billMaseterData.SubTotal}',  DiscountAmount = '${billMaseterData.DiscountAmount}',  GSTAmount = '${billMaseterData.GSTAmount}', TotalAmount = '${billMaseterData.TotalAmount}',DueAmount = '${billMaseterData.TotalAmount}'  Where ID = '${billMaseterData.ID}'`)
            }


            for (const item of billDetailData) {
                await connection.query(
                    `Update BillDetail SET DiscountAmount = ${item.DiscountAmount},SubTotal = '${item.SubTotal}',GSTAmount = '${item.GSTAmount}',TotalAmount = '${item.TotalAmount}', UpdatedBy = '${LoggedOnUser.ID}' Where ID = '${item.ID}'`
                );
            }

            console.log("bill currection done ......................!");
            await connection.query("COMMIT");
            return response;

        }catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }

    }

    static async updateBill(Body, LoggedOnUser, CompanyID, Company) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let billMaseterData = Body.billMaster;
            let billDetailData = Body.billDetail;
            let service = Body.service;

            let paymentStatus = 'Unpaid'
            console.log(billMaseterData.AddlDiscount , 'addddd');
            if (billMaseterData.AddlDiscount) {
                if (Number(billMaseterData.DueAmount - billMaseterData.AddlDiscount) === 0) {
                    billMaseterData.PaymentStatus = 'Paid';
                }
            }

            let updateBilldetail = await connection.query(
                `Update BillMaster set TrayNo = '${billMaseterData.TrayNo}' , DeliveryDate = '${billMaseterData.DeliveryDate}', BillDate = '${billMaseterData.BillDate}', DueAmount = '${billMaseterData.DueAmount - billMaseterData.AddlDiscount}', PaymentStatus = '${paymentStatus}' Where ID = '${billMaseterData.ID}'`
            );
            let oldBMaster = await connection.query(
                `Select * from PaymentDetail where BillMasterID = '${billMaseterData.ID}' and PaymentType IN( 'Customer' , 'Customer Reward')`
            );

            let oldBMasterCustomerReward = await connection.query(
                `Select * from PaymentDetail where BillMasterID = '${billMaseterData.ID}' and PaymentType IN( 'Customer Reward')`
            );



            oldBMasterCustomerReward.forEach(ele => {
                let DueA = ele.Amount + ele.DueAmount;
                let revertCustomerReward = connection.query(
                    `update PaymentDetail set Amount = 0 , DueAmount = '${DueA}' where ID = '${ele.ID}'`
                );



            })

            // if (oldBMaster.length != 0) {
            //     let UpdateRewardMasterRefund = connection.query(
            //         `update RewardMaster set Status = 'debit' where PMastID = '${oldBMaster[0].PaymentMasterID}'`
            //     );
            // }

            // let UpdateRewardMasterRefund1 = connection.query(
            //     `update RewardMaster set Status = 'debit' where PMastID = 0 and CustomerID = '${billMaseterData.CustomerID}'`
            // );



            let paidAmount = 0;

            oldBMaster.forEach((element) => {
                paidAmount = paidAmount + element.Amount;
            });

            if (paidAmount < billMaseterData.TotalAmount) {
                billMaseterData.DueAmount = billMaseterData.TotalAmount - paidAmount;
                billMaseterData.PaymentStatus = "Unpaid";
            } else if (paidAmount === billMaseterData.TotalAmount) {
                billMaseterData.DueAmount = 0;
                billMaseterData.PaymentStatus = "Paid";
            } else if (paidAmount > billMaseterData.TotalAmount) {
                billMaseterData.DueAmount = 0;
                billMaseterData.PaymentStatus = "Paid";
                let creditAmount = paidAmount - billMaseterData.TotalAmount;

                let refundPayment = await connection.query(
                    `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${billMaseterData.CustomerID}', '${CompanyID}', '${billMaseterData.ShopID}', 'Credit',now(), 'Customer Return', '', '${billMaseterData.InvoiceNo}', '0', '0', 0, 'Customer', '1',  '${LoggedOnUser.ID}', now())`
                );
                await connection.query(
                    `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${refundPayment.insertId}', '${CompanyID}', '${billMaseterData.CustomerID}', '${billMaseterData.ID}', '${billMaseterData.InvoiceNo}',-${creditAmount},'0','Customer', 'Credit', '1', '${LoggedOnUser.ID}', now())`
                );
                await connection.query(
                    `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${refundPayment.insertId}', '${CompanyID}', '${billMaseterData.CustomerID}', 0, 0,${creditAmount},'0','Customer Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`
                );
            }
            let bMaster = await connection.query(
                `Update BillMaster set Quantity = '${billMaseterData.Quantity}',  SubTotal = '${billMaseterData.SubTotal}', DiscountAmount = '${billMaseterData.DiscountAmount}', GSTAmount = '${billMaseterData.GSTAmount}', AddlDiscount = '${billMaseterData.AddlDiscount}', TotalAmount = '${billMaseterData.TotalAmount}', SubTotal = '${billMaseterData.SubTotal}', DueAmount = '${billMaseterData.DueAmount - billMaseterData.AddlDiscount}', PaymentStatus =  '${billMaseterData.PaymentStatus}' ,ProductStatus =  'Pending'   Where ID = '${billMaseterData.ID}'`
            );

            let bMasterID = billMaseterData.ID;

            // await Promise.all(
            //     billDetailData.map(async(item) => {
            for (const item of billDetailData) {
                if (item.Status === 0) {
                    await connection.query(
                        `Update BillDetail SET Status = 0, UpdatedBy = '${LoggedOnUser.ID}' Where ID = '${item.ID}'`
                    );


                    if (item.TotalAmount !== 0 && item.UpdatedBy === 0) {
                        let paymentt = item.TotalAmount;
                        let rewardpayment = 0
                        if(Company.RewardPercentage !== null  ){
                             rewardpayment = paymentt * Number(Company.RewardPercentage) / 100;
                        }else{
                            rewardpayment = 0
                        }

                        var currentDate = moment().format('YYYY-MM-DD');
                        var rewardexpirydate = moment(currentDate).add(Company.RewardExpiryDate, 'M').format('YYYY-MM-DD');
                        let qry = `insert into RewardMaster(CompanyID , CustomerID, PMastID, Payment, ExpiryDate, Status) values ('${item.CompanyID}','${billMaseterData.CustomerID}','${item.ID}', '-${rewardpayment}','${rewardexpirydate}', 'Credit')`;
                        let Reward = await connection.query(qry);
                    }

                    // let revertRewardMaster = connection.query(
                    //     `update RewardMaster set Status = 'debit'  where PMastID = '${item.BillID}'`
                    // );


                    if (item.PreOrder === 1) {
                        await connection.query(
                            `UPDATE BarcodeMaster SET CurrentStatus = "Pre Order", PreOrder = 1, SupplierID = NULL, BillDetailID = NULL WHERE BillDetailID = '${item.ID}'`
                        );
                    } else if (item.Manual === true || item.Manual === 1) {
                        await connection.query(
                            `UPDATE BarcodeMaster SET CurrentStatus = "Not Available", SupplierID = null, MeasurementID = NULL, Family = null, Option = null, BillDetailID = NULL WHERE BillDetailID = '${item.ID}'`
                        );
                    } else {
                        await connection.query(
                            `UPDATE BarcodeMaster SET CurrentStatus = "Available", SupplierID = null, MeasurementID = NULL, Family = null, Option = null, BillDetailID = NULL WHERE BillDetailID = '${item.ID}'`
                        );
                    }
                } else if (item.Status === 2) {
                    let preorder = 0;
                    if (item.PreOrder === true) {
                        preorder = 1;
                    }

                    let manual = 0;
                    if (item.Manual === true) {
                        manual = 1;
                    }

                    let wholesale = 0
                    if (item.WholeSale === true) {
                        wholesale = 1;
                    }


                    let result = await connection.query(
                        `insert into BillDetail (BillID,CompanyID,ProductTypeID,ProductTypeName,ProductName,HSNCode,UnitPrice,Quantity,SubTotal,DiscountPercentage,DiscountAmount,GSTPercentage,GSTAmount,GSTType,TotalAmount,WholeSale, Manual, PreOrder,BaseBarCode,Barcode,Status,MeasurementID, Option, Family,CreatedBy,CreatedOn, SupplierID, Remark, Warranty, ProductExpDate) values ('${bMasterID}', '${CompanyID}', '${item.ProductTypeID}','${item.ProductTypeName}','${item.ProductName}','${item.HSNCode}', '${item.UnitPrice}','${item.Quantity}', '${item.SubTotal}', '${item.DiscountPercentage}', '${item.DiscountAmount}','${item.GSTPercentage}', '${item.GSTAmount}', '${item.GSTType}' , '${item.TotalAmount}', '${wholesale}','${manual}', ${preorder}, '${item.BaseBarCode}' , '${item.Barcode}' , '1','${item.MeasurementID}' ,'${item.Option}' ,'${item.Family}' , '${LoggedOnUser.ID}', now(), '${item.SupplierID}', '${item.Remark}', '${item.Warranty}', '${item.ProductExpDate}')`
                    );

                    let elex = await connection.query(
                        `select * from BillDetail where BillID = '${bMasterID}' and ID = '${result.insertId}'`
                    );

                    let ele = elex[0];

                    if (ele.PreOrder === 1) {
                        let count = ele.Quantity;
                        let baseBarCode = parseInt(ele.BaseBarCode) * 1000;
                        let j = 0;
                        for (j = 0; j < count; j++) {
                            let qrry = `INSERT INTO BarcodeMaster (CompanyID, ShopID, PurchaseDetailID, BillDetailID, GSTType, GSTPercentage, BarCode, AvailableDate, CurrentStatus,
                                    RetailPrice, RetailDiscount, MultipleBarcode, ForWholeSale, WholeSalePrice, WholeSaleDiscount, PreOrder,Po, TransferStatus,
                                    TransferToShop, MeasurementID, OPTION, Family, STATUS, CreatedBy, CreatedOn) VALUES ('${CompanyID}', '${billMaseterData.ShopID}', 0, '${ele.ID}', '${ele.GSTType}', '${ele.GSTPercentage}', '${ele.Barcode}', now() , 'Pre Order', '${ele.UnitPrice}', 0 ,'0','${ele.WholeSale}','${ele.UnitPrice}',0, '1', '1','', 0, '${ele.MeasurementID}','${ele.Option}','${ele.Family}', '1', '${LoggedOnUser.ID}', now())`;
                            await connection.query(qrry);
                        }
                    } else if (ele.Manual === 1) {
                        let selectRows1 = await connection.query(
                            `SELECT * FROM BarcodeMaster WHERE CompanyID = '${CompanyID}' AND ShopID = '${billMaseterData.ShopID}' AND CurrentStatus = "Not Available" AND STATUS =1  LIMIT ${ele.Quantity}`
                        );



                        await Promise.all(
                            selectRows1.map(async (ele1) => {
                                let qry1 = `Update BarcodeMaster set CurrentStatus = "Sold" , MeasurementID = '${ele.MeasurementID}', Family = '${ele.Family}',Option = '${ele.Option}', BillDetailID = '${ele.ID}', SupplierID = '${ele.SupplierID}' Where ID = '${ele1.ID}'`;
                                let resultn = await connection.query(qry1);
                            })
                        );

                    } else {


                        let selectRows = await connection.query(
                            `SELECT * FROM BarcodeMaster WHERE CompanyID = '${CompanyID}' AND ShopID = '${billMaseterData.ShopID}' AND CurrentStatus = "Available" AND STATUS =1 AND Barcode = '${ele.Barcode}' LIMIT ${ele.Quantity}`
                        );


                        await Promise.all(
                            selectRows.map(async (ele1) => {
                                let qry = `Update BarcodeMaster set CurrentStatus = "Sold" , MeasurementID = '${ele.MeasurementID}', Family = '${ele.Family}',Option = '${ele.Option}', BillDetailID = '${ele.ID}', SupplierID = '${ele.SupplierID}' Where ID = '${ele1.ID}'`;
                                let resultn = await connection.query(qry);
                            })
                        );
                    }

                }
            }


            let UpdatedProduct = await connection.query(
                `Select * from BillDetail where BillID = '${billMaseterData.ID}' and ProductStatus = 1`
            );

            if (UpdatedProduct.length === billDetailData.length) {
                let updateBillMaster = await connection.query(
                    `Update BillMaster set ProductStatus = 'Deliverd' Where ID = '${billMaseterData.ID}'`
                );
            } else {
                let updateBillMaster1 = await connection.query(
                    `Update BillMaster set ProductStatus = 'Pending' Where ID = '${billMaseterData.ID}'`
                );
            }





            // let oldBMasterCustomerReward1 = await connection.query(
            //     `Select * from PaymentDetail where BillMasterID = '${billDetailData[0].BillID}'`
            // );

            // console.log(billDetailData , 'billDetailData');

            // oldBMasterCustomerReward1.forEach(ele => {
            //     if (ele.Status === 0) {

            //     let revertRewardMaster = connection.query(
            //         `update RewardMaster set Status = 'debit'  where PMastID = '${ele.PaymentMasterID}'`
            //     );
            // }

            // })


            //     })
            // );

            await Promise.all(
                service.map(async (ele) => {
                    if (ele.Status === 0) {
                        let result1 = await connection.query(
                            `Update BillService Set Status = 0 Where ID = '${ele.ID}'`
                        );
                    } else if (ele.Status === 2) {
                        let result1 = await connection.query(
                            `insert into BillService ( BillID, ServiceType ,CompanyID,Description, Price, GSTPercentage, GSTAmount, GSTType, TotalAmount, Status,CreatedBy,CreatedOn ) values ('${bMasterID}', '${ele.ServiceType}', '${CompanyID}',  '${ele.Description}', '${ele.Price}', '${ele.GSTPercentage}', '${ele.GSTAmount}', '${ele.GSTType}', '${ele.TotalAmount}', '1', '${LoggedOnUser.ID}', now())`
                        );
                    }
                })
            );


            // Doctor Commission Calculations below. Idea is to first find If doctor is eligible for Commission then based on the commission type calculate amount and update BillMaster table
            let doctorcommissionData = await connection.query(
                `select * from CommissionDetail where UserType = 'Doctor' and  BillMasterID = '${bMasterID}'`
            );
            let delFlag1 = false;
            if (doctorcommissionData.length === 0) {
                delFlag1 = true;
            } else if (doctorcommissionData[0].CommissionMaterID === 0) {
                await connection.query(
                    `delete from CommissionDetail where UserType = 'Doctor' and  BillMasterID = '${bMasterID}'`
                );
                delFlag1 = true;
            }
            if (delFlag1) {
                let commission = { Type: 0, Mode: 0, Value: 0, Amount: 0 };

                let doctorData = await connection.query(
                    `select * from Doctor where Doctor.ID = '${billMaseterData.Doctor}'`
                );
                if (doctorData.length !== 0 && doctorData[0].CommissionType == 1) {
                    commission.Type = doctorData[0].CommissionType;
                    if (doctorData[0].CommissionMode == 2) {
                        commission.Amount = doctorData[0].CommissionValue;
                        commission.Mode = doctorData[0].CommissionMode;
                        commission.Value = doctorData[0].CommissionValue;
                    } else if (doctorData[0].CommissionMode == 1) {
                        commission.Type = doctorData[0].CommissionType;
                        commission.Amount =
                            (+billMaseterData.SubTotal * +doctorData[0].CommissionValue) / 100;
                        commission.Mode = doctorData[0].CommissionMode;
                        commission.Value = doctorData[0].CommissionValue;
                    }
                } else if (doctorData.length !== 0 && doctorData[0].CommissionType == 2) {
                    let doctorResultB = await connection.query(
                        `SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType = 1`
                    );
                    let doctorResultNB = await connection.query(
                        `SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType <> 1`
                    );
                    commission.Type = doctorData[0].CommissionType;
                    if (doctorData[0].CommissionMode == 2) {
                        // commission.Amount = subTotal;
                        // commission.Mode = doctorData[0].CommissionMode;
                        // commission.Value = doctorData[0].CommissionValue;
                    } else if (doctorData[0].CommissionMode == 1) {
                        commission.Type = doctorData[0].CommissionType;
                        commission.Amount =
                            (doctorResultB[0].SubTotalVal * +doctorData[0].CommissionValue) / 100 +
                            (doctorResultNB[0].SubTotalVal * +doctorData[0].CommissionValueNB) /
                            100;
                        commission.Mode = doctorData[0].CommissionMode;
                        commission.Value = doctorData[0].CommissionValue;
                    }
                }

                if (commission.Type !== 0 && commission.Amount !== 0) {
                    await connection.query(
                        `insert into CommissionDetail (CompanyID,ShopID,CommissionMasterID, UserType, UserID,BillMasterID, CommissionMode, CommissionType, CommissionValue, CommissionAmount, Status,CreatedBy,CreatedOn ) values ('${CompanyID}', '${billMaseterData.ShopID}', '0','Doctor', '${billMaseterData.Doctor}', '${bMasterID}', '${commission.Mode}','${commission.Type}','${commission.Value}','${commission.Amount}',  '1',  '${LoggedOnUser.ID}', now())`
                    );
                }
            }


            let usercommissionData = await connection.query(
                `select * from CommissionDetail where UserType = 'Employee' and  BillMasterID = '${bMasterID}'`
            );
            let delFlag2 = false;
            if (usercommissionData.length === 0) {
                delFlag2 = true;
            } else if (usercommissionData[0].CommissionMaterID === 0) {
                await connection.query(
                    `delete from CommissionDetail where UserType = 'Employee' and  BillMasterID = '${bMasterID}'`
                );
                delFlag2 = true;
            }
            if (delFlag2) {
                let commission1 = { Type: 0, Mode: 0, Value: 0, Amount: 0 };
                // Employee Commission Calculations below. Idea is to first find If Employee is eligible for Commission then based on the commission type calculate amount and update BillMaster table
                let userData = await connection.query(
                    `select * from User where User.ID = '${LoggedOnUser.ID}'`
                );
                if (userData.length !== 0 && userData[0].CommissionType == 1) {
                    commission1.Type = userData[0].CommissionType;
                    if (userData[0].CommissionMode == 2) {
                        commission1.Amount = userData[0].CommissionValue;
                        commission1.Mode = userData[0].CommissionMode;
                        commission1.Value = userData[0].CommissionValue;
                    } else if (userData[0].CommissionMode == 1) {
                        commission1.Type = userData[0].CommissionType;
                        commission1.Amount =
                            (+billMaseterData.SubTotal * +userData[0].CommissionValue) /
                            100;
                        commission1.Mode = userData[0].CommissionMode;
                        commission1.Value = userData[0].CommissionValue;
                    }
                } else if (
                    userData.length !== 0 &&
                    userData[0].CommissionType == 2
                ) {
                    let userResultB = await connection.query(
                        `SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType = 1`
                    );
                    let userResultNB = await connection.query(
                        `SELECT SUM(BillDetail.SubTotal) as SubTotalVal FROM BillDetail LEFT JOIN BarcodeMaster ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BillDetail.BillID = '${bMasterID}' AND BrandType <> 1`
                    );
                    commission1.Type = userData[0].CommissionType;
                    if (userData[0].CommissionMode == 2) {
                        // commission1.Amount = subTotal;
                        // commission1.Mode = userData[0].CommissionMode;
                        // commission1.Value = userData[0].CommissionValue;
                    } else if (userData[0].CommissionMode == 1) {
                        commission1.Type = userData[0].CommissionType;
                        commission1.Amount =
                            (userResultB[0].SubTotalVal *
                                +userData[0].CommissionValue) /
                            100 +
                            (userResultNB[0].SubTotalVal *
                                +userData[0].CommissionValueNB) /
                            100;
                        commission1.Mode = userData[0].CommissionMode;
                        commission1.Value = userData[0].CommissionValue;
                    }
                }

                if (commission1.Type !== 0 && commission1.Amount !== 0) {
                    await connection.query(
                        `insert into CommissionDetail (CompanyID,ShopID,CommissionMasterID, UserType, UserID,BillMasterID, CommissionMode, CommissionType, CommissionValue, CommissionAmount, Status,CreatedBy,CreatedOn ) values ('${CompanyID}', '${billMaseterData.ShopID}', '0','Employee', '${LoggedOnUser.ID}', '${bMasterID}', '${commission1.Mode}','${commission1.Type}','${commission1.Value}','${commission1.Amount}',  '1',  '${LoggedOnUser.ID}', now())`
                    );
                }
            }



            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async purchaseReturn(Body, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let Barcode = await connection.query(
                `SELECT * FROM BarcodeMaster WHERE BarcodeMaster.CompanyID = '${CompanyID}' AND BarcodeMaster.CurrentStatus = 'Available' AND PurchaseDetailID = ${Body.PurchaseDetailID} LIMIT ${Body.ReturnQuantity}`
            );

            let updateBarcodeMaster = Barcode.forEach((ele) => {
                connection.query(
                    `Update BarcodeMaster SET CurrentStatus = 'Return To Supplier' where ID = '${ele.ID}' AND CompanyID = '${CompanyID}'`
                );
            });

            let cal = { DiscountAmount: "", SubTotal: "", TotalAmount: 0 };
            cal.SubTotal = Body.UnitPrice * Body.ReturnQuantity;
            if (Body.DiscountPercentage !== 0) {
                cal.DiscountAmount = cal.subtotal / Body.DiscountPercentage;
            } else {
                cal.DiscountAmount = 0;
            }
            cal.SubTotal = cal.SubTotal - cal.DiscountAmount;
            cal.GSTAmount = (cal.SubTotal * Body.GSTPercentage) / 100;
            cal.TotalAmount = cal.SubTotal + (cal.SubTotal * Body.GSTPercentage) / 100;

            let itemDetail = await connection.query(
                `select * from PurchaseDetail where ID = '${Body.PurchaseDetailID}'`
            );

            // let insertRecordPMaster = await connection.query(
            //     `insert into PurchaseMaster (CompanyID, ShopID, PurchaseDate,PaymentStatus, InvoiceNo, Quantity, SubTotal, DiscountAmount, GSTAmount, TotalAmount) values ('${Body.CompanyID}','${Body.ShopID}','${Body.PurchaseDate}','${Body.PaymentStatus}','${Body.InvoiceNo}','${Body.ReturnQuantity}','-${cal.SubTotal}','-${cal.DiscountAmount}','-${cal.GSTAmount}','-${cal.TotalAmount}')`
            // );

            // let insertRecordPDetail = await connection.query(
            //     `insert into PurchaseDetail(PurchaseID, CompanyID, ProductName, ProductTypeID, ProductTypeName, UnitPrice, Quantity, SubTotal, DiscountPercentage, DiscountAmount, GSTAmount, GSTType, TotalAmount, ReturnRef) values('${insertRecordPMaster.insertId}', '${Body.CompanyID}','${itemDetail[0].ProductName}','${itemDetail[0].ProductTypeID}','${itemDetail[0].ProductTypeName}','${Body.UnitPrice}','${Body.ReturnQuantity}','-${cal.SubTotal}','${Body.DiscountPercentage}','-${cal.DiscountAmount}','-${cal.GSTAmount}','${Body.GSTType}', '-${cal.TotalAmount}', '${Body.PurchaseDetailID}')`
            // );
            // return insertRecordPMaster;
            let paymentPMaster = await connection.query(
                `insert into PaymentMaster (CustomerID , CompanyID, ShopID, PaymentType,CreditType, PaymentDate, PaidAmount) values ('${Body.SupplierID}','${Body.CompanyID}','${Body.ShopID}','Supplier','Debit',now(),'${cal.TotalAmount}')`
            );

            let paymentDetail = await connection.query(
                `insert into PaymentDetail (PaymentMasterID, BillID, BillMasterID, CustomerID , CompanyID, Amount, PaymentType,Credit) values ('${paymentPMaster.insertId}','0','0','${Body.SupplierID}','${Body.CompanyID}','${cal.TotalAmount}','Vendor Credit','Credit')`
            );
            return paymentDetail;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async applyPayment(Body, UserMode, Mode, LoggedOnUser, CompanyID, Company) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            console.log(Body, 'payment');
            switch (UserMode) {
                case "Customer":
                    let unpaidList = Body.pendingPaymentList;
                    let customerCredit = Body.CustomerCredit;
                    let pid = 0;
                    if (customerCredit !== 0 && Body.ApplyReturn === true) {
                        for (const item of unpaidList) {
                            let ccList = await connection.query(
                                `Select * from PaymentDetail where CustomerID = '${Body.CustomerID}' And CompanyID = '${CompanyID}' And PaymentType = 'Customer Credit' and Credit = 'Debit' and Amount <> 0`
                            );
                            let itemDueAmount = item.DueAmount;
                            for (const cred of ccList) {
                                let credAmount = cred.Amount;
                                if (itemDueAmount !== 0) {
                                    if (credAmount >= itemDueAmount) {
                                        credAmount = credAmount - itemDueAmount;
                                        item.Amount = itemDueAmount;
                                        item.DueAmount = 0;
                                        item.PaymentStatus = "Paid";

                                        let qry3 = `Update PaymentDetail Set Amount = '${credAmount}', DueAmount = '0', UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','0','Customer Credit', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row

                                        let qry2 = `Update BillMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    } else {
                                        item.DueAmount = item.DueAmount - credAmount;
                                        item.Amount = credAmount;
                                        item.PaymentStatus = "Unpaid";
                                        itemDueAmount = 0;
                                        let qry3 = `Update PaymentDetail Set Amount = 0, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','Customer Credit', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row
                                        let qry2 = `Update BillMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    }


                                }
                            }
                            if (customerCredit !== 0) {
                                let paymentt = customerCredit;
                                let rewardpayment = paymentt * Number(Company.RewardPercentage) / 100;
                                var currentDate = moment().format('YYYY-MM-DD');
                                var rewardexpirydate = moment(currentDate).add(Company.RewardExpiryDate, 'M').format('YYYY-MM-DD');
                                let qry = `insert into RewardMaster(CompanyID , CustomerID, PMastID, Payment, ExpiryDate, Status) values ('${CompanyID}','${Body.CustomerID}','${ccList[0].PaymentMasterID}', '${rewardpayment}','${rewardexpirydate}', 'Credit')`;
                                let Reward = await connection.query(qry);
                            }
                        }
                        let whereList = `CustomerID  =  ${Body.CustomerID} and  PaymentStatus  <>  'paid'`;

                        let qry = this.getShortListQueryByParem(
                            "BillMaster",
                            whereList,
                            CompanyID
                        );
                        unpaidList = await connection.query(qry);
                        response.result = "Success";
                    }
                    //  apply rewar ammount

                    if (Body.ApplyReward === true && Body.RewardPayment !== null) {
                        let tempAmount = Body.RewardPayment;
                        var currentDate = moment().format('YYYY-MM-DD');
                        var rewardexpirydate = moment(currentDate).add(Company.RewardExpiryDate, 'M').format('YYYY-MM-DD');
                        // let qry = `Update RewardMaster SET  Status = 'Debit' where CustomerID = ${Body.CustomerID} and CompanyID = '${CompanyID}'`;

                        let pMaster = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${Body.CustomerID}', '${CompanyID}', '${Body.ShopID}', '${Body.CreditType}',now(), 'Customer Reward', '${Body.CardNo}', '${Body.PaymentReferenceNo}', '${Body.PayableAmount}', '${Body.RewardPayment}', '${Body.Comments}', 'Customer',  '1',  '${LoggedOnUser.ID}', now())`
                        );
                        let pMasterID = pMaster.insertId;
                        let qry = `insert into RewardMaster(CompanyID , CustomerID, PMastID, Payment, ExpiryDate, Status) values('${CompanyID}', '${Body.CustomerID}', '${pMasterID}', '-${Body.RewardPayment}', '${rewardexpirydate}', 'Credit')`;
                        let updateRewardTab = await connection.query(qry);
                        for (const item of unpaidList) {
                            if (tempAmount !== 0) {
                                if (tempAmount >= item.DueAmount) {
                                    tempAmount = tempAmount - item.DueAmount;
                                    item.Amount = item.DueAmount;
                                    item.DueAmount = 0;
                                    item.PaymentStatus = "Paid";
                                } else {
                                    item.DueAmount = item.DueAmount - tempAmount;
                                    item.Amount = tempAmount;
                                    item.PaymentStatus = "Unpaid";
                                    tempAmount = 0;
                                }
                                let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${item.CompanyID}', '${item.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','Customer Reward', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                                let pDetail = await connection.query(qry);
                                let qry2 = `Update BillMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                let bMaster = await connection.query(qry2);
                            }
                        }

                        //  tempAmmount !== 0 then
                        if (tempAmount !== 0) {
                            let paymentt = tempAmount;

                            let rewardpayment = paymentt;
                            var currentDate = moment().format('YYYY-MM-DD');
                            var rewardexpirydate = moment(currentDate).add(Company.RewardExpiryDate, 'M').format('YYYY-MM-DD');
                            let qry = `insert into RewardMaster(CompanyID , CustomerID, PMastID, Payment, ExpiryDate, Status) values ('${CompanyID}','${Body.CustomerID}','${pid}', '${rewardpayment}','${rewardexpirydate}', 'Credit')`;
                            let Reward = await connection.query(qry);
                        }
                        if (Body.PaidAmount !== 0 && unpaidList.length === 0) {
                            let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pid}', '${CompanyID}', '${Body.CustomerID}', '', '','${Body.PaidAmount}','0','Customer Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                            let pDetail = await connection.query(qry);
                        }
                    }

                    let tempAmount = Body.PaidAmount;
                    if (Body.PaidAmount !== 0 && unpaidList.length !== 0 && Body.ApplyReturn == false) {
                        let pMaster = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${Body.CustomerID}', '${CompanyID}', '${Body.ShopID}', '${Body.CreditType}',now(), '${Body.PaymentMode}', '${Body.CardNo}', '${Body.PaymentReferenceNo}', '${Body.PayableAmount}', '${Body.PaidAmount}', '${Body.Comments}', 'Customer',  '1',  '${LoggedOnUser.ID}', now())`
                        );

                        let pMasterID = pMaster.insertId;
                        pid = pMaster.insertId;
                        response.result = "Success";

                        for (const item of unpaidList) {
                            if (tempAmount !== 0) {
                                if (tempAmount >= item.DueAmount) {
                                    tempAmount = tempAmount - item.DueAmount;
                                    item.Amount = item.DueAmount;
                                    item.DueAmount = 0;
                                    item.PaymentStatus = "Paid";
                                } else {
                                    item.DueAmount = item.DueAmount - tempAmount;
                                    item.Amount = tempAmount;
                                    item.PaymentStatus = "Unpaid";
                                    tempAmount = 0;
                                }
                                let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${item.CompanyID}', '${item.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','${UserMode}', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                                let pDetail = await connection.query(qry);
                                let qry2 = `Update BillMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                let bMaster = await connection.query(qry2);
                            }

                            //  reward

                            if (Body.PaidAmount !== 0) {
                                let paymentt = Body.PaidAmount;
                                let rewardpayment = paymentt * Number(Company.RewardPercentage) / 100;
                                var currentDate = moment().format('YYYY-MM-DD');
                                var rewardexpirydate = moment(currentDate).add(Company.RewardExpiryDate, 'M').format('YYYY-MM-DD');
                                let qry = `insert into RewardMaster(CompanyID , CustomerID, PMastID, Payment, ExpiryDate, Status) values ('${CompanyID}','${Body.CustomerID}','${item.ID}', '${rewardpayment}','${rewardexpirydate}', 'Credit')`;
                                let Reward = await connection.query(qry);
                            }
                        }
                        if (tempAmount !== 0) {
                            let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${CompanyID}', '${Body.CustomerID}', '', '','${tempAmount}','0','Customer Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                            let pDetail = await connection.query(qry);
                        }


                    }

                    // if (Body.PaidAmount !== 0) {
                    //     let paymentt = Body.PaidAmount;
                    //     let rewardpayment = paymentt * Number(Company.RewardPercentage) / 100;
                    //     var currentDate = moment().format('YYYY-MM-DD');
                    //     var rewardexpirydate = moment(currentDate).add(Company.RewardExpiryDate, 'M').format('YYYY-MM-DD');
                    //     let qry = `insert into RewardMaster(CompanyID , CustomerID, PMastID, Payment, ExpiryDate, Status) values ('${CompanyID}','${Body.CustomerID}','${pid}', '${rewardpayment}','${rewardexpirydate}', 'Credit')`;
                    //     let Reward = await connection.query(qry);
                    // }


                    break;

                case "Vendor":
                    let unpaidList1 = Body.pendingPaymentList;
                    let customerCredit1 = Body.CustomerCredit;
                    unpaidList1.forEach(e =>{
                        if(e.CustomerID === undefined){
                           e.CustomerID = 0;
                        }
                    })
                    if (customerCredit1 !== 0) {
                        for (const item of unpaidList1) {
                            let ccList1 = await connection.query(
                                `Select * from PaymentDetail where CustomerID = '${Body.CustomerID}' And CompanyID = '${CompanyID}' And PaymentType = 'Vendor Credit' and Credit = 'Credit' and Amount <> 0`
                            );
                            let itemDueAmount = item.DueAmount;
                            for (const cred of ccList1) {
                                let credAmount1 = cred.Amount;
                                if (itemDueAmount !== 0) {
                                    if (credAmount1 >= itemDueAmount) {
                                        credAmount1 = credAmount1 - itemDueAmount;
                                        item.Amount = itemDueAmount;
                                        item.DueAmount = 0;
                                        item.PaymentStatus = "Paid";

                                        let qry3 = `Update PaymentDetail Set BillID = '${item.InvoiceNo}' ,  Amount = '${credAmount1}', DueAmount = '0', UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now(),CreatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','0','Vendor Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row

                                        let qry2 = `Update PurchaseMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    } else {
                                        item.DueAmount = item.DueAmount - credAmount1;
                                        item.Amount = credAmount1;
                                        item.PaymentStatus = "Unpaid";
                                        itemDueAmount = 0;
                                        let qry3 = `Update PaymentDetail Set BillID = '${item.InvoiceNo}' , Amount = 0, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now(),CreatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','Vendor Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row
                                        let qry2 = `Update PurchaseMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    }
                                }
                            }
                        }
                        let whereList = `SupplierID  =  ${Body.CustomerID} and  PaymentStatus  <>  'paid'`;

                        let qry = this.getShortListQueryByParem(
                            "PurchaseMaster",
                            whereList,
                            CompanyID
                        );
                        unpaidList1 = await connection.query(qry);
                        response.result = "Success";
                    }

                    let tempAmount1 = Body.PaidAmount;
                    if (Body.PaidAmount !== 0) {
                        let pMaster = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${Body.CustomerID}', '${CompanyID}', '${Body.ShopID}', '${Body.CreditType}',now(), '${Body.PaymentMode}', '${Body.CardNo}', '${Body.PaymentReferenceNo}', '${Body.PayableAmount}', '${Body.PaidAmount}', '${Body.Comments}', 'Supplier', '1',  '${LoggedOnUser.ID}', now())`
                        );

                        let pMasterID = pMaster.insertId;

                        response.result = "Success";

                        for (const item of unpaidList1) {
                            if (tempAmount1 !== 0) {
                                if (tempAmount1 >= item.DueAmount) {
                                    tempAmount1 = tempAmount1 - item.DueAmount;
                                    item.Amount = item.DueAmount;
                                    item.DueAmount = 0;
                                    item.PaymentStatus = "Paid";
                                } else {
                                    item.DueAmount = item.DueAmount - tempAmount1;
                                    item.Amount = tempAmount1;
                                    item.PaymentStatus = "Unpaid";
                                    tempAmount1 = 0;
                                }
                                let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${item.CompanyID}', '${item.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','${UserMode}', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                let pDetail = await connection.query(qry);
                                let qry2 = `Update PurchaseMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                let bMaster = await connection.query(qry2);
                            }
                        }
                        if (tempAmount1 !== 0) {
                            let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${CompanyID}', '${Body.CustomerID}', '', '','${tempAmount1}','0','Vendor Credit', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                            let pDetail = await connection.query(qry);
                        }
                    }
                    break;

                case "Fitter":
                    let unpaidListf = Body.pendingPaymentList;
                    let customerCreditf = Body.CustomerCredit;
                    if (customerCreditf !== 0) {
                        for (const item of unpaidListf) {
                            let ccList1 = await connection.query(
                                `Select * from PaymentDetail where CustomerID = '${Body.CustomerID}' And CompanyID = '${CompanyID}' And PaymentType = 'Fitter Credit' and Credit = 'Credit' and Amount <> 0`
                            );
                            let itemDueAmount = item.DueAmount;
                            for (const cred of ccList1) {
                                let credAmount1 = cred.Amount;
                                if (itemDueAmount !== 0) {
                                    if (credAmount1 >= itemDueAmount) {
                                        credAmount1 = credAmount1 - itemDueAmount;
                                        item.Amount = itemDueAmount;
                                        item.DueAmount = 0;
                                        item.PaymentStatus = "Paid";

                                        let qry3 = `Update PaymentDetail Set Amount = '${credAmount1}', DueAmount = '0', UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment
                                        let qryy = `Update PaymentMaster Set PayableAmount = ${Body.PayableAmount}, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.PaymentMasterID}`;
                                        let xpp = await connection.query(qryy);
                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','0','Fitter Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row

                                        let qry2 = `Update FitterMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    } else {
                                        item.DueAmount = item.DueAmount - credAmount1;
                                        item.Amount = credAmount1;
                                        item.PaymentStatus = "Unpaid";
                                        itemDueAmount = 0;
                                        let qry3 = `Update PaymentDetail Set Amount = 0, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment
                                        let qryy = `Update PaymentMaster Set PayableAmount = ${Body.PayableAmount}, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.PaymentMasterID}`;
                                        let xpp = await connection.query(qryy);
                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','Fitter Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row
                                        let qry2 = `Update FitterMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    }
                                }
                            }
                        }
                        let whereList = `FitterID  =  ${Body.CustomerID} and  PaymentStatus  <>  'paid'`;

                        let qry = this.getShortListQueryByParem(
                            "FitterMaster",
                            whereList,
                            CompanyID
                        );
                        unpaidListf = await connection.query(qry);
                        response.result = "Success";
                    }

                    let tempAmountf = Body.PaidAmount;
                    Body.PayableAmount = Body.PayableAmount - customerCreditf;
                    if (Body.PaidAmount != 0) {
                        let pMaster = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${Body.CustomerID}', '${CompanyID}', '${Body.ShopID}', '${Body.CreditType}',now(), '${Body.PaymentMode}', '${Body.CardNo}', '${Body.PaymentReferenceNo}', '${Body.PayableAmount}', '${Body.PaidAmount}', '${Body.Comments}', 'Fitter',  '1',  '${LoggedOnUser.ID}', now())`
                        );

                        let pMasterID = pMaster.insertId;

                        response.result = "Success";

                        for (const item of unpaidListf) {
                            if (tempAmountf !== 0) {
                                if (tempAmountf >= item.DueAmount) {
                                    tempAmountf = tempAmountf - item.DueAmount;
                                    item.Amount = item.DueAmount;
                                    item.DueAmount = 0;
                                    item.PaymentStatus = "Paid";
                                } else {
                                    item.DueAmount = item.DueAmount - tempAmountf;
                                    item.Amount = tempAmountf;
                                    item.PaymentStatus = "Unpaid";
                                    tempAmountf = 0;
                                }
                                let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${item.CompanyID}', '${item.FitterID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','${UserMode}', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                let pDetail = await connection.query(qry);
                                let qry2 = `Update FitterMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                let bMaster = await connection.query(qry2);
                            }
                        }
                        if (tempAmountf !== 0) {
                            let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${CompanyID}', '${Body.CustomerID}', 0, 0,'${tempAmountf}','0','Fitter Credit', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                            let pDetail = await connection.query(qry);
                        }
                    }
                    break;

                case "Doctor":
                    let unpaidListd = Body.pendingPaymentList;
                    let customerCreditd = Body.CustomerCredit;
                    if (customerCreditd !== 0) {
                        for (const item of unpaidListd) {
                            let ccListd = await connection.query(
                                `Select * from PaymentDetail where CustomerID = '${Body.CustomerID}' And CompanyID = '${CompanyID}' And PaymentType = 'Doctor Credit' and Credit = 'Credit' and Amount <> 0`
                            );
                            let itemDueAmount = item.DueAmount;
                            for (const cred of ccListd) {
                                let credAmount1 = cred.Amount;
                                if (itemDueAmount !== 0) {
                                    if (credAmount1 >= itemDueAmount) {
                                        credAmount1 = credAmount1 - itemDueAmount;
                                        item.Amount = itemDueAmount;
                                        item.DueAmount = 0;
                                        item.PaymentStatus = "Paid";

                                        let qry3 = `Update PaymentDetail Set Amount = '${credAmount1}', DueAmount = '0', UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','0','Doctor Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row

                                        let qry2 = `Update CommissionMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    } else {
                                        item.DueAmount = item.DueAmount - credAmount1;
                                        item.Amount = credAmount1;
                                        item.PaymentStatus = "Unpaid";
                                        itemDueAmount = 0;
                                        let qry3 = `Update PaymentDetail Set Amount = 0, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','Doctor Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row
                                        let qry2 = `Update CommissionMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    }
                                }
                            }
                        }
                        let whereList = `UserID  =  ${Body.CustomerID} and  PaymentStatus  <>  'paid' and UserType = '${Body.PaymentType}'`;

                        let qry = this.getShortListQueryByParem(
                            "CommissionMaster",
                            whereList,
                            CompanyID
                        );
                        unpaidListd = await connection.query(qry);
                        response.result = "Success";
                    }

                    let tempAmountd = Body.PaidAmount;
                    if (Body.PaidAmount !== 0) {
                        let pMaster = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${Body.CustomerID}', '${CompanyID}', '${Body.ShopID}', '${Body.CreditType}',now(), '${Body.PaymentMode}', '${Body.CardNo}', '${Body.PaymentReferenceNo}', '${Body.PayableAmount}', '${Body.PaidAmount}', '${Body.Comments}', 'Doctor',  '1',  '${LoggedOnUser.ID}', now())`
                        );

                        let pMasterID = pMaster.insertId;

                        response.result = "Success";

                        for (const item of unpaidListd) {
                            if (tempAmountd !== 0) {
                                if (tempAmountd >= item.DueAmount) {
                                    tempAmountd = tempAmountd - item.DueAmount;
                                    item.Amount = item.DueAmount;
                                    item.DueAmount = 0;
                                    item.PaymentStatus = "Paid";
                                } else {
                                    item.DueAmount = item.DueAmount - tempAmountd;
                                    item.Amount = tempAmountd;
                                    item.PaymentStatus = "Unpaid";
                                    tempAmountd = 0;
                                }
                                let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${item.CompanyID}', '${item.UserID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','${UserMode}', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                let pDetail = await connection.query(qry);
                                let qry2 = `Update  CommissionMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                let bMaster = await connection.query(qry2);
                            }
                        }
                        if (tempAmountd !== 0) {
                            let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${CompanyID}', '${Body.CustomerID}', 0, 0,'${tempAmountd}','0','Doctor Credit', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                            let pDetail = await connection.query(qry);
                        }
                    }
                    break;

                case "Employee1":
                    let unpaidListe = Body.pendingPaymentList;
                    let customerCredite = Body.CustomerCredit;
                    if (customerCredite !== 0) {
                        for (const item of unpaidListe) {
                            let ccListe = await connection.query(
                                `Select * from PaymentDetail where CustomerID = '${Body.CustomerID}' And CompanyID = '${CompanyID}' And PaymentType = 'Employee Credit' and Credit = 'Credit' and Amount <> 0`
                            );
                            let itemDueAmount = item.DueAmount;
                            for (const cred of ccListe) {
                                let credAmount1 = cred.Amount;
                                if (itemDueAmount !== 0) {
                                    if (credAmount1 >= itemDueAmount) {
                                        credAmount1 = credAmount1 - itemDueAmount;
                                        item.Amount = itemDueAmount;
                                        item.DueAmount = 0;
                                        item.PaymentStatus = "Paid";

                                        let qry3 = `Update PaymentDetail Set Amount = '${credAmount1}', DueAmount = '0', UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','0','Employee Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row

                                        let qry2 = `Update CommissionMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    } else {
                                        item.DueAmount = item.DueAmount - credAmount1;
                                        item.Amount = credAmount1;
                                        item.PaymentStatus = "Unpaid";
                                        itemDueAmount = 0;
                                        let qry3 = `Update PaymentDetail Set Amount = 0, UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now() where ID = ${cred.ID}`;
                                        let xp = await connection.query(qry3); // update payment

                                        let qry4 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${cred.PaymentMasterID}', '${cred.CompanyID}', '${cred.CustomerID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','Employee Credit', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                        let xpn = await connection.query(qry4); // new payment credit row
                                        let qry2 = `Update CommissionMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                        let bMaster = await connection.query(qry2);
                                    }
                                }
                            }
                        }
                        let whereList = `UserID  =  ${Body.CustomerID} and  PaymentStatus  <>  'paid' and UserType = 'Employee'`;

                        let qry = this.getShortListQueryByParem(
                            "CommissionMaster",
                            whereList,
                            CompanyID
                        );
                        unpaidListe = await connection.query(qry);
                        response.result = "Success";
                    }

                    let tempAmounte = Body.PaidAmount;
                    if (Body.PaidAmount !== 0) {
                        let pMaster = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${Body.CustomerID}', '${CompanyID}', '${Body.ShopID}', '${Body.CreditType}',now(), '${Body.PaymentMode}', '${Body.CardNo}', '${Body.PaymentReferenceNo}', '${Body.PayableAmount}', '${Body.PaidAmount}', '${Body.Comments}', 'Employee',  '1',  '${LoggedOnUser.ID}', now())`
                        );

                        let pMasterID = pMaster.insertId;

                        response.result = "Success";

                        for (const item of unpaidListe) {
                            if (tempAmounte !== 0) {
                                if (tempAmounte >= item.DueAmount) {
                                    tempAmounte = tempAmounte - item.DueAmount;
                                    item.Amount = item.DueAmount;
                                    item.DueAmount = 0;
                                    item.PaymentStatus = "Paid";
                                } else {
                                    item.DueAmount = item.DueAmount - tempAmounte;
                                    item.Amount = tempAmounte;
                                    item.PaymentStatus = "Unpaid";
                                    tempAmounte = 0;
                                }
                                let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${item.CompanyID}', '${item.UserID}', '${item.ID}', '${item.InvoiceNo}','${item.Amount}','${item.DueAmount}','Employee', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                                let pDetail = await connection.query(qry);
                                let qry2 = `Update  CommissionMaster SET  PaymentStatus = '${item.PaymentStatus}' , DueAmount = '${item.DueAmount}',UpdatedBy = '${LoggedOnUser.ID}',UpdatedOn = now(), LastUpdate = now() where ID = ${item.ID}`;
                                let bMaster = await connection.query(qry2);
                            }
                        }
                        if (tempAmounte !== 0) {
                            let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${CompanyID}', '${Body.CustomerID}', 0, 0,'${tempAmounte}','0','Employee Credit', 'Credit', '1', '${LoggedOnUser.ID}', now())`;
                            let pDetail = await connection.query(qry);
                        }
                    }
                    break;

                case "Employee":
                    let selectRow = await connection.query(`select * from PaymentMaster where CustomerID = '${Body.ID}' and PaymentType = 'Employee'`);
                    if (selectRow.length === 0) {
                        let pMaster = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType,Status,CreatedBy,CreatedOn ) values ('${Body.ID}', '${CompanyID}', '${Body.ShopID}', 'Debit',now(), '${Body.PaymentMode}', null, '${Body.PaymentRefereceNo}', '${Body.Salary}', '${Body.Salary}', '${Body.Comments}', '${UserMode}',  '1',  '${LoggedOnUser.ID}', now())`
                        );
                        let pMasterID = pMaster.insertId;
                        let InvoiceNo = Body.Month + "-" + Body.Year;
                        let qry = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMasterID}', '${Body.CompanyID}', '${Body.ID}', '${Body.ID}', '${InvoiceNo}','${Body.Salary}','0','${UserMode}', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                        let pDetail = await connection.query(qry);
                    } else {
                        let pMaster1 = await connection.query(
                            `update PaymentMaster set PaymentMode = '${Body.PaymentMode}',  PaidAmount = '${Body.Salary}' , PayableAmount = '${Body.Salary}'   where CustomerID = '${selectRow[0].CustomerID}'`
                        );
                        let InvoiceNo = Body.Month + "-" + Body.Year;

                        let pDetail1 = await connection.query(
                            `update PaymentDetail set  Amount = '${Body.Salary}', BillID = '${InvoiceNo}'  where CustomerID = '${selectRow[0].CustomerID}'`
                        );
                    }

                    break;

                case "Expense":
                    let selectRow1 = await connection.query(`select * from PaymentMaster where CustomerID = '${Body.EmployeeID}' and PaymentType = 'Expense'`);
                    if (selectRow1.length === 0) {
                        let pMaster1 = await connection.query(
                            `insert into PaymentMaster (CustomerID,CompanyID,ShopID,CreditType, PaymentDate, PaymentMode,CardNo, PaymentReferenceNo, PayableAmount, PaidAmount, Comments, PaymentType, Status,CreatedBy,CreatedOn ) values ('${Body.EmployeeID}', '${CompanyID}', '${Body.ShopID}', 'Debit',now(), '${Body.PaymentMode}', null, '${Body.PaymentRefereceNo}', '${Body.Amount}', '${Body.Amount}', '${Body.Comments}', '${UserMode}',  '1',  '${LoggedOnUser.ID}', now())`
                        );
                        let pMaster1ID = pMaster1.insertId;
                        let InvoiceNo1 = Body.Month + "-" + Body.Year;
                        let qry1 = `insert into PaymentDetail (PaymentMasterID,CompanyID, CustomerID, BillMasterID, BillID,Amount, DueAmount, PaymentType, Credit, Status,CreatedBy,CreatedOn ) values ('${pMaster1ID}', '${Body.CompanyID}', '${Body.EmployeeID}', '${Body.ID}', '${Body.ID}','${Body.Amount}','0','${UserMode}', 'Debit', '1', '${LoggedOnUser.ID}', now())`;
                        let pDetail1 = await connection.query(qry1);
                    } else {
                        let pMaster1 = await connection.query(
                            `update PaymentMaster set PaymentMode = '${Body.PaymentMode}', ShopID = '${Body.ShopID}', PaidAmount = '${Body.Amount}' , PayableAmount = '${Body.Amount}'   where CustomerID = '${Body.EmployeeID}'`
                        );

                        let pDetail1 = await connection.query(
                            `update PaymentDetail set  Amount = '${Body.Amount}'  where CustomerID = '${Body.EmployeeID}'`
                        );
                    }

                    break;


                case "ReturnCustomerPayment":
                    let customerreturn = await connection.query(
                        `insert into PaymentMaster(CustomerID, CompanyID,ShopID, PaymentType, CreditType,PaymentDate, PaymentMode, PayableAmount, PaidAmount)values('${Body.CustomerID}','${Body.CompanyID}','${Body.ShopID}','${Body.PaymentType}','${Body.CreditType}',now(),'${Body.PaymentMode}','${Body.PayableAmount}','${Body.PaidAmount}')`
                    );

                    let pMasterID1 = customerreturn.insertId;
                    let customerreturn1 = await connection.query(
                        `insert into PaymentDetail(PaymentMasterID, BillID, CustomerID, CompanyID,Amount, DueAmount, PaymentType, Credit, CreatedBy, CreatedOn)values('${pMasterID1}','0','${Body.CustomerID}','${Body.CompanyID}','-${Body.PaidAmount}','0','Customer Credit','${Body.CreditType}', '${LoggedOnUser.ID}', now())`
                    );
                    break;
            }

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getBillData(ID, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let billMaseterData = await connection.query(
                `select * from  BillMaster where CompanyID =  ${CompanyID} and ID = ${ID} and Status = 1 Order By ID Desc`
            );

            let billDetailData = await connection.query(
                `select * from  BillDetail where CompanyID =  ${CompanyID} and BillID = ${ID} Order By ID Desc`
            );

            let service = await connection.query(
                ` SELECT BillService.*, ServiceMaster.Name AS ServiceType  FROM  BillService  LEFT JOIN ServiceMaster ON ServiceMaster.ID = BillService.ServiceType WHERE BillService.CompanyID =  ${CompanyID} and BillID = ${ID} Order By ID Desc`
            );

            response.billMaster = billMaseterData[0];
            response.billDetail = billDetailData;
            response.service = service;
            response.success = "success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getcheckInvoicNo(Param, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let Parameter = JSON.parse(Param);
            let response = { data: null, success: null };
            let checkInvoicNo = await connection.query(
                `SELECT PurchaseMaster.* , Supplier.Name AS SupplierName FROM PurchaseMaster
                LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID
                WHERE PurchaseMaster.InvoiceNo = '${Parameter.InvoiceNo}'  AND Supplier.Name = '${Parameter.SupplierName}' AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.Status = 1`
            );

            response.success = "success";
            response.data = checkInvoicNo;
            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getcheckInvoicNoComm(Param, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let Parameter = JSON.parse(Param);
            let response = { data: null, success: null };
            let checkInvoicNo = await connection.query(
                `SELECT * FROM CommissionMaster
                 WHERE InvoiceNo = '${Parameter.InvoiceNo}' AND UserID = '${Parameter.UserID}' AND ShopID = '${Parameter.ShopID}' AND UserType = '${Parameter.UserType}' AND CompanyID = '${CompanyID}' AND Status = 1`
            );

            response.success = "success";
            response.data = checkInvoicNo;
            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getcheckInvoicNoFitter(Param, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let Parameter = JSON.parse(Param);
            let response = { data: null, success: null };
            let checkInvoicNo = await connection.query(
                `SELECT * FROM FitterMaster
                 WHERE InvoiceNo = '${Parameter.InvoiceNo}' AND FitterID = '${Parameter.FitterID}' AND ShopID = '${Parameter.ShopID}' AND CompanyID = '${CompanyID}' AND Status = 1`
            );

            response.success = "success";
            response.data = checkInvoicNo;
            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getdeletedata(TableName, LoggedOnUser, loggedInShop) {
        const connection = await mysql.connection();
        try {

            let response = { data: null, success: null };
            let Tab = TableName;
            let DelData = await connection.query(`select ${TableName}.*, User.Name as UpdatedPerson from ${TableName} left join User on User.ID = ${TableName}.UpdatedBy  where ${TableName}.CompanyID = ${LoggedOnUser.CompanyID} AND ${TableName}.Status = 0`);


            response.success = "success";
            response.data = DelData;

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getCredit(ID, LoggedOnUser, CompanyID, CreditEntity) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = "";
            if (CreditEntity === "Customer") {
                qry = `Select * from PaymentDetail where CustomerID = '${ID}' And CompanyID = '${CompanyID}' And PaymentType = 'Customer Credit' and Credit = 'Debit'`;
            } else if (CreditEntity === "Vendor") {
                qry = `Select * from PaymentDetail where CustomerID = '${ID}' And CompanyID = '${CompanyID}' And PaymentType = 'Vendor Credit' and Credit = 'Credit'`;
            } else if (CreditEntity === "Doctor") {
                qry = `Select * from PaymentDetail where CustomerID = '${ID}' And CompanyID = '${CompanyID}' And PaymentType = 'Doctor Credit' and Credit = 'Credit'`;
            } else if (CreditEntity === "Employee") {
                qry = `Select * from PaymentDetail where CustomerID = '${ID}' And CompanyID = '${CompanyID}' And PaymentType = 'Employee Credit' and Credit = 'Credit'`;
            } else if (CreditEntity === "Fitter") {
                qry = `Select * from PaymentDetail where CustomerID = '${ID}' And CompanyID = '${CompanyID}' And PaymentType = 'Fitter Credit' and Credit = 'Credit'`;
            }

            let data = await connection.query(qry);

            let creditAmount = 0;
            data.forEach((element) => {
                creditAmount = creditAmount + +element.Amount;
            });
            response.result = creditAmount;

            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getPreorderPurchaseList(Mode, CompanyID, ID, ShopID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data;
            if (Mode === "Purchase") {
                data = await connection.query(
                    `SELECT NULL AS sel, PurchaseDetail.*, PurchaseDetail.ID as PurchaseDetailID, PurchaseMaster.*,  BarcodeMaster.*, Customer.Name AS CustomerName, Customer.MobileNo1 AS MobileNo, BillMaster.InvoiceNo FROM PurchaseDetail
          LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID
          LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID  = PurchaseDetail.ID
          LEFT JOIN BillDetail ON BillDetail.ID = BarcodeMaster.BillDetailID
          LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
          LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
          WHERE PurchaseMaster.SupplierID ='${ID}' And PurchaseMaster.CompanyID = '${CompanyID}' And PStatus = 0 And PurchaseMaster.ShopID = '${ShopID}'`
                );
            } else if (Mode === "PurchaseConvertPurchase") {

                data = await connection.query(`SELECT PurchaseDetail.*, Customer.Name AS CustomerName, Customer.MobileNo1 AS MobileNo, BillMaster.InvoiceNo,BillMaster.BillDate FROM PurchaseMaster
                LEFT JOIN PurchaseDetail ON PurchaseDetail.PurchaseID = PurchaseMaster.ID
                LEFT JOIN BillDetail ON BillDetail.ID = PurchaseDetail.BillDetailIDForPreOrder
                LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
                LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                WHERE PurchaseMaster.SupplierID ='${ID}' And PurchaseMaster.CompanyID = '${CompanyID}' And PurchaseMaster.PStatus = 0 And PurchaseMaster.ShopID = '${ShopID}'  GROUP BY PurchaseDetail.BillDetailIDForPreOrder `);

            } else if (Mode === "Fitter") {
                data = await connection.query(
                    `SELECT NULL AS sel, FitterDetail.ID as FitterDetailID, FitterDetail.*, FitterMaster.* ,Customer.Name AS CustomerName, Customer.MobileNo1 AS MobileNo, FitterDetail.Quantity AS Qty, FitterDetail.TotalAmount AS Total FROM FitterDetail
          LEFT JOIN FitterMaster ON FitterDetail.FitterMasterID = FitterMaster.ID  LEFT JOIN BillMaster ON BillMaster.InvoiceNo = FitterDetail.CustomerInvoice
          LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID  where FitterID = '${ID}' And BillMaster.CompanyID = '${CompanyID}' And PStatus = 0`
                );
            } else if (Mode === "Doctor") {
                data = await connection.query(
                    `SELECT NULL AS sel, Customer.Name as CustomerName, Customer.MobileNo1 as MobileNo, User.Name AS CreatedByUser, BillMaster.InvoiceNo, BillMaster.BillDate,
          BillMaster.PaymentStatus, BillMaster.TotalAmount, CommissionDetail.* FROM CommissionDetail
          INNER JOIN User ON User.ID = CommissionDetail.CreatedBy
          INNER JOIN BillMaster ON BillMaster.ID = CommissionDetail.BillMasterID
          Inner Join Customer on Customer.ID = BillMaster.CustomerID
          where UserID = '${ID}' And CommissionDetail.CompanyID = '${CompanyID}'
          And CommissionDetail.CommissionMasterID = '0' and CommissionDetail.ShopID = '${ShopID}' and UserType = '${Mode}'`);
            } else if (Mode === 'Employee') {
                data = await connection.query(
                    `SELECT NULL AS sel, Customer.Name as CustomerName, Customer.MobileNo1 as MobileNo, User.Name AS CreatedByUser, BillMaster.InvoiceNo, BillMaster.BillDate,
          BillMaster.PaymentStatus, BillMaster.TotalAmount, CommissionDetail.* FROM CommissionDetail
          INNER JOIN User ON User.ID = CommissionDetail.CreatedBy
          INNER JOIN BillMaster ON BillMaster.ID = CommissionDetail.BillMasterID
          Inner Join Customer on Customer.ID = BillMaster.CustomerID
          where UserID = '${ID}' And CommissionDetail.CompanyID = '${CompanyID}'
          And CommissionDetail.CommissionMasterID = '0' and CommissionDetail.ShopID = '${ShopID}' and UserType = '${Mode}'`);
            }

            response.result = data;

            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getListByPage(Mode, CompanyID, ID, ShopID, pageLimit) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data;


            if (Mode === "PurchaseConvertPurchase") {

                data = await connection.query(`SELECT PurchaseDetail.*, Customer.Name AS CustomerName, Customer.MobileNo1 AS MobileNo, BillMaster.InvoiceNo,BillMaster.BillDate FROM PurchaseMaster LEFT JOIN PurchaseDetail ON PurchaseDetail.PurchaseID = PurchaseMaster.ID LEFT JOIN BillDetail ON BillDetail.ID = PurchaseDetail.BillDetailIDForPreOrder LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID WHERE PurchaseMaster.SupplierID ='${ID}' And PurchaseMaster.CompanyID = '${CompanyID}' And PurchaseMaster.PStatus = 0 And PurchaseMaster.ShopID = '${ShopID}'  GROUP BY PurchaseDetail.BillDetailIDForPreOrder order by PurchaseDetail.ID desc ` + pageLimit

                );
            }


            response.result = data;


            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    // get search barcode by param
    static async getSearchBarCodeFilter(
        LoggedOnUser,
        CompanyID,
        ShopID,
        PurchaseDetailID,
        ShopMode,
        mode
    ) {
        const connection = await mysql.connection();
        let shopMode = ``;
        let mode1 = ``;
        if (mode === 'search') {
            mode1 = `And BarcodeMaster.Barcode = '${PurchaseDetailID}'`;

        } else {
            mode1 = `And BarcodeMaster.PurchaseDetailID = '${PurchaseDetailID}'`;
        }
        try {
            let response = { data: null, success: null };
            let qry = "";
            if (ShopMode === "false" || ShopMode === false) {
                shopMode = `And BarcodeMaster.ShopID = '${ShopID}'`;
            }
            qry = `SELECT BarcodeMaster.* , Company.Name AS CompanyName, Shop.Name AS ShopName, Shop.AreaName AS AreaName, Shop.BarcodeName AS BarcodeShopName, PurchaseDetail.ProductName , PurchaseDetail.ProductTypeName, PurchaseDetail.BaseBarCode AS BarCode, PurchaseDetail.UniqueBarcode, PurchaseDetail.UnitPrice, PurchaseDetail.ProductName, PurchaseDetail.Quantity ,PurchaseMaster.InvoiceNo,Supplier.Name AS SupplierName   FROM BarcodeMaster LEFT JOIN Company ON Company.ID = BarcodeMaster.CompanyID LEFT JOIN Shop ON Shop.ID = BarcodeMaster.ShopID LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE BarcodeMaster.CurrentStatus != 'Pre Order' and  PurchaseDetail.Status = 1 AND BarcodeMaster.CompanyID = ${CompanyID}  ${shopMode} ${mode1}`;
            let barcodelist = await connection.query(qry);
            response.data = barcodelist;
            response.success = "success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async transferProduct(Body, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = `insert into TransferMaster ( CompanyID, ProductName, BarCode, BarCodeCount, TransferCount, Remark,
        TransferToShop, TransferFromShop, AcceptanceCode, DateStarted, TransferStatus,
        CreatedBy, CreatedOn)
      values ('${CompanyID}', '${Body.ProductName}', '${Body.BarCode}', '${Body.BarCodeCount}', '${Body.TransferCount}',  '${Body.Remark}',  '${Body.ToShopID}'
      , '${Body.TransferFromShop}', '${Body.AcceptanceCode}', now(),  '${Body.TransferStatus}','${LoggedOnUser.ID}', now())`;

            let xferData = await connection.query(qry);

            let xferID = xferData.insertId;

            let selectedRows = await connection.query(
                `SELECT ID FROM BarcodeMaster WHERE CurrentStatus = "Available" AND ShopID = '${Body.TransferFromShop}' AND Barcode = '${Body.BarCode}' AND PreOrder = '0' and CompanyID ='${CompanyID}' LIMIT ${Body.TransferCount}`
            );

            await Promise.all(
                selectedRows.map(async (ele) => {
                    await connection.query(
                        `UPDATE BarcodeMaster SET TransferID= ${xferID}, CurrentStatus = 'Transfer Pending', UpdatedBy = ${LoggedOnUser.ID}, updatedOn = now() WHERE ID = ${ele.ID}`
                    );
                })
            );

            let qry1 = this.getExtendedQueryByID(
                "TransferMaster",
                Body.TransferFromShop,
                CompanyID
            );
            let xferList = await connection.query(qry1);

            response.result = xferList;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async cancelTransfer(Body, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = `Update TransferMaster SET DateCompleted = now(),
      TransferStatus = "Transfer Cancelled", UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now(), Remark = '${Body.Remark}' where ID = '${Body.ID}'`;

            let xferData = await connection.query(qry);

            let xferID = xferData.insertId;

            let selectedRows = await connection.query(
                `SELECT * FROM BarcodeMaster WHERE TransferID = '${Body.ID}' and CurrentStatus = 'Transfer Pending' and ShopID = '${Body.TransferFromShop}' and CompanyID ='${CompanyID}'`
            );

            await Promise.all(
                selectedRows.map(async (ele) => {
                    await connection.query(
                        `UPDATE BarcodeMaster SET TransferID= 0 , CurrentStatus = 'Available', UpdatedBy = ${LoggedOnUser.ID}, updatedOn = now() WHERE ID = ${ele.ID}`
                    );
                })
            );

            let qry1 = this.getExtendedQueryByID(
                "TransferMaster",
                Body.TransferFromShop,
                CompanyID
            );
            let xferList = await connection.query(qry1);

            response.result = xferList;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async acceptTransfer(Body, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = `Update TransferMaster SET DateCompleted = now(),
      TransferStatus = "Transfer Completed", UpdatedBy = '${LoggedOnUser.ID}', UpdatedOn = now(), Remark = '${Body.Remark}' where ID = '${Body.ID}'`;

            let xferData = await connection.query(qry);

            let xferID = xferData.insertId;

            let selectedRows = await connection.query(
                `SELECT * FROM BarcodeMaster WHERE TransferID = '${Body.ID}' and CurrentStatus = 'Transfer Pending' and ShopID = '${Body.TransferFromShop}' and CompanyID ='${CompanyID}'`
            );

            await Promise.all(
                selectedRows.map(async (ele) => {
                    await connection.query(
                        `UPDATE BarcodeMaster SET ShopID = ${Body.TransferToShop}, CurrentStatus = 'Available', UpdatedBy = ${LoggedOnUser.ID}, updatedOn = now() WHERE ID = ${ele.ID}`
                    );
                })
            );

            let qry1 = this.getExtendedQueryByID(
                "TransferMaster",
                Body.TransferFromShop,
                CompanyID
            );
            console.log(qry1, "qry1");
            let xferList = await connection.query(qry1);

            response.result = xferList;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getProductDataByBarCodeNo(
        Req,
        LoggedOnUser,
        CompanyID,
        ShopID,
        PreOrder,
        ShopMode
    ) {
        let barCode = Req.SearchBarCode;
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = "";
            if (PreOrder === "false") {
                let shopMode = "";
                if (ShopMode === "false") {
                    shopMode = " And BarcodeMaster.ShopID = " + ShopID;
                } else {
                    shopMode = " Group By BarcodeMaster.ShopID ";
                }
                qry = `SELECT COUNT(PurchaseDetailID) AS BarCodeCount, PurchaseDetail.GSTType, PurchaseDetail.GSTPercentage, PurchaseDetail.ProductName,PurchaseDetail.ProductTypeName,PurchaseDetail.ProductTypeID, BarcodeMaster.*  FROM BarcodeMaster Left Join PurchaseDetail on PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE CurrentStatus = "Available" AND Barcode = '${barCode}' and PurchaseDetail.Status = 1 and PurchaseDetail.PurchaseID != 0 and  PurchaseDetail.CompanyID = '${CompanyID}' ${shopMode}`;
            } else {
                qry = `SELECT COUNT(PurchaseDetailID) AS BarCodeCount, PurchaseDetail.GSTType, PurchaseDetail.GSTPercentage,PurchaseDetail.GSTAmount, PurchaseDetail.ProductName,PurchaseDetail.ProductTypeName, PurchaseDetail.UnitPrice, PurchaseDetail.ProductTypeID, BarcodeMaster.*  FROM BarcodeMaster Left Join PurchaseDetail on PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID WHERE BarcodeMaster.Barcode = '${barCode}' and PurchaseDetail.Status = 1 AND BarcodeMaster.CurrentStatus = 'Pre Order'  and PurchaseDetail.CompanyID = '${CompanyID}'`;
            }
            let barCodeData = await connection.query(qry);
            // if (barCodeData.length === 1 || barCodeData.length > 0) {
            //     let qry = this.getProductSpecQuery(
            //         barCodeData[0].PurchaseDetailID,
            //         CompanyID
            //     );
            //     let specData = await connection.query(qry);
            //     barCodeData[0].Spec = specData;
            // }
            response.result = barCodeData[0];
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getBarCodeListBySearchString(
        SearchString,
        ProductName,
        LoggedOnUser,
        ShopID,
        CompanyID,
        ShopMode
    ) {
        let searchString = SearchString + "%";
        let shopMode = ``;
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            if (ShopMode === "false" || ShopMode === false) {
                shopMode = " And BarcodeMaster.ShopID = " + ShopID;
            }
            if (ShopMode === "true" || ShopMode === true) {
                shopMode = " ";
            }
            let qry = `SELECT COUNT(BarcodeMaster.ID) AS BarCodeCount, Shop.Name as ShopName,Shop.AreaName, PurchaseDetail.ProductName, BarcodeMaster.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID Left Join Shop on Shop.ID = BarcodeMaster.ShopID LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID  WHERE PurchaseDetail.ProductTypeName = '${ProductName}' ${shopMode} AND PurchaseDetail.ProductName LIKE '${searchString}' AND BarcodeMaster.CurrentStatus = "Available"   AND PurchaseDetail.Status = 1  and Shop.Status = 1 And BarcodeMaster.CompanyID = '${CompanyID}' GROUP BY BarcodeMaster.Barcode, BarcodeMaster.ShopID`;
            let purchaseData = await connection.query(qry);
            response.result = purchaseData;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getBarPreOrderCodeListBySearchString(
        SearchString,
        ProductName,
        LoggedOnUser,
        ShopID,
        CompanyID
    ) {
        let searchString = SearchString + "%";
        let shopMode = ``;
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            // let qry = `SELECT 'XXX' AS BarCodeCount, '' as ShopName,AreaName, PurchaseDetail.ProductName, BarcodeMaster.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID Left Join Shop on Shop.ID = BarcodeMaster.ShopID WHERE ProductTypeName = '${ProductName}' and PurchaseID = 0 AND ProductName LIKE '${searchString}' AND BarcodeMaster.Status = 1 And PurchaseDetail.CompanyID = '${CompanyID}' ${shopMode}  GROUP BY PurchaseDetail.ID`;

            let qry = `SELECT 'XXX' AS BarCodeCount,  Shop.AreaName as AreaName  ,Shop.Name as ShopName, PurchaseDetail.ProductName, BarcodeMaster.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID Left Join Shop on Shop.ID = BarcodeMaster.ShopID WHERE  ProductName LIKE '${searchString}' AND BarcodeMaster.CompanyID = '${CompanyID}'
            And ProductTypeName = '${ProductName}' and PurchaseID = 0  AND BarcodeMaster.Status = 1   AND PurchaseDetail.Status = 1  GROUP BY PurchaseDetail.ID`;
            let purchaseData = await connection.query(qry);
            response.result = purchaseData;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getPreOrderStatus(Mode, LoggedOnUser, CompanyID, ShopID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qstring = "";
            switch (Mode) {
                case "Unassigned":
                    qstring =
                        "BarcodeMaster.PreOrder = '1' and BarcodeMaster.SupplierID = 0 AND BarcodeMaster.CurrentStatus = 'Pre Order'";
                    break;
                case "UnassignedFitter":
                    qstring =
                        "BarcodeMaster.FitterID = 0 and BarcodeMaster.SupplierID <> 0 OR BarcodeMaster.SupplierID <> null AND BarcodeMaster.CurrentStatus = 'Pre Order'";
                    break;
                case "Assigned":
                    qstring =
                        "BarcodeMaster.PreOrder = '2' OR BarcodeMaster.PreOrder = '1' AND BarcodeMaster.CurrentStatus = 'Sold' OR BarcodeMaster.CurrentStatus = 'Pre Order' AND BarcodeMaster.SupplierID <> 0  AND BarcodeMaster.FitterID <> 0";
                    break;
                case "QC Checked":
                    qstring = " BarcodeMaster.PreOrder = 3 AND BarcodeMaster.CurrentStatus = 'Sold'";
                    break;
            }

            let qry = `SELECT 0 as Sel , COUNT(*) AS Qty, BarcodeMaster.*, Supplier.Name AS SupplierName, Fitter.Name as FitterName, Shop.Name as ShopName,Shop.AreaName as AreaName, BillDetail.ProductName, Customer.Name AS CustomerName, Customer.MobileNo1 AS MobileNo, BillMaster.InvoiceNo, BillMaster.DeliveryDate,BillMaster.BillDate, User.Name as UpdatePerson, PurchaseDetail.ProductTypeName, PurchaseDetail.ProductTypeID, PurchaseDetail.UnitPrice AS PurchaseRate, PurchaseDetail.GSTPercentage, PurchaseDetail.GSTAmount, PurchaseDetail.GSTType,PurchaseDetail.Quantity  FROM BarcodeMaster LEFT JOIN Supplier ON Supplier.ID = BarcodeMaster.SupplierID Left Join PurchaseDetail on PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID Left Join BillDetail on BillDetail.ID = BarcodeMaster.BillDetailID Left Join BillMaster on BillMaster.ID = BillDetail.BillID Left Join Customer on Customer.ID = BillMaster.CustomerID Left Join Shop on Shop.ID = BarcodeMaster.ShopID Left Join Fitter on Fitter.ID = BarcodeMaster.FitterID left join User on User.ID = BarcodeMaster.UpdatedBy GROUP BY BarcodeMaster.BillDetailID  having BarcodeMaster.ShopID = '${ShopID}'  and ${qstring} and BarcodeMaster.CompanyID = '${CompanyID}' and BarcodeMaster.BillDetailID != "null"  Order By BarcodeMaster.ID Desc `;
            console.log(qry, 'qc check');
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async setPreOrderStatus(Body, LoggedOnUser, Mode, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            for (const ele of Body.filterList) {

                const data = {
                    preOrder: ele.PreOrder,
                    supplierID: ele.SupplierID,
                    fitterID: ele.FitterID,
                    billDetailID: ele.BillDetailID,
                    lensType: ele.LensType,
                    fitterCost: ele.FitterCost
                }
                if (Mode === "Assign" || Mode === "AssignFitter") {
                    let qry = `select * from BarcodeMaster where PreOrder = 1 and BillDetailID = '${data.billDetailID}' and CompanyID = ${CompanyID}`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${data.preOrder} ,  SupplierID = ${data.supplierID} ,  FitterID = ${data.fitterID} , LensType = '${data.lensType}' , FitterCost = ${data.fitterCost} , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${e.ID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }
                if (Mode === "Cancel") {
                    let qry = `select * from BarcodeMaster where PreOrder = 2 and BillDetailID = '${data.billDetailID}' and CompanyID = ${CompanyID} and PurchaseDetailID = 0`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${data.preOrder} ,  SupplierID = ${data.supplierID} ,  FitterID = ${data.fitterID} , LensType = '${data.lensType}' , FitterCost = ${data.fitterCost} , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${e.ID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }
                if (Mode === "Save DB") {
                    let qry = `select * from BarcodeMaster where PreOrder = 2 and BillDetailID = '${data.billDetailID}' and CompanyID = ${CompanyID}`;

                    let selectedBarcode = await connection.query(qry);
                    let barcode = Number(ele.Barcode) / 1000;
                    let selectdataforPurchaseDetail = await connection.query(`select * from PurchaseDetail where BaseBarCode = '${barcode}' and PurchaseID = 0 and ProductName = '${ele.ProductName}'`);


                    let readyData = {
                        productName: selectdataforPurchaseDetail[0]?.ProductName,
                        productTypeID: selectdataforPurchaseDetail[0]?.ProductTypeID,
                        productTypeName: selectdataforPurchaseDetail[0]?.ProductTypeName,
                        unitPrice: selectdataforPurchaseDetail[0]?.UnitPrice,
                        quantity: ele.Qty,
                        subTotal: selectdataforPurchaseDetail[0]?.SubTotal,
                        discountPercentage: selectdataforPurchaseDetail[0]?.DiscountPercentage,
                        discountAmount: selectdataforPurchaseDetail[0]?.DiscountAmount,
                        gSTPercentage: selectdataforPurchaseDetail[0]?.GSTPercentage,
                        gSTAmount: selectdataforPurchaseDetail[0]?.GSTAmount,
                        gSTType: selectdataforPurchaseDetail[0]?.GSTType,
                        totalAmount: selectdataforPurchaseDetail[0]?.TotalAmount,
                        retailPrice: selectdataforPurchaseDetail[0]?.RetailPrice,
                        wholeSalePrice: selectdataforPurchaseDetail[0]?.WholeSalePrice,
                        multipleBarCode: selectdataforPurchaseDetail[0]?.MultipleBarCode,
                        wholeSale: selectdataforPurchaseDetail[0]?.WholeSale,
                        baseBarCode: selectdataforPurchaseDetail[0]?.BaseBarCode,

                    }
                    readyData.subTotal = Number(selectdataforPurchaseDetail[0]?.UnitPrice) * ele.Qty - Number(selectdataforPurchaseDetail[0]?.DiscountAmount);
                    readyData.totalAmount = readyData.subTotal + Number(selectdataforPurchaseDetail[0]?.GSTAmount);
                    let supplierMasterID = null;
                    let supplierMaster = await connection.query(
                        `Select * from PurchaseMaster where SupplierID = '${Body.supplier.ID}' and ShopID = '${Body.loggedInShop.ID}' and Status != 0 and PStatus = 0 limit 1`
                    );
                    if (supplierMaster.length === 0) {
                        let supplierMaster = await connection.query(`Insert INTO PurchaseMaster (SupplierID, CompanyID, ShopID, PaymentStatus, GSTNo, Quantity, TotalAmount,  Status, CreatedBy, CreatedOn, PStatus) values ('${Body.supplier.ID}','${CompanyID}','${Body.loggedInShop.ID}','Unpaid', '${Body.supplier.GSTNo}', 0, 0,1, '${LoggedOnUser.ID}', now(), 0)`);

                        supplierMasterID = supplierMaster.insertId;


                    } else {
                        supplierMasterID = supplierMaster[0].ID;

                    }

                    let insertPurchaseDetail = await connection.query(`Insert Into PurchaseDetail  (BillDetailIDForPreOrder,PurchaseID, CompanyID, ProductName,ProductTypeID,ProductTypeName, GSTPercentage, GSTAmount, GSTType, Status, CreatedBy, CreatedOn,DiscountPercentage,DiscountAmount,BaseBarCode,RetailPrice,WholeSalePrice,MultipleBarCode,WholeSale,UnitPrice,Quantity,SubTotal,TotalAmount) values ('${data.billDetailID}','${supplierMasterID}','${CompanyID}','${ele.ProductName}','${readyData.productTypeID}','${readyData.productTypeName}','${readyData.gSTPercentage}',${readyData.gSTAmount},'${readyData.gSTType}','1', '${LoggedOnUser.ID}', now(), '${readyData.discountPercentage}', '${readyData.discountAmount}', '${barcode}','${readyData.retailPrice}','${readyData.wholeSalePrice}','${readyData.multipleBarCode}','${readyData.wholeSale}',${readyData.unitPrice},${ele.Qty},${readyData.subTotal},${readyData.totalAmount})`);

                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster SET PurchaseDetailID = '${insertPurchaseDetail.insertId}' where BillDetailID = '${e.BillDetailID}'`)


                        })
                    }
                }

                if (Mode === "Save DB") {
                    let qry = `select * from BarcodeMaster where PreOrder = 2 and BillDetailID = '${ele.BillDetailID}' and CompanyID = ${CompanyID}`;
                    let selectedBarcode = await connection.query(qry);
                    console.log(selectedBarcode, 'fitter select');
                    let total = ele.Qty * Number(selectedBarcode[0].FitterCost);
                    let fitterMasterID = null;
                    let fitterMaster = await connection.query(
                        `Select * from FitterMaster where FitterID = '${Body.fitter.ID}' and ShopID = '${Body.loggedInShop.ID}' and PStatus = 0 limit 1`
                    );
                    if (fitterMaster.length === 0) {
                        let fitterMaster = await connection.query(`Insert INTO FitterMaster (FitterID, CompanyID, ShopID, PaymentStatus, GSTNo, Quantity, TotalAmount,  Status, CreatedBy, CreatedOn, PStatus) values ('${Body.fitter.ID}','${CompanyID}','${Body.loggedInShop.ID}','Unpaid', '${Body.fitter.GSTNo}', 0, 0,1, '${LoggedOnUser.ID}', now(), 0)`);

                        fitterMasterID = fitterMaster.insertId;



                    } else {
                        fitterMasterID = fitterMaster[0].ID;
                    }

                    let insertFitterDetail = await connection.query(`Insert Into FitterDetail  (FitterMasterID, CompanyID, ProductName, UnitPrice, Quantity, TotalAmount, CustomerInvoice, BarcodeID, LensType, AssignedOn, Status, CreatedBy, CreatedOn) values ('${fitterMasterID}','${CompanyID}','${ele.ProductName}','${selectedBarcode[0].FitterCost}','${ele.Qty}','${total}', '${ele.InvoiceNo}', '${ele.ID}', '${ele.LensType}', now(), '1', '${LoggedOnUser.ID}', now())`);

                }


                if (Mode === "QC Done") {
                    let qry = `select * from BarcodeMaster where PreOrder = 2 and BillDetailID = '${ele.BillDetailID}' and CompanyID = ${CompanyID}`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${ele.PreOrder} where BillDetailID = ${ele.BillDetailID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }
                if (Mode === "QC Cancel") {
                    let qry = `select * from BarcodeMaster where PreOrder = 3 and BillDetailID = '${ele.BillDetailID}' and CompanyID = ${CompanyID}`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${ele.PreOrder} where BillDetailID = ${ele.BillDetailID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }


            }

            response.result = "result";
            response.success = "Success";
            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async setPreOrderStatusPo(Body, LoggedOnUser, Mode, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            for (const ele of Body.filterList) {

                const data = {
                    preOrder: ele.PreOrder,
                    po: ele.Po,
                    supplierID: ele.SupplierID,
                    billDetailID: ele.BillDetailID,
                }
                if (Mode === "Assign" ) {
                    let qry = `select * from BarcodeMaster where PreOrder = 1 and Po = 1 and BillDetailID = '${data.billDetailID}' and CompanyID = ${CompanyID}`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${data.preOrder} , Po = ${data.po} ,  SupplierID = ${data.supplierID} ,  UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${e.ID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }
                if (Mode === "Cancel") {
                    let qry = `select * from BarcodeMaster where PreOrder = 1 and Po = 1 and BillDetailID = '${data.billDetailID}' and CompanyID = ${CompanyID} and PurchaseDetailID = 0`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${data.preOrder} ,
                            Po = ${data.po} , SupplierID = ${data.supplierID} ,  UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${e.ID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }
                if (Mode === "Save DB") {
                    let qry = `select * from BarcodeMaster where PreOrder = 1 and Po = 1 and BillDetailID = '${data.billDetailID}' and CompanyID = ${CompanyID}`;

                    let selectedBarcode = await connection.query(qry);
                    let barcode = Number(ele.Barcode) / 1000;
                    let selectdataforPurchaseDetail = await connection.query(`select * from PurchaseDetail where BaseBarCode = '${barcode}' and PurchaseID = 0 and ProductName = '${ele.ProductName}'`);
                    console.log(barcode,'barcode');

                    let readyData = {
                        productName: selectdataforPurchaseDetail[0]?.ProductName,
                        productTypeID: selectdataforPurchaseDetail[0]?.ProductTypeID,
                        productTypeName: selectdataforPurchaseDetail[0]?.ProductTypeName,
                        unitPrice: selectdataforPurchaseDetail[0]?.UnitPrice,
                        quantity: ele.Qty,
                        subTotal: selectdataforPurchaseDetail[0]?.SubTotal,
                        discountPercentage: selectdataforPurchaseDetail[0]?.DiscountPercentage,
                        discountAmount: selectdataforPurchaseDetail[0]?.DiscountAmount,
                        gSTPercentage: selectdataforPurchaseDetail[0]?.GSTPercentage,
                        gSTAmount: selectdataforPurchaseDetail[0]?.GSTAmount,
                        gSTType: selectdataforPurchaseDetail[0]?.GSTType,
                        totalAmount: selectdataforPurchaseDetail[0]?.TotalAmount,
                        retailPrice: selectdataforPurchaseDetail[0]?.RetailPrice,
                        wholeSalePrice: selectdataforPurchaseDetail[0]?.WholeSalePrice,
                        multipleBarCode: selectdataforPurchaseDetail[0]?.MultipleBarCode,
                        wholeSale: selectdataforPurchaseDetail[0]?.WholeSale,
                        baseBarCode: selectdataforPurchaseDetail[0]?.BaseBarCode,

                    }
                    console.log(readyData,'readyData');
                    readyData.subTotal = Number(selectdataforPurchaseDetail[0]?.UnitPrice) * ele.Qty - Number(selectdataforPurchaseDetail[0]?.DiscountAmount);
                    readyData.totalAmount = readyData.subTotal + Number(selectdataforPurchaseDetail[0]?.GSTAmount);
                    let supplierMasterID = null;
                    let supplierMaster = await connection.query(
                        `Select * from PurchaseMaster where SupplierID = '${Body.supplier.ID}' and ShopID = '${Body.loggedInShop.ID}' and Status != 0 and PStatus = 0 limit 1`
                    );
                    if (supplierMaster.length === 0) {
                        let supplierMaster = await connection.query(`Insert INTO PurchaseMaster (SupplierID, CompanyID, ShopID, PaymentStatus, GSTNo, Quantity, TotalAmount,  Status, CreatedBy, CreatedOn, PStatus) values ('${Body.supplier.ID}','${CompanyID}','${Body.loggedInShop.ID}','Unpaid', '${Body.supplier.GSTNo}', 0, 0,1, '${LoggedOnUser.ID}', now(), 0)`);

                        supplierMasterID = supplierMaster.insertId;


                    } else {
                        supplierMasterID = supplierMaster[0].ID;

                    }
                    console.log(readyData.subTotal,'readyData.subTotal');

                    let insertPurchaseDetail = await connection.query(`Insert Into PurchaseDetail  (BillDetailIDForPreOrder,PurchaseID, CompanyID, ProductName,ProductTypeID,ProductTypeName, GSTPercentage, GSTAmount, GSTType, Status, CreatedBy, CreatedOn,DiscountPercentage,DiscountAmount,BaseBarCode,RetailPrice,WholeSalePrice,MultipleBarCode,WholeSale,UnitPrice,Quantity,SubTotal,TotalAmount) values ('${data.billDetailID}','${supplierMasterID}','${CompanyID}','${ele.ProductName}','${readyData.productTypeID}','${readyData.productTypeName}','${readyData.gSTPercentage}',${readyData.gSTAmount},'${readyData.gSTType}','1', '${LoggedOnUser.ID}', now(), '${readyData.discountPercentage}', '${readyData.discountAmount}', '${barcode}','${readyData.retailPrice}','${readyData.wholeSalePrice}','${readyData.multipleBarCode}','${readyData.wholeSale}',${readyData.unitPrice},${ele.Qty},${readyData.subTotal},${readyData.totalAmount})`);

                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster SET PurchaseDetailID = '${insertPurchaseDetail.insertId}', Po = '3' where BillDetailID = '${e.BillDetailID}'`)


                        })
                    }
                }


                if (Mode === "QC Done") {
                    let qry = `select * from BarcodeMaster where PreOrder = 2 and Po = 2 and BillDetailID = '${ele.BillDetailID}' and CompanyID = ${CompanyID}`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${ele.PreOrder}, Po = ${ele.Po} where BillDetailID = ${ele.BillDetailID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }
                if (Mode === "QC Cancel") {
                    let qry = `select * from BarcodeMaster where PreOrder = 3 and Po = 3 and BillDetailID = '${ele.BillDetailID}' and CompanyID = ${CompanyID}`;
                    let selectedBarcode = await connection.query(qry);
                    if (selectedBarcode.length != 0) {
                        selectedBarcode.map(async (e) => {
                            let updateBarcodeMaster = await connection.query(`Update BarcodeMaster set PreOrder = ${ele.PreOrder}, Po = ${ele.Po} where BillDetailID = ${ele.BillDetailID} and CompanyID = ${CompanyID}`)
                        })
                    }
                }


            }

            response.result = "result";
            response.success = "Success";
            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    // static async setPreOrderStatus(Body, LoggedOnUser, Mode, CompanyID) {
    //     const connection = await mysql.connection();
    //     try {
    //         let response = { data: null, success: null };
    //         await Promise.all(
    //             Body.filterList.map(async(ele) => {
    //                 let qry = `Update BarcodeMaster set PreOrder = ${ele.PreOrder} ,  SupplierID = ${ele.SupplierID} ,  FitterID = ${ele.FitterID} , LensType = '${ele.LensType}' , FitterCost = ${ele.FitterCost} , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${ele.ID} and CompanyID = ${CompanyID}`;
    //                 let result = await connection.query(qry);
    //                 response.result = result;
    //                 response.success = "Success";
    //             })
    //         );

    //         if (Mode === "AssignFitter") {
    //             let fitterMasterID = null;
    //             let fitterMaster = await connection.query(
    //                 `Select * from FitterMaster where FitterID = '${Body.fitter.ID}' and ShopID = '${Body.loggedInShop.ID}' and PStatus = 0 limit 1`
    //             );
    //             if (fitterMaster.length === 0) {
    //                 let qry = `Insert INTO FitterMaster (FitterID, CompanyID, ShopID, PaymentStatus, GSTNo, Quantity, TotalAmount,  Status, CreatedBy, CreatedOn, PStatus) values ('${Body.fitter.ID}','${CompanyID}','${Body.loggedInShop.ID}','Unpaid', '${Body.fitter.GSTNo}', 0, 0,1, '${LoggedOnUser.ID}', now(), 0)`;
    //                 let fitterMaster = await connection.query(qry);
    //                 fitterMasterID = fitterMaster.insertId;
    //             } else {
    //                 fitterMasterID = fitterMaster[0].ID;
    //             }

    //             Body.filterList.map(async(ele) => {
    //                 let qry = `Insert Into FitterDetail  (FitterMasterID, CompanyID, ProductName, UnitPrice, Quantity, TotalAmount, CustomerInvoice, BarcodeID, LensType, AssignedOn, Status, CreatedBy, CreatedOn) values ('${fitterMasterID}','${CompanyID}','${ele.ProductName}','${ele.FitterCost}',1,'${ele.FitterCost}', '${ele.InvoiceNo}', '${ele.ID}', '${ele.LensType}', now(), '1', '${LoggedOnUser.ID}', now())`;
    //                 let result = await connection.query(qry);
    //                 response.result = result;
    //                 response.success = "Success";
    //             });
    //         }

    //         if (Mode === "Assign") {
    //             let supplierMasterID = null;
    //             let supplierMaster = await connection.query(
    //                 `Select * from PurchaseMaster where SupplierID = '${Body.supplier.ID}' and ShopID = '${Body.loggedInShop.ID}' and PStatus = 0 limit 1`
    //             );
    //             if (supplierMaster.length === 0) {
    //                 let qry = `Insert INTO PurchaseMaster (SupplierID, CompanyID, ShopID, PaymentStatus, GSTNo, Quantity, TotalAmount,  Status, CreatedBy, CreatedOn, PStatus) values ('${Body.supplier.ID}','${CompanyID}','${Body.loggedInShop.ID}','Unpaid', '${Body.supplier.GSTNo}', 0, 0,1, '${LoggedOnUser.ID}', now(), 0)`;
    //                 let supplierMaster = await connection.query(qry);
    //                 supplierMasterID = supplierMaster.insertId;
    //             } else {
    //                 supplierMasterID = supplierMaster[0].ID;
    //             }

    //             Body.filterList.map(async(ele) => {
    //                 let qry = `Insert Into PurchaseDetail  (PurchaseID, CompanyID, ProductName, RetailPrice, Quantity, GSTPercentage, GSTType, WholeSalePrice, Status, CreatedBy, CreatedOn) values ('${supplierMasterID}','${CompanyID}','${ele.ProductName}','${ele.RetailPrice}',1,'${ele.GSTPercentage}','${ele.GSTType}', '${ele.WholeSalePrice}','1', '${LoggedOnUser.ID}', now())`;
    //                 let result = await connection.query(qry);

    //                 await connection.query(
    //                     `Update BarcodeMaster SET PurchaseDetailID = '${result.insertId}' where ID = '${ele.ID}'`
    //                 );
    //             });
    //         }
    //         response.result = "result";
    //         response.success = "Success";
    //         await connection.query("COMMIT");
    //         return response;
    //     } catch (err) {
    //         await connection.query("ROLLBACK");
    //         console.log("ROLLBACK at querySignUp", err);
    //         throw err;
    //     } finally {
    //         await connection.release();
    //     }
    // }

    static async getAllData(TableName) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getAllDataByID(TableName, ID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where CompanyID =  ${ID} and Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getAllDataByParem(TableName, Parem) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where ${Parem} and Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getShortListByCompany(
        TableName,
        LoggedOnUser,
        CompanyID,
        DelMode
    ) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getShortQuery(TableName, LoggedOnUser, CompanyID, DelMode);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getShortListByCompanyOrderBy(
        TableName,
        LoggedOnUser,
        CompanyID,
        DelMode
    ) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getShortQuery1(TableName, LoggedOnUser, CompanyID, DelMode);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getExtendedListByCompany(TableName, LoggedOnUser, CompanyID, ShopID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = this.getExtendedQuery(TableName, LoggedOnUser, CompanyID, ShopID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async customeridd(TableName, LoggedOnUser, CompanyID, ShopID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = this.getcustomeriddQuery(TableName, LoggedOnUser, CompanyID, ShopID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getExtendedCustomerListBy2(TableName, LoggedOnUser, CompanyID, ShopID,Page) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };


            let data = await connection.query(`SELECT Customer.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser,Shop.Name AS ShopName , Shop.AreaName AS AreaName FROM Customer LEFT JOIN User ON User.ID = Customer.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Customer.UpdatedBy LEFT JOIN Shop ON Shop.ID = Customer.ID WHERE  Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1 ORDER BY ID desc`);





            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getExtendedCustomerListBy(TableName, LoggedOnUser, CompanyID, ShopID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };


            let data = await connection.query(`SELECT Customer.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser,Shop.Name AS ShopName , Shop.AreaName AS AreaName FROM Customer LEFT JOIN User ON User.ID = Customer.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Customer.UpdatedBy LEFT JOIN Shop ON Shop.ID = Customer.ID WHERE  Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1 ORDER BY ID desc`);

            let spectacle_rx = await connection.query(`SELECT * FROM spectacle_rx WHERE CompanyID = ${CompanyID}  ORDER BY ID DESC`);

            let contact_lens_rx = await connection.query(`SELECT * FROM contact_lens_rx WHERE CompanyID = ${CompanyID} ORDER BY ID DESC`);


            data.forEach(ele => {
                ele.contact_lens_rx = [];
                ele.spectacle_rx = [];
                spectacle_rx.forEach(e => {
                    if (ele.ID === e.CustomerID) {
                        e.CustomerID = ele.ID
                        e.Name = ele.Name
                        e.MobileNo1 = ele.MobileNo1
                        e.MobileNo2 = ele.MobileNo2
                        e.PhoneNo = ele.PhoneNo
                        e.Email = ele.Email
                        e.DOB = ele.DOB
                        e.Anniversary = ele.Anniversary
                        e.Address = ele.Address
                        e.VisitDate = ele.VisitDate
                        ele.spectacle_rx.push(e);
                    }

                })
                contact_lens_rx.forEach(el => {
                    if (ele.ID === el.CustomerID) {
                        el.CustomerID = ele.ID
                        el.Name = ele.Name
                        el.MobileNo1 = ele.MobileNo1
                        el.MobileNo2 = ele.MobileNo2
                        el.PhoneNo = ele.PhoneNo
                        el.Email = ele.Email
                        el.DOB = ele.DOB
                        el.Anniversary = ele.Anniversary
                        el.Address = ele.Address
                        el.VisitDate = ele.VisitDate
                        ele.contact_lens_rx.push(el);

                    }
                })


            })

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getShortDataByID(TableName, ID, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getShortQueryByID(TableName, ID, CompanyID);
            let data = await connection.query(qry);

            response.result = data[0];
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getExtendedDataByID(TableName, ID, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getExtendedQueryByID(TableName, ID, CompanyID);
            let data = await connection.query(qry);

            response.result = data[0];
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getExtendedListByID(TableName, ID, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getExtendedQueryByID(TableName, ID, CompanyID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getShortListByParem(TableName, Parem, CompanyID) {
        let whereList = "";
        let p = Object.entries(JSON.parse(Parem));
        for (const [key, value] of p) {
            if (whereList !== "") {
                whereList = whereList + " and ";
            }
            whereList = whereList + " " + `${key} =  ${value}`;
        }
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getShortListQueryByParem(TableName, whereList, CompanyID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getGenericListByParem(TableName, Parem, CompanyID) {
        let whereList = "";

        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getExtendedListQueryByParem(TableName, Parem, CompanyID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async newpurchasereports(TableName, Parem, CompanyID) {
        let whereList = "";

        const connection = await mysql.connection();
        try {
            let response = { data: null,calculation: [{
                "totalQty": 0,
                "totalGstAmount": 0,
                "totalAmount": 0,
                "totalDiscount": 0,
                "totalUnitPrice": 0,
                "gst_details": []
            }], success: null };

            let qry = this.getExtendedListQueryByParem(TableName, Parem, CompanyID);
            let data = await connection.query(qry);

            let datum = await connection.query(`SELECT SUM(PurchaseDetail.Quantity) as totalQty, SUM(PurchaseDetail.GSTAmount) as totalGstAmount, SUM(PurchaseDetail.TotalAmount) as totalAmount, SUM(PurchaseDetail.DiscountAmount) as totalDiscount, SUM(PurchaseDetail.SubTotal) as totalUnitPrice  FROM PurchaseDetail INNER JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID LEFT JOIN Shop ON Shop.ID = PurchaseMaster.ShopID LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID LEFT JOIN Product ON Product.ID = PurchaseDetail.ProductTypeID WHERE PurchaseDetail.Status = 1  AND PurchaseDetail.CompanyID = ${CompanyID}  ` + Parem)

           let qry2 = `SELECT PurchaseDetail.*,PurchaseMaster.InvoiceNo, PurchaseMaster.PurchaseDate, PurchaseMaster.PaymentStatus, Shop.Name AS ShopName,  Shop.AreaName AS AreaName, Supplier.Name AS SupplierName,Supplier.GSTNo AS SupplierGSTNo,Product.HSNCode AS HSNcode  FROM PurchaseDetail INNER JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID LEFT JOIN Shop ON Shop.ID = PurchaseMaster.ShopID LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID LEFT JOIN Product ON Product.ID = PurchaseDetail.ProductTypeID WHERE PurchaseDetail.Status = 1 AND PurchaseDetail.CompanyID = ${CompanyID}  ` + Parem;

            let data2 = await connection.query(qry2);

            let gstTypes = await connection.query(`select * from SupportMaster where CompanyID = ${CompanyID} and Status = 1 and TableName = 'TaxType'`)

            gstTypes = JSON.parse(JSON.stringify(gstTypes)) || []
            const values = []

            if (gstTypes.length) {
                for (const item of gstTypes) {
                    if ((item.Name).toUpperCase() === 'CGST-SGST') {
                        values.push(
                            {
                                GSTType: `CGST`,
                                Amount: 0
                            },
                            {
                                GSTType: `SGST`,
                                Amount: 0
                            }
                        )
                    } else {
                        values.push({
                            GSTType: `${item.Name}`,
                            Amount: 0
                        })
                    }
                }

            }
            const values2 = []

            if (gstTypes.length) {
                for (const item of gstTypes) {
                    values2.push({
                            GSTType: `${item.Name}`,
                            GSTAmount: 0
                        })
                }
            }

            if (data2.length && values.length) {
                for (const item of data2) {
                    values.forEach(e => {
                        if (e.GSTType === item.GSTType) {
                            e.Amount += item.GSTAmount
                        }

                        // CGST-SGST

                        if (item.GSTType === 'CGST-SGST') {

                            if (e.GSTType === 'CGST') {
                                e.Amount += item.GSTAmount / 2
                            }

                            if (e.GSTType === 'SGST') {
                                e.Amount += item.GSTAmount / 2
                            }
                        }
                    })

                }

            }

            if (data.length) {
             for(let item of data) {
                item.gst_details = []
                for(let item2 of data2) {
                    if (item.ID === item2.PurchaseID) {
                        item.gst_details.push({
                            "GSTType" : item2.GSTType,
                            "GSTAmount": item2.GSTAmount
                        })

                    }
                }
             }
            }




            // if (data.length) {
            //     for (let item of data) {
            //         item.gst_detail = values2
            //         for (const item2 of data2) {
            //             if (item.ID === item2.PurchaseID) {

            //                 // if (item2.GSTType !== 'CGST-SGST') {
            //                 //     gst_detail.push({
            //                 //         'GSTType': item2.GSTType,
            //                 //         'GSTAmount': item2.GSTAmount
            //                 //     })
            //                 // } else {
            //                 //     gst_detail.push(
            //                 //         {
            //                 //             'GSTType': 'CGST',
            //                 //             'GSTAmount': item2.GSTAmount / 2
            //                 //         },
            //                 //         {
            //                 //             'GSTType': 'SGST',
            //                 //             'GSTAmount': item2.GSTAmount / 2
            //                 //         }
            //                 //     )
            //                 // }
            //             }
            //         }
            //     }

            // }



            response.calculation[0].gst_details = values;

            response.calculation[0].totalQty = datum[0].totalQty ? datum[0].totalQty : 0
            response.calculation[0].totalGstAmount = datum[0].totalGstAmount ? datum[0].totalGstAmount : 0
            response.calculation[0].totalAmount = datum[0].totalAmount ? datum[0].totalAmount : 0
            response.calculation[0].totalDiscount = datum[0].totalDiscount ? datum[0].totalDiscount : 0
            response.calculation[0].totalUnitPrice = datum[0].totalUnitPrice ? datum[0].totalUnitPrice : 0

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async getGenericListByParemSalePayment(TableName, Parem, CompanyID) {
        let whereList = "";

        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(`SELECT DISTINCT(BillMaster.ID), BillMaster.*, Shop.Name AS ShopName, Shop.AreaName AS AreaName, Customer.Name AS CustomerName , Customer.MobileNo1,Customer.GSTNo AS GSTNo, BillDetail.ProductStatus as ProductStatus, BillDetail.HSNCode as HSNCode, BillDetail.ProductDeliveryDate as ProductDeliveryDate,BillDetail.GSTType AS GSTType ,BillDetail.UnitPrice AS UnitPrice,BillMaster.DeliveryDate AS DeliveryDate FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
            LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID  LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID  WHERE BillMaster.CompanyID = ${CompanyID} and (BillDetail.Manual = 0 || BillDetail.Manual = 1 )and BillMaster.Status = 1 ` +
            Parem + " GROUP BY BillMaster.InvoiceNo ");


            data.forEach(async(e, i) => {
                let Payments = []
                let Payment = await connection.query(`SELECT PaymentDetail.*, PaymentMaster.PaymentMode,PaymentMaster.PaymentDate  FROM PaymentDetail
                LEFT JOIN  PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
                WHERE PaymentMaster.PaymentType = 'Customer' AND PaymentDetail.BillID = '${e.InvoiceNo}' AND PaymentDetail.CompanyID = '${CompanyID}'`)
                Payments = Payment;
                e.paymentDetail = Payments;

            })




            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async getGenericListByParemSaleReport(TableName, Parem, CompanyID) {
        let whereList = "";

        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = this.getExtendedListQueryByParem(TableName, Parem, CompanyID);
            let data = await connection.query(qry);
            console.log(data,'data1data145754575');
            let modify = []
            data.forEach(async(e, i) => {
                if (e.Manual === 0) {
                  let detail = await connection.query(`select * from PurchaseDetail where BaseBarCode = '${e.Barcode.slice(0,-3)}' and CompanyID = '${CompanyID}'`)
                  let Discount = 0
                  Discount = Number(detail[0]?.UnitPrice) * Number(e.Quantity) * Number(detail[0]?.DiscountPercentage) / 100
                  let SubTotal = 0
                  SubTotal = Number(detail[0]?.UnitPrice) * Number(e.Quantity) - Discount;
                  let GSTAmount = 0
                  GSTAmount = SubTotal  * Number(detail[0]?.GSTPercentage) / 100;
                  e.PurchaseRate = SubTotal + GSTAmount
                  e.Profit = e.TotalAmount - e.PurchaseRate
                  modify.push(e)
                } else {
                    e.PurchaseRate = 0
                  e.Profit = e.TotalAmount - e.PurchaseRate
                  // e.PurchaseRate = e.UnitPrice

                  modify.push(e)
                }
            })
            response.result = modify;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }




    static async getLaserReportpdf(CustomerID, Parem, CompanyID) {
        let whereList = "";
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let finalArray = []
            let Bill = await connection.query(
                `SELECT Customer.Name AS CustomerName, Customer.MobileNo1 AS CustomerMob, BillMaster.* FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID WHERE  BillMaster.Status = 1` + Parem + ` and BillMaster.CompanyID = ${CompanyID}`
            );
            Bill.forEach(e => {
                e.Type = 'Invoice'
                e.types = ''
                finalArray.push(e);
            })

            let Temp = []
            await Promise.all(
                finalArray.map(async (ele) => {
                    let res = await connection.query(
                        `select PaymentMaster.*, PaymentDetail.BillID as InvoiceNo, PaymentDetail.Amount as InvoiceAmount, PaymentDetail.CreatedOn from PaymentMaster LEFT JOIN PaymentDetail ON PaymentDetail.PaymentMasterID = PaymentMaster.ID where PaymentDetail.BillID = '${ele.InvoiceNo}' and PaymentMaster.PaymentType = 'Customer' and PaymentMaster.CompanyID = ${CompanyID}  ORDER BY InvoiceNo ASC`
                    );

                    res.forEach(e => {
                        e.Type = 'Payment Recieved'
                        e.types = 'For Payment Of - '
                        Temp.push(e);
                    })

                })
            );

            let Array = []
            finalArray.forEach(e => {
                Array.push(e)
            })
            Temp.forEach(e => {
                Array.push(e)
            })


            Array.sort(function (a, b) {
                var c = new Date(a.CreatedOn).getTime();
                var d = new Date(b.CreatedOn).getTime();
                return c > d ? 1 : -1;
            })


            let totals = 0;
            let InvoicedAmount = 0
            let AmountPaid = 0
            Array.forEach(e => {
                if (e.Type === 'Invoice') {
                    totals = Number(totals) + Number(e.TotalAmount);
                    InvoicedAmount = Number(InvoicedAmount) + Number(e.TotalAmount);
                    e.totals = totals.toFixed(2);
                } else if (e.Type === 'Payment Recieved') {
                    if (e.PaymentMode === 'Customer Return') {
                        e.PaidAmount = Number(e.InvoiceAmount);
                    }
                    totals = Number(totals) - Number(e.InvoiceAmount);
                    e.totals = totals.toFixed(2);
                    AmountPaid = Number(AmountPaid) + Number(e.InvoiceAmount);
                }
            })
            response.data = Array;
            response.InvoicedAmount = InvoicedAmount;
            response.AmountPaid = AmountPaid;
            response.BalanceDue = (Number(InvoicedAmount) - Number(AmountPaid)).toFixed(2);
            response.success = "Success";

            console.log(response, 'response');
            await connection.query("COMMIT");
            return response;

        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getlaserReportSubpdf(SupplierID, Parem, CompanyID) {
        let whereList = "";
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let finalArray = []
            let Bill = await connection.query(
                `SELECT Supplier.Name AS SupplierName, Supplier.MobileNo1 AS SupplierMob, PurchaseMaster.* FROM PurchaseMaster
                LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID  WHERE PurchaseMaster.Status = 1` + Parem + ` and PurchaseMaster.CompanyID = ${CompanyID}`
            );
            console.log(Bill,'Bills');
            Bill.forEach(e => {
                e.Type = 'Invoice'
                e.types = ''
                finalArray.push(e);
            })

            let Temp = []
            await Promise.all(
                finalArray.map(async (ele) => {
                    let res = await connection.query(
                        `select PaymentMaster.*, PaymentDetail.BillID as InvoiceNo, PaymentDetail.Amount as InvoiceAmount,PaymentDetail.CreatedOn from PaymentMaster LEFT JOIN PaymentDetail ON PaymentDetail.PaymentMasterID = PaymentMaster.ID where PaymentDetail.BillID = '${ele.InvoiceNo}' and PaymentDetail.PaymentType IN('Vendor' , 'Vendor Credit')  and PaymentDetail.BillMasterID !=  0 ` + ` and PaymentMaster.CompanyID = ${CompanyID} and PaymentMaster.CustomerID = ${SupplierID}  `
                    );
                    console.log(res,'ress');
                    res.forEach(e => {
                        e.Type = 'Payment Recieved'
                        e.types = 'For Payment Of - '
                        Temp.push(e);
                    })

                })
            );
           console.log(Temp,'Temps');
            let Array = []
            finalArray.forEach(e => {
                Array.push(e)
            })
            Temp.forEach(e => {
                Array.push(e)
            })


            Array.sort(function (a, b) {
                var c = new Date(a.CreatedOn).getTime();
                var d = new Date(b.CreatedOn).getTime();
                return c > d ? 1 : -1;
            })


            let totals = 0;
            let InvoicedAmount = 0
            let AmountPaid = 0
            Array.forEach(e => {
                if (e.Type === 'Invoice') {
                    totals = Number(totals) + Number(e.TotalAmount);
                    InvoicedAmount = Number(InvoicedAmount) + Number(e.TotalAmount);
                    e.totals = totals;
                } else if (e.Type === 'Payment Recieved') {
                    if(e.PaymentType === 'Supplier' && e.PayableAmount == 0) {
                        e.PaymentMode = 'Vendor Credit'
                    }
                    totals = Number(totals) - Number(e.InvoiceAmount);
                    e.totals = totals;
                    AmountPaid = Number(AmountPaid) + Number(e.InvoiceAmount);
                }
            })
            response.data = Array;
            response.InvoicedAmount = InvoicedAmount;
            response.AmountPaid = AmountPaid;
            response.BalanceDue = Number(InvoicedAmount) - Number(AmountPaid);
            response.success = "Success";

            console.log(response, 'response');
            await connection.query("COMMIT");
            return response;

        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getlaserReportemppdf(EmployeeID, Parem, CompanyID) {
        let whereList = "";
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let finalArray = []
            let Bill = await connection.query(
                `SELECT User.Name AS EmpName, User.MobileNo1 AS Mob, Payroll.*  FROM Payroll LEFT JOIN User ON User.ID = Payroll.EmployeeID WHERE Payroll.Status = 1` + Parem + ` and Payroll.CompanyID = ${CompanyID}`
            );

            Bill.forEach(e => {
                e.Type = 'Invoice'
                e.types = ''
                finalArray.push(e);
            })

            let Temp = []
            await Promise.all(
                finalArray.map(async (ele) => {
                    let res = await connection.query(
                        `select PaymentMaster.*, PaymentDetail.BillID as InvoiceNo, PaymentDetail.Amount as InvoiceAmount,PaymentDetail.CreatedOn from PaymentMaster LEFT JOIN PaymentDetail ON PaymentDetail.PaymentMasterID = PaymentMaster.ID where PaymentDetail.BillID = '${ele.InvoiceNo}' and PaymentDetail.PaymentType IN('Employee' , 'Employee Credit')  and PaymentDetail.BillMasterID !=  0  and PaymentMaster.CompanyID = ${CompanyID}`
                    );
                     console.log(res,'res');
                    res.forEach(e => {
                        e.Type = 'Payment Recieved'
                        e.types = 'For Payment Of - '
                        Temp.push(e);
                    })

                })
            );

            let Array = []
            finalArray.forEach(e => {
                Array.push(e)
            })
            Temp.forEach(e => {
                Array.push(e)
            })


            Array.sort(function (a, b) {
                var c = new Date(a.CreatedOn).getTime();
                var d = new Date(b.CreatedOn).getTime();
                return c > d ? 1 : -1;
            })


            let totals = 0;
            let InvoicedAmount = 0
            let AmountPaid = 0
            Array.forEach(e => {
                if (e.Type === 'Invoice') {
                    totals = Number(totals) + Number(e.TotalAmount);
                    InvoicedAmount = Number(InvoicedAmount) + Number(e.TotalAmount);
                    e.totals = totals;
                } else if (e.Type === 'Payment Recieved') {
                    if(e.PaymentType === 'Employee' && e.PayableAmount == 0) {
                        e.PaymentMode = 'Employee Credit'
                    }
                    totals = Number(totals) - Number(e.InvoiceAmount);
                    e.totals = totals;
                    AmountPaid = Number(AmountPaid) + Number(e.InvoiceAmount);
                }
            })
            response.data = Array;
            response.InvoicedAmount = InvoicedAmount;
            response.AmountPaid = AmountPaid;
            response.BalanceDue = Number(InvoicedAmount) - Number(AmountPaid);
            response.success = "Success";

            console.log(response, 'response');
            await connection.query("COMMIT");
            return response;

        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getAggregateListByParem(
        TableName1,
        TableName2,
        Parem,
        CompanyID
    ) {
        let whereList = "";

        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getExtendedListQueryByParem(TableName1, Parem, CompanyID);
            let data = await connection.query(qry);

            await Promise.all(
                data.map(async (ele) => {
                    let res = await connection.query(
                        `select * from ${TableName2} where BillID = ${ele.ID} AND Status = 1`
                    );
                    ele.Detail = res;
                })
            );
            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getShortListByParemNew(TableName, Parem, CompanyID) {
        let whereList = "";
        let prm = JSON.parse(Parem);
        prm.forEach((element) => {
            if (whereList !== "") {
                whereList = whereList + " and ";
            }
            const x = Object.keys(element)[0];
            whereList = whereList + " " + `${x}  ${element.op}  '${element[x]}'`;
        });

        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            console.log(whereList, 'whereList');
            let qry = this.getShortListQueryByParem1(TableName, whereList, CompanyID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async shortListByParemNewBill(TableName, Parem, CompanyID) {
        let whereList = "";
        let prm = JSON.parse(Parem);
        prm.forEach((element) => {
            if (whereList !== "") {
                whereList = whereList + " and ";
            }
            const x = Object.keys(element)[0];
            whereList = whereList + " " + `${x}  ${element.op}  '${element[x]}'`;
        });

        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            console.log(whereList, 'whereList');
            let qry = this.getShortListQueryByParemBill(TableName, whereList, CompanyID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getExtendedListByParemNew(TableName, Parem, CompanyID) {
        let whereList = "";
        let prm = JSON.parse(Parem);
        prm.forEach((element) => {
            if (whereList !== "") {
                whereList = whereList + " and ";
            }
            const x = Object.keys(element)[0];
            whereList = whereList + " " + `${x}  ${element.op}  '${element[x]}'`;
        });

        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getExtendedListQueryByParem(
                TableName,
                whereList,
                CompanyID
            );
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getExtendedListByParem(TableName, Parem, CompanyID) {
        let whereList = "";
        let p = Object.entries(JSON.parse(Parem));
        for (const [key, value] of p) {
            if (whereList !== "") {
                whereList = whereList + " and ";
            }
            whereList = whereList + " " + `${key} =  ${value}`;
        }
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getExtendedListQueryByParem(
                TableName,
                whereList,
                CompanyID
            );
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getPaymentListByPaymentType(PaymentType, Parem, CompanyID) {
        let whereList = "";
        let p = Object.entries(JSON.parse(Parem));
        for (const [key, value] of p) {
            if (whereList !== "") {
                whereList = whereList + " and ";
            }
            whereList = whereList + " " + `${key} =  ${value}`;
        }
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry;
            let subqry;
            let subqry1;
            switch (PaymentType) {
                case "Supplier":
                    subqry = "Supplier.Name AS Name";
                    subqry1 = "Supplier ON Supplier.ID = ";
                    break;

                case "Fitter":
                    subqry = "Fitter.Name AS Name";
                    subqry1 = "Fitter ON Fitter.ID = ";
                    break;

                case "Doctor":
                    subqry = "Doctor.Name AS Name";
                    subqry1 = "Doctor ON Doctor.ID = ";
                    break;

                case "Employee":
                    subqry = "User.Name AS Name";
                    subqry1 = "User ON User.ID = ";
                    break;

                case Other:
                    break;
            }

            qry = `SELECT DISTINCT( PaymentMaster.ID),  PaymentMaster.*, ${subqry}, Shop.Name AS ShopName, User1.Name AS CreatedByUser, User2.Name AS UpdatedByUser, PaymentDetail.DueAmount AS Due , PaymentDetail.Amount As PAmount, PaymentDetail.BillID
         FROM PaymentMaster LEFT JOIN ${subqry1} PaymentMaster.CustomerID LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
         LEFT JOIN User as User1 ON User1.ID = PaymentMaster.CreatedBy LEFT JOIN User AS User2 ON User2.ID = PaymentMaster.UpdatedBy LEFT JOIN PaymentDetail ON  PaymentDetail.PaymentMasterID = PaymentMaster.ID WHERE PaymentMaster.Status =1
          and PaymentMaster.CompanyID = '${CompanyID}' and  ${whereList} and PaymentMaster.PaymentType = '${PaymentType}' and PaymentDetail.BillID != '' Order By PaymentMaster.ID Desc`;

            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getPurchaseFullDataByID(ID, LoggedOnUser, CompanyID) {
        let data = {
            PurchaseMaster: null,
            Product: null,
            PurchaseDetail: null,
            Charge: null,
        };
        let response = { data: null, success: null };

        const connection = await mysql.connection();
        try {
            let bMasterQry = `select PurchaseMaster.*, Supplier.Name as SupplierName from  PurchaseMaster Left Join Supplier on Supplier.ID = PurchaseMaster.SupplierID where PurchaseMaster.CompanyID =  ${CompanyID} and PurchaseMaster.ID = ${ID} and PurchaseMaster.Status = 1`;
            let billMaseterData = await connection.query(bMasterQry);
            data.PurchaseMaster = billMaseterData[0];

            let billDetailData = await connection.query(
                `select * from  PurchaseDetail where CompanyID =  ${CompanyID} and PurchaseID = ${ID} order by ID desc`
            );
            // await Promise.all(
            //     billDetailData.map(async(ele) => {
            //         let qry = this.getProductSpecQuery(ele.ID, CompanyID);
            //         let specData = await connection.query(qry);
            //         ele.Spec = specData;
            //     })
            // );
            data.PurchaseDetail = billDetailData;

            let charge = await connection.query(
                `SELECT PurchaseCharge.*, ChargerMaster.Name AS ChargerName FROM  PurchaseCharge
               LEFT JOIN ChargerMaster ON ChargerMaster.ID = PurchaseCharge.ChargeType where PurchaseCharge.CompanyID =  ${CompanyID} and PurchaseCharge.PurchaseID = ${ID}`
            );
            data.Charge = charge;

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getFitterInvoiceFullDataByID(ID, LoggedOnUser, CompanyID) {
        let data = {
            FitterMaster: null,
            FitterDetail: null,
        };
        let response = { data: null, success: null };

        const connection = await mysql.connection();
        try {
            let bMasterQry = `select FitterMaster.*, Fitter.Name as FitterName, Shop.Name AS ShopName from  FitterMaster
      Left Join Fitter on Fitter.ID = FitterMaster.FitterID LEFT JOIN Shop ON Shop.ID = FitterMaster.ShopID where FitterMaster.CompanyID =  ${CompanyID} and FitterMaster.ID = ${ID}
      and FitterMaster.Status = 1`;
            let fitterMaseterData = await connection.query(bMasterQry);
            data.FitterMaster = fitterMaseterData[0];

            let fitterDetailData = await connection.query(
                `select * from  FitterDetail where CompanyID =  ${CompanyID} and FitterMasterID = ${ID}`
            );

            data.FitterDetail = fitterDetailData;

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getCommissionInvoiceFullDataByID(ID, UserType, LoggedOnUser, CompanyID) {
        let data = {
            CommissionMaster: null,
            CommissionDetail: null,
        };
        let response = { data: null, success: null };

        const connection = await mysql.connection();
        try {
            let qry = "";
            if (UserType === 'Doctor') {
                qry = `Select CommissionMaster.*, Shop.Name as ShopName, Shop.AreaName as AreaName, Doctor.Name as UserName, User.Name as CreatedByEmp from CommissionMaster
        inner join Doctor on Doctor.ID = CommissionMaster.UserID inner join User on User.ID = CommissionMaster.CreatedBy
        inner join Shop on Shop.ID = CommissionMaster.ShopID where CommissionMaster.ID  = ${ID}`
            } else if (UserType === 'Employee') {
                qry = `Select CommissionMaster.*, Shop.Name as ShopName,Shop.AreaName as AreaName, User1.Name as UserName, User.Name as CreatedByEmp from CommissionMaster
        inner join User as User1 on User1.ID = CommissionMaster.UserID inner join User on User.ID = CommissionMaster.CreatedBy
        inner join Shop on Shop.ID = CommissionMaster.ShopID  where CommissionMaster.ID  = ${ID}`
            }
            let comissionMaseterData = await connection.query(qry);
            data.CommissionMaster = comissionMaseterData[0];

            let commissionDetailData = await connection.query(
                `select * from  CommissionDetail where CompanyID =  ${CompanyID} and CommissionMasterID = ${ID}`
            );

            data.CommissionDetail = commissionDetailData;

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getDataByID(TableName, ID, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where ID = ${ID} and CompanyID = ${CompanyID} and Status = 1`
            );

            response.result = data[0];
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getDataByOtherID(TableName, CompanyID, ID, LoggedOnUser, Shop) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getdataByotherID(TableName, CompanyID, ID, LoggedOnUser, Shop);
            console.log(qry, 'qryyyyy');
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getSearchDataByFilter(TableName, CompanyID, filter) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let qry = this.getdataByFilter(TableName, CompanyID, filter);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }
    static async getSearchDataByFilterForCashRegister(TableName, CompanyID, Filter) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            const filter = JSON.parse(Filter);

            let PettyCash = await connection.query(`SELECT * from PettyCash WHERE CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}' and  CreatedOn > '${filter.date1}' and Status = 1`);

            let PettyCashToday = await connection.query(`SELECT SUM(PettyCash.Amount) as Amount  from PettyCash WHERE CreditType='Deposit' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}' and  CreatedOn > '${filter.date1}' and Status = 1`);

            let PettyCashOld = await connection.query(`SELECT SUM(PettyCash.Amount) as Amount from PettyCash WHERE CreditType='Deposit' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}' and  CreatedOn > '${filter.date1}' and Status = 1`);

            let PettyCashwithdrawal = await connection.query(`SELECT SUM(PettyCash.Amount) as Amount from PettyCash WHERE CreditType='Withdrawal' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}' and CashType = 'CashCounter' and CreatedOn > '${filter.date1}' and Status = 1`);

            let PaymentMaster = await connection.query(`SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Customer' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}'  and CreatedOn > '${filter.date1}' and Status = 1`);

            let DoctorTodayPayment = await connection.query(`SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Doctor' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}'  and CreatedOn > '${filter.date1}' and Status = 1`);


            let EmployeeTodayPayment = await connection.query(`SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Employee' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}'  and CreatedOn > '${filter.date1}' and Status = 1`);

            let FitterTodayPayment = await connection.query(`SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Fitter' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}'  and CreatedOn > '${filter.date1}' and Status = 1`);

            let SupplierTodayPayment = await connection.query(`SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Supplier' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}'  and CreatedOn > '${filter.date1}' and Status = 1`);

            let ExpenseCash = await connection.query(`SELECT SUM(Expense.Amount) as Amount from Expense WHERE CashType = 'PettyCash' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}'  and CreatedOn > '${filter.date1}' and Status = 1`);

            let ExpenseCashCounter = await connection.query(`SELECT SUM(Expense.Amount) as Amount from Expense WHERE CashType = 'CashCounter' and CompanyID = '${CompanyID}' and ShopID = '${filter.ShopID}'  and CreatedOn > '${filter.date1}' and Status = 1`);




            response.PettyCash = PettyCash;
            response.PaymentMaster = PaymentMaster;
            response.DoctorTodayPayment = DoctorTodayPayment;
            response.EmployeeTodayPayment = EmployeeTodayPayment;
            response.FitterTodayPayment = FitterTodayPayment;
            response.SupplierTodayPayment = SupplierTodayPayment;
            response.ExpenseCash = ExpenseCash;
            response.ExpenseCashCounter = ExpenseCashCounter;
            response.PettyCashwithdrawal = PettyCashwithdrawal;
            response.PettyCashToday = PettyCashToday;
            response.PettyCashOld = PettyCashOld;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getFieldList(ProductType, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `Select ProductSpec.ID as SpecID, ProductSpec.ProductName , ProductSpec.Required , ProductSpec.CompanyID, ProductSpec.Name as FieldName, ProductSpec.Seq, ProductSpec.Type as FieldType, ProductSpec.Ref, ProductSpec.SptTableName, null as SptTableData, '' as SelectedValue, false as DisplayAdd,  '' as EnteredValue, null as SptFilterData from ProductSpec where ProductSpec.ProductName = '${ProductType}' and CompanyID = '${CompanyID}' and Status = 1  Order By ProductSpec.Seq ASC`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getDataByName(TableName, Name, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  ${TableName} where ProductName = '${Name}' and Status = 1 and CompanyID = ${CompanyID}`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getCommissionList(Parem, UserType, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = '';
            if (UserType === 'Doctor') {
                qry = `Select CommissionMaster.*, Shop.Name as ShopName, Doctor.Name as UserName, User.Name as CreatedByEmp from CommissionMaster
        inner join Doctor on Doctor.ID = CommissionMaster.UserID inner join User on User.ID = CommissionMaster.CreatedBy
        inner join Shop on Shop.ID = CommissionMaster.ShopID where CommissionMaster.CompanyID = ${CompanyID} ${Parem}
        and UserType = '${UserType}' order by CommissionMaster.ID Desc `
            } else if (UserType === 'Employee') {
                qry = `Select CommissionMaster.*, Shop.Name as ShopName, User1.Name as UserName, User.Name as CreatedByEmp from CommissionMaster
        inner join User as User1 on User1.ID = CommissionMaster.UserID inner join User on User.ID = CommissionMaster.CreatedBy
        inner join Shop on Shop.ID = CommissionMaster.ShopID where CommissionMaster.CompanyID = ${CompanyID} ${Parem}
        order by CommissionMaster.ID Desc `
            }

            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getCustomerCreditInfo(mode, CustomerID, ShopID, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = '';
            if (mode === 'Customer Credit') {
                qry = `SELECT PaymentMaster.ID, PaymentMaster.PaymentDate, PaymentMaster.PaymentReferenceNo AS RefundFromInvoice, PaymentMaster.PaymentMode, PaymentMaster.PaidAmount, User.Name AS PaymentAcceptedByUser,
        Shop.Name AS ShopName, User1.Name AS CreditedByUser, PaymentDetail.*
        FROM PaymentDetail
        LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
        LEFT JOIN User ON User.ID = PaymentMaster.CreatedBy
        LEFT JOIN User AS User1 ON User1.ID = PaymentMaster.CreatedBy
        LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
        WHERE PaymentDetail.CustomerID = ${CustomerID} AND
        PaymentDetail.PaymentType = 'Customer Credit' AND PaymentDetail.Amount <> 0 AND PaymentMaster.ShopID = ${ShopID}
        AND PaymentMaster.CompanyID = ${CompanyID}`
            } else if (mode === 'Customer') {
                qry = `SELECT PaymentMaster.ID, PaymentMaster.PaymentDate, PaymentMaster.PaymentReferenceNo AS RefundFromInvoice, PaymentMaster.PaymentMode, PaymentMaster.PaidAmount, User.Name AS PaymentAcceptedByUser,
        Shop.Name AS ShopName, User1.Name AS CreditedByUser,PaymentDetail.*
        FROM PaymentDetail
        LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
        LEFT JOIN User ON User.ID = PaymentMaster.CreatedBy
        LEFT JOIN User AS User1 ON User1.ID = PaymentMaster.CreatedBy
        LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
        WHERE PaymentDetail.CustomerID = ${CustomerID} AND PaymentMaster.PaymentMode = 'Customer Return'
        AND PaymentDetail.PaymentType = 'Customer' AND PaymentDetail.Amount <> 0 AND PaymentMaster.ShopID = ${ShopID}
        AND PaymentMaster.CompanyID = ${CompanyID} `
            }

            let data = await connection.query(qry);

            response = data;
            // response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getDashboardData(Date1, Date2, ShopID, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let res = { TotalCustomerCount: 0, CustomerCount: 0, SaleTotal: 0, PurchaseTotal: 0, ExpenseTotal: 0, SalesCount: 0 };
            let PurchaseShopID = ``;
            let BillMasterShopID = ``;
            let ExpenseShopID = ``;
            if (ShopID == 0) {
                PurchaseShopID = " ";
                BillMasterShopID = " ";
                ExpenseShopID = " ";


            } else {
                PurchaseShopID = `And PurchaseMaster.ShopID = '${ShopID}'`;
                BillMasterShopID = `And BillMaster.ShopID = '${ShopID}'`;
                ExpenseShopID = `And Expense.ShopID = '${ShopID}'`;


            }
            res.TotalCustomerCount = await connection.query(
                `SELECT COUNT(Customer.ID) as Count FROM Customer WHERE  Customer.CompanyID = ${CompanyID} and Customer.Status = 1`
            );
            res.CustomerCount = await connection.query(
                `SELECT COUNT(Customer.ID) as Count FROM Customer WHERE DATE_FORMAT(Customer.CreatedOn, "%Y-%m-%d") between '${Date1}' and '${Date2}' and Customer.CompanyID = ${CompanyID} and Customer.Status = 1`
            );

            res.SaleTotal = await connection.query(
                `Select Sum(BillDetail.TotalAmount) as Count from BillDetail LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID  where  DATE_FORMAT(BillDetail.CreatedOn, "%Y-%m-%d") between '${Date1}' and '${Date2}'  and BillDetail.CompanyID = ${CompanyID} ${BillMasterShopID}`
            );

            res.PurchaseTotal = await connection.query(
                `SELECT SUM(PurchaseDetail.TotalAmount) as Count FROM PurchaseDetail left join PurchaseMaster on PurchaseMaster.ID = PurchaseDetail.PurchaseID WHERE DATE_FORMAT(PurchaseDetail.CreatedOn, "%Y-%m-%d") BETWEEN '${Date1}' AND '${Date2}'  AND PurchaseDetail.CompanyID = ${CompanyID} ${PurchaseShopID}`
            );

            res.ExpenseTotal = await connection.query(
                `SELECT SUM(Amount) as Count FROM Expense WHERE DATE_FORMAT(Expense.CreatedOn, "%Y-%m-%d") BETWEEN '${Date1}' AND '${Date2}'  AND Expense.CompanyID = ${CompanyID} ${ExpenseShopID}`
            );

            res.SalesCount = await connection.query(
                `SELECT COUNT(BarcodeMaster.ID) AS Count FROM BarcodeMaster LEFT JOIN BillDetail ON BillDetail.ID = BarcodeMaster.BillDetailID LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
        WHERE DATE_FORMAT(BillDetail.CreatedOn, "%Y-%m-%d") BETWEEN '${Date1}' AND '${Date2}' AND BillMaster.CompanyID = ${CompanyID} ${BillMasterShopID} AND BarcodeMaster.CurrentStatus = 'Sold'
         `
            );

            if (res.TotalCustomerCount[0].Count === null) { res.TotalCustomerCount[0].Count = 0 }
            if (res.CustomerCount[0].Count === null) { res.CustomerCount[0].Count = 0 }
            if (res.SaleTotal[0].Count === null) { res.SaleTotal[0].Count = 0 }
            if (res.PurchaseTotal[0].Count === null) { res.PurchaseTotal[0].Count = 0 }
            if (res.ExpenseTotal[0].Count === null) { res.ExpenseTotal[0].Count = 0 }
            if (res.SalesCount[0].Count === null) { res.SalesCount[0].Count = 0 }
            response.result = res;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async getPermissionByRole(ID, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from  RolePermission where ProductName = '${Name}' and Status = 1 and CompanyID = ${CompanyID}`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getProductSupportData(TableName, Ref, LoggedOnUser, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from SpecSptTable where RefID = '${Ref}' and TableName = '${TableName}' and Status = 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async saveProductSupportData(
        TableName,
        Ref,
        SelectedValue,
        LoggedOnUser,
        CompanyID
    ) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data = await connection.query(
                `insert into SpecSptTable (TableName,  RefID, TableValue, Status) values ('${TableName}','${Ref}','${SelectedValue}',1)`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async saveData(Body, LoggedOnUser, TableName, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = this.getQuery(Body, LoggedOnUser, TableName, CompanyID);
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async saveSmallData(TableName, ID, Parem, CompanyID) {
        let updateList = "";
        let p = Object.entries(Parem);
        for (const [key, value] of p) {
            updateList = updateList + " " + `${key} =  ${value}`;
        }
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = `Update ${TableName} SET ${updateList} where ID = '${ID}'`;
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async updateData(ID, datax, LoggedOnUser, TableName, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry = `update ${TableName} set ${datax} , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${ID} and CompanyID = ${CompanyID} `;
            let data = await connection.query(qry);

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async deleteData(LoggedOnUser, TableName, ID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data = await connection.query(
                `update ${TableName} set Status = 0 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ID = '${ID}' `
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async deleteOtherID(LoggedOnUser, TableName, ID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data = await connection.query(
                `update ${TableName} set Status = 0 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ShopID = '${ID}' `
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async deletePreOrder(LoggedOnUser, TableName, ID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data1 = await connection.query(
                `update PurchaseDetail set Status = 0 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ID = '${ID}' and PurchaseID = 0`
            );

            let data = await connection.query(
                `update BarcodeMaster set Status = 0 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where PurchaseDetailID = '${ID}' and CurrentStatus = 'Pre Order'`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async deletePermanent(LoggedOnUser, TableName, ID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data = await connection.query(
                `update ${TableName} set Status = 2 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ID = '${ID}' `
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async Retrive(LoggedOnUser, TableName, ID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data = await connection.query(
                `update ${TableName} set Status = 1 , UpdatedOn = now() , UpdatedBy = ${LoggedOnUser.ID} where ID = '${ID}' `
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


    static async checkforDuplicate(TableName, LoginName) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let data = await connection.query(
                `Select * from ${TableName} where LoginName = '${LoginName}' AND Status = 1`
            );
            if (data.length === 0) {
                response.result = true;
            } else {
                response.result = false;
            }
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static getQuery(Body, LoggedOnUser, TableName, CompanyID) {
        let qry = "";
        switch (TableName) {
            case "UpdateRemark":
                qry = `update BarcodeMaster set Remark = '${Body.Remark}' where ID = ${Body.ID}`;
                break

            case "LocationMaster":
                qry = `insert into ${TableName} (CompanyID, PurchaseDetailID, Qty, Location,  CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.PurchaseDetailID}','${Body.Qty}', '${Body.Location}',  '${LoggedOnUser.ID}', now())`;
                break

            case "PettyCash":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID, EmployeeID, ShopID, CashType, CreditType, Amount,  Comments, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.EmployeeID}','${Body.ShopID}', '${Body.CashType}','${Body.CreditType}', ${Body.Amount},'${Body.Comments}', '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${CompanyID}' , EmployeeID = '${Body.EmployeeID}', ShopID = '${Body.ShopID}',  Amount = ${Body.Amount}, UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;
            case "CashRegister":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID, ShopID, OpeningBalance, ClosingBalance, OpeningBalanceCashCounter, ClosingBalanceCashCounter,OpeningBalancePettyCase, ClosingBalancePettyCase, OpenTime,  ClosedTime, CreatedBy , CreatedOn, sale, Doctor, Employee, Fitter,Supplier,customerreturn,expenseCashCounter, CashCounterwithdrawal) values ('${CompanyID}', '${Body.ShopID}', '${Body.OpeningBalance}', ${Body.ClosingBalance},'${Body.OpeningBalanceCashCounter}', ${Body.ClosingBalanceCashCounter},'${Body.OpeningBalancePettyCase}', ${Body.ClosingBalancePettyCase}, now(), '${Body.ClosedTime}', '${Body.CreatedBy}', now(), ${Body.sale}, ${Body.Doctor}, ${Body.Employee}, ${Body.Fitter}, ${Body.Supplier}, ${Body.customerreturn}, ${Body.expenseCashCounter}, ${Body.CashCounterwithdrawal})`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${CompanyID}' , ShopID = '${Body.ShopID}',  OpeningBalance = ${Body.OpeningBalance}, ClosingBalance = '${Body.ClosingBalance}',OpeningBalanceCashCounter = ${Body.OpeningBalanceCashCounter}, ClosingBalanceCashCounter = '${Body.ClosingBalanceCashCounter}',OpeningBalancePettyCase = ${Body.OpeningBalancePettyCase}, ClosingBalancePettyCase = '${Body.ClosingBalancePettyCase}', OpenTime = '${Body.OpenTime}' , ClosedTime = now() ,  UpdatedOn = now(), UpdatedBy = '${Body.UpdatedBy}',  sale = ${Body.sale},  Doctor = ${Body.Doctor},  Employee = ${Body.Employee},  Fitter = ${Body.Fitter},  Supplier = ${Body.Supplier},  customerreturn = ${Body.customerreturn},  expenseCashCounter = ${Body.expenseCashCounter},  CashCounterwithdrawal = ${Body.CashCounterwithdrawal} where ID = ${Body.ID}`;
                }
                break;

            case "ProductSpec":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (ProductName,  CompanyID, Name, Required, Seq,  Type,  Ref,  SptTableName, Status, CreatedBy , CreatedOn ) values ('${Body.ProductName}', '${CompanyID}', '${Body.Name}', ${Body.Required}, '${Body.Seq}', '${Body.Type}', '${Body.Ref}','${Body.SptTableName}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set ProductName = '${Body.ProductName}' , CompanyID = '${CompanyID}' , Name = '${Body.Name}',  Required = ${Body.Required}, Seq = '${Body.Seq}' , Type = '${Body.Type}' , Ref = '${Body.Ref}' , SptTableName = '${Body.SptTableName}' ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;
            case "Product":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Name,  CompanyID, HSNCode,GSTPercentage,GSTType, Status, CreatedBy , CreatedOn ) values ('${Body.Name}', '${CompanyID}', '${Body.HSNCode}', ${Body.GSTPercentage}, '${Body.GSTType}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set Name = '${Body.Name}' , CompanyID = '${CompanyID}' , HSNCode = '${Body.HSNCode}', GSTPercentage = ${Body.GSTPercentage}, GSTType = '${Body.GSTType}' ,Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "User":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  Name,  UserGroup,  DOB,  Anniversary,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  Branch,  PhotoURL,  LoginName,  Password, Status, CreatedBy , CreatedOn, CommissionType, CommissionMode, CommissionValue ) values ('${CompanyID}', '${Body.Name}', '${Body.UserGroup}', '${Body.DOB}', '${Body.Anniversary}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.Branch}','${Body.PhotoURL}','${Body.LoginName}','${Body.Password}', 1 , '${LoggedOnUser.ID}', now(), '${Body.CommissionType}', '${Body.CommissionMode}', '${Body.CommissionValue}')`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , Name = '${Body.Name}' , UserGroup = '${Body.UserGroup}' , DOB = '${Body.DOB}' , Anniversary = '${Body.Anniversary}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Branch = '${Body.Branch}' , PhotoURL = '${Body.PhotoURL}' , LoginName = '${Body.LoginName}' , Password = '${Body.Password}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}', CommissionType = '${Body.CommissionType}' ,CommissionMode = '${Body.CommissionMode}', CommissionValue = '${Body.CommissionValue}'  where ID = ${Body.ID}`;
                }
                break;

            case "Customer":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID, Idd , Sno, Name,  DOB, Age, Anniversary,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  PhotoURL,  GSTNo,  RefferedByDoc, ReferenceType, Gender, Category,Other,Remarks, Status, CreatedBy , CreatedOn, VisitDate ) values ('${CompanyID}', '${Body.Idd}', '${Body.Sno}', '${Body.Name}',  '${Body.DOB}', '${Body.Age}', '${Body.Anniversary}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.PhotoURL}','${Body.GSTNo}','${Body.RefferedByDoc}' ,'${Body.ReferenceType}' , '${Body.Gender}' ,'${Body.Category}','${Body.Other}','${Body.Remarks}', 1 , '${LoggedOnUser.ID}', now() , '${Body.VisitDate}')`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${CompanyID}' , Sno = '${Body.Sno}', Name = '${Body.Name}', DOB = '${Body.DOB}' , Age = '${Body.Age}' , Anniversary = '${Body.Anniversary}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , PhotoURL = '${Body.PhotoURL}' ,  GSTNo = '${Body.GSTNo}' , RefferedByDoc = '${Body.RefferedByDoc}' , ReferenceType = '${Body.ReferenceType}' , Gender = '${Body.Gender}' , Category = '${Body.Category}' , Remarks = '${Body.Remarks}' , VisitDate = '${Body.VisitDate}' , Other = '${Body.Other}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "CustomerCategory":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  ShopID, CategoryID, Fromm, Too, Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.ShopName}', '${Body.Category}', '${Body.From}','${Body.To}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set ShopID = '${Body.ShopName}' , CompanyID = '${CompanyID}' , CategoryID = '${Body.Category}' , Fromm = '${Body.From}' ,Too = '${Body.To}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "spectacle_rx":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Reminder, ExpiryDate, VisitNo,  CompanyID,  CustomerID,  REDPSPH,  REDPCYL,  REDPAxis,  REDPVA,  LEDPSPH,  LEDPCYL,  LEDPAxis,  LEDPVA,  RENPSPH, RENPCYL, RENPAxis, RENPVA, LENPSPH , LENPCYL, LENPAxis, LENPVA, REPD, LEPD, R_Addition, L_Addition, R_Prism, L_Prism, Lens, Shade, Frame, VertexDistance, RefractiveIndex, UploadBy, PhotoURL,  FittingHeight, ConstantUse, NearWork, DistanceWork, Family, RefferedByDoc, Status, CreatedBy, CreatedOn ) values ('${Body.Reminder}','${Body.ExpiryDate}','${Body.VisitNo}', '${CompanyID}', '${Body.CustomerID}',  '${Body.REDPSPH}', '${Body.REDPCYL}', '${Body.REDPAxis}', '${Body.REDPVA}', '${Body.LEDPSPH}','${Body.LEDPCYL}', '${Body.LEDPAxis}', '${Body.LEDPVA}','${Body.RENPSPH}','${Body.RENPCYL}', '${Body.RENPAxis}', '${Body.RENPVA}', '${Body.LENPSPH}', '${Body.LENPCYL}', '${Body.LENPAxis}', '${Body.LENPVA}', '${Body.REPD}', '${Body.LEPD}', '${Body.R_Addition}', '${Body.L_Addition}', '${Body.R_Prism}', '${Body.L_Prism}', '${Body.Lens}', '${Body.Shade}', '${Body.Frame}', '${Body.VertexDistance}', '${Body.RefractiveIndex}','${Body.UploadBy}','${Body.PhotoURL}','${Body.FittingHeight}', ${Body.ConstantUse}, ${Body.NearWork}, ${Body.DistanceWork}, '${Body.Family}', '${Body.RefferedByDoc}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set Reminder = '${Body.Reminder}', ExpiryDate = '${Body.ExpiryDate}',REDPSPH = '${Body.REDPSPH}', REDPCYL = '${Body.REDPCYL}', REDPAxis = '${Body.REDPAxis}', REDPVA = '${Body.REDPVA}', LEDPSPH = '${Body.LEDPSPH}', LEDPCYL = '${Body.LEDPCYL}', LEDPAxis = '${Body.LEDPAxis}', LEDPVA = '${Body.LEDPVA}',  RENPSPH = '${Body.RENPSPH}', RENPCYL = '${Body.RENPCYL}',  RENPAxis = '${Body.RENPAxis}', RENPVA = '${Body.RENPVA}', LENPSPH = '${Body.LENPSPH}', LENPCYL = '${Body.LENPCYL}', LENPAxis = '${Body.LENPAxis}', LENPVA = '${Body.LENPVA}', REPD = '${Body.REPD}', LEPD = '${Body.LEPD}', R_Addition = '${Body.R_Addition}' , L_Addition = '${Body.L_Addition}', R_Prism = '${Body.R_Prism}', L_Prism = '${Body.L_Prism}', Lens = '${Body.Lens}', Shade = '${Body.Shade}', Frame = '${Body.Frame}', VertexDistance = '${Body.VertexDistance}', RefractiveIndex = '${Body.RefractiveIndex}', FittingHeight = '${Body.FittingHeight}', Family = '${Body.Family}',ConstantUse = ${Body.ConstantUse}, NearWork = ${Body.NearWork}, DistanceWork = ${Body.DistanceWork}, Family = '${Body.Family}',RefferedByDoc = '${Body.RefferedByDoc}', PhotoURL = '${Body.PhotoURL}',UploadBy = '${Body.UploadBy}', Status = '${Body.Status}', UpdatedBy = '${LoggedOnUser.ID}', Updatedon = now() where ID = ${Body.ID}`;
                }
                break;

            case "contact_lens_rx":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (VisitNo,  CompanyID,  CustomerID,  REDPSPH,  REDPCYL,  REDPAxis,  REDPVA,  LEDPSPH,  LEDPCYL,  LEDPAxis,  LEDPVA,  RENPSPH, RENPCYL, RENPAxis, RENPVA, LENPSPH , LENPCYL, LENPAxis, LENPVA, REPD, LEPD, R_Addition, L_Addition, R_KR, L_KR, R_HVID, L_HVID, R_CS, L_CS, R_BC, L_BC, R_Diameter, L_Diameter, BR, Material, Modality, Other, ConstantUse, NearWork, DistanceWork, Multifocal, Family, RefferedByDoc, PhotoURL, Status, CreatedBy, CreatedOn ) values ('${Body.VisitNo}', '${CompanyID}', '${Body.CustomerID}',  '${Body.REDPSPH}', '${Body.REDPCYL}', '${Body.REDPAxis}', '${Body.REDPVA}', '${Body.LEDPSPH}','${Body.LEDPCYL}', '${Body.LEDPAxis}', '${Body.LEDPVA}','${Body.RENPSPH}','${Body.RENPCYL}', '${Body.RENPAxis}', '${Body.RENPVA}', '${Body.LENPSPH}', '${Body.LENPCYL}', '${Body.LENPAxis}', '${Body.LENPVA}', '${Body.REPD}', '${Body.LEPD}', '${Body.R_Addition}', '${Body.L_Addition}', '${Body.R_KR}', '${Body.L_KR}', '${Body.R_HVID}', '${Body.L_HVID}', '${Body.R_CS}', '${Body.L_CS}', '${Body.R_BC}', '${Body.L_BC}', '${Body.R_Diameter}', '${Body.L_Diameter}', '${Body.BR}', '${Body.Material}', '${Body.Modality}', '${Body.Other}', ${Body.ConstantUse}, ${Body.NearWork}, ${Body.DistanceWork}, ${Body.Multifocal}, '${Body.Family}', '${Body.RefferedByDoc}', '${Body.PhotoURL}',1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set REDPSPH = '${Body.REDPSPH}', REDPCYL = '${Body.REDPCYL}', REDPAxis = '${Body.REDPAxis}', REDPVA = '${Body.REDPVA}', LEDPSPH = '${Body.LEDPSPH}', LEDPCYL = '${Body.LEDPCYL}', LEDPAxis = '${Body.LEDPAxis}', LEDPVA = '${Body.LEDPVA}',  RENPSPH = '${Body.RENPSPH}', RENPCYL = '${Body.RENPCYL}',  RENPAxis = '${Body.RENPAxis}', RENPVA = '${Body.RENPVA}', LENPSPH = '${Body.LENPSPH}', LENPCYL = '${Body.LENPCYL}', Family = '${Body.Family}' LENPAxis = '${Body.LENPAxis}', LENPVA = '${Body.LENPVA}', REPD = '${Body.REPD}', LEPD = '${Body.LEPD}', R_Addition = '${Body.R_Addition}' , L_Addition = '${Body.L_Addition}', R_KR = '${Body.R_KR}', L_KR = '${Body.L_KR}', R_HVID = '${Body.R_HVID}', L_HVID = '${Body.L_HVID}', R_CS = '${Body.R_CS}', L_CS = '${Body.L_CS}', R_BC = '${Body.R_BC}', L_BC = '${Body.L_BC}', R_Diameter = '${Body.R_Diameter}', L_Diameter = '${Body.L_Diameter}', BR = '${Body.BR}', Material = '${Body.Material}', Modality = '${Body.Modality}', Other = '${Body.Other}', ConstantUse = ${Body.ConstantUse}, NearWork = ${Body.NearWork}, DistanceWork = ${Body.DistanceWork}, PhotoURL = '${Body.PhotoURL}', Multifocal = ${Body.Multifocal}, Status = ${Body.Status}, Family = '${Body.Family}',RefferedByDoc = '${Body.RefferedByDoc}',UpdatedBy = '${LoggedOnUser.ID}', Updatedon = now() where ID = ${Body.ID}`;
                }
                break;

            case "other_rx":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (VisitNo,  CompanyID,  CustomerID,  BP,  Sugar,  IOL_Power,  Operation,  R_VN,  L_VN,  R_TN,  L_TN,  R_KR, L_KR, Treatment, Diagnosis, Family, RefferedByDoc, Status, CreatedBy, CreatedOn ) values ('${Body.VisitNo}', '${CompanyID}', '${Body.CustomerID}',  '${Body.BP}', '${Body.Sugar}', '${Body.IOL_Power}', '${Body.Operation}', '${Body.R_VN}','${Body.L_VN}', '${Body.R_TN}', '${Body.L_TN}','${Body.R_KR}','${Body.L_KR}', '${Body.Treatment}', '${Body.Diagnosis}','${Body.Family}', '${Body.RefferedByDoc}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set VisitNo = '${Body.VisitNo}', Family = '${Body.Family}', BP = '${Body.BP}', Sugar = '${Body.Sugar}', IOL_Power = '${Body.IOL_Power}', Operation = '${Body.Operation}', R_VN = '${Body.R_VN}', L_VN = '${Body.L_VN}', R_TN = '${Body.R_TN}',  L_TN = '${Body.L_TN}', R_KR = '${Body.R_KR}',  L_KR = '${Body.L_KR}', Treatment = '${Body.Treatment}', Diagnosis = '${Body.Diagnosis}', Family = '${Body.Family}',RefferedByDoc = '${Body.RefferedByDoc}',Status = '${Body.Status}', UpdatedBy = '${LoggedOnUser.ID}', Updatedon = now() where ID = ${Body.ID}`;
                }
                break;

            case "Shop":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Name, AreaName, CompanyID,  MobileNo1,  MobileNo2,  PhoneNo,  Address,  Email,  Website,  GSTNo,  CINNo, BarcodeName, Discount, GSTnumber, LogoURL, HSNCode,CustGSTNo,Rate,Discounts,Tax,SubTotal,Total,ShopTiming, WelcomeNote,  Status, ShopStatus, CreatedBy , CreatedOn ) values
                     ('${Body.Name}', '${Body.AreaName}', '${CompanyID}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}', '${Body.Address}', '${Body.Email}','${Body.Website}','${Body.GSTNo}','${Body.CINNo}','${Body.BarcodeName}','${Body.Discount}','${Body.GSTnumber}','${Body.LogoURL}', '${Body.HSNCode}', '${Body.CustGSTNo}','${Body.Rate}','${Body.Discounts}', '${Body.Tax}','${Body.SubTotal}','${Body.Total}','${Body.ShopTiming}','${Body.WelcomeNote}', 1 , 0,  '${LoggedOnUser.ID}', now()) `;
                } else {
                    qry = `update ${TableName} set Name = '${Body.Name}' , AreaName = '${Body.AreaName}' , CompanyID = '${Body.CompanyID}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Address = '${Body.Address}' , Email = '${Body.Email}' , Website = '${Body.Website}' , GSTNo = '${Body.GSTNo}' , CINNo = '${Body.CINNo}' , BarcodeName = '${Body.BarcodeName}' , Discount = '${Body.Discount}' , GSTnumber = '${Body.GSTnumber}' , LogoURL = '${Body.LogoURL}' , HSNCode = '${Body.HSNCode}' , CustGSTNo = '${Body.CustGSTNo}' ,Rate = '${Body.Rate}' ,Discounts = '${Body.Discounts}' ,  Tax = '${Body.Tax}',  SubTotal = '${Body.SubTotal}',  Total = '${Body.Total}',  ShopTiming = '${Body.ShopTiming}' , WelcomeNote = '${Body.WelcomeNote}' , Status = 1 , ShopStatus= '${Body.ShopStatus}', UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;
            case "Role":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Name, CompanyID, Status, Permission, CreatedBy , CreatedOn ) values
                   ('${Body.Name}', '${Body.CompanyID}', 1 , '${Body.Permission}', '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}', Permission = '${Body.Permission}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }

                break;

            case "Department":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Name, CompanyID, DepartmentHead, ShopID, Status, CreatedBy , CreatedOn ) values
                    ('${Body.Name}', '${CompanyID}','${Body.DepartmentHead}','${Body.ShopID}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}',  Name = '${Body.Name}' , DepartmentHead = '${Body.DepartmentHead}' , ShopID = '${Body.ShopID}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }

                break;

            case "CategoryType":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (Name, CompanyID, DepartmentHead, ShopID, Status, CreatedBy , CreatedOn ) values
                    ('${Body.Name}', '${CompanyID}','${Body.DepartmentHead}','${Body.ShopID}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}',  Name = '${Body.Name}' , DepartmentHead = '${Body.DepartmentHead}' , ShopID = '${Body.ShopID}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }

                break;

            case "SupportMaster":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (TableName,Name, CompanyID,  Status) values ('${Body.TableName}','${Body.Name}', '${CompanyID}', 1)`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}',  Name = '${Body.Name}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }

                break;

            case "Supplier":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID, Sno, Name, DOB,  Anniversary,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  Website,  PhotoURL,  CINNO, GSTNo,  Fax, ContactPerson, Remark,  Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.Sno}', '${Body.Name}','${Body.DOB}', '${Body.Anniversary}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.Website}','${Body.PhotoURL}','${Body.CINNo}','${Body.GSTNo}','${Body.Fax}','${Body.ContactPerson}','${Body.Remark}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , Name = '${Body.Name}' ,  DOB = '${Body.DOB}' , Anniversary = '${Body.Anniversary}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Website = '${Body.website}' , PhotoURL = '${Body.PhotoURL}' , CINNo = '${Body.CINNo}' , GSTNo = '${Body.GSTNo}', Fax = '${Body.Fax}', ContactPerson = '${Body.ContactPerson}', Remark = '${Body.Remark}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;
            case "Fitter":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID, ShopID, Name, DOB,  Anniversary,  MobileNo1,  MobileNo2,  PhoneNo,  Email,  Address,  Website,  PhotoURL,  CINNO, GSTNo,  Fax, ContactPerson, Remark,  Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.ShopID}', '${Body.Name}', '${Body.DOB}', '${Body.Anniversary}', '${Body.MobileNo1}', '${Body.MobileNo2}', '${Body.PhoneNo}','${Body.Email}', '${Body.Address}', '${Body.Website}','${Body.PhotoURL}','${Body.CINNo}','${Body.GSTNo}','${Body.Fax}','${Body.ContactPerson}','${Body.Remark}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , ShopID = '${Body.ShopID}' , Name = '${Body.Name}' ,  DOB = '${Body.DOB}' , Anniversary = '${Body.Anniversary}' , MobileNo1 = '${Body.MobileNo1}' , MobileNo2 = '${Body.MobileNo2}', PhoneNo = '${Body.PhoneNo}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Website = '${Body.website}' , PhotoURL = '${Body.PhotoURL}' , CINNo = '${Body.CINNo}' , GSTNo = '${Body.GSTNo}', Fax = '${Body.Fax}', ContactPerson = '${Body.ContactPerson}', Remark = '${Body.Remark}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "FitterRateCard":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  FitterID, LensType, Rate,  Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.FitterID}', '${Body.LensType}', '${Body.Rate}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , FitterID = '${Body.FitterID}' ,  LensType = '${Body.LensType}' , Rate = ${Body.Rate} , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "FitterAssignedShop":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID, ShopID, FitterID, Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.ShopID}', '${Body.FitterID}',  1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , ShopID = '${Body.ShopID}' ,  FitterID = '${Body.FitterID}' ,  Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;
            case "UserShop":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (UserID,  ShopID,  RoleID, Status, CreatedBy , CreatedOn ) values ('${Body.UserID}', '${Body.ShopID}', '${Body.RoleID}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set UserID = '${Body.UserID}' , ShopID = '${Body.ShopID}' , RoleID = '${Body.RoleID}' , Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "ServiceMaster":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  Name, Description, Cost, Price, GSTPercentage, GSTAmount, GSTType, TotalAmount,  Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.Name}', '${Body.Description}', '${Body.Cost}', '${Body.Price}', '${Body.GSTPercentage}', '${Body.GSTAmount}',  '${Body.GSTType}','${Body.TotalAmount}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , Name = '${Body.Name}' ,  Description = '${Body.Description}' , Cost = '${Body.Cost}' , Price = '${Body.Price}' , GSTPercentage = '${Body.GSTPercentage}', GSTAmount = '${Body.GSTAmount}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Website = '${Body.website}' , PhotoURL = '${Body.PhotoURL}' , CINNo = '${Body.GSTType}' , GSTNo = '${Body.GSTType}', TotalAmount = '${Body.TotalAmount}', Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "ChargerMaster":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  Name, Description, Price, GSTPercentage, GSTAmount, GSTType, TotalAmount,  Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.Name}', '${Body.Description}',  '${Body.Price}', '${Body.GSTPercentage}', '${Body.GSTAmount}',  '${Body.GSTType}','${Body.TotalAmount}', 1 , '${LoggedOnUser.ID}', now())`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , Name = '${Body.Name}' ,  Description = '${Body.Description}' , Cost = '${Body.Cost}' , Price = '${Body.Price}' , GSTPercentage = '${Body.GSTPercentage}', GSTAmount = '${Body.GSTAmount}' , Email = '${Body.Email}' ,  Address = '${Body.Address}' , Website = '${Body.website}' , PhotoURL = '${Body.PhotoURL}' , CINNo = '${Body.GSTType}' , GSTNo = '${Body.GSTType}', TotalAmount = '${Body.TotalAmount}', Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}' where ID = ${Body.ID}`;
                }
                break;

            case "CompanySetting":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  CompanyLanguage, CompanyCurrency, CurrencyFormat, DateFormat, CompanyTagline, BillHeader, BillFooter, RewardsPointValidity, EmailReport, MessageReport, LogoURL, WatermarkLogoURL, WholeSalePrice, RetailRate,Composite,Color1,HSNCode,Discount,GSTNo,Rate,SubTotal,Total,CGSTSGST, InvoiceOption, Locale,  LoginTimeStart, LoginTimeEnd, Status, CreatedBy , CreatedOn,
                            BillFormat, WelComeNote, SenderID, MsgAPIKey SmsSetting, year, month, partycode, type,DataFormat,RewardExpiryDate,RewardPercentage,AppliedReward,MobileNo,FontApi,FontsStyle,BarCode, FeedbackDate,ServiceDate,DeliveryDay,AppliedDiscount,WhatsappSetting) values ('${CompanyID}', '${Body.CompanyLanguage}', '${Body.CompanyCurrency}', '${Body.CurrencyFormat}', '${Body.DateFormat}', '${Body.CompanyTagline}', '${Body.BillHeader}',  '${Body.BillFooter}','${Body.RewardsPointValidity}','${Body.EmailReport}','${Body.MessageReport}','${Body.LogoURL}','${Body.WatermarkLogoURL}', '${Body.WholeSalePrice}','${Body.RetailRate}','${Body.Composite}','${Body.Color1}','${Body.HSNCode}','${Body.Discount}','${Body.GSTNo}', '${Body.Rate}', '${Body.SubTotal}','${Body.Total}','${Body.CGSTSGST}','${Body.InvoiceOption}', '${Body.Locale}', '${Body.BillFormat}, '${Body.LoginTimeStart}', '${Body.LoginTimeEnd}', 1 , '${LoggedOnUser.ID}', now(), '${Body.WelComeNote}', '${Body.SenderID}', '${Body.MsgAPIKey}', '${Body.SmsSetting}', '${Body.year}', '${Body.month}', '${Body.partycode}','${Body.type}','${Body.DataFormat}','${Body.RewardExpiryDate}','${Body.RewardPercentage}','${Body.AppliedReward}','${Body.MobileNo}','${Body.FontApi}','${Body.FontsStyle}','${Body.BarCode}','${Body.FeedbackDate}','${Body.ServiceDate}','${Body.DeliveryDay}','${Body.AppliedDiscount}','${Body.WhatsappSetting}')`;
                } else {
                    qry = `update ${TableName} set CompanyID = '${Body.CompanyID}' , CompanyLanguage = '${Body.CompanyLanguage}' ,  CompanyCurrency = '${Body.CompanyCurrency}' , CurrencyFormat = '${Body.CurrencyFormat}' , DateFormat = '${Body.DateFormat}' , CompanyTagline = '${Body.CompanyTagline}', BillHeader = '${Body.BillHeader}' , BillFooter = '${Body.BillFooter}' ,  RewardsPointValidity = '${Body.RewardsPointValidity}' , EmailReport = '${Body.EmailReport}' , MessageReport = '${Body.MessageReport}' , LogoURL = '${Body.LogoURL}' , WatermarkLogoURL = '${Body.WatermarkLogoURL}', WholeSalePrice = '${Body.WholeSalePrice}' , RetailRate = '${Body.RetailRate}',Color1 = '${Body.Color1}',HSNCode = '${Body.HSNCode}',Discount = '${Body.Discount}',GSTNo = '${Body.GSTNo}',Rate = '${Body.Rate}',SubTotal = '${Body.SubTotal}',Total = '${Body.Total}',CGSTSGST = '${Body.CGSTSGST}',
                         Composite = '${Body.Composite}', InvoiceOption = '${Body.InvoiceOption}', Locale = '${Body.Locale}', LoginTimeStart = '${Body.LoginTimeStart}', LoginTimeEnd = '${Body.LoginTimeEnd}',BillFormat = '${Body.BillFormat}', Status = 1 , UpdatedOn = now(), UpdatedBy = '${LoggedOnUser.ID}', WelComeNote = '${Body.WelComeNote}' , SenderID = '${Body.SenderID}' , MsgAPIKey = '${Body.MsgAPIKey}', SmsSetting = '${Body.SmsSetting}', year = '${Body.year}', month = '${Body.month}', partycode = '${Body.partycode}', DataFormat = '${Body.DataFormat}', type = '${Body.type}', RewardExpiryDate = '${Body.RewardExpiryDate}', RewardPercentage = '${Body.RewardPercentage}', AppliedReward = '${Body.AppliedReward}' , MobileNo = '${Body.MobileNo}', FontApi = '${Body.FontApi}', FontsStyle = '${Body.FontsStyle}', BarCode = '${Body.BarCode}' , FeedbackDate = '${Body.FeedbackDate}' , ServiceDate = '${Body.ServiceDate}'
                         , DeliveryDay = '${Body.DeliveryDay}' , AppliedDiscount = '${Body.AppliedDiscount}' , WhatsappSetting = '${Body.WhatsappSetting}'  where ID = ${Body.ID}`;
                }
                break;

            case "Family":
                if (Body.ID === null || Body.ID === undefined) {
                    qry = `insert into ${TableName} (CompanyID,  CustomerID, Name,  Status, CreatedBy , CreatedOn ) values ('${CompanyID}', '${Body.CustomerID}', '${Body.Name}', 1 , '${LoggedOnUser.ID}', now())`;
                } else { }
                break;

            case "BarcodeMaster":
                qry = `Update BarcodeMaster set CurrentStatus = '${Body.CurrentStatus}' , Barcode = '${Body.Barcode}' , Remark = '${Body.Remark}' Where ID = '${Body.ID}'`;
                break;

            case "updatePaymentHistory":
                qry = `Update PaymentMaster set PaymentMode = '${Body.PaymentMode}'  Where ID = '${Body.PaymentMasterID}'`;
                break;
        }
        return qry;
    }

    static getShortQuery(TableName, LoggedOnUser, CompanyID, DelMode) {
        let deleteMode = "";
        if (DelMode === "1") {
            deleteMode = " Status = 1 and ";
        }
        let qry = `select * from  ${TableName} where ${deleteMode}  CompanyID = '${CompanyID}' Order By ID Desc`;
        return qry;
    }

    static getShortQuery1(TableName, LoggedOnUser, CompanyID, DelMode) {
        let deleteMode = "";
        if (DelMode === "1") {
            deleteMode = " Status = 1 and ";
        }
        let qry = `select * from  ${TableName} where ${deleteMode}  CompanyID = '${CompanyID}' Order By Name ASC`;
        return qry;
    }


    static getExtendedQuery(TableName, LoggedOnUser, CompanyID, ShopID) {
        let qry = "";
        switch (TableName) {
            case "SupplierfullList":
                qry = `SELECT Supplier.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                       FROM Supplier
                       LEFT JOIN User ON User.ID = Supplier.CreatedBy
                       LEFT JOIN User AS User1 ON User1.ID = Supplier.UpdatedBy
                       WHERE  Supplier.CompanyID  = '${CompanyID}' AND Supplier.Status = 1 ORDER BY Supplier.ID DESC`;
                break;

            case "PreorderfullList":
                qry = `SELECT DISTINCT(PurchaseDetail.ProductName),PurchaseDetail.ID, PurchaseDetail.Checked, PurchaseDetail.ProductTypeName, BarcodeMaster.Barcode AS BarCode, u.Name AS CreatedPerson, PurchaseDetail.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID LEFT JOIN User AS u ON u.ID = PurchaseDetail.CreatedBy WHERE BarcodeMaster.CurrentStatus = 'Pre Order' AND PurchaseDetail.ProductName !='' AND PurchaseDetail.ProductTypeName != '' AND PurchaseDetail.CompanyID  = '${CompanyID}' and BarcodeMaster.Status = 1 and PurchaseDetail.Status = 1 ORDER BY PurchaseDetail.ID DESC`;
                break;

            case "SupplierfullListAll":
                qry = `SELECT Supplier.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                       FROM Supplier
                       LEFT JOIN User ON User.ID = Supplier.CreatedBy
                       LEFT JOIN User AS User1 ON User1.ID = Supplier.UpdatedBy
                       WHERE  Supplier.CompanyID  = '${CompanyID}' ORDER BY Supplier.ID DESC`;
                break;

            case "UserFullList":
                qry = `SELECT User.*, user1.Name AS CreatedByUser, user2.Name AS UpdatedByUser FROM User
                LEFT JOIN User AS user1 ON user1.ID = User.CreatedBy
                LEFT JOIN User AS user2 ON user2.ID = User.UpdatedBy
                WHERE User.CompanyID = '${CompanyID}' AND User.Status = 1 ORDER BY User.ID DESC`;
                break;

            case "UserFullListAll":
                qry = `SELECT User.*, user1.Name AS CreatedByUser, user2.Name AS UpdatedByUser FROM User
                    LEFT JOIN User AS user1 ON user1.ID = User.CreatedBy
                    LEFT JOIN User AS user2 ON user2.ID = User.UpdatedBy
                    WHERE User.CompanyID = '${CompanyID}'  ORDER BY User.ID DESC`;
                break;

            case "ShopFullList":
                qry = `SELECT Shop.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                    FROM Shop
                    LEFT JOIN User ON User.ID = Shop.CreatedBy
                    LEFT JOIN User AS User1 ON User1.ID = Shop.UpdatedBy
                    WHERE Shop.CompanyID  = '${CompanyID}' AND Shop.Status = 1 ORDER BY Shop.ID DESC`;
                break;

            case "FitterFullList":
                if (LoggedOnUser.UserGroup !== 'CompanyAdmin') {
                    qry = `SELECT Fitter.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
          FROM Fitter
          LEFT JOIN User ON User.ID = Fitter.CreatedBy
          LEFT JOIN User AS User1 ON User1.ID = Fitter.UpdatedBy
          WHERE Fitter.CompanyID  = '${CompanyID}' AND Fitter.Status = 1 AND Fitter.ShopID = '${ShopID}' ORDER BY Fitter.ID DESC`;
                } else {
                    qry = `SELECT Fitter.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                    FROM Fitter
                    LEFT JOIN User ON User.ID = Fitter.CreatedBy
                    LEFT JOIN User AS User1 ON User1.ID = Fitter.UpdatedBy
                    WHERE Fitter.CompanyID  = '${CompanyID}' AND Fitter.Status = 1 ORDER BY Fitter.ID DESC`;
                }
                break;
            case "FitterFullListAll":
                qry = `SELECT Fitter.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                    FROM Fitter
                    LEFT JOIN User ON User.ID = Fitter.CreatedBy
                    LEFT JOIN User AS User1 ON User1.ID = Fitter.UpdatedBy
                    WHERE Fitter.CompanyID  = '${CompanyID}' ORDER BY Fitter.ID DESC`;
                break;
            case "CustomerFullList":
                qry = `SELECT Customer.*, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser,Shop.Name AS ShopName , Shop.AreaName AS AreaName FROM Customer LEFT JOIN User ON User.ID = Customer.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Customer.UpdatedBy LEFT JOIN Shop ON Shop.ID = Customer.ID WHERE  Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1 ORDER BY Customer.ID DESC `;
                break;

            case "CustomerFullListAll":
                qry = `SELECT Customer.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                             FROM Customer
                             LEFT JOIN User ON User.ID = Customer.CreatedBy
                             LEFT JOIN User AS User1 ON User1.ID = Customer.UpdatedBy
                             WHERE  Customer.CompanyID  = '${CompanyID}' AND  Customer.Status = 1 ORDER BY Customer.ID DESC `;
                break;

            case "DoctorFullList":
                qry = ` SELECT Doctor.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                    FROM Doctor
                    LEFT JOIN User ON User.ID = Doctor.CreatedBy
                    LEFT JOIN User AS User1 ON User1.ID = Doctor.UpdatedBy
                    WHERE  Doctor.CompanyID  = '${CompanyID}' AND Doctor.Status = 1 ORDER BY Doctor.ID DESC`;
                break;
            case "DoctorFullListAll":
                qry = ` SELECT Doctor.*,  User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                        FROM Doctor
                        LEFT JOIN User ON User.ID = Doctor.CreatedBy
                        LEFT JOIN User AS User1 ON User1.ID = Doctor.UpdatedBy
                        WHERE  Doctor.CompanyID  = '${CompanyID}'  ORDER BY Doctor.ID DESC`;
                break;

            case "PurchaseMaster":
                if (LoggedOnUser.UserGroup !== 'CompanyAdmin') {
                    qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
          FROM PurchaseMaster
          LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy
          LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy
          LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID
          INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID
          WHERE  PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.ShopID = '${ShopID}'  ORDER BY PurchaseMaster.ID DESC`;
                } else {

                    qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                FROM PurchaseMaster
                LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy
                LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy
                LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID
                INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID
                WHERE  PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' ORDER BY PurchaseMaster.ID DESC`;
                }
                break;
            case "PurchaseDetail":
                qry = `SELECT  COUNT(PurchaseDetail.ProductName) AS ProductCount, BarcodeMaster.Barcode, Shop.Name AS Shop, Shop1.Name AS PurchasedInShop ,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, PurchaseDetail.*  FROM PurchaseDetail INNER JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID   INNER JOIN Shop ON Shop.ID = BarcodeMaster.ShopID INNER JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID  INNER JOIN Shop AS Shop1 ON Shop1.ID = PurchaseMaster.ShopID  INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID  WHERE BarcodeMaster.CurrentStatus = "Available" and PurchaseDetail.CompanyID = '${CompanyID}' GROUP BY ProductName`;
                break;
            case "FitterMaster":
                qry = `Select FitterMaster.*, Shop.Name as ShopName, Fitter.Name as FitterName from FitterMaster Left Join Shop on FitterMaster.ShopID = Shop.ID inner join Fitter on Fitter.ID = FitterMaster.FitterID Where FitterMaster.Status = 1 and FitterMaster.CompanyID = '${CompanyID}' and PStatus =1 Order By FitterMaster.ID Desc`;
                break;
            case "Expense":
                qry = `SELECT Expense.*, Shop.Name AS ShopName , Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                FROM Expense
                 LEFT JOIN Shop ON Shop.ID = Expense.ShopID
                 LEFT JOIN User ON User.ID = Expense.CreatedBy
                 LEFT JOIN User AS User1 ON User1.ID = Expense.UpdatedBy
                 WHERE Expense.CompanyID = '${CompanyID}' AND Expense.ShopID = '${ShopID}' and Expense.Status = 1 ORDER BY ID DESC`;
                break;
            case "Payroll":
                qry = `SELECT Payroll.*, Users.Name AS EmployeeName ,User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM Payroll LEFT JOIN User AS Users ON Users.ID  = Payroll.EmployeeID  LEFT JOIN User ON User.ID = Payroll.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Payroll.UpdatedBy WHERE Payroll.CompanyID = '${CompanyID}' AND Payroll.ShopID = '${ShopID}' and Payroll.Status = 1 ORDER BY ID DESC`;
                break;
            case "PettyCash":
                qry = `SELECT PettyCash.*, Users.Name AS EmployeeName ,User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PettyCash LEFT JOIN User AS Users ON Users.ID  = PettyCash.EmployeeID  LEFT JOIN User ON User.ID = PettyCash.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PettyCash.UpdatedBy WHERE PettyCash.CompanyID = '${CompanyID}' and PettyCash.ShopID = '${ShopID}'  ORDER BY ID DESC`;
                break;
                case "PettyCashTotal":
                    qry =
                        `SELECT CashRegister.*, Shop.Name AS ShopName, Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM CashRegister LEFT JOIN Shop ON Shop.ID = CashRegister.ShopID LEFT JOIN User ON User.ID = CashRegister.CreatedBy LEFT JOIN User AS User1 ON User1.ID = CashRegister.UpdatedBy WHERE CashRegister.CompanyID = '${CompanyID}' and CashRegister.ShopID = '${ShopID}'` ;

                    break;
            case "DashBillmaster":
                qry = `SELECT BillMaster.*, Customer.Name AS CustomerName , Customer.MobileNo1 AS CustomerMobileNo1, BillMaster.BillDate AS BillDate, BillMaster.DeliveryDate AS DeliveryDate,
                    BillMaster.TotalAmount AS TotalAmonut, BillMaster.DueAmount AS DueAmount,  BillMaster.ProductStatus AS ProductStatus FROM BillMaster
                     LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                     WHERE BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 1  AND BillMaster.ShopID = '${ShopID}' ORDER BY BillMaster.ID DESC LIMIT 2 `;
                break;
        }
        return qry;
    }

    static getcustomeriddQuery(TableName, LoggedOnUser, CompanyID, ShopID) {
        let qry = "";
        switch (TableName) {
            case "CustomerIDD":
                qry = `SELECT COUNT(*) AS idd  FROM Customer WHERE Customer.CompanyID = '${CompanyID}' AND Customer.Status = 1`;
                break;
        }
        return qry;
    }

    static getShortQueryByID(TableName, ID, CompanyID) {
        let qry = `select * from  ${TableName} where Status = 1 and CompanyID = '${CompanyID}' and ID = '${ID}'`;
        return qry;
    }

    static getExtendedQueryByID(TableName, ID, CompanyID) {
        let qry = "";
        switch (TableName) {
            case "FitterMaster":
                qry = `Select FitterMaster.*, Shop.Name as ShopName, Fitter.Name as FitterName from FitterMaster Left Join Shop on FitterMaster.ShopID = Shop.ID inner join Fitter on Fitter.ID = FitterMaster.FitterID Where FitterMaster.Status = 1 and FitterMaster.CompanyID = '${CompanyID}' and PStatus =1 and FitterID = '${ID}' Order By FitterMaster.ID Desc`;
                break;
            case "PurchaseMaster":
                qry = `Select *, Shop.Name as ShopName, Supplier.Name as SupplierName from PurchaseMaster Inner Join Shop on PurchaseMaster.ShopID = Shop.ID inner join Supplier on Supplier.ID = PurchaseMaster.SupplierID Where PurchaseMaster.Status = 1 and PurchaseMaster.CompanyID = '${CompanyID}' and PurchaseMaster.ID = '${ID}'`;
                break;

            case "VendorMasterToApplyPayment":
                qry = `Select PurchaseMaster.*, Shop.Name as ShopName, Supplier.Name as Name from PurchaseMaster LEFT Join Shop on PurchaseMaster.ShopID = Shop.ID LEFT join Supplier on Supplier.ID = PurchaseMaster.SupplierID Where PurchaseMaster.Status = 1 and PurchaseMaster.CompanyID = '${CompanyID}' and PurchaseMaster.SupplierID = '${ID}' AND PurchaseMaster.PaymentStatus <> 'Paid'`;
                break;

            case "FitterMasterToApplyPayment":
                qry = `Select FitterMaster.*, Shop.Name as ShopName, Fitter.Name as Name from FitterMaster LEFT Join Shop on FitterMaster.ShopID = Shop.ID LEFT join Fitter on Fitter.ID = FitterMaster.FitterID Where FitterMaster.Status = 1 and FitterMaster.CompanyID = '${CompanyID}' and FitterMaster.FitterID = '${ID}' and FitterMaster.Quantity != 0 AND FitterMaster.PaymentStatus <> 'Paid'`;
                break;

            case "CustomerMasterToApplyPayment":
                qry = `SELECT PaymentDetail.*, PaymentDetail.Amount as DueAmount, Shop.Name as ShopName, Customer.Name, PaymentDetail.PaymentType as PaymentStatus,PaymentMaster.PaymentReferenceNo AS PaymentReferenceNo, PaymentMaster.CardNo AS CardNO FROM PaymentMaster
                LEFT JOIN PaymentDetail ON PaymentDetail.PaymentMasterID = PaymentMaster.ID
                left join Shop on Shop.ID = PaymentMaster.ShopID
                left join Customer on Customer.ID = PaymentMaster.CustomerID
                WHERE PaymentMaster.CustomerID = '${ID}' and PaymentDetail.CompanyID = '${CompanyID}' AND PaymentDetail.PaymentType = 'Customer Credit'`;
                break;

            case "DoctorMasterToApplyPayment":
                qry = `Select CommissionMaster.*, Shop.Name as ShopName, Doctor.Name as Name from CommissionMaster LEFT Join Shop on CommissionMaster.ShopID = Shop.ID LEFT join Doctor on Doctor.ID = CommissionMaster.UserID Where CommissionMaster.Status = 1 and CommissionMaster.CompanyID = '${CompanyID}' and CommissionMaster.UserID = '${ID}' AND CommissionMaster.PaymentStatus <> 'Paid' and CommissionMaster.UserType = 'Doctor'`;
                break;

            case "EmployeeMasterToApplyPayment":
                qry = `Select CommissionMaster.*, Shop.Name as ShopName, User.Name as Name from CommissionMaster LEFT Join Shop on CommissionMaster.ShopID = Shop.ID LEFT join User on User.ID = CommissionMaster.UserID Where CommissionMaster.Status = 1 and CommissionMaster.CompanyID = '${CompanyID}' and CommissionMaster.UserID = '${ID}' AND CommissionMaster.PaymentStatus <> 'Paid' and CommissionMaster.UserType = 'Employee'`;
                break;

            case "contact_lens_rx":
                qry = `SELECT * FROM contact_lens_rx WHERE CompanyID = '${CompanyID}' and CustomerID = '${ID}'`;
                break;

            case "Payroll":
                qry = `SELECT * FROM Payroll Left Join User on User.ID = Payroll.EmployeeID  WHERE Payroll.CompanyID = '${CompanyID}' and EmployeeID = '${ID}'`;
                break;

            case "other_rx":
                qry = `SELECT * FROM other_rx WHERE CompanyID = '${CompanyID}' and CustomerID = '${ID}'`;
                break;
            case "TransferMaster":
                qry = `SELECT TransferMaster.*, Shop.Name AS FromShop, ShopTo.Name AS ToShop, ShopTo.AreaName as ToAreaName,Shop.AreaName as FromAreaName, User.Name AS CreatedByUser, UserUpdate.Name AS UpdatedByUser
          FROM TransferMaster LEFT JOIN Shop ON Shop.ID = TransferFromShop LEFT JOIN Shop AS ShopTo ON ShopTo.ID = TransferToShop
          LEFT JOIN User ON User.ID = TransferMaster.CreatedBy LEFT JOIN User AS UserUpdate ON UserUpdate.ID = TransferMaster.UpdatedBy
          WHERE TransferMaster.CompanyID = '${CompanyID}' and TransferMaster.TransferStatus = 'Transfer Initiated' and (TransferMaster.TransferFromShop = '${ID}' or TransferMaster.TransferToShop = '${ID}') Order By TransferMaster.ID Desc`;
                break;

            case "BarcodeCount":
                qry = `SELECT COUNT(BarcodeMaster.Barcode) AS BarCodeCount FROM BarcodeMaster WHERE BarcodeMaster.PurchaseDetailID = '${ID}' And  CompanyID = '${CompanyID}' AND CurrentStatus = 'Available'`;
                break;
        }
        return qry;
    }

    static getdataByotherID(TableName, CompanyID, ID, LoggedOnUser, Shop) {
        let qry = "";
        switch (TableName) {
            case "FitterRateCard":
                qry = `SELECT * FROM ${TableName} WHERE CompanyID = ${CompanyID} and FitterID = ${ID} and Status = 1 ORDER BY ID DESC`;
                break;

            case "FitterAssignedShop":
                if (LoggedOnUser.UserGroup === 'CompanyAdmin') {
                    qry = `SELECT FitterAssignedShop.* , Shop.Name AS ShopName FROM FitterAssignedShop
            LEFT JOIN Shop ON Shop.ID = FitterAssignedShop.ShopID WHERE FitterAssignedShop.CompanyID = ${CompanyID} and FitterAssignedShop.FitterID = ${ID} and FitterAssignedShop.Status = 1 ORDER BY ID DESC`;
                } else {
                    qry = `SELECT FitterAssignedShop.* , Shop.Name AS ShopName FROM FitterAssignedShop
            LEFT JOIN Shop ON Shop.ID = FitterAssignedShop.ShopID WHERE FitterAssignedShop.CompanyID = ${CompanyID} and FitterAssignedShop.FitterID = ${ID} and FitterAssignedShop.ShopID = ${Shop.ShopID} and FitterAssignedShop.Status = 1 ORDER BY ID DESC`;
                }

                break;

            case "MaxCount":
                console.log(Shop, 'ShopShopShop');
                if (LoggedOnUser.UserGroup === 'CompanyAdmin') {
                    qry = `SELECT BillMaster.* , MAX(BillDetail.TotalAmount) AS MaxAmount FROM  BillMaster LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID WHERE BillMaster.CustomerID = ${ID} AND BillMaster.CompanyID = ${CompanyID} AND BillMaster.ShopID = ${Shop} AND BillDetail.Status = 1`;
                } else {
                    qry = `SELECT BillMaster.* , MAX(BillDetail.TotalAmount) AS MaxAmount FROM  BillMaster LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID WHERE BillMaster.CustomerID = ${ID} AND BillMaster.CompanyID = ${CompanyID} AND BillMaster.ShopID = ${Shop} AND BillDetail.Status = 1`;
                }

                break;

            case "spectacle_rx":
                qry = `SELECT * FROM ${TableName} WHERE CompanyID = ${CompanyID} and CustomerID = ${ID} ORDER BY ID DESC`;
                break;

            case "contact_lens_rx":
                qry = `SELECT * FROM ${TableName} WHERE CompanyID = ${CompanyID} and CustomerID = ${ID} ORDER BY ID DESC`;
                break;

            case "other_rx":
                qry = `SELECT * FROM ${TableName} WHERE CompanyID = ${CompanyID} and CustomerID = ${ID} ORDER BY ID DESC`;
                break;

            case "Family":
                qry = `SELECT * FROM ${TableName} WHERE CompanyID = ${CompanyID} and CustomerID = ${ID} ORDER BY ID DESC`;
                break;

            case "PaymentHistory":
                qry = `SELECT PaymentDetail.*, PurchaseMaster.*, PaymentMaster.PaymentType AS PaymentType, PaymentMaster.PaymentMode AS PaymentMode, PaymentMaster.PaidAmount, PaymentDetail.DueAmount AS Dueamount  FROM PaymentDetail
                    LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PaymentDetail.BillMasterID
                    LEFT JOIN PaymentMaster  ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
                    WHERE PaymentDetail.PaymentType = 'Vendor' AND PurchaseMaster.ID = ${ID}`;

                break;

            case "FitterPaymentHistory":
                qry = `SELECT PaymentDetail.*, PaymentMaster.PayableAmount, PaymentMaster.PaidAmount, PaymentMaster.PaymentDate, PaymentMaster.PaymentMode  FROM PaymentDetail
                LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
                WHERE PaymentDetail.PaymentType = 'Fitter' and PaymentDetail.BillMasterID = ${ID}`;

                break;

            case "CustomerPaymentHistory":
                qry = `SELECT PaymentDetail.*, BillMaster.*, PaymentMaster.PaymentType AS PaymentType,BillMaster.AddlDiscount AS AddlDiscount,PaymentMaster.PaymentDate AS PaymentDate, PaymentMaster.PaymentMode AS PaymentMode, PaymentDetail.DueAmount AS Dueamount  FROM PaymentDetail
            LEFT JOIN BillMaster ON BillMaster.ID = PaymentDetail.BillMasterID
            LEFT JOIN PaymentMaster  ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
            WHERE PaymentDetail.PaymentType IN( 'Customer', 'Customer Reward') AND BillMaster.ID = ${ID}`;
                break;

            case "DoctorPaymentHistory":
                qry = `SELECT PaymentDetail.*, CommissionMaster.*, PaymentMaster.PaymentType AS PaymentType, PaymentMaster.PaymentMode AS PaymentMode, PaymentDetail.DueAmount AS Dueamount  FROM PaymentDetail
            LEFT JOIN CommissionMaster ON CommissionMaster.ID = PaymentDetail.BillMasterID
            LEFT JOIN PaymentMaster  ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
            WHERE PaymentDetail.PaymentType = 'Doctor' AND CommissionMaster.ID = ${ID}`;
                break;

            case "EmployeePaymentHistory":
                qry = `SELECT PaymentDetail.*, CommissionMaster.*, PaymentMaster.PaymentType AS PaymentType, PaymentMaster.PaymentMode AS PaymentMode, PaymentDetail.DueAmount AS Dueamount  FROM PaymentDetail
          LEFT JOIN CommissionMaster ON CommissionMaster.ID = PaymentDetail.BillMasterID
          LEFT JOIN PaymentMaster  ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
          WHERE PaymentDetail.PaymentType = 'Employee' AND CommissionMaster.ID = ${ID}`;
                break;

            case "PurchaseMaster":
                qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName, Supplier.Name AS SupplierName FROM PurchaseMaster
                    LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID
                    INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID
                    WHERE PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' AND PurchaseMaster.SupplierID = ${ID} ORDER BY PurchaseMaster.ID DESC`;
                break;

            case "UserShop":
                if (ID === "0") {
                    qry = `SELECT Shop.*, Shop.ID as ShopID, Shop.Name AS NAME, Shop.AreaName AS AreaName  FROM Shop WHERE Shop.CompanyID = ${CompanyID} Order by Shop.Status desc`;
                } else {
                    qry = `SELECT Shop.*, UserShop.UserID, UserShop.ShopID, UserShop.RoleID, Shop.Name as ShopName, Role.Name AS RoleName, Shop.AreaName AS AreaName FROM UserShop LEFT JOIN Role ON UserShop.RoleID = Role.ID LEFT JOIN Shop ON UserShop.ShopID = Shop.ID WHERE UserID =  ${ID} AND UserShop.Status = 1`;
                }
                break;

            case "UserShop1":
                qry = `SELECT UserShop.*,Shop.Name AS ShopName, Role.Name AS RoleName, Shop.AreaName AS AreaName FROM UserShop
                        LEFT JOIN Role ON UserShop.RoleID = Role.ID
                        LEFT JOIN Shop ON UserShop.ShopID = Shop.ID
                        WHERE UserShop.Status = 1 AND UserShop.UserID =  ${ID}`;

                break;

            case "PaymentDetail":
                qry = `SELECT  PaymentMaster.PayableAmount, PaymentMaster.PaidAmount, PaymentDetail.Amount, PaymentDetail.PaymentType, PaymentMaster.PaymentMode, PaymentMaster.PaymentDate, PaymentDetail.BillID FROM PaymentDetail LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID WHERE PaymentDetail.PaymentMasterID = ${ID}`;
                break;

            case "CustomerCategory":
                qry = `SELECT CustomerCategory.*, Shop.Name AS ShopName, SupportMaster.Name AS Category FROM CustomerCategory
          LEFT JOIN Shop ON Shop.ID = CustomerCategory.ShopID
          LEFT JOIN SupportMaster ON SupportMaster.ID = CustomerCategory.CategoryID
          WHERE CustomerCategory.ShopID  = ${ID} AND CustomerCategory.Status = 1 order by ID desc`;
                break;

            case "CustomerSearch":
                let param = JSON.parse(ID);
                qry = `select * from Customer WHERE CompanyID = '${CompanyID}' and Name LIKE '%${param.Name}%' And  MobileNo1 LIKE '%${param.MobileNo1}%' And  Sno LIKE '%${param.Sno}%'  and Status = 1`;
                break;

        }
        return qry;
    }

    static getdataByFilter(TableName, CompanyID, filter) {
        const data = JSON.parse(filter);
        let qry = "";
        switch (TableName) {
            case "CustomerReport":
                qry = `SELECT BillMaster.*, Customer.Name AS CustomerName, Shop.Name AS ShopName, ProductName FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID  INNER JOIN BillDetail ON BillDetail.BillID = BillMaster.ID WHERE CustomerID = '${data.customerID}' AND BillMaster.CompanyID = ${CompanyID} AND BillDate BETWEEN '${data.date1}' AND '${data.date2}' Order By BillMaster.ID Desc`;
                break;

            case "InventoryReport":
                qry = `SELECT PurchaseMaster.*, Shop.Name AS ShopName, Supplier.Name AS SupplierName FROM PurchaseMaster LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = ${CompanyID} AND PurchaseDate BETWEEN '${data.date1}' AND '${data.date2}' ORDER BY PurchaseMaster.ID Desc`;
                break;
            case "SaleReport":
                qry = `SELECT BillMaster.*, Customer.Name AS CustomerName, ProductName FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID INNER JOIN BillDetail ON BillDetail.BillID = BillMaster.ID WHERE  BillMaster.CompanyID = 1 and BillDetail.Manual = 0  and BillDetail.Manual = 1 and BillMaster.Status = 1 AND BillDate BETWEEN '${data.date1}' AND '${data.date2}' GROUP BY BillMaster.InvoiceNo Order By BillMaster.ID Desc`;
                break;
            case "AccountingReport":
                console.log("Accounting Report");
                break;
            case "PettyCash":
                let dat = data.date1;
                qry = `SELECT * from PettyCash WHERE CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and  CreatedOn > '${dat}' and Status = 1`;
                break;

            case "PettyCashToday":
                let date = data.date1;
                qry = `SELECT SUM(PettyCash.Amount) as Amount  from PettyCash WHERE CreditType='Deposit' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}'  and CreatedOn > '${date}' and Status = 1`;
                break;

            case "PettyCashOld":
                let d = moment(data.date1).format('YYYY-MM-DD');
                let dateee = data.date1;
                qry = `SELECT SUM(PettyCash.Amount) as Amount from PettyCash WHERE CreditType='Deposit' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn < '${dateee}' and Status = 1`;
                break;
            case "PettyCashwithdrawal":
                let dateeeeeee = data.date1;
                qry = `SELECT SUM(PettyCash.Amount) as Amount from PettyCash WHERE CreditType='Withdrawal' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CashType = 'CashCounter' and CreatedOn > '${dateeeeeee}' and Status = 1`;
                break;

            case "PaymentMaster":
                let dateeee = data.date1;
                qry = `SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Customer' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn > '${dateeee}'`;
                break;
            case "DoctorTodayPayment":
                let date1 = data.date1;
                qry = `SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Doctor' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn > '${date1}' `;
                break;
            case "EmployeeTodayPayment":
                let date2 = data.date1;
                qry = `SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Employee' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn > '${date2}' `;
                break;
            case "FitterTodayPayment":
                let date3 = data.date1;
                qry = `SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Fitter' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn > '${date3}' `;
                break;
            case "SupplierTodayPayment":
                let date4 = data.date1;
                qry = `SELECT * from PaymentMaster WHERE PaymentMode = 'Cash' and PaymentType = 'Supplier' and CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn > '${date4}' `;
                break;

            case "ExpenseCash":
                let dateeeee = data.date1;

                qry = `SELECT SUM(Expense.Amount) as Amount from Expense WHERE CashType = 'PettyCash' AND    CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn > '${dateeeee}' and Status =  1`;
                break;
            case "ExpenseCashCounter":
                let dateeeeee = data.date1;
                qry = `SELECT SUM(Expense.Amount) as Amount from Expense WHERE CashType = 'CashCounter' AND    CompanyID = '${CompanyID}' and ShopID = '${data.ShopID}' and CreatedOn > '${dateeeeee}' and Status = 1`;
                break;
        }
        return qry;
    }

    static getShortListQueryByParem(TableName, Parem, CompanyID) {
        let qry = "";

        qry = `select * from  ${TableName}  where Status = 1 and CompanyID = '${CompanyID}' and ` +
            Parem;

        return qry;
    }

    static getShortListQueryByParem1(TableName, Parem, CompanyID) {
        let qry = "";

        qry = `select * from  ${TableName}  where Status = 1 and CompanyID = '${CompanyID}' and ` +
            Parem;
        // + ` order by ID desc`
        return qry;
    }
    static getShortListQueryByParemBill(TableName, Parem, CompanyID) {
        let qry = "";

        qry = `select * from  ${TableName}  where Status = 1 and CompanyID = '${CompanyID}' and ` +
            Parem + ` order by ID desc`;

        return qry;
    }

    static getExtendedListQueryByParem(TableName, Parem, CompanyID) {
        let qry = "";
        switch (TableName) {
            case "BillMaster":
                qry =
                    `SELECT BillMaster.*, Customer.Name AS CustomerName, Customer1.MobileNo1 AS CustomerMob,Customer1.Sno AS Sno,Customer1.Idd AS Idd,  Shop.Name AS ShopName, Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                    FROM BillMaster
                    LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID
                    LEFT JOIN User ON User.ID = BillMaster.CreatedBy
                    LEFT JOIN User AS User1 ON User1.ID = BillMaster.UpdatedBy
                     LEFT JOIN Customer AS Customer1 ON Customer1.ID = BillMaster.CustomerID
                    WHERE BillMaster.Status =1
                     AND BillMaster.CompanyID = '${CompanyID}' and ` +
                    Parem +
                    ` Order By BillMaster.ID Desc`;
                break;

            case "saleTypeReport":
                qry =
                    // `SELECT BillDetail.*, Customer.Name AS CustomerName, Customer.MobileNo1 AS CustomerMoblieNo1,  BillMaster.PaymentStatus AS PaymentStatus, BillMaster.InvoiceNo AS BillInvoiceNo, BarcodeMaster.Option
                    // FROM BillDetail
                    // LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
                    // LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    // left join BarcodeMaster on BarcodeMaster.BillDetailID = BillDetail.ID
                    // WHERE BillDetail.Status =1 AND BillDetail.CompanyID = '${CompanyID}' and BillDetail.Manual = 0` +
                    // Parem +
                    // ` Order By BillDetail.ID Desc`;
                    `SELECT BillDetail.*, Customer.Name AS CustomerName, Customer.MobileNo1 AS CustomerMoblieNo1,  Customer.GSTNo AS GSTNo, BillMaster.PaymentStatus AS PaymentStatus, BillMaster.InvoiceNo AS BillInvoiceNo,BillMaster.BillDate AS BillDate,BillMaster.DeliveryDate AS DeliveryDate FROM BillDetail  LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID WHERE BillDetail.Status = 1 AND BillDetail.CompanyID = '${CompanyID}' AND BillDetail.Quantity != 0` +
                    Parem
                    //  +` Order By BillDetail.ID Desc`;
                break;

            case "PreorderfullList":
                qry = `SELECT DISTINCT(PurchaseDetail.ProductName), PurchaseDetail.ProductTypeName, BarcodeMaster.Barcode AS BarCode, u.Name AS CreatedPerson, PurchaseDetail.* FROM PurchaseDetail LEFT JOIN BarcodeMaster ON BarcodeMaster.PurchaseDetailID = PurchaseDetail.ID LEFT JOIN User AS u ON u.ID = PurchaseDetail.CreatedBy WHERE BarcodeMaster.CurrentStatus = 'Pre Order' AND PurchaseDetail.ProductName !='' AND PurchaseDetail.ProductTypeName != '' AND BarcodeMaster.Status = 1 and PurchaseDetail.CompanyID  = '${CompanyID}'` +
                    Parem +
                    ` Order By PurchaseDetail.ID DESC`;
                break;

            case "BillMaster1":
                qry =
                    `SELECT DISTINCT(BillMaster.ID), BillMaster.*, Customer.Name AS CustomerName, Customer1.MobileNo1 AS CustomerMob, Shop.Name AS ShopName,Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                    FROM BillMaster
                    LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID
                    LEFT JOIN User ON User.ID = BillMaster.CreatedBy
                    LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID
                    LEFT JOIN User AS User1 ON User1.ID = BillMaster.UpdatedBy
                     LEFT JOIN Customer AS Customer1 ON Customer1.ID = BillMaster.CustomerID
                    WHERE BillMaster.Status =1
                     AND BillMaster.CompanyID = '${CompanyID}' and BillDetail.Manual = 0 and BillDetail.Status = 1` +
                    Parem +
                    ` Order By BillMaster.ID Desc`;
                break;


            case "PurchaseMaster":
                qry =
                    `SELECT PurchaseMaster.*, Supplier.Name AS SupplierName, Shop.Name AS ShopName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
            FROM PurchaseMaster LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID LEFT JOIN Shop ON Shop.ID = PurchaseMaster.ShopID
            LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy WHERE PurchaseMaster.Status =1
             and PurchaseMaster.CompanyID = '${CompanyID}' and ` +
                    Parem +
                    ` Order By PurchaseMaster.ID Desc`;
                break;

            case "PaymentMaster":
                qry =
                    `SELECT PaymentMaster.*, Supplier.Name AS SupplierName, Shop.Name AS ShopName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser
                FROM PaymentMaster LEFT JOIN Supplier ON Supplier.ID = PaymentMaster.CustomerID LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                LEFT JOIN User ON User.ID = PaymentMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PaymentMaster.UpdatedBy WHERE PaymentMaster.Status =1
                 and PaymentMaster.CompanyID = '${CompanyID}' and ` +
                    Parem +
                    ` Order By PaymentMaster.ID Desc`;
                break;

            case "PaymentDetail":
                qry =
                    `SELECT PaymentDetail.*, PaymentMaster.PaymentDate as PaymentDate, PaymentMaster.PaymentType AS PaymentType,PaymentMaster.PaymentMode as PaymentMode, PaymentMaster.CardNo as CardNo, PaymentMaster.PaymentReferenceNo as PaymentReferenceNo, User.Name as Employee
          FROM PaymentDetail Inner JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID Inner Join User on User.ID = PaymentMaster.CreatedBy WHERE PaymentMaster.Status =1
           and PaymentMaster.CompanyID = '${CompanyID}' and ` +
                    Parem + `AND PaymentMaster.PaymentType = 'Customer'` +
                    `Order By PaymentDetail.ID ASC`;
                break;
            case "BarcodeMaster":
                qry =
                    `SELECT BarcodeMaster.*, Supplier.Name AS SupplierName, Shop.Name as ShopName, PurchaseDetail.ProductName, Customer.Name AS CustomerName, BillMaster.InvoiceNo, BillMaster.DeliveryDate FROM BarcodeMaster LEFT JOIN Supplier ON Supplier.ID = BarcodeMaster.SupplierID Left Join PurchaseDetail on PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID Left Join BillDetail on BillDetail.ID = BarcodeMaster.BillDetailID Left Join BillMaster on BillMaster.ID = BillDetail.BillID Left Join Customer on Customer.ID = BillMaster.CustomerID Left Join Shop on Shop.ID = BarcodeMaster.ShopID Where ` +
                    Parem;
                break;
            case "ProductInventory":
                qry =
                    `SELECT COUNT(BarcodeMaster.ID) AS Count, PurchaseDetail.BrandType, PurchaseDetail.ID as PurchaseDetailID , PurchaseDetail.UnitPrice, PurchaseDetail.Quantity, PurchaseDetail.ID, PurchaseDetail.DiscountAmount, PurchaseDetail.TotalAmount, Supplier.Name AS SupplierName, Shop.Name AS ShopName, Shop.AreaName AS AreaName, PurchaseDetail.ProductName, PurchaseDetail.ProductTypeName, PurchaseDetail.UnitPrice, PurchaseDetail.SubTotal, PurchaseDetail.DiscountPercentage, PurchaseDetail.GSTPercentage as GSTPercentagex, PurchaseDetail.GSTAmount, PurchaseDetail.GSTType as GSTTypex, PurchaseDetail.WholeSalePrice, PurchaseMaster.InvoiceNo, PurchaseMaster.PurchaseDate, PurchaseMaster.PaymentStatus,  BarcodeMaster.*, PurchaseMaster.SupplierID FROM BarcodeMaster LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID  LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID  LEFT JOIN Shop ON Shop.ID = BarcodeMaster.ShopID  where BarcodeMaster.CompanyID = ${CompanyID} AND PurchaseDetail.Status = 1` +
                    Parem +
                    " Group By BarcodeMaster.PurchaseDetailID, BarcodeMaster.ShopID" + " HAVING BarcodeMaster.Status = 1";

                console.log(qry, 'qry');
                break;

            case "SaleReport":
                qry =
                    `SELECT DISTINCT(BillMaster.ID), BillMaster.*, Shop.Name AS ShopName, Shop.AreaName AS AreaName, Customer.Name AS CustomerName , Customer.MobileNo1,Customer.GSTNo AS GSTNo, BillDetail.ProductStatus as ProductStatus, BillDetail.HSNCode as HSNCode, BillDetail.ProductDeliveryDate as ProductDeliveryDate,BillDetail.GSTType AS GSTType ,BillDetail.UnitPrice AS UnitPrice,BillMaster.DeliveryDate AS DeliveryDate FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID  LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID  WHERE BillMaster.CompanyID = ${CompanyID} and (BillDetail.Manual = 0 || BillDetail.Manual = 1 )and BillMaster.Status = 1 ` +
                    Parem + " GROUP BY BillMaster.InvoiceNo ORDER BY BillMaster.ID DESC";
                break;

            case "SaleReportDetail":
                // qry =
                //     `SELECT BillDetail.*, BillMaster.InvoiceNo, BillMaster.PaymentStatus, BillMaster.BillDate AS InvoiceDate, Shop.Name AS ShopName, Customer.Name AS CustomerName , Customer.MobileNo1 FROM BillMaster
                // LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID
                // LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                // LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID
                //  WHERE BillMaster.CompanyID = ${CompanyID} and BillDetail.Manual = 0 and BillDetail.Status = 1` +
                //     Parem;
                qry =
                    `SELECT * FROM salereportingss  WHERE salereportingss.CompanyID = ${CompanyID} AND salereportingss.Manual = 0 AND salereportingss.Status = 1 ` +
                    Parem;
                break;

            case "BillMasterExpProduct":
                qry =
                    `SELECT DISTINCT(BillMaster.ID), BillMaster.*, Customer.Name AS CustomerName, Customer1.MobileNo1 AS CustomerMob, Shop.Name AS ShopName, Shop.AreaName AS AreaName,User.Name AS CreatedByUser, User1.Name AS UpdatedByUser, BillDetail.ProductTypeName ,BillDetail.ProductName, BillDetail.UnitPrice, BillDetail.GSTType, BillDetail.GSTPercentage, BillDetail.Barcode,BillDetail.ProductDeliveryDate,BillDetail.ProductStatus , BillDetail.ProductExpDate

                    FROM BillMaster
                    LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID
                    LEFT JOIN User ON User.ID = BillMaster.CreatedBy
                    LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID
                    LEFT JOIN User AS User1 ON User1.ID = BillMaster.UpdatedBy
                     LEFT JOIN Customer AS Customer1 ON Customer1.ID = BillMaster.CustomerID
                    WHERE BillMaster.Status = 1
                     AND BillMaster.CompanyID = '${CompanyID}'` +
                    Parem +
                    ` Order By BillMaster.ID Desc`;
                break;

            case "CashCollectionReport":
                qry =
                    `SELECT PaymentDetail.*, PaymentMaster.PaymentType AS PaymentType, PaymentMaster.PaymentMode, PaymentMaster.PaymentDate,Customer.Name AS CustomerName , Shop.Name AS ShopName , Shop.AreaName AS AreaName ,BillMaster.BillDate AS BillDate,BillMaster.DeliveryDate AS DeliveryDate, BillMaster.PaymentStatus AS PaymentStatus,Customer.MobileNo1 AS MobileNo, PaymentMaster.PayableAmount , PaymentMaster.PaidAmount,BillMaster.TotalAmount As TotalAmount FROM PaymentDetail LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID LEFT JOIN Customer ON Customer.ID = PaymentDetail.CustomerID LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID LEFT JOIN BillMaster ON BillMaster.ID = PaymentDetail.BillMasterID WHERE PaymentDetail.CompanyID = ${CompanyID} AND PaymentMaster.PaymentType = 'Customer' ` +
                    Parem;
                // + ` GROUP BY PaymentDetail.BillMasterID`
                break;

            case "ExpenseReport":
                qry =
                    `SELECT Expense.*, Shop.Name AS ShopName , Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM Expense LEFT JOIN Shop ON Shop.ID = Expense.ShopID LEFT JOIN User ON User.ID = Expense.CreatedBy LEFT JOIN User AS User1 ON User1.ID = Expense.UpdatedBy WHERE Expense.CompanyID = '${CompanyID}'` +
                    Parem + ` Order By ID Desc`;
                // + ` GROUP BY PaymentDetail.BillMasterID`
                break;

            case "CashCounterReport":
                qry =
                    `SELECT CashRegister.*, Shop.Name AS ShopName, Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM CashRegister LEFT JOIN Shop ON Shop.ID = CashRegister.ShopID LEFT JOIN User ON User.ID = CashRegister.CreatedBy LEFT JOIN User AS User1 ON User1.ID = CashRegister.UpdatedBy WHERE CashRegister.CompanyID = '${CompanyID}'` +
                    Parem;

                break;

            case "CashCounterReportWithdrl":
                qry =
                    `SELECT PettyCash.*, Shop.Name AS ShopName, Shop.AreaName AS AreaName,  User.Name AS EmpName FROM PettyCash LEFT JOIN Shop ON Shop.ID = PettyCash.ShopID LEFT JOIN User ON User.ID = PettyCash.EmployeeID WHERE PettyCash. CompanyID = '${CompanyID}'  AND PettyCash.CashType = 'CashCounter' AND PettyCash.CreditType = 'Withdrawal'` +
                    Parem + ` Order By ID Desc`;

                break;

            case "PettyCashReports":
                qry =
                    `SELECT PettyCash.*, Shop.Name AS ShopName, Shop.AreaName AS AreaName,  User.Name AS EmpName FROM PettyCash LEFT JOIN Shop ON Shop.ID = PettyCash.ShopID  LEFT JOIN User ON User.ID = PettyCash.EmployeeID WHERE PettyCash.CompanyID = '${CompanyID}'` +
                    Parem;
                // + ` GROUP BY PaymentDetail.BillMasterID`
                break;

                case "AvailableBalance":
                qry =
                    `SELECT CreditType, SUM(Amount) AS Amount FROM PettyCash WHERE  PettyCash.CompanyID = '${CompanyID}' AND  PettyCash.CashType = 'PettyCash' ` +
                    Parem + ` GROUP BY CreditType `;
                // + ` GROUP BY PaymentDetail.BillMasterID`
                break;
                case "AvailableBalance1":
                    qry =
                        `SELECT * FROM CashRegister WHERE  CashRegister.CompanyID = '${CompanyID}' ` +
                        Parem + ` ORDER BY ID DESC LIMIT 1  `;
                    // + ` GROUP BY PaymentDetail.BillMasterID`
                    break;
            case "PurchaseReport":
                qry =
                    `SELECT PurchaseDetail.*,  PurchaseMaster.InvoiceNo, PurchaseMaster.PurchaseDate, PurchaseMaster.PaymentStatus, Shop.Name AS ShopName,  Shop.AreaName AS AreaName, Supplier.Name AS SupplierName,Supplier.GSTNo AS SupplierGSTNo,Product.HSNCode AS HSNcode  FROM PurchaseDetail INNER JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID
              LEFT JOIN Shop ON Shop.ID = PurchaseMaster.ShopID LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID LEFT JOIN Product ON Product.ID = PurchaseDetail.ProductTypeID WHERE   PurchaseDetail.Status = 1  AND PurchaseDetail.CompanyID = ${CompanyID} and PurchaseDetail.PurchaseID != 0 and PurchaseDetail.PurchaseID != -1` +
                    Parem;
                break;

            case "PurchaseReportExp":
                qry =
                    `SELECT PurchaseDetail.*, PurchaseMaster.InvoiceNo, PurchaseMaster.PurchaseDate, PurchaseMaster.PaymentStatus, Shop.Name AS ShopName, Shop.AreaName AS AreaName,Supplier.Name AS SupplierName  FROM PurchaseDetail LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID
              LEFT JOIN Shop ON Shop.ID = PurchaseMaster.ShopID LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE  PurchaseDetail.Ledger = 0 AND PurchaseDetail.WholeSale = 0 AND PurchaseDetail.CompanyID = ${CompanyID} ` +
                    Parem;
                break;


            case "PurchaseReports":
                qry =
                    `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName,  Supplier.Name AS SupplierName,Supplier.GSTNo AS SupplierGSTNo, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM PurchaseMaster LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID WHERE PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID = '${CompanyID}' ` +
                    Parem;
                break;

            case "PurchaseReports1":
               qry =
                    `SELECT PurchaseMaster.*, Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName,Supplier.GSTNo AS SupplierGSTNo, User.Name AS CreatedByUser, PurchaseDetail.GSTType AS GstTyp, PurchaseMaster.GSTAmount AS GSTAmount, PurchaseDetail.PurchaseID AS PurchaseID, User1.Name AS UpdatedByUser FROM PurchaseMaster LEFT JOIN User ON User.ID = PurchaseMaster.CreatedBy  LEFT JOIN User AS User1 ON User1.ID = PurchaseMaster.UpdatedBy  LEFT JOIN PurchaseDetail AS PurchaseDetail ON PurchaseDetail.PurchaseID = PurchaseMaster.ID  LEFT JOIN Shop ON PurchaseMaster.ShopID = Shop.ID
                     INNER JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID  WHERE PurchaseMaster.Status = 1 AND PurchaseMaster.CompanyID =  '${CompanyID}' ` +
                    Parem + `GROUP BY PurchaseID`;
                break;

            case "AccountingReport":
                let params = JSON.parse(Parem);
                if (params.reportType === "Payable") {
                    qry = `SELECT PaymentDetail.*, PaymentMaster.PaymentType AS PaymentType, PaymentMaster.PaymentDate, PaymentMaster.ShopID, Shop.Name AS ShopName, Shop.AreaName AS AreaName  FROM PaymentDetail
                   LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
                   LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                   WHERE PaymentDetail.PaymentType IN ('Customer Credit', 'Vendor', 'Employee')
                   AND PaymentDetail.CompanyID = ${CompanyID} AND PaymentMaster.PaymentDate BETWEEN  '${params.date1}' AND '${params.date2}' AND PaymentMaster.ShopID = ${params.shopID}`;
                } else if (params.reportType === "Recieveable") {
                    qry = `SELECT PaymentDetail.*, PaymentMaster.PaymentType AS PaymentType, PaymentMaster.PaymentDate, PaymentMaster.ShopID, Shop.Name AS ShopName, Shop.AreaName AS AreaName   FROM PaymentDetail
                    LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
                    LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                    WHERE PaymentDetail.PaymentType IN ('Customer', 'Vendor Credit') AND PaymentDetail.CompanyID = ${CompanyID}
                    AND PaymentMaster.PaymentDate BETWEEN  '${params.date1}' AND '${params.date2}' AND PaymentMaster.ShopID = ${params.shopID}`;
                } else if (params.reportType === "Expense") {
                    qry = `SELECT PaymentDetail.*, PaymentMaster.PaymentType AS PaymentType, PaymentMaster.PaymentDate, PaymentMaster.ShopID, Shop.Name AS ShopName, Shop.AreaName AS AreaName   FROM PaymentDetail
                    LEFT JOIN PaymentMaster ON PaymentMaster.ID = PaymentDetail.PaymentMasterID
                    LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                    WHERE PaymentDetail.PaymentType IN ('Expense') AND PaymentDetail.CompanyID = ${CompanyID}
                    AND PaymentMaster.PaymentDate BETWEEN  '${params.date1}' AND '${params.date2}' AND PaymentMaster.ShopID = ${params.shopID}`;
                }
                break;


            case "PurchaseChargeReport":
                qry = `SELECT PurchaseCharge.*, PurchaseMaster.InvoiceNo, PurchaseMaster.ShopID,Shop.Name AS ShopName,Shop.AreaName AS AreaName FROM PurchaseCharge
                LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseCharge.PurchaseID
                LEFT JOIN Shop ON Shop.ID = PurchaseMaster.ShopID
                WHERE PurchaseCharge.CompanyID = ${CompanyID} AND PurchaseCharge.Status = 1 ` +
                    Parem;
                break;


            case "BillServiceReport":
                qry = `SELECT BillService.*, BillMaster.InvoiceNo,BillMaster.ShopID,Shop.Name AS ShopName,Shop.AreaName AS AreaName FROM BillService
                LEFT JOIN BillMaster ON BillMaster.ID = BillService.BillID
                LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID
                WHERE BillService.CompanyID = ${CompanyID} AND BillService.Status = 1` +
                    Parem;
                break;


                case "SupplierNotification":
                    let s = Parem.split("/")
                    qry = `select * from Supplier  where Supplier.CompanyID = ${CompanyID} AND Supplier.Status = 1 AND DATE_FORMAT(STR_TO_DATE(${s[0]}, '%Y-%m-%d'), '%d-%m') = DATE_FORMAT(STR_TO_DATE(${s[1]},'%Y-%m-%d'), '%d-%m')`
                    break;


            case "CustomerNotification":
                let p = Parem.split("/")
                qry = `select * from Customer  where Customer.CompanyID = ${CompanyID} AND Customer.Status = 1 AND
                 DATE_FORMAT(STR_TO_DATE(${p[0]}, '%Y-%m-%d'), '%d-%m') = DATE_FORMAT(STR_TO_DATE(${p[1]},'%Y-%m-%d'), '%d-%m')`;

                break;

            case "EmployeeNotification":
                let e = Parem.split("/")
                qry = `select * from User  where User.CompanyID = ${CompanyID} AND User.Status = 1 AND DATE_FORMAT(STR_TO_DATE(${e[0]}, '%Y-%m-%d'), '%d-%m') = DATE_FORMAT(STR_TO_DATE(${e[1]},'%Y-%m-%d'), '%d-%m')`
                    // AND DATE_FORMAT(STR_TO_DATE(Customer.DOB, '%Y-%m-%d'), '%d-%m') = DATE_FORMAT(STR_TO_DATE('2022-12-13','%Y-%m-%d'), '%d-%m')
                break;

            case "FitterNotification":
                let f = Parem.split("/")
                qry = `select * from Fitter  where Fitter.CompanyID = ${CompanyID} AND Fitter.Status = 1 AND DATE_FORMAT(STR_TO_DATE(${f[0]}, '%Y-%m-%d'), '%d-%m') = DATE_FORMAT(STR_TO_DATE(${f[1]},'%Y-%m-%d'), '%d-%m')`

                break;

            case "DoctorNotification":
                let d = Parem.split("/")
                qry = `select * from Doctor  where Doctor.CompanyID = ${CompanyID} AND Doctor.Status = 1 AND DATE_FORMAT(STR_TO_DATE(${d[0]}, '%Y-%m-%d'), '%d-%m') = DATE_FORMAT(STR_TO_DATE(${d[1]},'%Y-%m-%d'), '%d-%m')`

                break;

            case "DeliveryNotification":
                qry = `select BillMaster.*, Customer.MobileNo1 AS CustomerMobileNo1, Customer.Name AS CustomerName from BillMaster  LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID  where BillMaster.CompanyID = ${CompanyID}  AND BillMaster.Status = 1 and Customer.Status = 1` +
                    Parem;
                break;

            //  Customer solution Expiry
            case "CustomerSolutionNotification":
                qry = `SELECT BillDetail.*, Customer.Name, Customer.MobileNo1 FROM BillDetail
                    LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
                    LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    WHERE BillDetail.ProductTypeName = 'SOLUTION' AND BillMaster.CompanyID = ${CompanyID} AND Customer.Status = 1` +
                    Parem;
                break;

            //  supplier solution expiry

            case "SupplierSolutionNotification":
                qry = `SELECT PurchaseDetail.*, Supplier.Name , Supplier.MobileNo1 FROM PurchaseDetail
                    LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID
                    LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID
                    WHERE PurchaseDetail.ProductTypeName = 'SOLUTION' AND  PurchaseMaster.CompanyID = ${CompanyID}` +
                    Parem;
                break;
            //  Customer Contact lens Expiry
            case "CustomerContactLensNotification":
                qry = `SELECT BillDetail.*, Customer.Name, Customer.MobileNo1 FROM BillDetail
                    LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
                    LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    WHERE BillDetail.ProductTypeName = 'CONTACT LENS' AND BillMaster.CompanyID = ${CompanyID} AND Customer.Status = 1` +
                    Parem;
                break;

            //  supplier contact lens expiry
            case "SupplierContactLensNotification":
                qry = `SELECT PurchaseDetail.*, Supplier.Name , Supplier.MobileNo1 FROM PurchaseDetail
                    LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID
                    LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID
                    WHERE PurchaseDetail.ProductTypeName = 'CONTACT LENS' AND PurchaseMaster.CompanyID = ${CompanyID} ` +
                    Parem;
                break;


            case "PendingNotification":
                qry = `SELECT BillDetail.*, Customer.MobileNo1 AS CustomerMobileNo1, Customer.Name AS CustomerName  FROM BillDetail
                LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
                LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID WHERE BillDetail.CompanyID = ${CompanyID} AND BillDetail.ProductStatus = 0 AND BillDetail.Status = 1 AND Customer.Status = 1` +
                    Parem;
                break;

            case "SupplierPayNotification":
                qry = `SELECT PaymentMaster.*, PaymentDetail.BillID, Supplier.Name AS SupplierName , Supplier.MobileNo1 FROM PaymentMaster
                LEFT JOIN PaymentDetail ON PaymentDetail.PaymentMasterID =  PaymentMaster.ID
                LEFT JOIN Supplier ON Supplier.ID = PaymentMaster.CustomerID
                LEFT JOIN BillMaster ON BillMaster.ID = PaymentDetail.BillMasterID
                LEFT JOIN BillDetail ON BillDetail.BillID = BillMaster.ID
                WHERE PaymentMaster.PaymentType = 'Supplier' AND PaymentMaster.CompanyID = ${CompanyID} AND PaymentMaster.Status = 1` +
                    Parem + `GROUP BY PaymentDetail.BillID`;
                break;

            case "EyeTestNotification":
                qry = `SELECT spectacle_rx.*, Customer.Name, Customer.MobileNo1, Shop.Name AS ShopName , Shop.AreaName AS AreaName FROM spectacle_rx
                LEFT JOIN Customer ON Customer.ID = spectacle_rx.CustomerID
                LEFT JOIN Shop ON Shop.ID = Customer.ID
                WHERE spectacle_rx.CompanyID = ${CompanyID} AND spectacle_rx.Status = 1 And Customer.Status = 1` +
                    Parem;
                break;

            case "ServiceNotification":
                qry = `SELECT BillDetail.*, Customer.Name, Customer.MobileNo1 FROM BillDetail
                    LEFT JOIN BillMaster ON BillMaster.ID = BillDetail.BillID
                    LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID
                    WHERE BillDetail.CompanyID = ${CompanyID} AND BillDetail.Status = 1 AND Customer.Status = 1` +
                    Parem + `GROUP BY BillDetail.BillID `;
                break;

            case "Supplier":
                qry = `select ${TableName}.*, User.Name as UpdatedPerson from ${TableName} left join User on User.ID = ${TableName}.UpdatedBy  where ${TableName}.CompanyID = ${CompanyID} AND ${TableName}.Status = 0` +
                    Parem;
                break;

            case "FilterCustomer":
                qry = `select Customer.*, User.Name as UpdatedPerson from Customer left join User on User.ID = Customer.UpdatedBy  where Customer.CompanyID = ${CompanyID} AND Customer.Status = 0` +
                    Parem;
                break;

            case "BillMaster":
                qry = `SELECT BillMaster.*, Customer.Name AS CustomerName, Customer1.MobileNo1 AS CustomerMob,Customer1.Sno AS Sno,  Shop.Name AS ShopName, Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM BillMaster  LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID LEFT JOIN User ON User.ID = BillMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = BillMaster.UpdatedBy LEFT JOIN Customer AS Customer1 ON Customer1.ID = BillMaster.CustomerID WHERE BillMaster.CompanyID = '${CompanyID}' AND BillMaster.Status = 0` +
                    Parem;

                break;

            case "FilterPurchaseMaster":
                qry = `select PurchaseMaster.*, User.Name as UpdatedPerson from PurchaseMaster left join User on User.ID = PurchaseMaster.UpdatedBy  where PurchaseMaster.CompanyID = ${CompanyID} AND PurchaseMaster.Status = 0` +
                    Parem;
                break;

            case "FilterShops":
                qry = `select Shop.*, User.Name as UpdatedPerson from Shop left join User on User.ID = Shop.UpdatedBy  where Shop.CompanyID = ${CompanyID} AND Shop.Status = 0` +
                    Parem;
                break;

            case "FilterDoctors":
                qry = `select Doctor.*, User.Name as UpdatedPerson from Doctor left join User on User.ID = Doctor.UpdatedBy  where Doctor.CompanyID = ${CompanyID} AND Doctor.Status = 0` +
                    Parem;
                break;

            case "FilterFitters":
                qry = `select Fitter.*, User.Name as UpdatedPerson from Fitter left join User on User.ID = Fitter.UpdatedBy  where Fitter.CompanyID = ${CompanyID} AND Fitter.Status = 0` +
                    Parem;
                break;

            case "CompanyFilter":
                qry = `SELECT Company.*, User.Name AS OwnerName FROM Company  LEFT JOIN User ON User.CompanyID = Company.ID  WHERE User.UserGroup = 'CompanyAdmin' And  Company.Status = 1` +
                    Parem;
                break;

            case "FilterLoginHistory":
                qry = `SELECT * FROM  LoginHistory WHERE   CompanyID = '${CompanyID}' AND LoginHistory.Status = 1 ` +
                    Parem;
                break;

            case "FilterPayroll":
                qry = `SELECT Payroll.*, User.Name AS OwnerName, user1.Name as CreatedByUser, user2.Name as UpdatedByUser FROM Payroll  LEFT JOIN User ON User.ID = Payroll.EmployeeID LEFT JOIN User as user1 ON user1.ID = Payroll.CreatedBy LEFT JOIN User as user2 ON user2.ID = Payroll.UpdatedBy WHERE  Payroll.Status = 1 and  Payroll.CompanyID = ${CompanyID}` +
                    Parem;
                break;

            case "FilterPetty":
                qry = `SELECT PettyCash.*, User.Name AS OwnerName, user1.Name AS CreatedByUser, user2.Name AS UpdatedByUser
                FROM PettyCash LEFT JOIN User ON User.ID = PettyCash.EmployeeID LEFT JOIN User AS user1 ON user1.ID = PettyCash.CreatedBy LEFT JOIN User AS user2 ON user2.ID = PettyCash.UpdatedBy WHERE  PettyCash.Status = 1 and  PettyCash.CompanyID = ${CompanyID} ` +
                    Parem;
                break;
            case "FilterExpense":
                qry = `SELECT Expense.*,  user1.Name AS CreatedByUser, user2.Name AS UpdatedByUser , Shop.Name AS ShopName, Shop.AreaName AS AreaName  FROM Expense LEFT JOIN User AS user1 ON user1.ID = Expense.CreatedBy  LEFT JOIN User AS user2 ON user2.ID = Expense.UpdatedBy LEFT JOIN Shop AS Shop ON Shop.ID = Expense.ShopID WHERE  Expense.Status = 1 and  Expense.CompanyID = ${CompanyID}` +
                    Parem;
                break;

            case "deleteUsers":
                qry = `select User.*, user1.Name as UpdatedPerson from User left join User as user1 on user1.ID = User.UpdatedBy  where User.CompanyID = ${CompanyID} AND User.Status = 0`;
                break;

            case "filterReward":
                qry = `SELECT SUM(Payment) AS RewardPayment FROM RewardMaster WHERE CompanyID = ${CompanyID}` +
                    Parem;
                break;

            case "FilterPaymentMasterSupplier":
                qry = `SELECT DISTINCT( PaymentMaster.ID), PaymentMaster.*, Supplier.Name AS Name, Shop.Name AS ShopName, User1.Name AS CreatedByUser, User2.Name AS UpdatedByUser, PaymentDetail.DueAmount AS Due, PaymentDetail.Amount As PAmount,PaymentDetail.BillID
                FROM PaymentMaster LEFT JOIN Supplier ON Supplier.ID =  PaymentMaster.CustomerID LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                LEFT JOIN User as User1 ON User1.ID = PaymentMaster.CreatedBy LEFT JOIN User AS User2 ON User2.ID = PaymentMaster.UpdatedBy LEFT JOIN PaymentDetail ON  PaymentDetail.PaymentMasterID = PaymentMaster.ID WHERE PaymentMaster.Status = 1 and PaymentDetail.Status = 1 and PaymentMaster.CompanyID = '${CompanyID}'` +
                    Parem + `and PaymentMaster.PaymentType = 'Supplier' AND PaymentDetail.Amount != 0 and PaymentDetail.BillID != '' Order By PaymentMaster.ID Desc`;
                break;

            case "FilterPaymentMasterFitter":
                qry = `SELECT PaymentMaster.*, Fitter.Name AS Name, Shop.Name AS ShopName, User1.Name AS CreatedByUser, User2.Name AS UpdatedByUser, PaymentDetail.DueAmount AS Due, PaymentDetail.Amount As PAmount, PaymentDetail.BillID
                    FROM PaymentMaster LEFT JOIN Fitter ON Fitter.ID =  PaymentMaster.CustomerID LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                    LEFT JOIN User as User1 ON User1.ID = PaymentMaster.CreatedBy LEFT JOIN User AS User2 ON User2.ID = PaymentMaster.UpdatedBy LEFT JOIN PaymentDetail ON  PaymentDetail.PaymentMasterID = PaymentMaster.ID WHERE PaymentMaster.Status = 1 and PaymentMaster.CompanyID = '${CompanyID}'` +
                    Parem + `and PaymentMaster.PaymentType = 'Fitter' and PaymentDetail.BillID != '' Order By PaymentMaster.ID Desc`;
                break;

            case "FilterPaymentMasterEmployee":
                qry = `SELECT PaymentMaster.*, User.Name AS Name, Shop.Name AS ShopName, User1.Name AS CreatedByUser, User2.Name AS UpdatedByUser, PaymentDetail.DueAmount AS Due
                        FROM PaymentMaster LEFT JOIN User ON User.ID =  PaymentMaster.CustomerID LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                        LEFT JOIN User as User1 ON User1.ID = PaymentMaster.CreatedBy LEFT JOIN User AS User2 ON User2.ID = PaymentMaster.UpdatedBy LEFT JOIN PaymentDetail ON  PaymentDetail.PaymentMasterID = PaymentMaster.ID WHERE PaymentMaster.Status = 1 and PaymentMaster.CompanyID = '${CompanyID}'` +
                    Parem + `and PaymentMaster.PaymentType = 'User' Order By PaymentMaster.ID Desc`;
                break;

            case "FilterPaymentMasterDoctor":
                qry = `SELECT PaymentMaster.*, Doctor.Name AS Name, Shop.Name AS ShopName, User1.Name AS CreatedByUser, User2.Name AS UpdatedByUser, PaymentDetail.DueAmount AS Due
                            FROM PaymentMaster LEFT JOIN Doctor ON Doctor.ID =  PaymentMaster.CustomerID LEFT JOIN Shop ON Shop.ID = PaymentMaster.ShopID
                            LEFT JOIN User as User1 ON User1.ID = PaymentMaster.CreatedBy LEFT JOIN User AS User2 ON User2.ID = PaymentMaster.UpdatedBy LEFT JOIN PaymentDetail ON  PaymentDetail.PaymentMasterID = PaymentMaster.ID WHERE PaymentMaster.Status = 1 and PaymentMaster.CompanyID = '${CompanyID}'` +
                    Parem + `and PaymentMaster.PaymentType = 'Doctor' Order By PaymentMaster.ID Desc`;
                break;

            case "TransferReport":
                qry = `SELECT TransferMaster.*, Shop.Name AS FromShop, ShopTo.Name AS ToShop, Shop.AreaName AS AreaName, ShopTo.AreaName AS ToAreaName, User.Name AS CreatedByUser, UserUpdate.Name AS UpdatedByUser FROM TransferMaster LEFT JOIN Shop ON Shop.ID = TransferFromShop LEFT JOIN Shop AS ShopTo ON ShopTo.ID = TransferToShop LEFT JOIN User ON User.ID = TransferMaster.CreatedBy LEFT JOIN User AS UserUpdate ON UserUpdate.ID = TransferMaster.UpdatedBy WHERE TransferMaster.CompanyID = '${CompanyID}' ` + Parem + ` Order By TransferMaster.ID Desc`;
                break;

            case "ProductSummaryReport":
                qry = `SELECT BarcodeMaster.*,PurchaseDetail.ProductTypeName,PurchaseDetail.ProductName,Shop.Name AS ShopName,Shop.AreaName AS AreaName, Supplier.Name AS SupplierName, PurchaseMaster.InvoiceNo AS InvoiceNo,
                SUM(CASE WHEN BarcodeMaster.CurrentStatus = 'Available' THEN 1 ELSE 0 END) AS Available,
                SUM(CASE WHEN BarcodeMaster.CurrentStatus = 'Sold' THEN 1 ELSE 0 END) AS Sold, SUM(CASE WHEN BarcodeMaster.CurrentStatus = 'Damaged' THEN 1 ELSE 0 END) AS Damaged, SUM(CASE WHEN BarcodeMaster.CurrentStatus = 'Transfer Pending' THEN 1 ELSE 0 END) AS TransferPending, SUM(CASE WHEN BarcodeMaster.CurrentStatus = 'Lost/Stolen' THEN 1 ELSE 0 END) AS LostStolen, COUNT(*) AS totalQty FROM BarcodeMaster
                LEFT JOIN PurchaseDetail ON PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID
                LEFT JOIN Shop ON Shop.ID = BarcodeMaster.ShopID
                LEFT JOIN PurchaseMaster ON PurchaseMaster.ID = PurchaseDetail.PurchaseID
                LEFT JOIN Supplier ON Supplier.ID = PurchaseMaster.SupplierID
                WHERE BarcodeMaster.CompanyID = '${CompanyID}' AND BarcodeMaster.CurrentStatus != 'Pre Order' and PurchaseDetail.Status = 1 and PurchaseDetail.PurchaseID != -1` + Parem + ` GROUP BY BarcodeMaster.Barcode`;
                break;

            // case "PreOrederFillter":
            //     qry = `SELECT 0 as Sel , COUNT(*) AS Qty, BarcodeMaster.*, Supplier.Name AS SupplierName, Fitter.Name as FitterName, Shop.Name as ShopName,Shop.AreaName as AreaName, BillDetail.ProductName, Customer.Name AS CustomerName, Customer.MobileNo1 AS MobileNo, BillMaster.InvoiceNo, BillMaster.DeliveryDate,BillMaster.BillDate, User.Name as UpdatePerson, PurchaseDetail.ProductTypeName, PurchaseDetail.ProductTypeID, PurchaseDetail.UnitPrice, PurchaseDetail.GSTPercentage, PurchaseDetail.GSTAmount, PurchaseDetail.GSTType,PurchaseDetail.Quantity  FROM BarcodeMaster LEFT JOIN Supplier ON Supplier.ID = BarcodeMaster.SupplierID Left Join PurchaseDetail on PurchaseDetail.ID = BarcodeMaster.PurchaseDetailID Left Join BillDetail on BillDetail.ID = BarcodeMaster.BillDetailID Left Join BillMaster on BillMaster.ID = BillDetail.BillID Left Join Customer on Customer.ID = BillMaster.CustomerID Left Join Shop on Shop.ID = BarcodeMaster.ShopID Left Join Fitter on Fitter.ID = BarcodeMaster.FitterID left join User on User.ID = BarcodeMaster.UpdatedBy GROUP BY BarcodeMaster.BillDetailID  having BarcodeMaster.ShopID = '${ShopID}'  and ${qstring} and BarcodeMaster.CompanyID = '${CompanyID}' and BarcodeMaster.BillDetailID != "null"  Order By BarcodeMaster.ID Desc `;
            //     break;



        }
        console.log(qry, 'hbn');
        return qry;

    }

    static async getSupportMasterList(TableName, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from SupportMaster where TableName = '${TableName}' and CompanyID = '${CompanyID}' and Status = 1 Order by ID Desc`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getCashRegisterData(ShopID, CompanyID) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            let data = await connection.query(
                `select * from CashRegister where ShopID = '${ShopID}' and CompanyID = '${CompanyID}'  Order by ID Desc Limit 1`
            );

            response.result = data;
            response.success = "Success";

            await connection.query("COMMIT");
            return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static getProductSpecQuery(PurchaseDetailID, CompanyID) {
        let qry = `SELECT ProductSpec.ID AS SpecID, ProductSpec.ProductName , ProductSpec.CompanyID, ProductSpec.Name AS FieldName,
    ProductSpec.Seq, ProductSpec.Type AS FieldType, ProductSpec.Ref, ProductSpec.SptTableName, NULL AS SptTableData, ProductDataSpec.ProductSpecValue AS SelectedValue,
    FALSE AS DisplayAdd,  '' AS EnteredValue, NULL AS SptFilterData FROM ProductSpec
    LEFT JOIN ProductDataSpec ON ProductDataSpec.ProductSpecID = ProductSpec.ID
    WHERE  ProductDataSpec.PurchaseDetailID = '${PurchaseDetailID}'
    AND ProductSpec.CompanyID = '${CompanyID}' ORDER BY ProductSpec.Seq ASC `;

        return qry;
    }

    static async filterDataByParam(Body, LoggedOnUser, CompanyID, TableName) {
        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };
            let qry;
            switch (TableName) {
                case "BillMaster":
                    qry = `SELECT BillMaster.*, Customer.Name AS CustomerName, Customer.MobileNo1 AS CustomerMob, Shop.Name AS ShopName, Shop.AreaName AS AreaName, User.Name AS CreatedByUser, User1.Name AS UpdatedByUser FROM BillMaster LEFT JOIN Customer ON Customer.ID = BillMaster.CustomerID LEFT JOIN Shop ON Shop.ID = BillMaster.ShopID LEFT JOIN User ON User.ID = BillMaster.CreatedBy LEFT JOIN User AS User1 ON User1.ID = BillMaster.UpdatedBy WHERE  BillMaster.Status = 1 AND BillMaster.CompanyID = '${CompanyID}' and `;
                    break;
            }

            let subqry = "";
            for (let [key, value] of Object.entries(Body)) {
                if (value != null && value != "") {
                    if (subqry == "") {
                        subqry += `${key} LIKE('${value}')`;
                    } else {
                        subqry += ` AND ${key} LIKE('${value}')`;
                    }
                }
            }
            let fullQry = qry + subqry;
            if (subqry != "") {
                let data = await connection.query(fullQry);
                response.result = data;
                await connection.query("COMMIT");
                return response;
            }
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }

    static async getdata() {
        let updateBilldetail = await connection.query(
            `select * from Customer where CompanyID = 1`
        );
        console.log(updateBilldetail, 'updateBilldetail');
        return updateBilldetail
    }

    static async getchack() {


        const connection = await mysql.connection();
        try {
            let response = { data: null, success: null };

            const datum = [
                {
                 "name": "-0.25 CYL BB",
                 "balance": 2
                },
                {
                 "name": "-0.25 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-0.25-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5 CYL BB",
                 "balance": 2
                },
                {
                 "name": "-0.5 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-0.5-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-0.75 CYL BB",
                 "balance": 2
                },
                {
                 "name": "-0.75-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-0.75-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-0.75-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-0.75-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-0.75-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-0.75SPH BB",
                 "balance": 2
                },
                {
                 "name": "-1.0 CYL BB",
                 "balance": 2
                },
                {
                 "name": "-1.0 SPH BB",
                 "balance": 3
                },
                {
                 "name": "-1.0-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.0-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.0-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.0-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-1.0-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.0-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.0-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.0-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25 CYL BB",
                 "balance": 2
                },
                {
                 "name": "-1.25 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.25-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5 CYL BB",
                 "balance": 2
                },
                {
                 "name": "-1.5 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.5-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-1.75-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0 CYL BB",
                 "balance": 2
                },
                {
                 "name": "-2.0 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.0-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.25-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-2.5 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-2.5-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.5-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.5-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-2.5-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-2.5-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.5-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.75 SPH BB",
                 "balance": 4
                },
                {
                 "name": "-2.75-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.75-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.75-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-2.75-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-2.75-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-2.75-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-2.75-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-3.0-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-3.25 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-3.25-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.25-0.75 BB",
                 "balance": 1
                },
                {
                 "name": "-3.25-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.25-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-3.25-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-3.5 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-3.5-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.5-0.5 BB",
                 "balance": 2
                },
                {
                 "name": "-3.5-0.75 BB",
                 "balance": 3
                },
                {
                 "name": "-3.5-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-3.5-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.5-1.5 BB",
                 "balance": 2
                },
                {
                 "name": "-3.5-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-3.5-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-3.75 SPH BB",
                 "balance": 2
                },
                {
                 "name": "-3.75-0.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.75-0.75 BB",
                 "balance": 2
                },
                {
                 "name": "-3.75-1.0 BB",
                 "balance": 2
                },
                {
                 "name": "-3.75-1.25 BB",
                 "balance": 2
                },
                {
                 "name": "-3.75-1.75 BB",
                 "balance": 2
                },
                {
                 "name": "-3.75-2.0 BB",
                 "balance": 2
                },
                {
                 "name": "-4.0 SPH BB",
                 "balance": 2
                },
                {
                 "name": "00.00 BB",
                 "balance": 10
                },
                {
                 "name": "3028 AVIATOR FRAME",
                 "balance": 12
                },
                {
                 "name": "A GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "A&S GENTS WATCH",
                 "balance": 92
                },
                {
                 "name": "A&S SUPRA FRAME",
                 "balance": 10
                },
                {
                 "name": "A.WATCH LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "AALISAN SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "ABBYGALE GENTS WATCH",
                 "balance": 4
                },
                {
                 "name": "ACETATE FRAME",
                 "balance": 10
                },
                {
                 "name": "ACTIBO METAL FRAME",
                 "balance": 4
                },
                {
                 "name": "ACTIVE TR FRAME",
                 "balance": 9
                },
                {
                 "name": "ACTIVION TR FRAME",
                 "balance": 3
                },
                {
                 "name": "ADVOGUE GENTS WATCH",
                 "balance": 6
                },
                {
                 "name": "AFFIX GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "AFFIX TR FRAME",
                 "balance": 3
                },
                {
                 "name": "AFTEROUN SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "AGABANG TR FRAME",
                 "balance": 2
                },
                {
                 "name": "AIR TR FRAME",
                 "balance": 1
                },
                {
                 "name": "AIRFLEX FRAME",
                 "balance": 19
                },
                {
                 "name": "AIRFORCE METAL FULL FRAME",
                 "balance": 7
                },
                {
                 "name": "AIRLITE SUPRA FRAME",
                 "balance": 5
                },
                {
                 "name": "AJANTA ODC-104 DIGITAL CLOCK",
                 "balance": 1
                },
                {
                 "name": "AJANTA ODC-120 DIGITAL CLOCK",
                 "balance": 1
                },
                {
                 "name": "AJANTA OLC-103 DIGITAL CLOCK",
                 "balance": 1
                },
                {
                 "name": "ALLEGRO TR FRAME",
                 "balance": 9
                },
                {
                 "name": "ALLPH SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "ALTRA 810 WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "ALTRMX SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "AMAZFIT BIP S LITE SMARTWATCH[CHARCOAL BLACK]",
                 "balance": 1
                },
                {
                 "name": "AMAZFIT BIP SMARTWATCH[BLACK]",
                 "balance": 3
                },
                {
                 "name": "AMAZFIT NEO SMARTWATCH[BLACK]",
                 "balance": 1
                },
                {
                 "name": "AMBLE TITANIUM FRAME",
                 "balance": 1
                },
                {
                 "name": "AMERICAN STYLE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "AMIRICAN STYLE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ANA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ANALOGX GENTS WATCH",
                 "balance": 25
                },
                {
                 "name": "ANALOGX LADIES STEEL WATCH",
                 "balance": 48
                },
                {
                 "name": "ANALOGX LADIES WATCH",
                 "balance": 24
                },
                {
                 "name": "ANILING SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "ANTI BLUE TR FRAME",
                 "balance": 29
                },
                {
                 "name": "AOA SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "AOGFMOOL TR FRAME",
                 "balance": 1
                },
                {
                 "name": "AOKENAN METAL FRAME",
                 "balance": 8
                },
                {
                 "name": "AONE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "AOPOESS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ARROW FLOT METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "AS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ASPHALT SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "ATDHXB SUPRA FRAME",
                 "balance": 10
                },
                {
                 "name": "ATTRACTION IND TR",
                 "balance": 2
                },
                {
                 "name": "AUDEMARS PIGUET LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "AVAVGE METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "AVAVGE METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "AWESOME TR FRAME",
                 "balance": 1
                },
                {
                 "name": "AX LADIES WATCH",
                 "balance": 3
                },
                {
                 "name": "AXISART ACETATE FRAME",
                 "balance": 4
                },
                {
                 "name": "AXISART TR FRAME",
                 "balance": 3
                },
                {
                 "name": "B LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "B&B LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "B&B METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "B&G GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "B&R LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "B&S TR FRAME",
                 "balance": 3
                },
                {
                 "name": "B&W FIBRE FRAME",
                 "balance": 2
                },
                {
                 "name": "B&W TR FRAME",
                 "balance": 1
                },
                {
                 "name": "BABBIE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "BABY BEE ACETATE FRAME",
                 "balance": 25
                },
                {
                 "name": "BABYDEER TR FRAME",
                 "balance": 3
                },
                {
                 "name": "BABYSTAR TR FRAME",
                 "balance": 5
                },
                {
                 "name": "BACKGUND TR FRAME",
                 "balance": 1
                },
                {
                 "name": "BADADOS TR FRAME",
                 "balance": 9
                },
                {
                 "name": "BALENO SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "BAR NINE METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "BARIHO GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "BARIHO LADIES METAL WATCH",
                 "balance": 8
                },
                {
                 "name": "BCODE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "BE HUMAN ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "BEHUMAN ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "BEN-10 ACETATE FRAME",
                 "balance": 6
                },
                {
                 "name": "BERKS METAL FULL FRAME",
                 "balance": 4
                },
                {
                 "name": "BERLIN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "BEST SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "BESTER TR FRAME",
                 "balance": 2
                },
                {
                 "name": "BIAN METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "BIAN SUPRA FRAME",
                 "balance": 4
                },
                {
                 "name": "BIGBOSS TTN FRAME",
                 "balance": 1
                },
                {
                 "name": "BIKE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "BIRR METAL FULL FRAME",
                 "balance": 4
                },
                {
                 "name": "BLACK METAL FULL FRAME",
                 "balance": 4
                },
                {
                 "name": "BLACK SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "BLANCPAIN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "BLOOM TR FRAME",
                 "balance": 1
                },
                {
                 "name": "BLUEBERY TR FRAME",
                 "balance": 20
                },
                {
                 "name": "BLUECUT FRAME",
                 "balance": 1
                },
                {
                 "name": "BLUECUT ULTEM FRAME",
                 "balance": 10
                },
                {
                 "name": "BLUERIBBON METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "BMW ACETATE FRAME FRAME",
                 "balance": 3
                },
                {
                 "name": "BOAT BASSHEADS 100 WIRED EARPHONE",
                 "balance": 2
                },
                {
                 "name": "BOAT BASSHEADS 110 WIRED EARPHONES",
                 "balance": 1
                },
                {
                 "name": "BOAT BASSHEADS 132 WIRED EARPHONES",
                 "balance": 3
                },
                {
                 "name": "BOAT ROCKERZ 235V2 WIRELESS NECKBAND[BLUE]",
                 "balance": 1
                },
                {
                 "name": "BOAT ROCKERZ 238 WIRELESS NECKBAND[BLACK]",
                 "balance": 2
                },
                {
                 "name": "BOAT ROCKERZ 245V2 WIRELESS BLUETOOTH HEADSETS",
                 "balance": 1
                },
                {
                 "name": "BOAT ROCKERZ 255 [CSK BLUE]",
                 "balance": 1
                },
                {
                 "name": "BOAT ROCKERZ 255 PRO WIRELESS NECKBAND[NAVY BLUE]",
                 "balance": 2
                },
                {
                 "name": "BOAT ROCKERZ 255PRO [BLAZING YELLOW]",
                 "balance": 1
                },
                {
                 "name": "BOAT ROCKERZ 338 WIRELESS BLUETOOTH HEADSETS",
                 "balance": 1
                },
                {
                 "name": "BOAT ROCKERZ 338 WIRELESS NECKBAND[OCEAN BLUE]",
                 "balance": 1
                },
                {
                 "name": "BOAT WATCH FLASH SMARTWATCH[LIGHTNINGBLACK]",
                 "balance": 3
                },
                {
                 "name": "BOAT WATCH FLASH SMARTWATCH[MOONRED]",
                 "balance": 2
                },
                {
                 "name": "BOAT WATCH MERCURY SMARTWATCH[DEEP BLUE]",
                 "balance": 1
                },
                {
                 "name": "BOAT WATCH PRIMIA SMARTWATCH[ACTIVEBLACK]",
                 "balance": 2
                },
                {
                 "name": "BOAT WATCH XTEND SMARTWATCH[SANDY CREAM]",
                 "balance": 1
                },
                {
                 "name": "BOAT WATCH XTEND[OLIVE GREEN]",
                 "balance": 1
                },
                {
                 "name": "BOAT WAVE ARCADE SMARTWATCH[ACTIVE BLACK]",
                 "balance": 6
                },
                {
                 "name": "BOGARIS METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "BOMNIR TR FRAME",
                 "balance": 4
                },
                {
                 "name": "BOND TR FRAME",
                 "balance": 1
                },
                {
                 "name": "BOSIYAAN TR FRAME",
                 "balance": 1
                },
                {
                 "name": "BOSS SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "BOSS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "BOULT AUDIO PROBASS CURVE WIRELESS NECKBAND",
                 "balance": 2
                },
                {
                 "name": "BOXILN GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "BRAOI TR FRAME",
                 "balance": 11
                },
                {
                 "name": "BREED SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "BROWSE METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "BRSDK BANGLE WATCH",
                 "balance": 22
                },
                {
                 "name": "BTL LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "BURBERRY METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "BVLGARI METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "BVLGARI TR FRAME",
                 "balance": 7
                },
                {
                 "name": "C&K COUPLE WATCH",
                 "balance": 1
                },
                {
                 "name": "C&K GENTS MAGNET BELT WATCH",
                 "balance": 1
                },
                {
                 "name": "C&K GENTS METAL STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "C&K GENTS METAL WATCH",
                 "balance": 1
                },
                {
                 "name": "C&K GENTS WATCH",
                 "balance": 23
                },
                {
                 "name": "C&K LADIES METAL STRAP WATCH",
                 "balance": 32
                },
                {
                 "name": "C&K LADIES WATCH",
                 "balance": 6
                },
                {
                 "name": "C&O GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "C&P LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "C&R GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "C&R GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "C&R METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "C&R SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "C&R TR FRAME",
                 "balance": 4
                },
                {
                 "name": "C&S GENTS METAL STRAP WATCH",
                 "balance": 3
                },
                {
                 "name": "C&S METAL DIGITAL WATCH",
                 "balance": 2
                },
                {
                 "name": "C9 TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CABBEEN TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CAIN TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CALVIN TR FRAME",
                 "balance": 3
                },
                {
                 "name": "CAMPA ACETATE FRAME",
                 "balance": 47
                },
                {
                 "name": "CAPTI TR FRAME",
                 "balance": 4
                },
                {
                 "name": "CARGO SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "CARLINGTON LADIES STEEL WATCH",
                 "balance": 16
                },
                {
                 "name": "CARMEN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CARMILAR TR FRAME",
                 "balance": 4
                },
                {
                 "name": "CARNIVAL GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "CARRERA ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "CARTIER TR FRAME",
                 "balance": 11
                },
                {
                 "name": "CATALYST TITANIUM FRAME",
                 "balance": 3
                },
                {
                 "name": "CATEYE ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "CENTR-STYLE TR FRAME",
                 "balance": 10
                },
                {
                 "name": "CEO ACETATE FRAME",
                 "balance": 26
                },
                {
                 "name": "CEREMONY TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CHANEL LADIES METAL WATCH",
                 "balance": 1
                },
                {
                 "name": "CHANEL TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CHARLIE JUNIOR TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CHASE ACETATE FRAME",
                 "balance": 17
                },
                {
                 "name": "CHERISH SUPRA  FRAME",
                 "balance": 1
                },
                {
                 "name": "CHERISH SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "CHILD TR FRAME",
                 "balance": 6
                },
                {
                 "name": "CHILDEN TR FRAME",
                 "balance": 9
                },
                {
                 "name": "CHILLS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CHOPARD LADIES BRACELET WATCH",
                 "balance": 1
                },
                {
                 "name": "CHOPARD LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "CHRISTIAN DIOR TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CINEMA TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CITIZEN GENTS IGP ROUND WATCH",
                 "balance": 20
                },
                {
                 "name": "CITIZEN GENTS IGP SQUARE DIAL WATCH",
                 "balance": 15
                },
                {
                 "name": "CITIZEN GENTS ROUND DIAL LEATHER STRAP WATCH",
                 "balance": 16
                },
                {
                 "name": "CITIZEN GENTS SQUARE DIAL LEATHER STRAP WATCH",
                 "balance": 14
                },
                {
                 "name": "CITIZEN GENTS SQUARE DIAL METAL STRAP WATCH",
                 "balance": 6
                },
                {
                 "name": "CITIZEN GENTS SQUARE IGP WATCH",
                 "balance": 25
                },
                {
                 "name": "CITIZEN GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "CITIZEN LADIES IGP WATCH",
                 "balance": 11
                },
                {
                 "name": "CITIZEN LADIES LEATHER STRAP WATCH",
                 "balance": 13
                },
                {
                 "name": "CITIZEN LADIES METAL STRAP WATCH",
                 "balance": 26
                },
                {
                 "name": "CITIZEN ROUND DIAL GENTS METAL STRAP WATCH",
                 "balance": 20
                },
                {
                 "name": "CLARISH METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "CLARISH METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "CLASS GENTS IGP ROUND WATCH",
                 "balance": 7
                },
                {
                 "name": "CLASS GENTS ROUND DIAL LEATHER STRAP WATCH",
                 "balance": 6
                },
                {
                 "name": "CLASS GENTS ROUND DIAL METAL STRAP WATCH",
                 "balance": 3
                },
                {
                 "name": "CLASS IGP GENTS LEATHER STRAP WATCH",
                 "balance": 6
                },
                {
                 "name": "CLASS IGP LEATHER LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "CLASS LADIES METAL WATCH",
                 "balance": 5
                },
                {
                 "name": "CLEB HYBRID FRAME",
                 "balance": 6
                },
                {
                 "name": "CLEVER TR FRAME",
                 "balance": 24
                },
                {
                 "name": "CLOUD IND TR FRAME",
                 "balance": 39
                },
                {
                 "name": "CMARALL TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CODE METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "COLLECTION TR FRAME",
                 "balance": 2
                },
                {
                 "name": "COLOREYE ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "COLORSU METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "COLORSU METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "COLOUR CHOICE IND TR FRAME",
                 "balance": 9
                },
                {
                 "name": "CONSIDER SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "CONTACT LENSES",
                 "balance": 4
                },
                {
                 "name": "CONTACTS & SALES TR",
                 "balance": 3
                },
                {
                 "name": "CONVERSE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "COOPERATION TR FRAME",
                 "balance": 1
                },
                {
                 "name": "COPLEY TR FRAME",
                 "balance": 9
                },
                {
                 "name": "COPTER-FIGHTER TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CORA ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "CORDECON METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "CORDECON SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "CORES IND TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CORLOS TR FRAME",
                 "balance": 3
                },
                {
                 "name": "COULD SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "COURTEOUS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CRAEST TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CREAM SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "CREATIVE CHILD FIBRE FRAME",
                 "balance": 2
                },
                {
                 "name": "CUBE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CUPER TR FRAME",
                 "balance": 2
                },
                {
                 "name": "CURREN GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "CURREN LADIES METAL STRAP WATCH",
                 "balance": 15
                },
                {
                 "name": "CURREN LADIES WATCH",
                 "balance": 3
                },
                {
                 "name": "CUSTOM GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "CUSTOM LADIES STEEL WATCH",
                 "balance": 14
                },
                {
                 "name": "CUSTOM LADIES WATCH",
                 "balance": 4
                },
                {
                 "name": "CUT TR FRAME",
                 "balance": 10
                },
                {
                 "name": "CUTE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "CYLINDER SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "D&G LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "D&L GENTS METAL WATCH",
                 "balance": 1
                },
                {
                 "name": "D&L GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "D&R LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "D&R METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "D&R TR FRAME",
                 "balance": 3
                },
                {
                 "name": "DADI METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "DAILY KEEN LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "DALLAS TR FRAME",
                 "balance": 2
                },
                {
                 "name": "DAMON TR FRAME",
                 "balance": 6
                },
                {
                 "name": "DANIEL HUNTER METAL FRAME",
                 "balance": 6
                },
                {
                 "name": "DANIELHUNTER TR FRAME",
                 "balance": 8
                },
                {
                 "name": "DANLEEX GENTS WATCH",
                 "balance": 6
                },
                {
                 "name": "DARK FANTASY TR FRAME",
                 "balance": 1
                },
                {
                 "name": "DASH BY TITAN KIDS FRAME[1024]",
                 "balance": 2
                },
                {
                 "name": "DASH BY TITAN KIDS FRAME[1025]",
                 "balance": 1
                },
                {
                 "name": "DASHING TR FRAME",
                 "balance": 1
                },
                {
                 "name": "DATA SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "DAVID ADAM ACETATE FRAME",
                 "balance": 28
                },
                {
                 "name": "DB LADIES METAL STRAP WATCH",
                 "balance": 9
                },
                {
                 "name": "DECOSTA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "DEFERENTIAL METAL FULL FRAME",
                 "balance": 2
                },
                {
                 "name": "DEFERENTIAL SUPRA FRAME",
                 "balance": 6
                },
                {
                 "name": "DEFY SPACE SMARTWATCH[ACTIVE BLACK]",
                 "balance": 2
                },
                {
                 "name": "DELTIN TR FRAME",
                 "balance": 5
                },
                {
                 "name": "DELTON GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "DELTON GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "DENY BROWN TR FRAME",
                 "balance": 4
                },
                {
                 "name": "DHIHAN IND TR FRAME",
                 "balance": 4
                },
                {
                 "name": "DIGITAL SPORTS WATCH",
                 "balance": 83
                },
                {
                 "name": "DIKALO TR FRAME",
                 "balance": 7
                },
                {
                 "name": "DIMANNI TR FRAME",
                 "balance": 3
                },
                {
                 "name": "DINIHO GENTS BLACK METAL WATCH",
                 "balance": 1
                },
                {
                 "name": "DIOR METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "DIOR SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "DIRECT TR FRAME",
                 "balance": 2
                },
                {
                 "name": "DISCOVERY NOW TR FRAME",
                 "balance": 5
                },
                {
                 "name": "DIXON TR FRAME",
                 "balance": 1
                },
                {
                 "name": "DIYUNANJUE FIBRE FRAME",
                 "balance": 1
                },
                {
                 "name": "DK GENTS DATE WATCH",
                 "balance": 10
                },
                {
                 "name": "DK GENTS STEEL WATCH",
                 "balance": 8
                },
                {
                 "name": "DK GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "DK LADIES STEEL WATCH",
                 "balance": 6
                },
                {
                 "name": "DK LADIES WATCH",
                 "balance": 4
                },
                {
                 "name": "DNEIOCN TR FRAME",
                 "balance": 7
                },
                {
                 "name": "DOLKAR METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "DOLKAR SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "DOMINICA TR FRAME",
                 "balance": 2
                },
                {
                 "name": "DOOR TR FRAME",
                 "balance": 2
                },
                {
                 "name": "DREAM SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "DW BOYS WATCH",
                 "balance": 3
                },
                {
                 "name": "DW COUPLE WATCH",
                 "balance": 3
                },
                {
                 "name": "DW GENTS MAGNET WATCH",
                 "balance": 7
                },
                {
                 "name": "DYNAMIC ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "DZ09 SMART WATCH",
                 "balance": 2
                },
                {
                 "name": "E&A COUPLE WATCH",
                 "balance": 3
                },
                {
                 "name": "E&A GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "E&A SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "E&A TR FRAME",
                 "balance": 6
                },
                {
                 "name": "EAGLE TIME GENTS STEEL WATCH",
                 "balance": 16
                },
                {
                 "name": "EAGLE TIME GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "EB TR FRAME",
                 "balance": 1
                },
                {
                 "name": "EBARTEX TR FRAME",
                 "balance": 2
                },
                {
                 "name": "ECZ TR FRAME",
                 "balance": 1
                },
                {
                 "name": "EDWIN CLARK GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "ELFIN GENTS STEEL WATCH",
                 "balance": 6
                },
                {
                 "name": "ELFIN GENTS WATCH",
                 "balance": 16
                },
                {
                 "name": "ELLENS SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "ELSAER TR",
                 "balance": 9
                },
                {
                 "name": "EMAGE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ENKSELR TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ENLARGE TR FRAME",
                 "balance": 2
                },
                {
                 "name": "ERMENEGILDO ZEGNA SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "ESKD TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ETHGAVMO SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "EUROMARE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "EVIAN TR FRAME",
                 "balance": 6
                },
                {
                 "name": "EWIN SPORT GENTS WATCH",
                 "balance": 7
                },
                {
                 "name": "EXCLUSIVE IND TR FRAME",
                 "balance": 5
                },
                {
                 "name": "EXOTTIC METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "EYE CANDY ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "EYE PLAYER TR FRAME",
                 "balance": 3
                },
                {
                 "name": "EYE-5 ACETATE FRAME",
                 "balance": 22
                },
                {
                 "name": "EYE-CATEYES FIBRE FFRAME",
                 "balance": 5
                },
                {
                 "name": "EYE-PLAYER TR FRAME",
                 "balance": 1
                },
                {
                 "name": "EYECANDY ACETATE FRAME",
                 "balance": 5
                },
                {
                 "name": "EYECOSTA TR FRAME",
                 "balance": 7
                },
                {
                 "name": "EYEFIL BLUE TR FRAME",
                 "balance": 18
                },
                {
                 "name": "EYEGOLD ACETATE FRAME",
                 "balance": 3
                },
                {
                 "name": "EYELINER TR FRAME",
                 "balance": 4
                },
                {
                 "name": "EYEPLAYER SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "EYEPROTECT TR FRAME",
                 "balance": 1
                },
                {
                 "name": "EYES METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "EYETONIC SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "F&L GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "F&S GENTS LEATHER STRAP WATCH",
                 "balance": 5
                },
                {
                 "name": "F&S GENTS METAL STRAP WATCH",
                 "balance": 8
                },
                {
                 "name": "F&S LADIES METAL STRAP WATCH",
                 "balance": 3
                },
                {
                 "name": "F&S LADIES WATCH",
                 "balance": 3
                },
                {
                 "name": "F&T GENTS WATCH",
                 "balance": 30
                },
                {
                 "name": "F9 GENTS WATCH",
                 "balance": 4
                },
                {
                 "name": "FACTOR GENTS WATCH",
                 "balance": 8
                },
                {
                 "name": "FACTUAL METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "FACTUAL SUPRA FRAME",
                 "balance": 8
                },
                {
                 "name": "FAMOUSRAIN TR FRAME",
                 "balance": 3
                },
                {
                 "name": "FARLEY GENTS WATCH",
                 "balance": 27
                },
                {
                 "name": "FASCINO GENTS WATCH",
                 "balance": 11
                },
                {
                 "name": "FASHION METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTER GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "FASTRACK 1001 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1002 FRAME",
                 "balance": 2
                },
                {
                 "name": "FASTRACK 1006 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1007 FRAME",
                 "balance": 2
                },
                {
                 "name": "FASTRACK 1009 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1012 FRAME",
                 "balance": 2
                },
                {
                 "name": "FASTRACK 1017 FRAME",
                 "balance": 2
                },
                {
                 "name": "FASTRACK 1018 FRAME",
                 "balance": 7
                },
                {
                 "name": "FASTRACK 1026 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1038 FRAME",
                 "balance": 3
                },
                {
                 "name": "FASTRACK 1039 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1050 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1052 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1060 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1068 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1069 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1070 FRAME",
                 "balance": 2
                },
                {
                 "name": "FASTRACK 1076 FRAME",
                 "balance": 2
                },
                {
                 "name": "FASTRACK 1085 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1100 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1123 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1124 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1139 FRAME",
                 "balance": 3
                },
                {
                 "name": "FASTRACK 1144 FRAME",
                 "balance": 2
                },
                {
                 "name": "FASTRACK 1148 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1149 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1150 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1169 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1173 FRAME",
                 "balance": 1
                },
                {
                 "name": "FASTRACK 1205 FRAME",
                 "balance": 6
                },
                {
                 "name": "FASTRACK REFLEX BEAT SMARTBAND",
                 "balance": 1
                },
                {
                 "name": "FASTRACK REFLEX TUNES FB1 WIRELESS NECKBAND",
                 "balance": 3
                },
                {
                 "name": "FASTRON BOYS WATCH",
                 "balance": 14
                },
                {
                 "name": "FASTRON KIDS WATCH",
                 "balance": 6
                },
                {
                 "name": "FASTRON LADIES WATCH",
                 "balance": 7
                },
                {
                 "name": "FELEX BOYS WATCH",
                 "balance": 3
                },
                {
                 "name": "FELIX GENTS STEEL WATCH",
                 "balance": 7
                },
                {
                 "name": "FELIX GENTS WATCH",
                 "balance": 24
                },
                {
                 "name": "FELIX LADIES METAL STRAP WATCH",
                 "balance": 23
                },
                {
                 "name": "FELIX LADIES WATCH",
                 "balance": 65
                },
                {
                 "name": "FENDI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "FENIX GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "FENTEX GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "FENTON GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "FHULUN LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "FICCI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "FICKIES BOYS WATCH",
                 "balance": 24
                },
                {
                 "name": "FICKIES LADIES WATCH",
                 "balance": 58
                },
                {
                 "name": "FIDEROCK GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "FIDRC SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "FILA BOYS WATCH",
                 "balance": 10
                },
                {
                 "name": "FILA LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "FIND SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "FIONEY LADIES STEEL WATCH",
                 "balance": 18
                },
                {
                 "name": "FIONEY LADIES WATCH",
                 "balance": 37
                },
                {
                 "name": "FIREBOLTT TALK SMARTWATCH[TEAL]",
                 "balance": 1
                },
                {
                 "name": "FIRSTRANK LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "FIXEN GENTS WATCH",
                 "balance": 10
                },
                {
                 "name": "FIZIX GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "FLAGS BI-METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "FLAUNT ACETATE FRAME",
                 "balance": 6
                },
                {
                 "name": "FLICKER METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "FLOURISH SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "FLUID TR FRAME",
                 "balance": 4
                },
                {
                 "name": "FLYHORSE GENTS WATCH",
                 "balance": 6
                },
                {
                 "name": "FMTRF SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "FOCUS LADIES WATCH",
                 "balance": 3
                },
                {
                 "name": "FONEX GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "FORCE SUNGLASSES",
                 "balance": 55
                },
                {
                 "name": "FOREST GENTS MAGNET BELT WATCH",
                 "balance": 6
                },
                {
                 "name": "FOREST GENTS ROSEGOLD WATCH",
                 "balance": 1
                },
                {
                 "name": "FOREST GENTS STEEL WATCH",
                 "balance": 63
                },
                {
                 "name": "FOREST GENTS WATCH",
                 "balance": 52
                },
                {
                 "name": "FOREST LADIES BRACELET WATCH",
                 "balance": 43
                },
                {
                 "name": "FOREST LADIES METAL STRAP WATCH",
                 "balance": 53
                },
                {
                 "name": "FOREST LADIES WATCH",
                 "balance": 82
                },
                {
                 "name": "FOREX IND TR FRAME",
                 "balance": 1
                },
                {
                 "name": "FOREX INDIAN TR FRAME",
                 "balance": 1
                },
                {
                 "name": "FOSS GENTS WATCH",
                 "balance": 6
                },
                {
                 "name": "FRANK GENTS STEEL WATCH",
                 "balance": 5
                },
                {
                 "name": "FRANK GENTS WATCH",
                 "balance": 4
                },
                {
                 "name": "FRANK LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "FREE FRESH TR FRAME",
                 "balance": 2
                },
                {
                 "name": "FREELY ACETATE FRAME",
                 "balance": 3
                },
                {
                 "name": "FRENDSYZ SUPRA FRAME",
                 "balance": 7
                },
                {
                 "name": "FRENKLM TR FRAME",
                 "balance": 3
                },
                {
                 "name": "FST LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "FST TR FRAME",
                 "balance": 16
                },
                {
                 "name": "FULL SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "FUSION ACETATE FRAME",
                 "balance": 8
                },
                {
                 "name": "FUSION IND TR FRAME",
                 "balance": 2
                },
                {
                 "name": "G&C COUPLE WATCH",
                 "balance": 1
                },
                {
                 "name": "G&C GENTS METAL STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "G&C GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "G&C LADIES METAL STRAP WATCH",
                 "balance": 2
                },
                {
                 "name": "G&C LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "G&C METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "G&C SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "G&C TR FRAME",
                 "balance": 20
                },
                {
                 "name": "G&S LADIES STEEL WATCH",
                 "balance": 5
                },
                {
                 "name": "G-STAR FIBRE FRAME",
                 "balance": 1
                },
                {
                 "name": "GALAXY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "GANGNAM STYLE TR FRAME",
                 "balance": 25
                },
                {
                 "name": "GANGOU TR FRAME",
                 "balance": 2
                },
                {
                 "name": "GEGE SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "GENEVA LADIES BRACELET",
                 "balance": 1
                },
                {
                 "name": "GENEVA LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "GENEVA LADIES WATCH",
                 "balance": 7
                },
                {
                 "name": "GENOXS METAL FRAME",
                 "balance": 4
                },
                {
                 "name": "GENOXS SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "GENTLE BOSS SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "GENTS ROUND WATCH",
                 "balance": 22
                },
                {
                 "name": "GENTS SQUARE WATCH",
                 "balance": 34
                },
                {
                 "name": "GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "GENUINE METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "GENX LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "GENX LADIES WATCH",
                 "balance": 13
                },
                {
                 "name": "GEO BABY TR FRAME",
                 "balance": 1
                },
                {
                 "name": "GF METAL FULL FRAME",
                 "balance": 3
                },
                {
                 "name": "GF SUPRA FRAME",
                 "balance": 6
                },
                {
                 "name": "GHANDHI METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "GIONEE EBT1W WIRELESS NECKBAND",
                 "balance": 3
                },
                {
                 "name": "GIONEE EBT2W WIRELESS NECKBAND",
                 "balance": 4
                },
                {
                 "name": "GIONEE SENORITA SMARTWATCH[SILVER]",
                 "balance": 1
                },
                {
                 "name": "GIORGLO ARMANI METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "GLAMOUR VISION TR FRAME",
                 "balance": 3
                },
                {
                 "name": "GLORIOUS TR FRAME",
                 "balance": 4
                },
                {
                 "name": "GODUN SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "GOLD SILK METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "GOLF CLUB SUPRA FRAME",
                 "balance": 5
                },
                {
                 "name": "GOLFSERIES TR FRAME",
                 "balance": 5
                },
                {
                 "name": "GRACE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "GREENCITY TR FRAME",
                 "balance": 1
                },
                {
                 "name": "GREYJACK ATTACHMENT FRAME",
                 "balance": 3
                },
                {
                 "name": "GRLKEW SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "GUEDO LADIES STEEL WATCH",
                 "balance": 7
                },
                {
                 "name": "GUN METAL FRAME",
                 "balance": 18
                },
                {
                 "name": "GUOYU GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "GVNECHY GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "H20 ACETATE FRAME",
                 "balance": 7
                },
                {
                 "name": "HALF METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "HAN-SHA TR FRAME",
                 "balance": 4
                },
                {
                 "name": "HANIBOTE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "HAPPY METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "HAPPYTIME BOYS WATCH",
                 "balance": 10
                },
                {
                 "name": "HARBOUR TR FRAME",
                 "balance": 3
                },
                {
                 "name": "HARLEY BOYS WATCH",
                 "balance": 5
                },
                {
                 "name": "HARLEY GENTS WATCH",
                 "balance": 12
                },
                {
                 "name": "HASHAN LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "HAYAT TR FRAME",
                 "balance": 4
                },
                {
                 "name": "HDLY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "HELEN KELLER METAL FRAME",
                 "balance": 10
                },
                {
                 "name": "HELEN KELLER TR FRAME",
                 "balance": 1
                },
                {
                 "name": "HELIX GUSTO BAND TW0HXB201T",
                 "balance": 1
                },
                {
                 "name": "HELPFUL METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "HENG JUN GENTS STEEL WATCH",
                 "balance": 8
                },
                {
                 "name": "HENNA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "HIFI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "HILTER GENTS METAL STRAP WATCH",
                 "balance": 4
                },
                {
                 "name": "HILTER GENTS WATCH",
                 "balance": 26
                },
                {
                 "name": "HILTER LADIES METAL STRAP WATCH",
                 "balance": 20
                },
                {
                 "name": "HILTER LADIES WATCH",
                 "balance": 9
                },
                {
                 "name": "HITAIER TR FRAME",
                 "balance": 2
                },
                {
                 "name": "HNUKE TR FRAME",
                 "balance": 2
                },
                {
                 "name": "HORIEN METAL FRAME",
                 "balance": 4
                },
                {
                 "name": "HOSTIALE TR FRAME",
                 "balance": 8
                },
                {
                 "name": "HRMOUR BOYS WATCH",
                 "balance": 1
                },
                {
                 "name": "HUANJING SUPRA FRAME",
                 "balance": 7
                },
                {
                 "name": "HUMPTY DUMPTY KIDS FRAME",
                 "balance": 5
                },
                {
                 "name": "HUNEY LADIES STEEL WATCH",
                 "balance": 8
                },
                {
                 "name": "HW12 WATCH",
                 "balance": 4
                },
                {
                 "name": "I&D ACETATE FRAME",
                 "balance": 5
                },
                {
                 "name": "I-STYLE TR FRAME",
                 "balance": 8
                },
                {
                 "name": "ICEHOCKEY IND TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ICEKON TR",
                 "balance": 1
                },
                {
                 "name": "IDEA IND TR FRAME",
                 "balance": 13
                },
                {
                 "name": "IDEE 1317 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1317 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1347 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1364 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1549 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1597 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1613 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1640 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1646 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1648 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1648 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1652 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1664 C7 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1665 C7 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1669 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1688 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1690 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1695 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1705 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1706 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1706 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1707 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1721 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1727 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1743 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1744 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1750 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1758 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1758 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1759 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1760 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1763 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1766 C7 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1767 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1770 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1770 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1772 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1773 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1782 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1826 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1833 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1857 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1858 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1867 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1877 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1877 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1878 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1879 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1880 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1880 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1881 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1882 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1892 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1894 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1894 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1897 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1900 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1902 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1908 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1909 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 1909 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IDEE 2000 C4 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2565 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2607 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2607 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2686 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2686 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2701 C5 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2748 C4 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2749 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2749 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2750 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2751 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2751 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2753 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2754 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2759 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2759 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2760 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2765 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2770 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2771 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2778 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2781 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2781 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2790 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2792 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2795 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2795 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2795 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2796 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2798 C6 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2801 C1 SUNGLASSES",
                 "balance": 2
                },
                {
                 "name": "IDEE 2803 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2823 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE 2825 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S1899 C4 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2306 C1P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2354 C5P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2409 C3P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2409 C5P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2415 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2423 C9P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2466 C2P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2471 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2484 C5 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2485 C6 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2500 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2500 C4 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2500 C40 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2500 C43 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2514 C4 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2526 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2527 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2529 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2531 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2538 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2540 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2565 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2577 C3P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2584 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2584 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2611 C4 SUNGLASSES",
                 "balance": 2
                },
                {
                 "name": "IDEE S2611 C7P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2626 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2636 C3P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2645 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2668 C4P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2690 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2748 C4P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2751 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2754 C2P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2762 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2766 C2 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2781 C1P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IDEE S2782 C4P SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IF GENTS WATCH",
                 "balance": 6
                },
                {
                 "name": "IGNITION SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "IIK LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "IKON FIBRE FRAME",
                 "balance": 6
                },
                {
                 "name": "IMAGE METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "IMAGE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "IMISTAR TR FRAME",
                 "balance": 1
                },
                {
                 "name": "IMP FRAME",
                 "balance": 176
                },
                {
                 "name": "IMP SUNGLASSES",
                 "balance": 499
                },
                {
                 "name": "IMPRESSION SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "INDIAN METAL FRAME",
                 "balance": 229
                },
                {
                 "name": "INFACE FRAME",
                 "balance": 4
                },
                {
                 "name": "INFACE REGULAR METAL",
                 "balance": 2
                },
                {
                 "name": "INTELLIGENCE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "INTIME METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "INTIME SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "INTIMEL SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "IQ ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "IRUS 1124 C4 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IRUS 1126 C4 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IRUS 1127 C1 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IRUS 1127 C5 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IRUS 1130 C8 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IRUS 1131 C8 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IRUS 1150 C3 SUNGLASSES",
                 "balance": 1
                },
                {
                 "name": "IRUS 2009 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2032 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2034 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2034 C8 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2040 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2176 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2177 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2181 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2181 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2184 C2 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2184 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2185 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2190 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2192 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2194 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2194 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2195 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2195 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2196 C4 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2196 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2199 C3 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2203 C5 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2203 C6 FRAME",
                 "balance": 1
                },
                {
                 "name": "IRUS 2204 C1 FRAME",
                 "balance": 1
                },
                {
                 "name": "ISTYLE TR FRAME",
                 "balance": 6
                },
                {
                 "name": "ITALAIAS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "JACK JOIVES TR FRAME",
                 "balance": 1
                },
                {
                 "name": "JACK&JILL TR FRAME",
                 "balance": 1
                },
                {
                 "name": "JACUZZI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "JAEGER LE COULTRE GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "JAGVAR BOYS WATCH",
                 "balance": 38
                },
                {
                 "name": "JAPIE  METAL FRAME",
                 "balance": 4
                },
                {
                 "name": "JBL C150SI IN EAR HEADPHONES",
                 "balance": 1
                },
                {
                 "name": "JBL T160 IN EAR HEADPHONES",
                 "balance": 3
                },
                {
                 "name": "JEALN GENTS STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "JEALN GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "JEANS CLUB ACETATE FRAME",
                 "balance": 3
                },
                {
                 "name": "JEAVONI METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "JIASHILL TR FRAME",
                 "balance": 1
                },
                {
                 "name": "JINGO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "JINLI LADIES WATCH",
                 "balance": 3
                },
                {
                 "name": "JIUJING TR FRAME",
                 "balance": 5
                },
                {
                 "name": "JL LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "JOHY-SMITH TR FRAME",
                 "balance": 1
                },
                {
                 "name": "JONA METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "JORDAN GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "JOU METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "JOURNALIST TR FRAME",
                 "balance": 2
                },
                {
                 "name": "JOY & LIFE TR FRAME",
                 "balance": 6
                },
                {
                 "name": "JOY KIDS FRAME",
                 "balance": 7
                },
                {
                 "name": "JUDE LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "JUMBO GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "JUNGLE BOOK ACETATE FRAME",
                 "balance": 55
                },
                {
                 "name": "KAISER SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "KALUDZHIXING TR",
                 "balance": 3
                },
                {
                 "name": "KANGAROO METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "KANGAROO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "KDESIGN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "KEBINO GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "KEEN SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "KENZO IND TR FRAME",
                 "balance": 10
                },
                {
                 "name": "KEVIN GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "KH SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "KICRELI METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "KIDS PARK TR FRAME",
                 "balance": 1
                },
                {
                 "name": "KIDS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "KILLER GENTS ROUND DIAL LEATHER STRAP WATCH",
                 "balance": 19
                },
                {
                 "name": "KILLER GENTS ROUND DIAL METAL STRAP WATCH",
                 "balance": 7
                },
                {
                 "name": "KILLER GENTS SQUARE DIAL LEATHER STRAP WATCH",
                 "balance": 10
                },
                {
                 "name": "KILLER LADIES LEATHER STRAP WATCH",
                 "balance": 18
                },
                {
                 "name": "KILLER LADIES METAL STRAP WATCH",
                 "balance": 14
                },
                {
                 "name": "KMS LADIES WATCH",
                 "balance": 3
                },
                {
                 "name": "KNIGHT HORSE METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "L&C GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "L&C TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LADIES BRACELET",
                 "balance": 45
                },
                {
                 "name": "LADIES STEEL WATCH",
                 "balance": 4
                },
                {
                 "name": "LADIES WATCH",
                 "balance": 7
                },
                {
                 "name": "LADIES WEDDING WATCH",
                 "balance": 6
                },
                {
                 "name": "LAKNUM TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LANEIGE METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "LD TR FRAME",
                 "balance": 13
                },
                {
                 "name": "LEARNED TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LED SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "LEMON ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "LENS.",
                 "balance": 861
                },
                {
                 "name": "LENSES",
                 "balance": 914
                },
                {
                 "name": "LEO BABY FIBRE FRAME",
                 "balance": 9
                },
                {
                 "name": "LEO TR FRAME",
                 "balance": 11
                },
                {
                 "name": "LETS GO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LEVIS ACETATE FRAME",
                 "balance": 3
                },
                {
                 "name": "LEVOLU METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "LEVOLU SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "LEWIS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LEXUS TR FRAME",
                 "balance": 3
                },
                {
                 "name": "LG GENTS FIBRE STRAP WATCH",
                 "balance": 5
                },
                {
                 "name": "LG GENTS IGP FANCY WATCH",
                 "balance": 1
                },
                {
                 "name": "LG GENTS ROUND DIAL LEATHER STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "LG GENTS SQUARE DIAL LEATHER STRAP WATCH",
                 "balance": 6
                },
                {
                 "name": "LG GENTS SQUARE DIAL METAL STRAP WATCH",
                 "balance": 3
                },
                {
                 "name": "LG LADIES LEATHER STRAP WATCH",
                 "balance": 11
                },
                {
                 "name": "LIGHT TITANIUM FRAME",
                 "balance": 9
                },
                {
                 "name": "LIHGTER SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "LIMIHO LADIES STEEL WATCH",
                 "balance": 4
                },
                {
                 "name": "LINEART TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LIOPIONT TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LITLLE CHAMPS IND TR FRAME",
                 "balance": 13
                },
                {
                 "name": "LITTLE ANGEL ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "LITTLE CHAMP TR FRAME",
                 "balance": 10
                },
                {
                 "name": "LIVEL HYBRID FRAME",
                 "balance": 2
                },
                {
                 "name": "LOMBARD SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "LONDON BRIDGE TR",
                 "balance": 4
                },
                {
                 "name": "LONGBEST SUPRA FRAME",
                 "balance": 7
                },
                {
                 "name": "LONGINES GENTS WATCH",
                 "balance": 8
                },
                {
                 "name": "LOOK FACE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "LOOK SUPRA FRAME",
                 "balance": 6
                },
                {
                 "name": "LOTUS SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "LOUIS RENEE LADIES STEEL WATCH",
                 "balance": 52
                },
                {
                 "name": "LOUN SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "LOYALTY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "LULLABY SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "LUOBIN GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "M&B FIBRE FRAME",
                 "balance": 3
                },
                {
                 "name": "M&B GENTS METAL WATCH",
                 "balance": 1
                },
                {
                 "name": "M&B METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "M&B TR FRAME",
                 "balance": 8
                },
                {
                 "name": "M&K LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "MAC TR FRAME",
                 "balance": 5
                },
                {
                 "name": "MACHA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "MAGIC PLUS TR FRAME",
                 "balance": 3
                },
                {
                 "name": "MAGNETIC SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "MAIBA LUO TR FRAME",
                 "balance": 12
                },
                {
                 "name": "MANSPOL SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "MANSTAR METAL FRAME",
                 "balance": 20
                },
                {
                 "name": "MARA-BOSS TR FRAME",
                 "balance": 6
                },
                {
                 "name": "MARABOUS SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "MARABOUS TR FRAME",
                 "balance": 2
                },
                {
                 "name": "MARCO METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "MARK METAL FRAME",
                 "balance": 25
                },
                {
                 "name": "MARKELRICH SUPRA FRAME",
                 "balance": 4
                },
                {
                 "name": "MARKENI METAL FRAME",
                 "balance": 7
                },
                {
                 "name": "MARS METAL FULL FRAME",
                 "balance": 2
                },
                {
                 "name": "MARSHAL GENTS IGP WATCH",
                 "balance": 1
                },
                {
                 "name": "MARSHAL GENTS ROUND DIAL LEATHER STRAP WATCH",
                 "balance": 13
                },
                {
                 "name": "MARSHAL GENTS ROUND DIAL METAL STRAP WATCH",
                 "balance": 2
                },
                {
                 "name": "MARSHAL GENTS SQUARE DIAL LEATHER STRAP WATCH",
                 "balance": 11
                },
                {
                 "name": "MARSHAL LADIES LEATHER STRAP WATCH",
                 "balance": 10
                },
                {
                 "name": "MARSHAL LADIES METAL STRAP WATCH",
                 "balance": 15
                },
                {
                 "name": "MASSIF TR FRAME",
                 "balance": 1
                },
                {
                 "name": "MATRUSSX POLARISED SUNGLASSES",
                 "balance": 59
                },
                {
                 "name": "MAY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "MCCANN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "MECHANICAL CLOCK",
                 "balance": 10
                },
                {
                 "name": "MEIZU METAL FULL FRAME",
                 "balance": 2
                },
                {
                 "name": "MENTBAL METAL FULL FRAME",
                 "balance": 5
                },
                {
                 "name": "MERCEDES BENZ METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "MERCIFUL SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "METAL ATTACHMENT FRAME",
                 "balance": 18
                },
                {
                 "name": "METAL FRAME",
                 "balance": 143
                },
                {
                 "name": "METAL HYBRID FRAME",
                 "balance": 11
                },
                {
                 "name": "MG17 SMARTWATCH",
                 "balance": 2
                },
                {
                 "name": "MI EARPHONES BASIC",
                 "balance": 6
                },
                {
                 "name": "MI SMART BAND 2",
                 "balance": 1
                },
                {
                 "name": "MICROWEAR W17 SMARTWATCH",
                 "balance": 2
                },
                {
                 "name": "MIDO GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "MIGAOMEI TR FRAME",
                 "balance": 2
                },
                {
                 "name": "MILD TR FRAME",
                 "balance": 1
                },
                {
                 "name": "MINIATURE METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "MINO SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "MIRROR IND TR FRAME",
                 "balance": 8
                },
                {
                 "name": "MISOLT GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "MISS & CHIEF KIDS WATCH",
                 "balance": 1
                },
                {
                 "name": "MISS TIME TR FRAME",
                 "balance": 5
                },
                {
                 "name": "MISS TR FRAME",
                 "balance": 2
                },
                {
                 "name": "MISSING TR FRAME",
                 "balance": 1
                },
                {
                 "name": "MIUMIU TR FRAME",
                 "balance": 1
                },
                {
                 "name": "MJ ATTACHMENT",
                 "balance": 2
                },
                {
                 "name": "MJ FIBRE FRAME",
                 "balance": 6
                },
                {
                 "name": "MOCKB TR FRAME",
                 "balance": 1
                },
                {
                 "name": "MOMENTUM TR FRAME",
                 "balance": 25
                },
                {
                 "name": "MONY BLOCK GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "MOTIVATE METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "MOTIVATE METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "MOUNTAIN DROP TR FRAME",
                 "balance": 2
                },
                {
                 "name": "MOVADO GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "MOVADO LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "MUKTI IND TR FRAME",
                 "balance": 6
                },
                {
                 "name": "MUSIC SPORTMAN TR FRAME",
                 "balance": 3
                },
                {
                 "name": "N&K GENTS WATCH",
                 "balance": 12
                },
                {
                 "name": "N&K TR FRAME",
                 "balance": 6
                },
                {
                 "name": "N6009 GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "NAIJIEJ SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "NAINZ SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "NANSHA TR FRAME",
                 "balance": 5
                },
                {
                 "name": "NAPSTER SUPRA FRAME",
                 "balance": 4
                },
                {
                 "name": "NATIONAL MDF CLOCK",
                 "balance": 22
                },
                {
                 "name": "NAVICFORCE GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "NAVY FORCE GENTS METAL STRAP WATCH",
                 "balance": 3
                },
                {
                 "name": "NEARBODY TR FRAME",
                 "balance": 1
                },
                {
                 "name": "NECORE METAL FRAME",
                 "balance": 6
                },
                {
                 "name": "NESS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "NEW WEAR SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "NEXTDAY TR FRAME",
                 "balance": 3
                },
                {
                 "name": "NI LADIES STEEL WATCH",
                 "balance": 2
                },
                {
                 "name": "NICO GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "NICONMI TR FRAME",
                 "balance": 23
                },
                {
                 "name": "NIKADO LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "NIKADO LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "NIKITA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "NO-1 TR FRAME",
                 "balance": 20
                },
                {
                 "name": "NO.1 TR FRAME",
                 "balance": 3
                },
                {
                 "name": "NOISE COLORFIT CALIBER[METALBLACK]",
                 "balance": 1
                },
                {
                 "name": "NOISE COLORFIT PULSE SMARTWATCH[JETBLACK]",
                 "balance": 1
                },
                {
                 "name": "NOISE COLORFIT QUBE SMARTWATCH[ROSEGOLDWINE]",
                 "balance": 1
                },
                {
                 "name": "NOISE COLORFIT QUBE SMARTWATCH[SILVERBLUE]",
                 "balance": 1
                },
                {
                 "name": "NOISE EXCEL SMARTWATCH[CHARCOALBLACK]",
                 "balance": 2
                },
                {
                 "name": "NOISE FLAIR BLUETOOTH NECKBAND[CARBON BLACK]",
                 "balance": 2
                },
                {
                 "name": "NOISE FLAIR BLUETOOTH NECKBAND[MIST GREY]",
                 "balance": 1
                },
                {
                 "name": "NOISE SENSE BLUETOOTH NECKBAND[COBALT BLUE]",
                 "balance": 2
                },
                {
                 "name": "NOISE SENSE BLUETOOTH NECKBAND[JET BLACK]",
                 "balance": 2
                },
                {
                 "name": "NOISE TUNE ACTIVE BLUETOOTH NECKBAND[HOT RED]",
                 "balance": 1
                },
                {
                 "name": "NOISE TUNE ACTIVE BLUETOOTH NECKBAND[POP YELLOW]",
                 "balance": 2
                },
                {
                 "name": "NOISE TUNE ACTIVE PLUS[SAPPHIRE BLUE]",
                 "balance": 1
                },
                {
                 "name": "NOISE TUNE CHARGE BLUETOOTH NECKBAND",
                 "balance": 3
                },
                {
                 "name": "NOISE TUNE ELITE SPORT[LIVELY BLACK]",
                 "balance": 2
                },
                {
                 "name": "NOISEFIT ENDURE SMARTWATCH[CHERRY RED]",
                 "balance": 1
                },
                {
                 "name": "NOLILON GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "NOVA TR FRAME",
                 "balance": 5
                },
                {
                 "name": "NUMBERONE METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "O&G GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "O&K TR FRAME",
                 "balance": 3
                },
                {
                 "name": "O-MATTER TR FRAME",
                 "balance": 11
                },
                {
                 "name": "OFF-ON TR FRAME",
                 "balance": 5
                },
                {
                 "name": "OKLAY POL",
                 "balance": 77
                },
                {
                 "name": "OKLY SPORT ATTACHMENT",
                 "balance": 1
                },
                {
                 "name": "OKYCOEKY METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "OLEVA-BUTON LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "OMAKI LADIES METAL STRAP WATCH",
                 "balance": 5
                },
                {
                 "name": "ONE OF KIND LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "ONEPLUS BULLETS WIRELESS Z2[ACOUSTIC RED]",
                 "balance": 2
                },
                {
                 "name": "ONEPLUS BULLETS WIRELESS Z2[MAGICO BLACK]",
                 "balance": 2
                },
                {
                 "name": "ONEPLUS NORD BUDS [WHITE MARBLE]",
                 "balance": 1
                },
                {
                 "name": "ONEPLUS NORD BUDS[BLACK SLATE]",
                 "balance": 2
                },
                {
                 "name": "ONLY GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "ONLY TR-90 FRAME",
                 "balance": 39
                },
                {
                 "name": "ONTRUN TR FRAME",
                 "balance": 1
                },
                {
                 "name": "OPASLLI TR FRAME",
                 "balance": 4
                },
                {
                 "name": "OPPO BAND STYLE",
                 "balance": 1
                },
                {
                 "name": "OPTICLUB TR FRAME",
                 "balance": 1
                },
                {
                 "name": "OPTICON SUPRA FRAME",
                 "balance": 4
                },
                {
                 "name": "OPTIFOCAL METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "OREVA AA3177 TIMEPIECE",
                 "balance": 2
                },
                {
                 "name": "OREVA AA3307 TIMEPIECE",
                 "balance": 1
                },
                {
                 "name": "OREVA AA3447 TIMEPIECE",
                 "balance": 2
                },
                {
                 "name": "OREVA AQ 5847 SS WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ 7707B WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "OREVA AQ1497 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ1847 WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "OREVA AQ3487 SS-DX WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ4237-SS WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ5137 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ5227 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ5347-SS WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ5457 SS WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ5627 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ5647 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6207 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6227-SS-DSR WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "OREVA AQ6307 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6437 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6457 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6517 WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "OREVA AQ6587 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6797 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6907-SS WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ6927 WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "OREVA AQ6947-SS WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "OREVA AQ7117-SS WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ7217 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ7647 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ7707 WALLCLOCK",
                 "balance": 4
                },
                {
                 "name": "OREVA AQ7747 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA AQ7827 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "OREVA ODC130 DIGITAL WALLCLOCK",
                 "balance": 2
                },
                {
                 "name": "OREVA TIMEPIECE AA3307",
                 "balance": 1
                },
                {
                 "name": "ORIGIN RENEE LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "OUFENG METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "OULYSHA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "OXY SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "P&C GENTS METAL WATCH",
                 "balance": 6
                },
                {
                 "name": "P&C GENTS WATCH",
                 "balance": 25
                },
                {
                 "name": "P&C SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "P&C TR FRAME",
                 "balance": 2
                },
                {
                 "name": "P&D METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "P&D SUPRA FRAME",
                 "balance": 8
                },
                {
                 "name": "P&D TR FRAME",
                 "balance": 14
                },
                {
                 "name": "P&U SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "P&U TR FRAME",
                 "balance": 2
                },
                {
                 "name": "P9 OVERHEAD HEADPHONES",
                 "balance": 1
                },
                {
                 "name": "PAIDU COUPLE WATCH",
                 "balance": 1
                },
                {
                 "name": "PANNKH SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "PAOUAL TR FRAME",
                 "balance": 6
                },
                {
                 "name": "PARA ATTACHMENT FRAME",
                 "balance": 7
                },
                {
                 "name": "PARA TR-90 FRAME",
                 "balance": 14
                },
                {
                 "name": "PARADE FASHION METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "PARIS TR FRAME",
                 "balance": 46
                },
                {
                 "name": "PARIS-IMPERATORIAL SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "PARPOR LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "PATINUM LADIES STEEL WATCH",
                 "balance": 3
                },
                {
                 "name": "PATINUM LADIES WATCH",
                 "balance": 4
                },
                {
                 "name": "PAUL FRANK METAL FRAME",
                 "balance": 5
                },
                {
                 "name": "PAULFRANK TR FRAME",
                 "balance": 1
                },
                {
                 "name": "PAW PATROL BY VELOCITY KIDS FRAME",
                 "balance": 4
                },
                {
                 "name": "PEACE GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "PERFECT CRYSTAL TR FRAME",
                 "balance": 2
                },
                {
                 "name": "PERTERPAN METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "PERTERPAN SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "PERUCCI GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "PHILIPMORGAN METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "PHOENIX HYBRID FRAME",
                 "balance": 2
                },
                {
                 "name": "PIEWORKS METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "PINE WOOD WALLCLOCK",
                 "balance": 9
                },
                {
                 "name": "PINIRA METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "PLATINUM METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "PLATINUM TR FRAME",
                 "balance": 1
                },
                {
                 "name": "PLAY SUPRA FRAME",
                 "balance": 4
                },
                {
                 "name": "PLAYARTE SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "PLAYBOY TR FRAME",
                 "balance": 3
                },
                {
                 "name": "PLUS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "PLYZEN ACETATE FRAME",
                 "balance": 8
                },
                {
                 "name": "POCO IND TR FRAME",
                 "balance": 1
                },
                {
                 "name": "POCO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "POINT SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "POKEMON ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "POLAND METAL FRAME",
                 "balance": 14
                },
                {
                 "name": "POLAROID METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "POLISH GENTS STEEL WATCH",
                 "balance": 4
                },
                {
                 "name": "POLISH GENTS WATCH",
                 "balance": 7
                },
                {
                 "name": "POLO GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "POLYMADE FRAME",
                 "balance": 101
                },
                {
                 "name": "POMO BOYS WATCH",
                 "balance": 1
                },
                {
                 "name": "POMO GENTS WATCH",
                 "balance": 49
                },
                {
                 "name": "PONY RIDER TR FRAME",
                 "balance": 1
                },
                {
                 "name": "PORSCHE DESIGN TR FRAME",
                 "balance": 1
                },
                {
                 "name": "PORSH TR FRAME",
                 "balance": 8
                },
                {
                 "name": "PORTIVE GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "PORTRONICS CONCH BETA WIRED EARPHONES",
                 "balance": 1
                },
                {
                 "name": "POSSESS METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "PR ACETATE FRAME",
                 "balance": 3
                },
                {
                 "name": "PRAMIDE GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "PRECISE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "PRODESIGN-DENMARK FRAME",
                 "balance": 7
                },
                {
                 "name": "PRODUCE METAL FRAME",
                 "balance": 5
                },
                {
                 "name": "PRODUCE METAL FULL FRAME",
                 "balance": 3
                },
                {
                 "name": "PROULART SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "PROVIN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "PROVO TR FRAME",
                 "balance": 7
                },
                {
                 "name": "PRSR TR FRAME",
                 "balance": 10
                },
                {
                 "name": "PTRON INTUNES LITE WIRELESS NECKBAND",
                 "balance": 1
                },
                {
                 "name": "PUB G WATCH",
                 "balance": 15
                },
                {
                 "name": "PURE ACETATE FRAME",
                 "balance": 6
                },
                {
                 "name": "PUSHPA FRAME",
                 "balance": 8
                },
                {
                 "name": "QUARTERLY METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "QUEEN BABY TR FRAME",
                 "balance": 19
                },
                {
                 "name": "QUEEN DREAM METAL FRAME",
                 "balance": 5
                },
                {
                 "name": "QUEENS TR FRAME",
                 "balance": 2
                },
                {
                 "name": "QUENTIN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "QUKELEI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "R&B METAL FRAME",
                 "balance": 23
                },
                {
                 "name": "R&B SUPRA FRAME",
                 "balance": 21
                },
                {
                 "name": "R&B TR FRAME",
                 "balance": 75
                },
                {
                 "name": "R&D COUPLE WATCH",
                 "balance": 4
                },
                {
                 "name": "R&D GENTS METAL WATCH",
                 "balance": 7
                },
                {
                 "name": "R&D GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "R&D LADIES METAL STRAP WATCH",
                 "balance": 5
                },
                {
                 "name": "R&X COUPLE WATCH",
                 "balance": 3
                },
                {
                 "name": "R&X GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "RADD BLACK METAL GENTS WATCH",
                 "balance": 4
                },
                {
                 "name": "RADD GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "RADIATE ACETATE FRAME",
                 "balance": 6
                },
                {
                 "name": "RAFA TR FRAME",
                 "balance": 22
                },
                {
                 "name": "RALPH LAUREN TR FRAME",
                 "balance": 1
                },
                {
                 "name": "RAOTER TR FRAME",
                 "balance": 3
                },
                {
                 "name": "RAYMOND ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "RAYWEAR SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "RB BRIDGE",
                 "balance": 10
                },
                {
                 "name": "RB CR+OTHER",
                 "balance": 6
                },
                {
                 "name": "RB GLASS POL",
                 "balance": 3
                },
                {
                 "name": "RB PG AVIATOR",
                 "balance": 7
                },
                {
                 "name": "RB TINT AV",
                 "balance": 2
                },
                {
                 "name": "RBB2 3517 BLACK BLACK",
                 "balance": 3
                },
                {
                 "name": "RBB2 3517 BLACK-BLACK",
                 "balance": 1
                },
                {
                 "name": "RBB2 3517 BLACK-GREEN",
                 "balance": 6
                },
                {
                 "name": "RBB2 3517 BROWN BROWN",
                 "balance": 5
                },
                {
                 "name": "RBB2 3517 BROWN-BROWN",
                 "balance": 4
                },
                {
                 "name": "RBB2 3517 GOLD BLACK",
                 "balance": 3
                },
                {
                 "name": "RBB2 3517 GOLD BROWN",
                 "balance": 3
                },
                {
                 "name": "RBB2 3517 GOLDEN GREEN",
                 "balance": 2
                },
                {
                 "name": "RBB2 BLACK-BLACK",
                 "balance": 12
                },
                {
                 "name": "RBB2 BLACK-BROWN",
                 "balance": 1
                },
                {
                 "name": "RBB2 BLACK-GREEN",
                 "balance": 15
                },
                {
                 "name": "RBB2 BROWN-BROWN",
                 "balance": 23
                },
                {
                 "name": "RBB2 GOLD-GREEN",
                 "balance": 26
                },
                {
                 "name": "RBB2 GOLDEN BLACK",
                 "balance": 56
                },
                {
                 "name": "RBB2 GOLDEN BROWN",
                 "balance": 36
                },
                {
                 "name": "RBB2 GUN-GREEN",
                 "balance": 4
                },
                {
                 "name": "RBB2 RED-BLACK",
                 "balance": 1
                },
                {
                 "name": "RBDC 3517 BLACK BLACK",
                 "balance": 1
                },
                {
                 "name": "RBDC 3517 BLACK BROWN",
                 "balance": 2
                },
                {
                 "name": "RBDC 3517 BLACK-BLUE",
                 "balance": 10
                },
                {
                 "name": "RBDC 3517 GOLD BLUE",
                 "balance": 9
                },
                {
                 "name": "RBDC 3517 GOLD BROWN",
                 "balance": 11
                },
                {
                 "name": "RBDC 3517 GOLD-BLACK",
                 "balance": 1
                },
                {
                 "name": "RBDC BLACK-BLACK",
                 "balance": 32
                },
                {
                 "name": "RBDC BLACK-BLUE",
                 "balance": 24
                },
                {
                 "name": "RBDC BROWN-BROWN",
                 "balance": 41
                },
                {
                 "name": "RBDC GOLD GREEN",
                 "balance": 1
                },
                {
                 "name": "RBDC GOLD-BLUE",
                 "balance": 10
                },
                {
                 "name": "RBDC GOLD-BROWN",
                 "balance": 24
                },
                {
                 "name": "RBDC SILVER BLUE",
                 "balance": 20
                },
                {
                 "name": "RBRV BLACK BLUE",
                 "balance": 3
                },
                {
                 "name": "RBRV BLACK RED",
                 "balance": 1
                },
                {
                 "name": "RBRV BLACK SILVER",
                 "balance": 5
                },
                {
                 "name": "RBRV BLACK-GREEN",
                 "balance": 3
                },
                {
                 "name": "RBRV BROWN-GOLD",
                 "balance": 1
                },
                {
                 "name": "RBRV GOLD BLUE",
                 "balance": 14
                },
                {
                 "name": "RBRV GOLD GOLD",
                 "balance": 13
                },
                {
                 "name": "RBRV GOLD-GREEN",
                 "balance": 9
                },
                {
                 "name": "RBRV GOLD-PINK",
                 "balance": 2
                },
                {
                 "name": "RBRV GOLD-SILVER",
                 "balance": 10
                },
                {
                 "name": "RBRV GUN-SILVER",
                 "balance": 1
                },
                {
                 "name": "RBRV SILVER GREEN",
                 "balance": 2
                },
                {
                 "name": "RBRV SILVER SILVER",
                 "balance": 6
                },
                {
                 "name": "REAL 4167 WALLCLOCK",
                 "balance": 3
                },
                {
                 "name": "REAL 437 WALLCLOCK",
                 "balance": 3
                },
                {
                 "name": "REAL 577 WALLCLOCK",
                 "balance": 3
                },
                {
                 "name": "REALITY HYBRID FRAME",
                 "balance": 3
                },
                {
                 "name": "REALME BUDS 2 WIRED EARPHONES",
                 "balance": 2
                },
                {
                 "name": "REALME BUDS WIRELESS 2",
                 "balance": 1
                },
                {
                 "name": "REALME BUDS WIRELESS 2 NEO[BLACK]",
                 "balance": 4
                },
                {
                 "name": "REALME BUDS WIRELESS NECKBAND[ORANGE]",
                 "balance": 3
                },
                {
                 "name": "REATI METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "REDART ACETATE FRAME",
                 "balance": 4
                },
                {
                 "name": "REDBULL GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "REDMI SONICBASS WIRELESS EARPHONES",
                 "balance": 1
                },
                {
                 "name": "REDWHITE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "REEBOK FIBRE FRAME",
                 "balance": 2
                },
                {
                 "name": "RELATIVE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "REMEMBERME TR FRAME",
                 "balance": 7
                },
                {
                 "name": "RENAN GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "RENOS LADIES STEEL WATCH",
                 "balance": 15
                },
                {
                 "name": "REPORTO ACETATE FRAME",
                 "balance": 7
                },
                {
                 "name": "RESM METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "RESPORT TR FRAME",
                 "balance": 2
                },
                {
                 "name": "REWRITE METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "REX TR FRAME",
                 "balance": 1
                },
                {
                 "name": "RICHEAR TR FRAME",
                 "balance": 1
                },
                {
                 "name": "RICHORA TR FRAME",
                 "balance": 5
                },
                {
                 "name": "RICKSHOW TR FRAME",
                 "balance": 1
                },
                {
                 "name": "RIIISAR TR FRAME",
                 "balance": 1
                },
                {
                 "name": "RIMLESS FRAME",
                 "balance": 165
                },
                {
                 "name": "RINNANDY LADIES WATCH",
                 "balance": 4
                },
                {
                 "name": "RISTA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "RIVOC GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "RIVOC GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "RIVOC LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "RIVOC LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "RIXX TR FRAME",
                 "balance": 2
                },
                {
                 "name": "ROBERTO CAVALLI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ROCFAR BOYS WATCH",
                 "balance": 10
                },
                {
                 "name": "ROCFAR GENTS WATCH",
                 "balance": 4
                },
                {
                 "name": "ROCKY LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "ROCKY TR FRAME",
                 "balance": 6
                },
                {
                 "name": "RODENSTOCK METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "RODENSTOCK TR FRAME",
                 "balance": 2
                },
                {
                 "name": "RODUSK TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ROOBINGS SHEET KIDS FRAME",
                 "balance": 23
                },
                {
                 "name": "ROSEE SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "ROSRA GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "RUNNEY METAL FULL FRAME",
                 "balance": 3
                },
                {
                 "name": "S&F GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "SAFE I ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "SAFE-I ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "SAGE 2161 WOOD WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "SAGE 2535 WOOD WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "SAGE 3005 WOOD PENDULLUM WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "SAGE SG-02 WOOD WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "SAMSUNG GALAXY FIT E",
                 "balance": 1
                },
                {
                 "name": "SANMARINO METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "SANTA ANA TR FRAME",
                 "balance": 1
                },
                {
                 "name": "SANTRO GENTS STEEL WATCH",
                 "balance": 4
                },
                {
                 "name": "SARIES 4 WIRELESS CHARGING WATCH",
                 "balance": 1
                },
                {
                 "name": "SATISFY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SAZM TR FRAME",
                 "balance": 2
                },
                {
                 "name": "SEAGULL METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "SEAL SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SEGOUR GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "SERS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "SET SHINE METAL FRAME",
                 "balance": 10
                },
                {
                 "name": "SEVEN STREET TTN FRAME",
                 "balance": 16
                },
                {
                 "name": "SHARIFF METAL FULL FRAME",
                 "balance": 2
                },
                {
                 "name": "SHARKFIN BOYS WATCH",
                 "balance": 9
                },
                {
                 "name": "SHFRING METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "SHINE TR FRAME",
                 "balance": 3
                },
                {
                 "name": "SHINE WEAR TR FRAME",
                 "balance": 1
                },
                {
                 "name": "SHIQIU TR FRAME",
                 "balance": 2
                },
                {
                 "name": "SHISHANG METAL FULL FRAME",
                 "balance": 2
                },
                {
                 "name": "SHISHANG SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "SHOCK METAL WATCH",
                 "balance": 3
                },
                {
                 "name": "SHOCK SPORTS WATCH",
                 "balance": 49
                },
                {
                 "name": "SHOCK WATCH",
                 "balance": 66
                },
                {
                 "name": "SHWAB SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SIDILIA ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "SIGNATURE GENTS STEEL WATCH",
                 "balance": 4
                },
                {
                 "name": "SIGNATURE GENTS WATCH",
                 "balance": 7
                },
                {
                 "name": "SILHOUETTE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SILHOUETTE TR FRAME",
                 "balance": 4
                },
                {
                 "name": "SILHOUTTE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SINAI METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "SINAI SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SISMATI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "SISTER LADIES WATCH",
                 "balance": 8
                },
                {
                 "name": "SKATE SUPRA FRAME",
                 "balance": 4
                },
                {
                 "name": "SKECHERS ACETATE FRAME",
                 "balance": 3
                },
                {
                 "name": "SKILIVA SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "SKYFALL METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "SLICK TR FRAME",
                 "balance": 23
                },
                {
                 "name": "SLOBODA METAL FRAME",
                 "balance": 14
                },
                {
                 "name": "SLOGGI LADIES WATCH",
                 "balance": 23
                },
                {
                 "name": "SMART ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "SMILE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "SNILLE COUPLE WATCH",
                 "balance": 1
                },
                {
                 "name": "SNILLE GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "SOCIAL ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "SOFTAND TR FRAME",
                 "balance": 7
                },
                {
                 "name": "SOLDER METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "SOLO ACETATE FRAME",
                 "balance": 6
                },
                {
                 "name": "SOLOPASIN SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "SONY WI-C200 WIRELESS STEREO HEADSET",
                 "balance": 1
                },
                {
                 "name": "SOONS LADIES METAL STRAP WATCH",
                 "balance": 38
                },
                {
                 "name": "SOPURE TR FRAME",
                 "balance": 3
                },
                {
                 "name": "SOUL SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "SPACILERTD TR FRAME",
                 "balance": 2
                },
                {
                 "name": "SPARTA SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SPARTEN TR-METAL FRAME",
                 "balance": 14
                },
                {
                 "name": "SPETAC METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "SPETAC SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "SPORT BOYS WATCH",
                 "balance": 1
                },
                {
                 "name": "SPRING METAL FULL FRAME",
                 "balance": 2
                },
                {
                 "name": "SPRING SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SQUARE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "STACY TR FRAME",
                 "balance": 3
                },
                {
                 "name": "STAR GOLF TR FRAME",
                 "balance": 12
                },
                {
                 "name": "STARGOLF METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "STARGOLF SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "STARK METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "STARK SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "STARTIT METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "STONISH SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "STPAL SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "STRATTON TR FRAME",
                 "balance": 1
                },
                {
                 "name": "STRIKING TR FRAME",
                 "balance": 29
                },
                {
                 "name": "STRIKING TR SUPRA",
                 "balance": 13
                },
                {
                 "name": "SUBWAY TR FRAME",
                 "balance": 1
                },
                {
                 "name": "SUCH METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "SUFEIYA TR",
                 "balance": 1
                },
                {
                 "name": "SUKINA LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "SULLIVAN TR FRAME",
                 "balance": 2
                },
                {
                 "name": "SUNCITY METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "SUNCITY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SUNCORE TR FRAME",
                 "balance": 2
                },
                {
                 "name": "SUNDAE FIBRE STRAP WATCH",
                 "balance": 2
                },
                {
                 "name": "SUNDAE GENTS ROUND DIAL LEATHER STRAP WATCH",
                 "balance": 6
                },
                {
                 "name": "SUNDAE GENTS ROUND DIAL METAL STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "SUNDAE GENTS SQUARE DIAL LEATHER STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "SUNDAE GENTS SQUARE DIAL METAL STRAP WATCH",
                 "balance": 2
                },
                {
                 "name": "SUNDAE LADIES LEATHER STRAP WATCH",
                 "balance": 2
                },
                {
                 "name": "SUNDAE LADIES METAL STRAP WATCH",
                 "balance": 8
                },
                {
                 "name": "SUNGLASSES",
                 "balance": 948
                },
                {
                 "name": "SUNSHINE METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "SUNSHINE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "SUOFIUDA GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "SUPER RICH INDIAN TR",
                 "balance": 8
                },
                {
                 "name": "SUPER SLIM FIBRE FRAME",
                 "balance": 2
                },
                {
                 "name": "SUPERB FASHION TR FRAME",
                 "balance": 4
                },
                {
                 "name": "SUPRA FRAME",
                 "balance": 24
                },
                {
                 "name": "SURE SHOT LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "SUSAN TR FRAME",
                 "balance": 3
                },
                {
                 "name": "SVAROWSKI LADIES METAL STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "SWAROVSKI LADIES WATCH",
                 "balance": 28
                },
                {
                 "name": "SWAROVSKI TR FRAME",
                 "balance": 1
                },
                {
                 "name": "SWEET TR FRAME",
                 "balance": 8
                },
                {
                 "name": "SWITCH HIT METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "T&G GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "T&G GENTS WATCH",
                 "balance": 13
                },
                {
                 "name": "T&G SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "T&G TR FRME",
                 "balance": 1
                },
                {
                 "name": "T&H GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "T&H LADIES METAL STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "T&H TR FRAME",
                 "balance": 1
                },
                {
                 "name": "T&T GENTS STEEL WATCH",
                 "balance": 4
                },
                {
                 "name": "T&T GENTS WATCH",
                 "balance": 7
                },
                {
                 "name": "T&T LADIES METAL STRAP WATCH",
                 "balance": 9
                },
                {
                 "name": "T&T SUPRA FRAME",
                 "balance": 4
                },
                {
                 "name": "T&T TR FRAME",
                 "balance": 48
                },
                {
                 "name": "T-FOS GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "T100 PLUS SMART WATCH",
                 "balance": 1
                },
                {
                 "name": "TAG HILLS TR FRAME",
                 "balance": 2
                },
                {
                 "name": "TAGEYE HYBRID FRAME",
                 "balance": 1
                },
                {
                 "name": "TAGEYE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "TAGEYE TITANIUM FRAME",
                 "balance": 6
                },
                {
                 "name": "TAGEYE TR FRAME",
                 "balance": 4
                },
                {
                 "name": "TAGLINE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "TAIZIBAO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "TAKE METAL FULL FRAME",
                 "balance": 3
                },
                {
                 "name": "TAKING METAL FULL FRAME",
                 "balance": 2
                },
                {
                 "name": "TALE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "TALENT SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "TC-AH TR FRAME",
                 "balance": 7
                },
                {
                 "name": "TEAMANGER METAL FRAME",
                 "balance": 4
                },
                {
                 "name": "TEESORT GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "TELLO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "TEMPO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "TENPUBIKI TR FRAME",
                 "balance": 2
                },
                {
                 "name": "TENWEI GENTS WATCH",
                 "balance": 3
                },
                {
                 "name": "TERMINATOR TR FRAME",
                 "balance": 2
                },
                {
                 "name": "TEXAS TACO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "THE GALLERY TR FRAME",
                 "balance": 16
                },
                {
                 "name": "THEO TQ1106 WALL CLOCK",
                 "balance": 1
                },
                {
                 "name": "THEO TQ2101 WALLCLOCK",
                 "balance": 3
                },
                {
                 "name": "THEO TQ2102 WALLCLOCK",
                 "balance": 3
                },
                {
                 "name": "THEO TQ2111 WALLCLOCK",
                 "balance": 5
                },
                {
                 "name": "THEO TQ2113 WALLCLOCK",
                 "balance": 5
                },
                {
                 "name": "THEO TQ7011 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "THEO TQ9018 WALLCLOCK",
                 "balance": 1
                },
                {
                 "name": "THIN CRUSH TR FRAME",
                 "balance": 2
                },
                {
                 "name": "TIANZI METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "TIFA BOYS WATCH",
                 "balance": 3
                },
                {
                 "name": "TIFA GENTS BLACKMETAL WATCH",
                 "balance": 1
                },
                {
                 "name": "TIFA GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "TIME2 GENTS WATCH",
                 "balance": 16
                },
                {
                 "name": "TIMETRACK GENTS BLACKMETAL WATCH",
                 "balance": 4
                },
                {
                 "name": "TIMETRACK GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "TIMETRACK GENTS WATCH",
                 "balance": 45
                },
                {
                 "name": "TIMETRACK LADIES STEEL WATCH",
                 "balance": 14
                },
                {
                 "name": "TIMETRACK LADIES WATCH",
                 "balance": 26
                },
                {
                 "name": "TINGS TR FRAME",
                 "balance": 5
                },
                {
                 "name": "TITAMO TR FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 0001 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 0002 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 0004 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 0013 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 0022 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 0043 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1002 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1003 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1005 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1014 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1015 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1016 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1017 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1041 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1046 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1050 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1051 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1055 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1056 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1059 FRAME",
                 "balance": 4
                },
                {
                 "name": "TITAN 1062 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1063 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1064 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1072 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1073 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1079 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1083 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1090 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1094 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1097 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1105 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1110 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1111 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1113 FRAME",
                 "balance": 4
                },
                {
                 "name": "TITAN 1118 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1122 FRAME",
                 "balance": 5
                },
                {
                 "name": "TITAN 1130 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1135 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1136 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1139 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1151 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1158 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1160 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1187 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1190 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1199 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1201 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1207 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1208 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1361 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1362 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1391 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1399 FRAME",
                 "balance": 2
                },
                {
                 "name": "TITAN 1404 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1409 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1421 FRAME",
                 "balance": 3
                },
                {
                 "name": "TITAN 1423 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 1443 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2171 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2258 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2270 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2313 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2323 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2326 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2413 FRAME",
                 "balance": 1
                },
                {
                 "name": "TITAN 2422 FRAME",
                 "balance": 1
                },
                {
                 "name": "TODGAR ACETATE FRAME",
                 "balance": 1
                },
                {
                 "name": "TOM BLACK METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "TOM BLACK SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "TOM FORD METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "TOM HARDY METAL FRAME",
                 "balance": 7
                },
                {
                 "name": "TOM HARDY TR FRAME",
                 "balance": 9
                },
                {
                 "name": "TOM HERALDS TR FRAME",
                 "balance": 1
                },
                {
                 "name": "TOM HILL FIBRE FRAME",
                 "balance": 75
                },
                {
                 "name": "TOM HILL METAL FRAME",
                 "balance": 3
                },
                {
                 "name": "TOM RISE TR FRAME",
                 "balance": 5
                },
                {
                 "name": "TOM&JERRY TR FRAME",
                 "balance": 1
                },
                {
                 "name": "TOMBLUE SUPRA FRAME",
                 "balance": 13
                },
                {
                 "name": "TOMFORD TR FRAME",
                 "balance": 2
                },
                {
                 "name": "TOMHARDY ACETATE FRAME",
                 "balance": 2
                },
                {
                 "name": "TOMHARDY SUPRA FRAME",
                 "balance": 6
                },
                {
                 "name": "TOMI LADIES WATCH",
                 "balance": 1
                },
                {
                 "name": "TOMI-TORMI BOYS WATCH",
                 "balance": 18
                },
                {
                 "name": "TOMMY TR FRAME",
                 "balance": 2
                },
                {
                 "name": "TOMMY-BROWN TR FRAME",
                 "balance": 3
                },
                {
                 "name": "TON METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "TORMENT TR FRAME",
                 "balance": 2
                },
                {
                 "name": "TOROM GENTS WATCH",
                 "balance": 4
                },
                {
                 "name": "TOSSORT GENTS WATCH",
                 "balance": 9
                },
                {
                 "name": "TOUCHME INDIAN TR FRAME",
                 "balance": 4
                },
                {
                 "name": "TR FRAME",
                 "balance": 164
                },
                {
                 "name": "TWIN BROTHERS KIDS FRAME",
                 "balance": 12
                },
                {
                 "name": "TYCOON METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "UDREAM LADIES WATCH",
                 "balance": 18
                },
                {
                 "name": "ULTEM SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "ULYSSE NARDIN GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "UNIVERSAL ACETATE FRAME",
                 "balance": 32
                },
                {
                 "name": "UNIVERSAL METAL FRAME",
                 "balance": 2
                },
                {
                 "name": "UNIVERSAL SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "USANER METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "USE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "USS KIDS WATCH",
                 "balance": 40
                },
                {
                 "name": "V&C LADIES METAL STRAP WATCH",
                 "balance": 1
                },
                {
                 "name": "V&C LADIES WATCH",
                 "balance": 2
                },
                {
                 "name": "V&C METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "V&C TR FRAME",
                 "balance": 2
                },
                {
                 "name": "V4 GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "V7 GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "V9 GENTS STEEL WATCH",
                 "balance": 5
                },
                {
                 "name": "V9 GENTS WATCH",
                 "balance": 12
                },
                {
                 "name": "VACHERON CONSTANTIN COUPLE WATCH",
                 "balance": 2
                },
                {
                 "name": "VACHERONCONSTANTIN GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "VALENTINO RUDY TR FRAME",
                 "balance": 2
                },
                {
                 "name": "VANDENBERG METAL FRAME",
                 "balance": 1
                },
                {
                 "name": "VARSITY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "VELOCITY ANTI BLUERAY SPECTS",
                 "balance": 1
                },
                {
                 "name": "VELOCITY B2 SUNGLASSES",
                 "balance": 57
                },
                {
                 "name": "VELOCITY METAL FRAME",
                 "balance": 16
                },
                {
                 "name": "VELOCITY RIMLESS FRAME",
                 "balance": 15
                },
                {
                 "name": "VELOCITY SUNGLASSES",
                 "balance": 128
                },
                {
                 "name": "VELOCITY SUNGLASSES LUXE-DE-PARIS",
                 "balance": 9
                },
                {
                 "name": "VELOCITY SUPRA FRAME",
                 "balance": 29
                },
                {
                 "name": "VELOCITY TR FRAME",
                 "balance": 67
                },
                {
                 "name": "VENDOR EXCLUSIVE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "VENDOR EXCLUSIVE TR FRAME",
                 "balance": 2
                },
                {
                 "name": "VERSAC GENTS WATCH",
                 "balance": 5
                },
                {
                 "name": "VICEROY SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "VIDEO TR FRAME",
                 "balance": 10
                },
                {
                 "name": "VIKSE LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "VILLS TR FRAME",
                 "balance": 2
                },
                {
                 "name": "VINCENT CHASE ACETATE FRAME",
                 "balance": 13
                },
                {
                 "name": "VIRGIN TR FRAME",
                 "balance": 5
                },
                {
                 "name": "VISION X TR FRAME",
                 "balance": 5
                },
                {
                 "name": "VOGCITY TR FRAME",
                 "balance": 10
                },
                {
                 "name": "VOGUE FIBRE FRAME",
                 "balance": 1
                },
                {
                 "name": "VOLCANO POLARISED SUNGLASSES",
                 "balance": 18
                },
                {
                 "name": "VS LADIES STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "WAGOI SUPRA FRAME",
                 "balance": 3
                },
                {
                 "name": "WAMDA GENTS STEEL WATCH",
                 "balance": 8
                },
                {
                 "name": "WAMDA GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "WASGINGTON TR FRAME",
                 "balance": 1
                },
                {
                 "name": "WATCH 7 LOGO",
                 "balance": 1
                },
                {
                 "name": "WEALTHY METAL FULL FRAME",
                 "balance": 4
                },
                {
                 "name": "WECREAT SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "WELFARE SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "WENLONG LADIES BRACELET",
                 "balance": 1
                },
                {
                 "name": "WILD IND TR FRAME",
                 "balance": 3
                },
                {
                 "name": "WINOSFU SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "WISH SUPRA FRAME",
                 "balance": 2
                },
                {
                 "name": "WONDER DELUXE TR FRAME",
                 "balance": 26
                },
                {
                 "name": "WONDER DURO TR FRAME",
                 "balance": 23
                },
                {
                 "name": "WONDER HYBRID FRAME",
                 "balance": 16
                },
                {
                 "name": "WONDER MAX METAL FRAME",
                 "balance": 14
                },
                {
                 "name": "WONDER METAL FRAME",
                 "balance": 9
                },
                {
                 "name": "WONDER PRO TR FRAME",
                 "balance": 6
                },
                {
                 "name": "WONDER ULTRA FRAME",
                 "balance": 33
                },
                {
                 "name": "WONDFUL TR FRAME",
                 "balance": 5
                },
                {
                 "name": "WOOD AND GLASS WALLCLOCK",
                 "balance": 4
                },
                {
                 "name": "WOODY GENTS WATCH",
                 "balance": 1
                },
                {
                 "name": "WOVE GENTS MAGNET BELT WATCH",
                 "balance": 2
                },
                {
                 "name": "WRINBOILN METAL FULL FRAME",
                 "balance": 3
                },
                {
                 "name": "X-EYE TR FRAME",
                 "balance": 1
                },
                {
                 "name": "X-TECH TR FRAME",
                 "balance": 2
                },
                {
                 "name": "XENLEX GENTS STEEL WATCH",
                 "balance": 1
                },
                {
                 "name": "XENLEX GENTS WATCH",
                 "balance": 2
                },
                {
                 "name": "XENLEX LADIES WATCH",
                 "balance": 35
                },
                {
                 "name": "XIANGSHI SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "XINGYUN SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "XMAN METAL FULL FRAME",
                 "balance": 1
                },
                {
                 "name": "XOVEE GOLD TR FRAME",
                 "balance": 1
                },
                {
                 "name": "XROTAEI SUPRA FRAME",
                 "balance": 1
                },
                {
                 "name": "YARIS BOYS WATCH",
                 "balance": 2
                },
                {
                 "name": "YVEL LADIES BRACELET",
                 "balance": 12
                },
                {
                 "name": "YYRESP TR FRAME",
                 "balance": 2
                },
                {
                 "name": "ZEBLAZE SMARTWATCH",
                 "balance": 1
                },
                {
                 "name": "ZED+ TR FRAME",
                 "balance": 16
                },
                {
                 "name": "ZENSTAR TR FRAME",
                 "balance": 1
                },
                {
                 "name": "ZIVO TR FRAME",
                 "balance": 1
                }
               ]

            let Count = 0;

            for (const item of datum) {
             const check  = await connection.query(`select * from  PurchaseDetail where CompanyID = 96 and Quantity = ${item.balance} and ProductName =  'PRODUCT/${item.name}'`)
             if(!check.length){
               console.log(item);
               Count = Count + item.balance
               console.log(Count,'Count');
             }
            }
               return
            // response.result = data;
            // response.success = "Success";

            // await connection.query("COMMIT");
            // return response;
        } catch (err) {
            await connection.query("ROLLBACK");
            console.log("ROLLBACK at querySignUp", err);
            throw err;
        } finally {
            await connection.release();
        }
    }


}
module.exports = companyService;